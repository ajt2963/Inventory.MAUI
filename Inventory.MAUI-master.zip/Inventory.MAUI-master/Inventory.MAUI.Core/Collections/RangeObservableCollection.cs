using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;

namespace Inventory.MAUI.Core.Collections;

/// <summary>
/// An <see cref="ObservableCollection{T}"/> that supports batch operations
/// via <see cref="ReplaceRange"/> to avoid firing individual
/// <see cref="NotifyCollectionChangedAction.Add"/> events per item.
/// </summary>
public sealed class RangeObservableCollection<T> : ObservableCollection<T>
{
    private bool _suppressNotifications;

    /// <summary>
    /// Clears the collection and adds the supplied items in a single operation,
    /// raising a single <see cref="NotifyCollectionChangedAction.Reset"/> notification.
    /// </summary>
    public void ReplaceRange(IEnumerable<T> items)
    {
        _suppressNotifications = true;
        try
        {
            Items.Clear();
            foreach (var item in items)
                Items.Add(item);
        }
        finally
        {
            _suppressNotifications = false;
        }

        OnPropertyChanged(new PropertyChangedEventArgs("Count"));
        OnPropertyChanged(new PropertyChangedEventArgs("Item[]"));
        OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
    }

    protected override void OnCollectionChanged(NotifyCollectionChangedEventArgs e)
    {
        if (!_suppressNotifications)
            base.OnCollectionChanged(e);
    }

    protected override void OnPropertyChanged(PropertyChangedEventArgs e)
    {
        if (!_suppressNotifications)
            base.OnPropertyChanged(e);
    }
}
