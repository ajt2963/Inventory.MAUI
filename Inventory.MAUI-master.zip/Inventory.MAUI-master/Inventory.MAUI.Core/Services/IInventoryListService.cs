using Inventory.MAUI.Core.Models;

namespace Inventory.MAUI.Core.Services;

public interface IInventoryListService
{
    Task<IReadOnlyList<InventoryList>> GetInventoryListAsync(string? search);

    IAsyncEnumerable<InventoryList> StreamInventoryListAsync(string? search);

    Task<IReadOnlyList<InventoryList>> GetInventoryListPageAsync(string? search, int skip, int take);

    Task<int> GetInventoryListCountAsync(string? search);

    Task<InventoryList?> GetByIdAsync(int inventoryId);

    Task<InventoryList?> GetLastAsync(string? search);

    Task<IReadOnlyList<InventoryList>> GetLastPageAsync(string? search, int take);

    // Dashboard aggregate queries
    Task<List<(string Name, int Count)>> GetCountByStatusAsync();
    Task<List<(string Name, int Count)>> GetCountByLocationAsync();
    Task<List<(string Location, string Name, int Count)>> GetCountByFieldPerLocationAsync(string fieldName);

    Task<IReadOnlyList<InventoryList>> GetByLocationAsync(string clliCode);
}
