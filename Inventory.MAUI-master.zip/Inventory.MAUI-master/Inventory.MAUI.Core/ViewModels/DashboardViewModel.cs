using System.Collections.ObjectModel;
using Inventory.MAUI.Core.Models;
using Inventory.MAUI.Core.Services;

namespace Inventory.MAUI.Core.ViewModels;

public sealed class DashboardViewModel : ViewModelBase
{
    private readonly IInventoryListService _inventoryListService;

    private int _totalInventoryCount;
    private bool _isBusy;

    private List<StatusStat> _statusStats = [];
    private List<LocationStat> _locationStats = [];
    private List<LocationGroupStat> _ownerByLocation = [];
    private List<LocationGroupStat> _categoryByLocation = [];
    private List<LocationGroupStat> _typeByLocation = [];
    private List<LocationGroupStat> _manufacturerByLocation = [];

    private string? _selectedLocation;
    private ObservableCollection<InventoryList> _locationItems = [];

    public DashboardViewModel(IInventoryListService inventoryListService)
    {
        _inventoryListService = inventoryListService;
        RefreshCommand = new(async () => await LoadStatisticsAsync());
        LocationDetailCommand = new AsyncCommand<string>(async (clli) => await LoadLocationItemsAsync(clli));
    }

    public int TotalInventoryCount
    {
        get => _totalInventoryCount;
        private set => SetProperty(ref _totalInventoryCount, value);
    }

    public bool IsBusy
    {
        get => _isBusy;
        private set => SetProperty(ref _isBusy, value);
    }

    public List<StatusStat> StatusStats
    {
        get => _statusStats;
        private set => SetProperty(ref _statusStats, value);
    }

    public List<LocationStat> LocationStats
    {
        get => _locationStats;
        private set => SetProperty(ref _locationStats, value);
    }

    public List<LocationGroupStat> OwnerByLocation
    {
        get => _ownerByLocation;
        private set => SetProperty(ref _ownerByLocation, value);
    }

    public List<LocationGroupStat> CategoryByLocation
    {
        get => _categoryByLocation;
        private set => SetProperty(ref _categoryByLocation, value);
    }

    public List<LocationGroupStat> TypeByLocation
    {
        get => _typeByLocation;
        private set => SetProperty(ref _typeByLocation, value);
    }

    public List<LocationGroupStat> ManufacturerByLocation
    {
        get => _manufacturerByLocation;
        private set => SetProperty(ref _manufacturerByLocation, value);
    }

    public string? SelectedLocation
    {
        get => _selectedLocation;
        private set => SetProperty(ref _selectedLocation, value);
    }

    public ObservableCollection<InventoryList> LocationItems
    {
        get => _locationItems;
        private set => SetProperty(ref _locationItems, value);
    }

    public bool HasLocationItems => SelectedLocation is not null;

    public AsyncCommand RefreshCommand { get; }
    public AsyncCommand<string> LocationDetailCommand { get; }

    public async Task InitializeAsync()
    {
        if (TotalInventoryCount > 0)
            return;

        await LoadStatisticsAsync();
    }

    private async Task LoadStatisticsAsync()
    {
        try
        {
            IsBusy = true;
            await Task.Yield();

            // All queries run as SQL GROUP BY � no full-table load.
            TotalInventoryCount = await _inventoryListService.GetInventoryListCountAsync(null);

            StatusStats = (await _inventoryListService.GetCountByStatusAsync())
                .Select(x => new StatusStat(x.Name, x.Count))
                .ToList();

            LocationStats = (await _inventoryListService.GetCountByLocationAsync())
                .Select(x => new LocationStat(x.Name, x.Count))
                .ToList();

            OwnerByLocation = BuildLocationGroup(
                await _inventoryListService.GetCountByFieldPerLocationAsync("Owner"));

            CategoryByLocation = BuildLocationGroup(
                await _inventoryListService.GetCountByFieldPerLocationAsync("CatName"));

            TypeByLocation = BuildLocationGroup(
                await _inventoryListService.GetCountByFieldPerLocationAsync("Type"));

            ManufacturerByLocation = BuildLocationGroup(
                await _inventoryListService.GetCountByFieldPerLocationAsync("CompanyName"));
        }
        finally
        {
            IsBusy = false;
        }
    }

    public async Task LoadLocationItemsAsync(string clliCode)
    {
        if (string.IsNullOrWhiteSpace(clliCode))
            return;

        try
        {
            IsBusy = true;
            await Task.Yield();

            SelectedLocation = clliCode;
            OnPropertyChanged(nameof(HasLocationItems));

            var items = await _inventoryListService.GetByLocationAsync(clliCode);
            LocationItems = new ObservableCollection<InventoryList>(items);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private static List<LocationGroupStat> BuildLocationGroup(
        List<(string Location, string Name, int Count)> data)
    {
        return data
            .GroupBy(x => x.Location)
            .OrderBy(g => g.Key)
            .Select(g => new LocationGroupStat(
                g.Key,
                g.Select(x => new NameCountStat(x.Name, x.Count))
                 .OrderByDescending(x => x.Count)
                 .ToList()))
            .ToList();
    }
}

public record StatusStat(string Status, int Count);
public record LocationStat(string Location, int Count);
public record NameCountStat(string Name, int Count);

/// <summary>
/// A group of NameCountStat items keyed by Location.
/// Extends List so that CollectionView.IsGrouped can enumerate the items directly.
/// </summary>
public class LocationGroupStat : List<NameCountStat>
{
    public string Location { get; }

    public LocationGroupStat(string location, List<NameCountStat> items) : base(items)
    {
        Location = location;
    }
}
