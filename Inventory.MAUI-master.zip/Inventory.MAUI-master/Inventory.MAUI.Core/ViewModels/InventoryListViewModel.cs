using System.Collections.ObjectModel;
using System.ComponentModel;
using Inventory.MAUI.Core.Models;
using Inventory.MAUI.Core.Services;

namespace Inventory.MAUI.Core.ViewModels;

public sealed class InventoryListViewModel : ViewModelBase
{
#if ANDROID
    private const int DefaultPageSize = 50;
#else
    private const int DefaultPageSize = 250;
#endif

    private readonly IInventoryListService _inventoryListService;

    private ObservableCollection<InventoryListRow> _rows = new();
    private InventoryListRow? _selectedRow;
    private InventoryList? _selected;
    private string? _currentSearch;
    private string _searchText = string.Empty;
    private string _statusText = string.Empty;
    private string _selectedPositionText = string.Empty;
    private bool _isBusy;
    private double _loadProgress;

    private int _totalCount;
    private int _loadedCount;
    private int _pageSize = DefaultPageSize;

    private readonly SemaphoreSlim _refreshGate = new(1, 1);

    private int _selectedAbsoluteIndex = -1;
    private int _windowStart;

    private bool _windowedMode;

    private long _loadSeq;

    public InventoryListViewModel(IInventoryListService inventoryListService)
    {
        _inventoryListService = inventoryListService;

        SearchCommand = new(async () => await LoadAsync(SearchText));
        ClearCommand = new(async () =>
        {
            SearchText = string.Empty;
            await LoadAsync();
        });

        MoveFirstCommand = new(() => MoveToIndex(0));
        MovePreviousCommand = new(() => MoveToIndex(Math.Max(0, SelectedRowIndex - 1)));
        MoveNextCommand = new(() => MoveToIndex(Math.Min(Rows.Count - 1, SelectedRowIndex + 1)));
        MoveLastCommand = new(async () => await MoveToLastAsync());

        LoadMoreCommand = new(async () => await LoadMoreAsync(), () => CanLoadMore && !IsBusy);
    }

    public ObservableCollection<InventoryListRow> Rows
    {
        get => _rows;
        private set => SetProperty(ref _rows, value);
    }

    public InventoryListRow? SelectedRow
    {
        get => _selectedRow;
        set
        {
            var previous = _selectedRow;
            if (SetProperty(ref _selectedRow, value))
            {
                if (previous is not null) previous.IsSelected = false;
                if (value is not null) value.IsSelected = true;

                Selected = value?.Item;

                if (value is not null)
                {
                    var localIdx = Rows.IndexOf(value);
                    if (localIdx >= 0)
                        SelectedAbsoluteIndex = WindowStart + localIdx;
                    else
                        SelectedAbsoluteIndex = -1;
                }
                else
                {
                    SelectedAbsoluteIndex = -1;
                }

                UpdateStatusText();
            }
        }
    }

    public int SelectedRowIndex => SelectedRow is null ? -1 : Rows.IndexOf(SelectedRow);

    public int SelectedAbsoluteIndex
    {
        get => _selectedAbsoluteIndex;
        private set
        {
            if (SetProperty(ref _selectedAbsoluteIndex, value))
                UpdateStatusText();
        }
    }

    public InventoryList? Selected
    {
        get => _selected;
        private set
        {
            if (SetProperty(ref _selected, value))
                UpdateStatusText();
        }
    }

    public string StatusText
    {
        get => _statusText;
        private set => SetProperty(ref _statusText, value);
    }

    public string SelectedPositionText
    {
        get => _selectedPositionText;
        private set => SetProperty(ref _selectedPositionText, value);
    }

    public string SearchText
    {
        get => _searchText;
        set => SetProperty(ref _searchText, value);
    }

    public bool IsBusy
    {
        get => _isBusy;
        private set
        {
            if (SetProperty(ref _isBusy, value))
                LoadMoreCommand.RaiseCanExecuteChanged();
        }
    }

    public double LoadProgress
    {
        get => _loadProgress;
        private set => SetProperty(ref _loadProgress, value);
    }

    public int TotalCount
    {
        get => _totalCount;
        private set
        {
            if (SetProperty(ref _totalCount, value))
                OnPropertyChanged(nameof(CanLoadMore));
        }
    }

    public int LoadedCount
    {
        get => _loadedCount;
        private set
        {
            if (SetProperty(ref _loadedCount, value))
                OnPropertyChanged(nameof(CanLoadMore));
        }
    }

    public bool CanLoadMore => LoadedCount < TotalCount;

    public int WindowStart
    {
        get => _windowStart;
        private set => SetProperty(ref _windowStart, value);
    }

    public bool IsWindowedMode
    {
        get => _windowedMode;
        private set => SetProperty(ref _windowedMode, value);
    }

    // UI-agnostic commands (usable by MAUI and Blazor)
    public AsyncCommand SearchCommand { get; }
    public AsyncCommand ClearCommand { get; }
    public RelayCommand MoveFirstCommand { get; }
    public RelayCommand MovePreviousCommand { get; }
    public RelayCommand MoveNextCommand { get; }
    public RelayCommand MoveLastCommand { get; }
    public AsyncCommand LoadMoreCommand { get; }

    public Action<string>? DebugLog { get; set; }

    private void Log(string message)
    {
        DebugLog?.Invoke($"{DateTime.Now:HH:mm:ss.fff} [InventoryListVM] seq={_loadSeq} {message}");
    }

    private void SetBusy(bool value) => IsBusy = value;

    private void SetProgress(double value) => LoadProgress = Math.Clamp(value, 0, 100);

    public async Task InitializeAsync()
    {
        // Skip if already loaded � prevents redundant DB round-trips when the VM
        // is reused or when multiple views initialize against the same instance.
        if (Rows.Count > 0 || TotalCount > 0)
            return;

        await LoadAsync();
    }

    public async Task LoadAsync(string? search = null)
    {
        var seq = NextLoadSeq();
        Log($"LoadAsync(start) search='{search}' currentSearch(before)='{_currentSearch}'");

        try
        {
            SetBusy(true);
            SetProgress(1);
            await Task.Yield();

            _currentSearch = string.IsNullOrWhiteSpace(search) ? null : search.Trim();
            SearchText = _currentSearch ?? string.Empty;

            StatusText = string.Empty;
            SelectedPositionText = string.Empty;

            Rows = new ObservableCollection<InventoryListRow>();
            SelectedRow = null;

            WindowStart = 0;
            IsWindowedMode = false;

            SetProgress(5);
            await Task.Yield();

            TotalCount = await _inventoryListService.GetInventoryListCountAsync(_currentSearch);
            LoadedCount = 0;
            Log($"LoadAsync(count) TotalCount={TotalCount}");

            if (TotalCount == 0)
            {
                SetProgress(100);
                UpdateStatusText();
                Log("LoadAsync(done) TotalCount=0");
                return;
            }

            if (seq != _loadSeq)
            {
                Log("LoadAsync(cancelled) stale seq");
                return;
            }

            await LoadFirstPageAsync(selectFirst: true, initialLoad: true);

            SetProgress(100);
            Log("LoadAsync(done)");
        }
        finally
        {
            SetBusy(false);
            LoadMoreCommand.RaiseCanExecuteChanged();
        }
    }

    private async Task LoadMoreAsync(bool initialLoad = false)
    {
        var seq = NextLoadSeq();
        Log($"LoadMoreAsync(start) initialLoad={initialLoad} WindowStart={WindowStart} LoadedCount={LoadedCount} Rows.Count={Rows.Count} TotalCount={TotalCount}");

        if (IsWindowedMode)
        {
            Log("LoadMoreAsync(skip) IsWindowedMode");
            return;
        }

        if (IsBusy && !initialLoad)
        {
            Log("LoadMoreAsync(skip) IsBusy");
            return;
        }

        if (!CanLoadMore)
        {
            Log("LoadMoreAsync(skip) !CanLoadMore");
            return;
        }

        await _refreshGate.WaitAsync();
        try
        {
            if (!initialLoad)
                SetBusy(true);

            if (WindowStart != 0 || LoadedCount != Rows.Count)
            {
                Log($"LoadMoreAsync(skip) append precondition failed WindowStart={WindowStart} LoadedCount={LoadedCount} Rows.Count={Rows.Count}");
                return;
            }

            var skip = LoadedCount;
            var take = _pageSize;
            Log($"LoadMoreAsync(fetch) skip={skip} take={take}");

            var page = await _inventoryListService.GetInventoryListPageAsync(_currentSearch, skip, take);

            if (seq != _loadSeq)
            {
                Log("LoadMoreAsync(cancelled) stale seq");
                return;
            }

            Log($"LoadMoreAsync(apply) fetched={page.Count} firstId={(page.FirstOrDefault()?.InventoryID?.ToString() ?? "-")} lastId={(page.LastOrDefault()?.InventoryID?.ToString() ?? "-")}");

            var startIndex = Rows.Count;
            for (var i = 0; i < page.Count; i++)
            {
                var absoluteIndex = startIndex + i;
                Rows.Add(new InventoryListRow(page[i], isAltRow: absoluteIndex % 2 == 1));
            }

            LoadedCount += page.Count;

            if (SelectedRow is null && Rows.Count > 0)
                SelectedRow = Rows[0];

            UpdateStatusText();
        }
        finally
        {
            if (!initialLoad)
                SetBusy(false);

            _refreshGate.Release();
            LoadMoreCommand.RaiseCanExecuteChanged();
        }
    }

    private async Task LoadWindowAsync(int skip, bool selectIndexFromEnd, bool selectFirst = false, bool initialLoad = false)
    {
        var seq = NextLoadSeq();
        Log($"LoadWindowAsync(start) skip={skip} selectIndexFromEnd={selectIndexFromEnd} selectFirst={selectFirst} initialLoad={initialLoad}");

        if (IsBusy && !initialLoad)
        {
            Log("LoadWindowAsync(skip) IsBusy");
            return;
        }

        skip = Math.Max(0, skip);

        await _refreshGate.WaitAsync();
        try
        {
            if (!initialLoad)
                SetBusy(true);

            Log($"LoadWindowAsync(fetch) skip={skip} take={_pageSize}");
            var page = await _inventoryListService.GetInventoryListPageAsync(_currentSearch, skip, _pageSize);

            if (seq != _loadSeq)
            {
                Log("LoadWindowAsync(cancelled) stale seq");
                return;
            }

            Log($"LoadWindowAsync(apply) fetched={page.Count} firstId={(page.FirstOrDefault()?.InventoryID?.ToString() ?? "-")} lastId={(page.LastOrDefault()?.InventoryID?.ToString() ?? "-")}");

            Rows = new ObservableCollection<InventoryListRow>();
            for (var i = 0; i < page.Count; i++)
            {
                var absoluteIndex = skip + i;
                Rows.Add(new InventoryListRow(page[i], isAltRow: absoluteIndex % 2 == 1));
            }

            WindowStart = skip;
            IsWindowedMode = skip > 0;

            if (WindowStart == 0 && Rows.Count >= LoadedCount)
                LoadedCount = Rows.Count;
            else
                LoadedCount = TotalCount;

            if (Rows.Count > 0)
            {
                if (selectFirst)
                    SelectedRow = Rows[0];
                else
                    SelectedRow = selectIndexFromEnd ? Rows[^1] : Rows[0];
            }
            else
            {
                SelectedRow = null;
            }

            UpdateStatusText();
        }
        finally
        {
            if (!initialLoad)
                SetBusy(false);

            _refreshGate.Release();
            LoadMoreCommand.RaiseCanExecuteChanged();
        }
    }

    public async Task MoveToLastAsync()
    {
        var seq = NextLoadSeq();
        Log("MoveToLastAsync(start)");

        await _refreshGate.WaitAsync();
        try
        {
            SetBusy(true);

            TotalCount = await _inventoryListService.GetInventoryListCountAsync(_currentSearch);
            Log($"MoveToLastAsync(count) TotalCount={TotalCount}");

            if (TotalCount <= 0)
                return;

            var page = await _inventoryListService.GetLastPageAsync(_currentSearch, _pageSize);
            Log($"MoveToLastAsync(fetch) fetched={page.Count} firstId={(page.FirstOrDefault()?.InventoryID?.ToString() ?? "-")} lastId={(page.LastOrDefault()?.InventoryID?.ToString() ?? "-")}");

            if (page.Count == 0)
                return;

            if (seq != _loadSeq)
            {
                Log("MoveToLastAsync(cancelled) stale seq");
                return;
            }

            // WindowStart is only used for status/absolute positioning; with keyset paging we don't have a reliable skip.
            // But we *do* know we're at the end of the filtered set.
            WindowStart = Math.Max(0, TotalCount - page.Count);
            IsWindowedMode = WindowStart > 0;
            LoadedCount = TotalCount;

            Rows = new ObservableCollection<InventoryListRow>();
            for (var i = 0; i < page.Count; i++)
            {
                Rows.Add(new InventoryListRow(page[i], isAltRow: (WindowStart + i) % 2 == 1));
            }

            SelectedRow = Rows[^1];

            // Make status deterministic: if we are selecting the last record, its absolute index is TotalCount-1.
            SelectedAbsoluteIndex = TotalCount - 1;

            UpdateStatusText();
            Log($"MoveToLastAsync(done) WindowStart={WindowStart} Rows.Count={Rows.Count} SelectedAbs={SelectedAbsoluteIndex}");
        }
        finally
        {
            SetBusy(false);
            _refreshGate.Release();
            LoadMoreCommand.RaiseCanExecuteChanged();
        }
    }

    private void UpdateStatusText()
    {
        var totalLoaded = Rows.Count;

        if (TotalCount == 0)
        {
            StatusText = string.IsNullOrWhiteSpace(_currentSearch) ? "No records" : $"No records for: {_currentSearch}";
            SelectedPositionText = string.Empty;
            return;
        }

        StatusText = string.IsNullOrWhiteSpace(_currentSearch)
            ? $"Loaded {totalLoaded} of {TotalCount}"
            : $"Search: {_currentSearch} (Loaded {totalLoaded} of {TotalCount})";

        if (SelectedAbsoluteIndex < 0)
            SelectedPositionText = string.Empty;
        else
            SelectedPositionText = $"Record {SelectedAbsoluteIndex + 1} of {TotalCount}";

        OnPropertyChanged(nameof(CanLoadMore));
    }

    private static bool MatchesSearch(InventoryList item, string? search)
    {
        if (string.IsNullOrWhiteSpace(search))
            return true;

        var s = search.Trim();
        return (item.AssetTag?.Contains(s, StringComparison.OrdinalIgnoreCase) ?? false)
            || (item.ToolKitID?.Contains(s, StringComparison.OrdinalIgnoreCase) ?? false)
            || (item.PartNumber?.Contains(s, StringComparison.OrdinalIgnoreCase) ?? false)
            || (item.SerialNumber?.Contains(s, StringComparison.OrdinalIgnoreCase) ?? false)
            || (item.Description?.Contains(s, StringComparison.OrdinalIgnoreCase) ?? false)
            || (item.CompanyName?.Contains(s, StringComparison.OrdinalIgnoreCase) ?? false)
            || (item.Type?.Contains(s, StringComparison.OrdinalIgnoreCase) ?? false)
            || (item.CatName?.Contains(s, StringComparison.OrdinalIgnoreCase) ?? false)
            || (item.Storage?.Contains(s, StringComparison.OrdinalIgnoreCase) ?? false)
            || (item.Owner?.Contains(s, StringComparison.OrdinalIgnoreCase) ?? false);
    }

    public async Task RefreshEditedRowAsync(int inventoryId)
    {
        if (inventoryId <= 0)
            return;

        await _refreshGate.WaitAsync();
        try
        {
            SetBusy(true);

            var updated = await _inventoryListService.GetByIdAsync(inventoryId);
            if (updated is null)
                return;

            var idx = -1;
            for (var i = 0; i < Rows.Count; i++)
            {
                if (Rows[i].InventoryID == inventoryId)
                {
                    idx = i;
                    break;
                }
            }

            var matches = MatchesSearch(updated, _currentSearch);

            if (!matches)
            {
                if (idx >= 0)
                {
                    Rows.RemoveAt(idx);
                    SelectedRow = Rows.Count > 0 ? Rows[Math.Clamp(idx, 0, Rows.Count - 1)] : null;
                    UpdateStatusText();
                }

                return;
            }

            if (idx < 0)
            {
                // Not in the currently loaded window; do nothing.
                return;
            }

            Rows[idx] = new InventoryListRow(updated, isAltRow: idx % 2 == 1);
            SelectedRow = Rows[idx];
        }
        finally
        {
            SetBusy(false);
            _refreshGate.Release();
        }
    }

    public async Task MoveToFirstAsync()
    {
        var seq = NextLoadSeq();
        Log($"MoveToFirstAsync(start)");

        if (IsBusy)
        {
            Log("MoveToFirstAsync(skip) IsBusy");
            return;
        }

        await LoadFirstPageAsync(selectFirst: true, initialLoad: false);

        if (seq != _loadSeq)
        {
            Log("MoveToFirstAsync(cancelled) stale seq");
            return;
        }

        Log("MoveToFirstAsync(done)");
    }

    private async Task LoadFirstPageAsync(bool selectFirst, bool initialLoad)
    {
        Log($"LoadFirstPageAsync(start) selectFirst={selectFirst} initialLoad={initialLoad}");
        await LoadWindowAsync(skip: 0, selectIndexFromEnd: false, selectFirst: selectFirst, initialLoad: initialLoad);
        Log("LoadFirstPageAsync(done)");
    }

    public void OnSelectionChanged(IReadOnlyList<object> currentSelection)
    {
        SelectedRow = currentSelection.FirstOrDefault() as InventoryListRow;
    }

    private void MoveToIndex(int index)
    {
        if (Rows.Count == 0)
            return;

        index = Math.Clamp(index, 0, Rows.Count - 1);
        SelectedRow = Rows[index];

        SelectedAbsoluteIndex = WindowStart + index;
        UpdateStatusText();
    }

    public async Task MovePreviousAsync()
    {
        if (Rows.Count == 0)
            return;

        var idx = SelectedRowIndex;
        if (idx > 0)
        {
            MoveToIndex(idx - 1);
            return;
        }

        if (WindowStart <= 0)
        {
            SelectedRow = Rows[0];
            return;
        }

        await LoadWindowAsync(Math.Max(0, WindowStart - _pageSize), selectIndexFromEnd: true);
    }

    public async Task MoveNextAsync()
    {
        if (Rows.Count == 0)
            return;

        var idx = SelectedRowIndex;
        if (idx >= 0 && idx < Rows.Count - 1)
        {
            MoveToIndex(idx + 1);
            return;
        }

        var nextWindowStart = WindowStart + Rows.Count;
        if (nextWindowStart >= TotalCount)
        {
            SelectedRow = Rows[^1];
            return;
        }

        await LoadWindowAsync(nextWindowStart, selectIndexFromEnd: false);
    }

    private long NextLoadSeq() => Interlocked.Increment(ref _loadSeq);
}

public sealed class InventoryListRow : INotifyPropertyChanged
{
    private bool _isSelected;

    public InventoryListRow(InventoryList item, bool isAltRow)
    {
        Item = item;
        IsAltRow = isAltRow;
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    public InventoryList Item { get; }
    public bool IsAltRow { get; }

    public bool IsSelected
    {
        get => _isSelected;
        set
        {
            if (_isSelected == value) return;
            _isSelected = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSelected)));
        }
    }

    public int? InventoryID => Item.InventoryID;
    public string? AssetTag => Item.AssetTag;
    public string? ToolKitID => Item.ToolKitID;
    public string? Status => Item.Status;
    public string? Owner => Item.Owner;
    public string? CatName => Item.CatName;
    public string? Type => Item.Type;
    public string? CompanyName => Item.CompanyName;
    public string? PartNumber => Item.PartNumber;
    public string? SerialNumber => Item.SerialNumber;
    public string? Description => Item.Description;
    public int? Quantity => Item.Quantity;
    public string? BatteryType => Item.BatteryType;
    public string? ClliCode => Item.ClliCode;
    public string? Storage => Item.Storage;
    public string? Divider => Item.Divider;
    public string? Section => Item.Section;
    public string? Option => Item.Option;
}
