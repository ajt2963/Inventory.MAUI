using Microsoft.EntityFrameworkCore;

namespace Inventory.MAUI.Data;

public sealed class WindowsInventoryDbContextFactory : IDbContextFactory<InventoryDbContext>
{
    private readonly DbContextOptions<InventoryDbContext> _options;

    public WindowsInventoryDbContextFactory(DbContextOptions<InventoryDbContext> options)
    {
        _options = options;
    }

    public InventoryDbContext CreateDbContext() => new(_options);
}
