using Inventory.MAUI.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Inventory.MAUI.Data;

public sealed class InventoryDbContext : DbContext
{
    public InventoryDbContext(DbContextOptions<InventoryDbContext> options) : base(options)
    {
    }

    public DbSet<InventoryItem> InventoryItem => Set<InventoryItem>();
    public DbSet<Asset> Asset => Set<Asset>();
    public DbSet<AssetOwner> AssetOwner => Set<AssetOwner>();
    public DbSet<AssetType> AssetType => Set<AssetType>();
    public DbSet<AssetUse> AssetUse => Set<AssetUse>();
    public DbSet<Inventory.MAUI.Models.Contacts> Contacts => Set<Inventory.MAUI.Models.Contacts>();
    public DbSet<CTTMInventory> CTTMInventory => Set<CTTMInventory>();
    public DbSet<Calibration> Calibration => Set<Calibration>();
    public DbSet<CalibrationSchedule> CalibrationSchedule => Set<CalibrationSchedule>();
    public DbSet<Category> Category => Set<Category>();
    public DbSet<Companies> Companies => Set<Companies>();
    public DbSet<CompanyRoles> CompanyRoles => Set<CompanyRoles>();
    public DbSet<Roles> Roles => Set<Roles>();
    public DbSet<InventoryStorage> InventoryStorage => Set<InventoryStorage>();
    public DbSet<Notes> Notes => Set<Notes>();
    public DbSet<Projects> Projects => Set<Projects>();
    public DbSet<Locations> Locations => Set<Locations>();
    public DbSet<Shipping> Shipping => Set<Shipping>();
    public DbSet<Customs> Customs => Set<Customs>();
    public DbSet<InventoryList> InventoryList => Set<InventoryList>();
    public DbSet<ReferenceValue> ReferenceValues => Set<ReferenceValue>();
    public DbSet<AppRole> AppRole => Set<AppRole>();
    public DbSet<AppUser> AppUser => Set<AppUser>();
    public DbSet<AuditLog> AuditLog => Set<AuditLog>();
    public DbSet<PasswordHistory> PasswordHistory => Set<PasswordHistory>();
    public DbSet<UserSession> UserSession => Set<UserSession>();
    public DbSet<PasswordResetToken> PasswordResetToken => Set<PasswordResetToken>();
    public DbSet<SystemSetting> SystemSettings => Set<SystemSetting>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<InventoryItem>().ToTable("InventoryItem");
        modelBuilder.Entity<InventoryItem>().HasKey(e => e.InventoryID);

        modelBuilder.Entity<InventoryItem>().HasOne(i => i.Asset).WithMany().HasForeignKey(i => i.AssetID);
        modelBuilder.Entity<InventoryItem>().HasOne(i => i.AssetType).WithMany().HasForeignKey(i => i.TypeID);
        modelBuilder.Entity<InventoryItem>().HasOne(i => i.Companies).WithMany().HasForeignKey(i => i.CompanyID);
        modelBuilder.Entity<InventoryItem>().HasOne(i => i.InventoryStorage).WithMany().HasForeignKey(i => i.StorageID);
        modelBuilder.Entity<InventoryItem>().HasOne(i => i.Locations).WithMany().HasForeignKey(i => i.LocationID);
        modelBuilder.Entity<InventoryItem>().HasOne(i => i.Category).WithMany().HasForeignKey(i => i.CatID);
        modelBuilder.Entity<InventoryItem>().HasOne(i => i.AssetOwner).WithMany().HasForeignKey(i => i.OwnerID);
        modelBuilder.Entity<InventoryItem>().HasOne(i => i.Notes).WithMany().HasForeignKey(i => i.NotesID);

        modelBuilder.Entity<Asset>()
            .HasOne(a => a.InventoryItem)
            .WithMany()
            .HasForeignKey(a => a.InventoryID);

        modelBuilder.Entity<Asset>().ToTable("Asset").HasKey(e => e.AssetID);
        modelBuilder.Entity<AssetOwner>().ToTable("AssetOwner").HasKey(e => e.OwnerID);
        modelBuilder.Entity<AssetType>().ToTable("AssetType").HasKey(e => e.TypeID);
        modelBuilder.Entity<AssetUse>().ToTable("AssetUse").HasKey(e => e.UseLogID);
        modelBuilder.Entity<Inventory.MAUI.Models.Contacts>().ToTable("Contacts").HasKey(e => e.ContactID);
        modelBuilder.Entity<CTTMInventory>().ToTable("CTTMInventory").HasKey(e => e.ToolKitID);
        modelBuilder.Entity<Calibration>().ToTable("Calibration").HasKey(e => e.CalInfoID);
        modelBuilder.Entity<Calibration>().Property(e => e.CalInfoID).ValueGeneratedOnAdd();
        modelBuilder.Entity<CalibrationSchedule>().ToTable("CalibrationSchedule").HasKey(e => e.CSID);
        modelBuilder.Entity<CalibrationSchedule>().Property(e => e.CSID).ValueGeneratedOnAdd();
        modelBuilder.Entity<Category>().ToTable("Category").HasKey(e => e.CatID);

        modelBuilder.Entity<Companies>().ToTable("Companies").HasKey(e => e.CompanyID);
        modelBuilder.Entity<Companies>().Property(e => e.CompanyName).IsRequired().HasMaxLength(100);

        modelBuilder.Entity<Customs>().ToTable("Customs").HasKey(e => e.CustomsID);

        modelBuilder.Entity<CompanyRoles>(e =>
        {
            e.ToTable("CompanyRoles");
            e.HasKey(cr => cr.CRID);
            e.Property(cr => cr.CRID).ValueGeneratedOnAdd();
            e.HasOne(cr => cr.Company)
                .WithMany(c => c.CompanyRoles)
                .HasForeignKey(cr => cr.CompanyID)
                .OnDelete(DeleteBehavior.Restrict);
            e.HasOne(cr => cr.Role)
                .WithMany()
                .HasForeignKey(cr => cr.RoleID)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Roles>().ToTable("Roles").HasKey(e => e.RoleID);
        modelBuilder.Entity<Roles>().Property(e => e.RoleName).IsRequired().HasMaxLength(100);
        modelBuilder.Entity<Roles>()
            .Property(r => r.RoleID)
            .ValueGeneratedOnAdd();

        modelBuilder.Entity<InventoryStorage>().ToTable("InventoryStorage").HasKey(e => e.StorageID);
        modelBuilder.Entity<InventoryStorage>()
            .Property(e => e.DisplayValue)
            .ValueGeneratedOnAddOrUpdate()
            .Metadata.SetBeforeSaveBehavior(PropertySaveBehavior.Ignore);
        modelBuilder.Entity<InventoryStorage>()
            .Property(e => e.DisplayValue)
            .Metadata.SetAfterSaveBehavior(PropertySaveBehavior.Ignore);

        modelBuilder.Entity<Locations>().ToTable("Locations").HasKey(e => e.LocationID);
        modelBuilder.Entity<Notes>().ToTable("Notes").HasKey(e => e.NotesID);
        modelBuilder.Entity<Projects>().ToTable("Projects").HasKey(e => e.ProjectID);

        modelBuilder.Entity<Shipping>().ToTable("Shipping").HasKey(e => e.ShippingID);
        modelBuilder.Entity<Shipping>().HasOne(e => e.AssetUse).WithMany().HasForeignKey(e => e.UseLogID);

        modelBuilder.Entity<Shipping>()
            .HasOne(s => s.ShipFromLocation)
            .WithMany()
            .HasForeignKey(s => s.ShipFromID)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Shipping>()
            .HasOne(s => s.ShipToLocation)
            .WithMany()
            .HasForeignKey(s => s.ShipToID)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<InventoryList>().HasNoKey().ToView("InventoryList");

        modelBuilder.Entity<AssetUse>()
            .HasOne(a => a.Asset)
            .WithMany()
            .HasForeignKey(a => a.AssetID);

        modelBuilder.Entity<Customs>()
            .Property(c => c.CommercialValue)
            .HasColumnType("decimal(18, 2)");

        modelBuilder.Entity<Customs>()
            .Property(c => c.PurchasePrice)
            .HasColumnType("decimal(18, 2)");

        modelBuilder.Entity<Shipping>()
            .Property(s => s.ShipCost)
            .HasColumnType("decimal(18, 2)");

        modelBuilder.Entity<ReferenceValue>()
            .HasIndex(r => new { r.Domain, r.Code })
            .IsUnique();

        modelBuilder.Entity<ReferenceValue>()
            .HasIndex(r => new { r.Domain, r.Display })
            .IsUnique();

        // AppRole / AppUser (IAM)
        modelBuilder.Entity<AppRole>().ToTable("AppRole").HasKey(e => e.RoleID);
        modelBuilder.Entity<AppRole>().Property(e => e.RoleName).IsRequired().HasMaxLength(50);

        modelBuilder.Entity<AppUser>().ToTable("AppUser").HasKey(e => e.UserID);
        modelBuilder.Entity<AppUser>().Property(e => e.ATTUID).IsRequired().HasMaxLength(100);
        modelBuilder.Entity<AppUser>().HasIndex(e => e.ATTUID).IsUnique();
        modelBuilder.Entity<AppUser>().Property(e => e.DisplayName).IsRequired().HasMaxLength(150);
        modelBuilder.Entity<AppUser>().Property(e => e.Email).HasMaxLength(200);
        modelBuilder.Entity<AppUser>().Property(e => e.PasswordHash).HasMaxLength(500);
        modelBuilder.Entity<AppUser>().Property(e => e.PasswordSalt).HasMaxLength(500);
        modelBuilder.Entity<AppUser>()
            .HasOne(u => u.Role)
            .WithMany()
            .HasForeignKey(u => u.RoleID)
            .OnDelete(DeleteBehavior.Restrict);

        // AuditLog
        modelBuilder.Entity<AuditLog>().ToTable("AuditLog").HasKey(e => e.LogID);
        modelBuilder.Entity<AuditLog>().Property(e => e.EventType).IsRequired().HasMaxLength(50);
        modelBuilder.Entity<AuditLog>().Property(e => e.ATTUID).HasMaxLength(100);
        modelBuilder.Entity<AuditLog>().Property(e => e.EntityType).HasMaxLength(100);
        modelBuilder.Entity<AuditLog>().Property(e => e.EntityID).HasMaxLength(50);
        modelBuilder.Entity<AuditLog>().Property(e => e.Details).HasMaxLength(2000);
        modelBuilder.Entity<AuditLog>().Property(e => e.Platform).HasMaxLength(50);
        modelBuilder.Entity<AuditLog>().HasIndex(e => e.TimestampUtc);
        modelBuilder.Entity<AuditLog>().HasIndex(e => e.EventType);
        modelBuilder.Entity<AuditLog>().HasIndex(e => e.UserID);
        modelBuilder.Entity<AuditLog>()
            .HasOne(a => a.User)
            .WithMany()
            .HasForeignKey(a => a.UserID)
            .OnDelete(DeleteBehavior.SetNull);

        // PasswordHistory
        modelBuilder.Entity<PasswordHistory>().ToTable("PasswordHistory").HasKey(e => e.HistoryID);
        modelBuilder.Entity<PasswordHistory>().Property(e => e.PasswordHash).IsRequired().HasMaxLength(500);
        modelBuilder.Entity<PasswordHistory>().Property(e => e.PasswordSalt).IsRequired().HasMaxLength(500);
        modelBuilder.Entity<PasswordHistory>().HasIndex(e => e.UserID);
        modelBuilder.Entity<PasswordHistory>()
            .HasOne(h => h.User)
            .WithMany()
            .HasForeignKey(h => h.UserID)
            .OnDelete(DeleteBehavior.Cascade);

        // UserSession
        modelBuilder.Entity<UserSession>().ToTable("UserSession").HasKey(e => e.SessionID);
        modelBuilder.Entity<UserSession>().Property(e => e.SessionToken).IsRequired().HasMaxLength(64);
        modelBuilder.Entity<UserSession>().HasIndex(e => e.SessionToken).IsUnique();
        modelBuilder.Entity<UserSession>().Property(e => e.ATTUID).HasMaxLength(100);
        modelBuilder.Entity<UserSession>().Property(e => e.EndReason).HasMaxLength(50);
        modelBuilder.Entity<UserSession>().Property(e => e.Platform).HasMaxLength(50);
        modelBuilder.Entity<UserSession>().Property(e => e.DeviceInfo).HasMaxLength(200);
        modelBuilder.Entity<UserSession>().HasIndex(e => e.UserID);
        modelBuilder.Entity<UserSession>().HasIndex(e => new { e.UserID, e.EndedAtUtc });
        modelBuilder.Entity<UserSession>()
            .HasOne(s => s.User)
            .WithMany()
            .HasForeignKey(s => s.UserID)
            .OnDelete(DeleteBehavior.Cascade);

        // PasswordResetToken
        modelBuilder.Entity<PasswordResetToken>().ToTable("PasswordResetToken").HasKey(e => e.TokenID);
        modelBuilder.Entity<PasswordResetToken>().Property(e => e.Token).IsRequired().HasMaxLength(10);
        modelBuilder.Entity<PasswordResetToken>().HasIndex(e => e.UserID);
        modelBuilder.Entity<PasswordResetToken>().HasIndex(e => e.Token);
        modelBuilder.Entity<PasswordResetToken>()
            .HasOne(t => t.User)
            .WithMany()
            .HasForeignKey(t => t.UserID)
            .OnDelete(DeleteBehavior.Cascade);

        // SystemSettings
        modelBuilder.Entity<SystemSetting>().ToTable("SystemSettings").HasKey(e => e.SettingKey);
        modelBuilder.Entity<SystemSetting>().Property(e => e.SettingKey).HasMaxLength(100);
        modelBuilder.Entity<SystemSetting>().Property(e => e.SettingValue).HasMaxLength(4000);
        modelBuilder.Entity<SystemSetting>().Property(e => e.Category).HasMaxLength(50);
        modelBuilder.Entity<SystemSetting>().Property(e => e.Description).HasMaxLength(500);
        modelBuilder.Entity<SystemSetting>().HasIndex(e => e.Category);
    }
}
