using Microsoft.EntityFrameworkCore;

namespace Inventory.MAUI.Data;

public interface IInventoryDbContextFactory
{
    DbContext CreateDbContext();
}
