﻿using Inventory.MAUI.ViewModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using CommunityToolkit.Maui;
using Inventory.MAUI.Services;
using Inventory.MAUI.Configuration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Inventory.MAUI
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .UseMauiCommunityToolkit()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                    fonts.AddFont("FluentSystemIcons-Regular.ttf", "FluentIcons");
                });

            GlobalExceptionHandler.Register();

#if WINDOWS
            Inventory.MAUI.Platforms.Windows.CollectionViewScrollBarMapper.EnableScrollBars();
#endif

            var configBuilder = new ConfigurationBuilder();

#if ANDROID
            // On Android, read config from embedded MauiAssets (deployed to APK).
            // The base template is always loaded; the local override (gitignored) supplies real credentials.
            configBuilder.AddJsonStream(GetConfigStream("Configuration/appsettings.json"));
            configBuilder.AddJsonStream(GetConfigStream("Configuration/appsettings.android.json"));
            configBuilder.AddJsonStream(GetConfigStream("Configuration/appsettings.android.local.json"));
#elif IOS || MACCATALYST
            // On iOS/Mac Catalyst, read config from embedded MauiAssets (deployed to app bundle).
            configBuilder.AddJsonStream(GetConfigStream("Configuration/appsettings.json"));
            configBuilder.AddJsonStream(GetConfigStream("Configuration/appsettings.ios.json"));
            configBuilder.AddJsonStream(GetConfigStream("Configuration/appsettings.ios.local.json"));
#else
            // On Windows, read from the app output folder.
            // The base template is always loaded; the local override (gitignored) supplies real credentials.
            configBuilder.SetBasePath(AppContext.BaseDirectory)
                .AddJsonFile("Configuration/appsettings.json", optional: true, reloadOnChange: false)
                .AddJsonFile("Configuration/appsettings.local.json", optional: true, reloadOnChange: false);
#endif

            var config = configBuilder.Build();

            builder.Services.AddOptions<SqlServerOptions>()
                .Bind(config.GetSection(SqlServerOptions.SectionName))
                .Validate(o =>
                {
                    if (string.IsNullOrWhiteSpace(o.ConnectionString))
                        return false;
                    // Detect unreplaced template placeholders from the committed config
                    if (o.ConnectionString.Contains("#{") && o.ConnectionString.Contains("}#"))
                        return false;
                    return true;
                },
                "SQL Server connection string is required. " +
                "Create Configuration/appsettings.local.json (Windows) or Configuration/appsettings.android.local.json (Android) " +
                "from the .local.example.json template and provide a real connection string.")
                .ValidateOnStart();

            // SMTP configuration (optional — password recovery requires it)
            builder.Services.AddOptions<Inventory.MAUI.Configuration.SmtpOptions>()
                .Bind(config.GetSection(Inventory.MAUI.Configuration.SmtpOptions.SectionName));

            builder.Services.AddSingleton<ISqlServerConnectionStringProvider, SqlServerConnectionStringProvider>();

            builder.Services.AddDbContext<Inventory.MAUI.Data.InventoryDbContext>((sp, options) =>
            {
                var sqlOptions = sp.GetService<Microsoft.Extensions.Options.IOptions<SqlServerOptions>>()?.Value;
                var sqlCs = sqlOptions?.ConnectionString;

                if (string.IsNullOrWhiteSpace(sqlCs))
                    throw new InvalidOperationException(
                        "SQL Server connection string is required. " +
                        "Create Configuration/appsettings.local.json (Windows) or Configuration/appsettings.android.local.json (Android) " +
                        "from the .local.example.json template.");

                options.UseSqlServer(sqlCs, sqlServerOptions =>
                {
                    sqlServerOptions.CommandTimeout(30);
                    sqlServerOptions.EnableRetryOnFailure(
                        maxRetryCount: 2,
                        maxRetryDelay: TimeSpan.FromSeconds(5),
                        errorNumbersToAdd: null);
                });
            });

            builder.Services.AddDbContextFactory<Inventory.MAUI.Data.InventoryDbContext>();

            builder.Services.AddScoped<Inventory.MAUI.Services.IInventoryService, Inventory.MAUI.Services.InventoryService>();
            builder.Services.AddScoped<Inventory.MAUI.Services.IRoleService, Inventory.MAUI.Services.RoleService>();
            builder.Services.AddScoped<Inventory.MAUI.Services.IProjectService, Inventory.MAUI.Services.ProjectService>();
            builder.Services.AddScoped<Inventory.MAUI.Services.IInventoryListService, Inventory.MAUI.Services.InventoryListService>();
            builder.Services.AddScoped<Inventory.MAUI.Services.IInventoryItemService, Inventory.MAUI.Services.InventoryItemService>();
            builder.Services.AddScoped<Inventory.MAUI.Services.ICalibrationService, Inventory.MAUI.Services.CalibrationService>();

            builder.Services.AddScoped<Inventory.MAUI.Core.Services.IInventoryListService, Inventory.MAUI.Services.CoreInventoryListServiceAdapter>();

            // IAM services
#if ANDROID || IOS || MACCATALYST
            builder.Services.AddSingleton<Inventory.MAUI.Services.IIdentityService, Inventory.MAUI.Services.AndroidIdentityService>();
#else
            builder.Services.AddSingleton<Inventory.MAUI.Services.IIdentityService, Inventory.MAUI.Services.WindowsIdentityService>();
#endif
#if ANDROID
            builder.Services.AddSingleton<Inventory.MAUI.Services.IFileSaveService, Inventory.MAUI.Services.AndroidFileSaveService>();
#else
            builder.Services.AddSingleton<Inventory.MAUI.Services.IFileSaveService, Inventory.MAUI.Services.DefaultFileSaveService>();
#endif
            builder.Services.AddSingleton<Inventory.MAUI.Services.ISystemSettingsService, Inventory.MAUI.Services.SystemSettingsService>();
            builder.Services.AddSingleton<Inventory.MAUI.Services.PasswordPolicy>();
            builder.Services.AddSingleton<Inventory.MAUI.Services.IAuditService, Inventory.MAUI.Services.AuditService>();
            builder.Services.AddSingleton<Inventory.MAUI.Services.ISessionService, Inventory.MAUI.Services.SessionService>();
            builder.Services.AddSingleton<Inventory.MAUI.Services.IEmailService, Inventory.MAUI.Services.EmailService>();
            builder.Services.AddSingleton<Inventory.MAUI.Services.AppSessionService>();
            builder.Services.AddSingleton<Inventory.MAUI.Services.IAppSessionService>(sp =>
                sp.GetRequiredService<Inventory.MAUI.Services.AppSessionService>());
            builder.Services.AddScoped<Inventory.MAUI.Services.IAppUserService, Inventory.MAUI.Services.AppUserService>();
            builder.Services.AddScoped<Inventory.MAUI.Services.IPasswordResetService, Inventory.MAUI.Services.PasswordResetService>();
            builder.Services.AddSingleton<Inventory.MAUI.Services.IDatabaseService, Inventory.MAUI.Services.DatabaseService>();

            builder.Services.AddTransient<Inventory.MAUI.Core.ViewModels.InventoryListViewModel>();
            builder.Services.AddTransient<Inventory.MAUI.Core.ViewModels.DashboardViewModel>();

            // Views/pages
            builder.Services.AddSingleton<Inventory.MAUI.Pages.InventoryListView>();
            builder.Services.AddTransient<Inventory.MAUI.Pages.DashboardView>();
            builder.Services.AddTransient<Inventory.MAUI.ViewModels.InventoryItemEditViewModel>();
            builder.Services.AddTransient<Inventory.MAUI.Pages.InventoryItemEditPage>();
            builder.Services.AddTransient<Inventory.MAUI.ViewModels.InventoryRecordCrudViewModel>();
            builder.Services.AddTransient<Inventory.MAUI.Pages.InventoryRecordCrudView>();
            builder.Services.AddTransient<Inventory.MAUI.Pages.InventoryRecordCrudPage>();
            builder.Services.AddTransient<Inventory.MAUI.ViewModels.InventoryItemCreateViewModel>();
            builder.Services.AddTransient<Inventory.MAUI.Pages.InventoryItemCreateView>();

            // Calibration views
            builder.Services.AddTransient<Inventory.MAUI.ViewModels.CalibrationSchedulerViewModel>();
            builder.Services.AddTransient<Inventory.MAUI.Pages.CalibrationSchedulerView>();
            builder.Services.AddTransient<Inventory.MAUI.ViewModels.CalibrationCompletionViewModel>();
            builder.Services.AddTransient<Inventory.MAUI.Pages.CalibrationCompletionView>();
            builder.Services.AddTransient<Inventory.MAUI.ViewModels.CalibrationLogViewModel>();
            builder.Services.AddTransient<Inventory.MAUI.Pages.CalibrationLogView>();

            // IAM views
            builder.Services.AddTransient<Inventory.MAUI.ViewModels.UserAdminViewModel>();
            builder.Services.AddTransient<Inventory.MAUI.Pages.UserAdminView>();
            builder.Services.AddTransient<Inventory.MAUI.Pages.LoginPage>();
            builder.Services.AddTransient<Inventory.MAUI.Pages.ChangePasswordPage>();
            builder.Services.AddTransient<Inventory.MAUI.Pages.ForgotPasswordPage>();
            builder.Services.AddTransient<Inventory.MAUI.Pages.GeneralSettingsView>();
            builder.Services.AddTransient<Inventory.MAUI.Pages.SecurityView>();
            builder.Services.AddTransient<Inventory.MAUI.Pages.DatabaseUtilitiesView>();
            builder.Services.AddTransient<Inventory.MAUI.Pages.TableMaintenancePage>();

#if DEBUG
			builder.Logging.AddDebug();
#endif

            return builder.Build();
        }

#if ANDROID || IOS || MACCATALYST
        private static Stream GetConfigStream(string assetPath)
        {
            try
            {
                return FileSystem.OpenAppPackageFileAsync(assetPath).GetAwaiter().GetResult();
            }
            catch
            {
                System.Diagnostics.Debug.WriteLine($"[Config] Asset not found: {assetPath} — using empty config. If this is a .local.json file, create it from the .local.example.json template.");
                return new MemoryStream(System.Text.Encoding.UTF8.GetBytes("{}"));
            }
        }
#endif
    }
}

