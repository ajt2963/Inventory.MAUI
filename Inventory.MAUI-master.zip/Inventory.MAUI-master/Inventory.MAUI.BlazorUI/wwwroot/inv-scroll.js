window.invFindScrollParent = (el) => {
  let cur = el;
  while (cur) {
    if (cur === document.body) return null;
    const style = window.getComputedStyle(cur);
    const overflowY = style.overflowY;
    if ((overflowY === 'auto' || overflowY === 'scroll') && cur.scrollHeight > cur.clientHeight) {
      return cur;
    }
    cur = cur.parentElement;
  }
  return null;
};

window.invScrollSelectedIntoView = () => {
  const selected = document.querySelector('[data-inv-selected="true"]');
  if (!selected) return;

  const container = window.invFindScrollParent(selected) || selected.parentElement;
  if (!container) {
    selected.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    return;
  }

  const headerOffset = 50;
  const targetTop = selected.offsetTop - (container.clientHeight / 2) + (selected.offsetHeight / 2) - headerOffset;
  container.scrollTop = Math.max(0, targetTop);
};
