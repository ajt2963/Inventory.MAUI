﻿namespace Inventory.MAUI
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
        }

        protected override Window CreateWindow(IActivationState? activationState)
        {
            var window = new Window(new AppShell());

#if WINDOWS
            window.Created += (s, e) =>
            {
                var mauiWindow = s as Window;
                var nativeWindow = mauiWindow?.Handler?.PlatformView as Microsoft.UI.Xaml.Window;
                if (nativeWindow is not null)
                {
                    var timer = new System.Timers.Timer(150) { AutoReset = false };
                    var resizing = false;

                    nativeWindow.SizeChanged += (_, _) =>
                    {
                        if (!resizing)
                        {
                            resizing = true;
                            MainThread.BeginInvokeOnMainThread(() =>
                            {
                                if (mauiWindow.Page is ContentPage { Content: View root })
                                    root.InputTransparent = true;
                            });
                        }

                        timer.Stop();
                        timer.Start();
                    };

                    timer.Elapsed += (_, _) =>
                    {
                        resizing = false;
                        MainThread.BeginInvokeOnMainThread(() =>
                        {
                            // Re-enable interaction and force a single clean layout pass.
                            if (mauiWindow.Page is ContentPage cp)
                            {
                                if (cp.Content is View root)
                                    root.InputTransparent = false;

                                (cp as IView).InvalidateMeasure();
                            }
                        });
                    };
                }
            };
#endif

            return window;
        }
    }
}