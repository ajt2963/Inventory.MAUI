using System.Globalization;

namespace Inventory.MAUI.Converters;

/// <summary>
/// Two-way converter between <see cref="DateTime?"/> and <see cref="string"/>
/// for use with Entry controls. Prevents binding warnings when the value is
/// null or the text is empty.
/// </summary>
public sealed class NullableDateConverter : IValueConverter
{
    private const string Format = "MM/dd/yyyy";

    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        => value is DateTime dt ? dt.ToString(Format, CultureInfo.InvariantCulture) : string.Empty;

    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is not string text || string.IsNullOrWhiteSpace(text))
            return null;

        return DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.None, out var result)
            ? result
            : null;
    }
}
