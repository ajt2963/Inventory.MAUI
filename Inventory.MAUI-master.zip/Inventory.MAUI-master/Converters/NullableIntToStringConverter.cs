using System.Globalization;

namespace Inventory.MAUI.Converters;

public sealed class NullableIntToStringConverter : IValueConverter
{
    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        return value switch
        {
            null => string.Empty,
            int i => i.ToString(culture),
            _ => value.ToString()
        };
    }

    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var s = value?.ToString();
        if (string.IsNullOrWhiteSpace(s))
            return null;

        return int.TryParse(s, NumberStyles.Integer, culture, out var i) ? i : null;
    }
}
