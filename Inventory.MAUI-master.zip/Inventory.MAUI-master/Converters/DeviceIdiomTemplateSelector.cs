namespace Inventory.MAUI.Converters;

/// <summary>
/// Selects between a Phone template and a Tablet/Desktop template
/// based on the current device idiom. This avoids inflating both
/// templates for every item (which kills Android performance).
/// </summary>
public sealed class DeviceIdiomTemplateSelector : DataTemplateSelector
{
    public DataTemplate? PhoneTemplate { get; set; }
    public DataTemplate? TabletTemplate { get; set; }

    protected override DataTemplate OnSelectTemplate(object item, BindableObject container)
    {
        var idiom = DeviceInfo.Current.Idiom;
        if (idiom == DeviceIdiom.Phone)
            return PhoneTemplate ?? TabletTemplate!;
        return TabletTemplate ?? PhoneTemplate!;
    }
}
