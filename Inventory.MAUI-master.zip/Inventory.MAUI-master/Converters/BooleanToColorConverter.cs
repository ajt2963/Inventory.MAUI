using System.Globalization;

namespace Inventory.MAUI.Converters;

public sealed class BooleanToColorConverter : IValueConverter
{
    public static BooleanToColorConverter Instance { get; } = new();

    public Color TrueColor { get; set; } = Colors.Red;
    public Color FalseColor { get; set; } = Color.FromArgb("#D0D0D0");

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var flag = value is bool b && b;
        return flag ? TrueColor : FalseColor;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}
