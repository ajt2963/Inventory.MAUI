namespace Inventory.MAUI.Configuration;

/// <summary>
/// SMTP configuration for outbound email (password recovery, notifications).
/// Bind to the "Smtp" section of appsettings.
/// </summary>
public sealed class SmtpOptions
{
    public const string SectionName = "Smtp";

    public string Host { get; init; } = string.Empty;
    public int Port { get; init; } = 587;
    public bool UseSsl { get; init; } = true;
    public string Username { get; init; } = string.Empty;
    public string Password { get; init; } = string.Empty;
    public string FromAddress { get; init; } = string.Empty;
    public string FromName { get; init; } = "UCOM Inventory System";
}
