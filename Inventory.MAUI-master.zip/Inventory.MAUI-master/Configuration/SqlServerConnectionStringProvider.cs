using Microsoft.Extensions.Options;

namespace Inventory.MAUI.Configuration;

public interface ISqlServerConnectionStringProvider
{
    string ConnectionString { get; }
}

public sealed class SqlServerConnectionStringProvider : ISqlServerConnectionStringProvider
{
    private readonly SqlServerOptions _options;

    public SqlServerConnectionStringProvider(IOptions<SqlServerOptions> options)
    {
        _options = options.Value;
    }

    public string ConnectionString
    {
        get
        {
            var cs = _options.ConnectionString;
            if (string.IsNullOrWhiteSpace(cs))
                throw new InvalidOperationException($"Missing required configuration: `{SqlServerOptions.SectionName}:ConnectionString`.");

            return cs;
        }
    }
}
