namespace Inventory.MAUI.Configuration;

public sealed class SqlServerOptions
{
    public const string SectionName = "SqlServer";

    public string? ConnectionString { get; init; }
}
