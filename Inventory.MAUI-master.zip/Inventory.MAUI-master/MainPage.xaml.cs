using System.ComponentModel;
using System.Net.Sockets;
using Inventory.MAUI.Configuration;
using Inventory.MAUI.Core.ViewModels;
using Inventory.MAUI.Services;
using Inventory.MAUI.ViewModels;

namespace Inventory.MAUI;

public partial class MainPage : ContentPage
{
    private const string HomeKey = "Home";
    private const string DashboardKey = "Dashboard";
    private const string InventoryListKey = "Inventory List";
    private const string InventoryEditKey = "Inventory Edit";
    private const string InventoryAddKey = "Add Record";

    private const string CalibrationGroupTitle = "Calibration Management";
    private const string LogisticsGroupTitle = "Logistics Management";
    private const string SysAdminGroupTitle = "System Administration";

    private const string CalibrationSchedulerKey = "Calibration Scheduler";
    private const string CalibrationCompletionKey = "Calibration Completion";
    private const string CalibrationLogKey = "Calibration Log";
    private const string LogisticsKey = "Logistics";
    private const string UserAdminKey = "User Administration";
    private const string GeneralSettingsKey = "General Settings";
    private const string SecurityKey = "Security";
    private const string DatabaseUtilitiesKey = "Database Utilities";
    private const string TableMaintenanceKey = "Table Maintenance";

    private sealed class NavGroup(string title, IReadOnlyList<NavigationItem> items) : List<NavigationItem>(items), INotifyPropertyChanged
    {
        private readonly IReadOnlyList<NavigationItem> _allItems = items;
        private bool _isExpanded = true;

        public event PropertyChangedEventHandler? PropertyChanged;

        public string Title { get; } = title;

        public bool IsExpanded
        {
            get => _isExpanded;
            set
            {
                if (_isExpanded == value)
                    return;

                _isExpanded = value;
                Refresh();
                OnPropertyChanged(nameof(IsExpanded));
                OnPropertyChanged(nameof(Chevron));
            }
        }

        public string Chevron => string.IsNullOrWhiteSpace(Title) ? string.Empty : (IsExpanded ? "v" : ">");

        public void Toggle() => IsExpanded = !IsExpanded;

        private void Refresh()
        {
            Clear();

            if (IsExpanded)
            {
                foreach (var item in _allItems)
                    Add(item);
            }
        }

        private void OnPropertyChanged(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    private readonly IReadOnlyList<NavGroup> _items =
    [
        new NavGroup("", 
        [ 
            new NavigationItem(HomeKey, "Welcome", "icon_home.png"),
            new NavigationItem(DashboardKey, "Dashboard", "icon_table.png")
        ]),
        new NavGroup("Inventory Management",
        [
            new NavigationItem(InventoryListKey, "Browse inventory records", "icon_list.png"),
            new NavigationItem(InventoryAddKey, "Add a new inventory record", "icon_add.png"),
        ]),
        new NavGroup(CalibrationGroupTitle,
        [
            new NavigationItem(CalibrationSchedulerKey, "Schedule calibration by location", "icon_edit.png"),
            new NavigationItem(CalibrationCompletionKey, "Complete scheduled calibrations", "icon_edit.png"),
            new NavigationItem(CalibrationLogKey, "View calibration history", "icon_list.png"),
        ]),
        new NavGroup(LogisticsGroupTitle,
        [
            new NavigationItem(LogisticsKey, "Logistics (coming soon)", "icon_table.png"),
        ]),
        new NavGroup(SysAdminGroupTitle,
        [
            new NavigationItem(UserAdminKey, "Manage users and roles", "icon_edit.png"),
            new NavigationItem(GeneralSettingsKey, "App settings and features", "icon_edit.png"),
            new NavigationItem(SecurityKey, "Password, sessions, MFA, SSO, audit", "icon_edit.png"),
            new NavigationItem(DatabaseUtilitiesKey, "Backup, restore, replication", "icon_table.png"),
            new NavigationItem(TableMaintenanceKey, "Manage lookup tables", "icon_list.png"),
        ])
    ];

    private string? _activeKey;
    private bool _navCollapsed;

    private Pages.InventoryListView? _inventoryListView;
    private Pages.InventoryItemEditPage? _inventoryEditPage;

    private CancellationTokenSource? _busyAnimCts;
    private View? _activeHostedView;

    // --- Generic busy-indicator wiring ---
    private INotifyPropertyChanged? _watchedBusyVm;

    // --- Breadcrumb trail ---
    private sealed record BreadcrumbEntry(string Key, View CachedView);
    private readonly List<BreadcrumbEntry> _breadcrumbTrail = [];
    private readonly Dictionary<string, View> _viewCache = [];
    private int _activeBreadcrumbIndex = -1;

    public MainPage()
    {
        InitializeComponent();

        // Set column definitions based on device idiom
        if (LayoutRoot is Grid grid)
        {
            grid.ColumnDefinitions.Clear();
            
            if (DeviceInfo.Current.Idiom == DeviceIdiom.Phone)
            {
                // Phone: nav overlay on top of content (column 2), no sidebar
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(0) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(0) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
                
                // Place nav panel as an overlay over column 2 (content area)
                Grid.SetColumn(NavColumn, 2);
                NavColumn.HorizontalOptions = LayoutOptions.Start;
                NavColumn.WidthRequest = 280;
            }
            else if (DeviceInfo.Current.Idiom == DeviceIdiom.Tablet)
            {
                // Tablet: medium nav, small handle
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(240) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(20) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
                
                Grid.SetColumn(NavColumn, 0);
                NavColumn.HorizontalOptions = LayoutOptions.Fill;
                NavColumn.WidthRequest = -1;
            }
            else
            {
                // Desktop: wide nav, normal handle
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(280) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(24) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
                
                Grid.SetColumn(NavColumn, 0);
                NavColumn.HorizontalOptions = LayoutOptions.Fill;
                NavColumn.WidthRequest = -1;
            }
        }

        NavList.ItemsSource = _items;

        // Don't pre-select a nav item � user must authenticate first
        
        // On phone, start with nav collapsed
        if (DeviceInfo.Current.Idiom == DeviceIdiom.Phone)
        {
            _navCollapsed = true;
            NavColumn.IsVisible = false;
        }
        else
        {
            if (NavToggleIcon is not null)
                NavToggleIcon.Text = "<";
        }

        // Don't show any content before authentication � start locked.
        // ClearSessionState will be called by UpdateUserStatusBar in OnMainPageLoaded.
        MainHost.Content = null;

        // Initialize IAM session on load
        Loaded += OnMainPageLoaded;
    }

    private async void OnMainPageLoaded(object? sender, EventArgs e)
    {
        Loaded -= OnMainPageLoaded; // once only

        try
        {
            var userService = AppServices.Get<IAppUserService>();
            var session = AppServices.Get<AppSessionService>();

            if (userService is null || session is null)
                return;

            // Show a connecting indicator so the user isn't staring at a blank screen
            MainHost.Content = new VerticalStackLayout
            {
                HorizontalOptions = LayoutOptions.Center,
                VerticalOptions = LayoutOptions.Center,
                Spacing = 12,
                Children =
                {
                    new ActivityIndicator { IsRunning = true, Color = Color.FromArgb("#1976D2") },
                    new Label
                    {
                        Text = "Connecting to database�",
                        FontSize = 14,
                        TextColor = Color.FromArgb("#666"),
                        HorizontalTextAlignment = TextAlignment.Center
                    }
                }
            };

            // Quick TCP reachability check � fails in ~5s instead of the full 30s connect timeout.
            await VerifyDatabaseReachableAsync();

            // Ensure seed data (default roles + auto-register first user)
            await userService.EnsureSeedDataAsync();
            System.Diagnostics.Debug.WriteLine("[IAM] Seed data ensured.");

            // Initialize system settings (creates table + seeds defaults if needed)
            var settingsService = AppServices.GetRequired<ISystemSettingsService>();
            await settingsService.EnsureInitializedAsync();
            System.Diagnostics.Debug.WriteLine("[IAM] System settings initialized.");

            // Wire session changes to update the status bar
            session.SessionChanged += () => MainThread.BeginInvokeOnMainThread(() => UpdateUserStatusBar(session));
            UpdateUserStatusBar(session);

            // Start session timeout checker
            StartSessionTimeoutTimer(session);

            // App requires authentication � auto-open the login page on startup
            if (!session.IsAuthenticated)
            {
                System.Diagnostics.Debug.WriteLine("[IAM] No active session � prompting for login.");
                OnSignInClicked(this, EventArgs.Empty);
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[IAM] Session init failed: {ex.Message}");
            System.Diagnostics.Debug.WriteLine($"[IAM] Stack: {ex.StackTrace}");
            UpdateUserStatusBar(null);
            
            await DisplayAlert("Database Connection Error", 
                "Unable to connect to the SQL database. Please ensure the IP address is correct and the firewall is allowing connections to the database on your host machine.", "OK");
                
            // Still prompt for login so the user isn't stuck on a blank screen, though login will likely fail until DB is fixed.
            OnSignInClicked(this, EventArgs.Empty);
        }
    }

    /// <summary>
    /// Performs a fast TCP socket check against the SQL Server host/port parsed from the
    /// connection string. Throws if the server is unreachable within 5 seconds, surfacing
    /// the "Database Connection Error" dialog immediately instead of waiting for the full
    /// 30-second ADO.NET connect timeout on every EF Core call.
    /// </summary>
    private static async Task VerifyDatabaseReachableAsync()
    {
        var csProv = AppServices.Get<ISqlServerConnectionStringProvider>();
        if (csProv is null)
            return;

        var cs = csProv.ConnectionString;
        if (string.IsNullOrWhiteSpace(cs))
            return;

        // Parse "Data Source=host,port" from the connection string
        var builder = new Microsoft.Data.SqlClient.SqlConnectionStringBuilder(cs);
        var dataSource = builder.DataSource; // e.g. "10.201.223.38,62138" or "SERVER\INSTANCE"
        if (string.IsNullOrWhiteSpace(dataSource))
            return;

        // Named instances (contain '\') use the SQL Browser service to resolve the
        // actual TCP port at connect time. A raw TCP socket check can't handle that,
        // so skip the pre-check and let ADO.NET connect normally.
        if (dataSource.Contains('\\'))
            return;

        string host;
        int port;
        var commaIdx = dataSource.IndexOf(',');
        if (commaIdx > 0)
        {
            host = dataSource[..commaIdx].Trim();
            _ = int.TryParse(dataSource[(commaIdx + 1)..].Trim(), out port);
            if (port <= 0) port = 1433;
        }
        else
        {
            host = dataSource.Trim();
            port = 1433;
        }

        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(5));
        using var socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        try
        {
            await socket.ConnectAsync(host, port, cts.Token);
        }
        catch (OperationCanceledException)
        {
            throw new InvalidOperationException(
                $"SQL Server at {host}:{port} is not reachable (timed out after 5 seconds). " +
                "Check network connectivity, firewall rules, and the Data Source in your connection string.");
        }
        catch (SocketException ex)
        {
            throw new InvalidOperationException(
                $"SQL Server at {host}:{port} is not reachable: {ex.Message}. " +
                "Check network connectivity, firewall rules, and the Data Source in your connection string.", ex);
        }
    }

    private IDispatcherTimer? _sessionTimer;

    private void StartSessionTimeoutTimer(AppSessionService session)
    {
        _sessionTimer = Dispatcher.CreateTimer();
        _sessionTimer.Interval = TimeSpan.FromMinutes(1);
        _sessionTimer.Tick += (_, _) =>
        {
            if (session.CheckAndExpireSession())
            {
                System.Diagnostics.Debug.WriteLine("[IAM] Session expired due to inactivity.");
                MainThread.BeginInvokeOnMainThread(async () =>
                {
                    UpdateUserStatusBar(session);
                    await DisplayAlert("Session Expired",
                        "Your session has expired due to inactivity. Please sign in again.",
                        "OK");
                });
            }
        };
        _sessionTimer.Start();
    }

    private void UpdateUserStatusBar(Services.AppSessionService? session)
    {
        if (UserStatusLabel is null)
            return;

        if (session is null || !session.IsAuthenticated)
        {
            UserStatusLabel.Text = "Not authenticated";
            UserStatusLabel.TextColor = Color.FromArgb("#C62828");
            SignOutButton.IsVisible = false;
            ChangePasswordButton.IsVisible = false;
            SignInButton.IsVisible = true;

            // Lock the app � clear all cached pages and show the locked state
            ClearSessionState();
            return;
        }

        UserStatusLabel.Text = $"{session.DisplayName}  |  {session.RoleName}";
        UserStatusLabel.TextColor = Color.FromArgb("#333333");
        SignOutButton.IsVisible = true;
        ChangePasswordButton.IsVisible = true;
        SignInButton.IsVisible = false;
    }

    /// <summary>
    /// Clears all cached views, breadcrumbs, and shows the locked splash.
    /// Called on logout, session expiry, or any unauthenticated state.
    /// </summary>
    private void ClearSessionState()
    {
        _viewCache.Clear();
        _breadcrumbTrail.Clear();
        _activeBreadcrumbIndex = -1;
        _activeKey = null;
        _inventoryListView = null;
        _inventoryEditPage = null;

        RebuildBreadcrumbBar();

        // Show a locked content view instead of the last page the user was on
        MainHost.Content = new VerticalStackLayout
        {
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.Center,
            Spacing = 12,
            Children =
            {
                new Label
                {
                    Text = "??",
                    FontSize = 48,
                    HorizontalTextAlignment = TextAlignment.Center
                },
                new Label
                {
                    Text = "Authentication Required",
                    FontSize = 20,
                    FontAttributes = FontAttributes.Bold,
                    TextColor = Color.FromArgb("#0B2239"),
                    HorizontalTextAlignment = TextAlignment.Center
                },
                new Label
                {
                    Text = "Sign in to access the UCOM Inventory Management System.",
                    FontSize = 13,
                    TextColor = Color.FromArgb("#666"),
                    HorizontalTextAlignment = TextAlignment.Center
                }
            }
        };
    }

    private void OnSignOutClicked(object? sender, EventArgs e)
    {
        var session = AppServices.Get<AppSessionService>();
        session?.Clear();
    }

    private async void OnChangePasswordClicked(object? sender, EventArgs e)
    {
        var userService = AppServices.Get<IAppUserService>();
        var session = AppServices.Get<AppSessionService>();

        if (userService is null || session is null || !session.IsAuthenticated)
            return;

        try
        {
            var changePage = AppServices.GetRequired<Pages.ChangePasswordPage>();

            changePage.PasswordChanged += () =>
            {
                MainThread.BeginInvokeOnMainThread(async () =>
                {
                    await Navigation.PopModalAsync();
                    await DisplayAlert("Password Changed",
                        "Your password has been changed successfully.",
                        "OK");
                });
            };

            changePage.Cancelled += () =>
            {
                MainThread.BeginInvokeOnMainThread(async () =>
                {
                    await Navigation.PopModalAsync();
                });
            };

            await Navigation.PushModalAsync(changePage);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[IAM] Change password failed: {ex.Message}");
            await DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async void OnSignInClicked(object? sender, EventArgs e)
    {
        var userService = AppServices.Get<IAppUserService>();
        var session = AppServices.Get<AppSessionService>();

        if (userService is null || session is null)
            return;

        try
        {
            var loginPage = AppServices.GetRequired<Pages.LoginPage>();

            loginPage.LoginSucceeded += () =>
            {
                MainThread.BeginInvokeOnMainThread(async () =>
                {
                    await Navigation.PopModalAsync();
                    UpdateUserStatusBar(session);

                    // After successful login, navigate to Home
                    _activeKey = null; // Reset so ActivateAsync won't short-circuit
                    await ActivateAsync(HomeKey);
                    SyncNavSelection(HomeKey);
                });
            };

            loginPage.LoginCancelled += () =>
            {
                MainThread.BeginInvokeOnMainThread(async () =>
                {
                    await Navigation.PopModalAsync();
                });
            };

            loginPage.ForgotPasswordRequested += () =>
            {
                MainThread.BeginInvokeOnMainThread(async () =>
                {
                    await Navigation.PopModalAsync();
                    await ShowForgotPasswordAsync();
                });
            };

            await Navigation.PushModalAsync(loginPage);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[IAM] Sign-in failed: {ex.Message}");
            await DisplayAlert("Sign In Failed", ex.Message, "OK");
        }
    }

    private async Task ShowForgotPasswordAsync()
    {
        try
        {
            var forgotPage = AppServices.GetRequired<Pages.ForgotPasswordPage>();

            forgotPage.PasswordResetCompleted += () =>
            {
                MainThread.BeginInvokeOnMainThread(async () =>
                {
                    await Navigation.PopModalAsync();
                    // Re-open login page so user can sign in with new password
                    OnSignInClicked(this, EventArgs.Empty);
                });
            };

            forgotPage.Cancelled += () =>
            {
                MainThread.BeginInvokeOnMainThread(async () =>
                {
                    await Navigation.PopModalAsync();
                    // Re-open login page
                    OnSignInClicked(this, EventArgs.Empty);
                });
            };

            await Navigation.PushModalAsync(forgotPage);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[IAM] Forgot password failed: {ex.Message}");
            await DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private void OnToggleNavClicked(object sender, EventArgs e)
    {
        _navCollapsed = !_navCollapsed;

        NavColumn.IsVisible = !_navCollapsed;

        // Show/hide the scrim on phone
        if (DeviceInfo.Current.Idiom == DeviceIdiom.Phone)
        {
            NavScrim.IsVisible = !_navCollapsed;
        }

        if (LayoutRoot is Grid grid && grid.ColumnDefinitions.Count > 0)
        {
            // On phone, nav is an overlay (always width 0 in layout, visibility controls it)
            // On tablet/desktop, nav is a column that collapses
            var isPhone = DeviceInfo.Current.Idiom == DeviceIdiom.Phone;
            
            if (!isPhone)
            {
                var targetWidth = DeviceInfo.Current.Idiom == DeviceIdiom.Tablet ? 240 : 280;
                grid.ColumnDefinitions[0].Width = _navCollapsed ? new GridLength(0) : new GridLength(targetWidth);
            }
        }

        if (NavToggleIcon is not null)
            NavToggleIcon.Text = _navCollapsed ? ">" : "<";

        OnPropertyChanged(nameof(IsNavCollapsed));
    }

    public bool IsNavCollapsed => _navCollapsed;

    private void OnNavScrimTapped(object? sender, TappedEventArgs e)
    {
        if (DeviceInfo.Current.Idiom == DeviceIdiom.Phone && !_navCollapsed)
        {
            _navCollapsed = true;
            NavColumn.IsVisible = false;
            NavScrim.IsVisible = false;
        }
    }

    private async void OnNavSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.FirstOrDefault() is not NavigationItem item)
            return;

        // Record user activity to keep session alive
        AppServices.Get<AppSessionService>()?.RecordActivity();

        // On phone, auto-collapse nav after selection
        if (DeviceInfo.Current.Idiom == DeviceIdiom.Phone && !_navCollapsed)
        {
            _navCollapsed = true;
            NavColumn.IsVisible = false;
            NavScrim.IsVisible = false;
        }

        await ActivateAsync(item.Title);
    }

    private async Task ActivateAsync(string key)
    {
        if (string.Equals(_activeKey, key, StringComparison.Ordinal))
            return;

        // ?? Centralized access gate ??
        var session = AppServices.GetRequired<AppSessionService>();

        if (!session.IsAuthenticated)
        {
            await ShowAccessDeniedAsync("You must sign in to access this application.");
            return;
        }

        // Per-page authorization
        if (!IsAuthorized(key, session, out var deniedReason))
        {
            await DisplayAlert("Access Denied", deniedReason, "OK");
            return;
        }

        _activeKey = key;

        View? view = null;

        if (key == HomeKey)
        {
            view = GetOrCreateCachedView(HomeKey, () => new Pages.WelcomeView());
            PushBreadcrumb(key, view);
            SetMainHostContent(view);
            return;
        }

        if (key == DashboardKey)
        {
            var dashboardView = AppServices.GetRequired<Pages.DashboardView>();
            dashboardView.LocationDetailRequested -= OnDashboardLocationDetailRequested;
            dashboardView.LocationDetailRequested += OnDashboardLocationDetailRequested;
            _viewCache[DashboardKey] = dashboardView;
            PushBreadcrumb(key, dashboardView);
            SetMainHostContent(dashboardView);
            
            await dashboardView.EnsureInitializedAsync();
            return;
        }

        if (key == InventoryListKey)
        {
            EnsureInventoryViewAndVm();
            WireInventoryViewLifecycle(_inventoryListView!);
            WireInventoryListEdit(_inventoryListView!);

            view = _inventoryListView!;
            _viewCache[InventoryListKey] = view;
            PushBreadcrumb(key, view);
            SetMainHostContent(view);

            var listVm = GetInventoryListVm();
            if (listVm is not null)
                await listVm.LoadAsync();
            return;
        }

        if (key == InventoryEditKey)
        {
            view = AppServices.GetRequired<Pages.InventoryItemEditPage>();
            _viewCache[InventoryEditKey] = view;
            PushBreadcrumb(key, view);
            SetMainHostContent(view);
            return;
        }

        if (key == InventoryAddKey)
        {
            view = AppServices.GetRequired<Pages.InventoryItemCreateView>();
            _viewCache[InventoryAddKey] = view;
            PushBreadcrumb(key, view);
            SetMainHostContent(view);
            return;
        }

        if (key == CalibrationSchedulerKey)
        {
            view = AppServices.GetRequired<Pages.CalibrationSchedulerView>();
            _viewCache[CalibrationSchedulerKey] = view;
            PushBreadcrumb(key, view);
            SetMainHostContent(view);
            return;
        }

        if (key == CalibrationCompletionKey)
        {
            view = AppServices.GetRequired<Pages.CalibrationCompletionView>();
            _viewCache[CalibrationCompletionKey] = view;
            PushBreadcrumb(key, view);
            SetMainHostContent(view);
            return;
        }

        if (key == CalibrationLogKey)
        {
            view = AppServices.GetRequired<Pages.CalibrationLogView>();
            _viewCache[CalibrationLogKey] = view;
            PushBreadcrumb(key, view);
            SetMainHostContent(view);
            return;
        }

        if (key == UserAdminKey)
        {
            var adminView = AppServices.GetRequired<Pages.UserAdminView>();
            _viewCache[UserAdminKey] = adminView;
            PushBreadcrumb(key, adminView);
            SetMainHostContent(adminView);

            await adminView.EnsureInitializedAsync();
            return;
        }

        if (key == GeneralSettingsKey)
        {
            var settingsView = AppServices.GetRequired<Pages.GeneralSettingsView>();
            _viewCache[GeneralSettingsKey] = settingsView;
            PushBreadcrumb(key, settingsView);
            SetMainHostContent(settingsView);

            await settingsView.EnsureInitializedAsync();
            return;
        }

        if (key == SecurityKey)
        {
            var securityView = AppServices.GetRequired<Pages.SecurityView>();
            _viewCache[SecurityKey] = securityView;
            PushBreadcrumb(key, securityView);
            SetMainHostContent(securityView);

            await securityView.EnsureInitializedAsync();
            return;
        }

        if (key == DatabaseUtilitiesKey)
        {
            var dbView = AppServices.GetRequired<Pages.DatabaseUtilitiesView>();
            _viewCache[DatabaseUtilitiesKey] = dbView;
            PushBreadcrumb(key, dbView);
            SetMainHostContent(dbView);

            await dbView.EnsureInitializedAsync();
            return;
        }

        if (key == TableMaintenanceKey)
        {
            var tablePage = AppServices.GetRequired<Pages.TableMaintenancePage>();
            _viewCache[TableMaintenanceKey] = tablePage;
            PushBreadcrumb(key, tablePage);
            SetMainHostContent(tablePage);
            return;
        }

        await Task.CompletedTask;
    }

    /// <summary>
    /// Checks whether the current session has permission to access the given page.
    /// Returns false with a reason message if access is denied.
    /// </summary>
    private static bool IsAuthorized(string pageKey, AppSessionService session, out string deniedReason)
    {
        deniedReason = string.Empty;

        switch (pageKey)
        {
            // Home is accessible to any authenticated user
            case HomeKey:
                return true;

            // Require CanView (Viewer, Editor, Admin)
            case DashboardKey:
            case InventoryListKey:
            case CalibrationLogKey:
            case LogisticsKey:
                if (!session.CanView)
                {
                    deniedReason = "You do not have permission to view this page. Contact your administrator.";
                    return false;
                }
                return true;

            // Require CanEdit (Editor, Admin)
            case InventoryEditKey:
            case CalibrationSchedulerKey:
            case CalibrationCompletionKey:
                if (!session.CanEdit)
                {
                    deniedReason = "This page requires Editor or Administrator privileges.";
                    return false;
                }
                return true;

            // Require CanCreate (Editor, Admin)
            case InventoryAddKey:
                if (!session.CanCreate)
                {
                    deniedReason = "You do not have permission to create records. Contact your administrator.";
                    return false;
                }
                return true;

            // Require CanAdmin (Admin only)
            case UserAdminKey:
            case GeneralSettingsKey:
            case SecurityKey:
            case DatabaseUtilitiesKey:
            case TableMaintenanceKey:
                if (!session.CanAdmin)
                {
                    deniedReason = "This page requires Administrator privileges.";
                    return false;
                }
                return true;

            default:
                deniedReason = "Unknown page.";
                return false;
        }
    }

    /// <summary>
    /// Shows an access-denied message and prompts the user to sign in.
    /// </summary>
    private async Task ShowAccessDeniedAsync(string message)
    {
        await DisplayAlert("Authentication Required", message, "OK");

        // Auto-open the login page
        OnSignInClicked(this, EventArgs.Empty);
    }

    // --- Breadcrumb management ---

    private View GetOrCreateCachedView(string key, Func<View> factory)
    {
        if (_viewCache.TryGetValue(key, out var cached))
            return cached;

        var view = factory();
        _viewCache[key] = view;
        return view;
    }

    private void PushBreadcrumb(string key, View view)
    {
        // Each page appears at most once. If it already exists, update its view and activate it.
        for (var i = 0; i < _breadcrumbTrail.Count; i++)
        {
            if (_breadcrumbTrail[i].Key == key)
            {
                _breadcrumbTrail[i] = new BreadcrumbEntry(key, view);
                _activeBreadcrumbIndex = i;
                RebuildBreadcrumbBar();
                return;
            }
        }

        _breadcrumbTrail.Add(new BreadcrumbEntry(key, view));
        _activeBreadcrumbIndex = _breadcrumbTrail.Count - 1;
        RebuildBreadcrumbBar();
    }

    private void NavigateToBreadcrumb(int index)
    {
        if (index < 0 || index >= _breadcrumbTrail.Count)
            return;

        var entry = _breadcrumbTrail[index];

        // Re-check authorization before allowing breadcrumb navigation
        var session = AppServices.GetRequired<AppSessionService>();
        if (!session.IsAuthenticated || !IsAuthorized(entry.Key, session, out _))
        {
            _ = ShowAccessDeniedAsync("Your session has changed. Please sign in again.");
            return;
        }

        _activeKey = entry.Key;
        _activeBreadcrumbIndex = index;

        SetMainHostContent(entry.CachedView);

        // Sync the nav-column selection to match.
        SyncNavSelection(entry.Key);

        RebuildBreadcrumbBar();
    }

    private void SyncNavSelection(string key)
    {
        foreach (var group in _items)
        {
            foreach (var item in group)
            {
                if (string.Equals(item.Title, key, StringComparison.Ordinal))
                {
                    NavList.SelectedItem = item;
                    return;
                }
            }
        }
    }

    private async void OnBreadcrumbClearClicked(object sender, EventArgs e)
    {
        // Clear the trail completely and navigate to Home � just like the legacy app.
        _breadcrumbTrail.Clear();
        _activeBreadcrumbIndex = -1;
        RebuildBreadcrumbBar();

        _activeKey = null; // Reset so ActivateAsync won't short-circuit.
        await ActivateAsync(HomeKey);
        SyncNavSelection(HomeKey);
    }

    private void RebuildBreadcrumbBar()
    {
        BreadcrumbBar.Children.Clear();

        for (var i = 0; i < _breadcrumbTrail.Count; i++)
        {
            var entry = _breadcrumbTrail[i];
            var isActive = i == _activeBreadcrumbIndex;

            if (i > 0)
            {
                BreadcrumbBar.Children.Add(new Label
                {
                    Text = ">",
                    TextColor = Colors.Gray,
                    FontSize = 13,
                    VerticalOptions = LayoutOptions.Center,
                    Margin = new Thickness(2, 0),
                });
            }

            if (isActive)
            {
                // Active page � bold, not clickable.
                BreadcrumbBar.Children.Add(new Label
                {
                    Text = entry.Key,
                    TextColor = Color.FromArgb("#0B2239"),
                    FontAttributes = FontAttributes.Bold,
                    FontSize = 13,
                    VerticalOptions = LayoutOptions.Center,
                });
            }
            else
            {
                // Other page � clickable link (Button for reliable tap on WinUI).
                var idx = i;
                var link = new Button
                {
                    Text = entry.Key,
                    TextColor = Color.FromArgb("#1565C0"),
                    FontSize = 13,
                    BackgroundColor = Colors.Transparent,
                    BorderWidth = 0,
                    Padding = new Thickness(4, 2),
                    VerticalOptions = LayoutOptions.Center,
                };

                // Hover / press highlight via VisualStateManager.
                // Button already has a built-in "CommonStates" group � replace it.
                var normalState = new VisualState { Name = "Normal" };
                normalState.Setters.Add(new Setter { Property = Button.BackgroundColorProperty, Value = Colors.Transparent });
                normalState.Setters.Add(new Setter { Property = Button.TextColorProperty, Value = Color.FromArgb("#1565C0") });

                var pointerOverState = new VisualState { Name = "PointerOver" };
                pointerOverState.Setters.Add(new Setter { Property = Button.BackgroundColorProperty, Value = Color.FromArgb("#E3F2FD") });
                pointerOverState.Setters.Add(new Setter { Property = Button.TextColorProperty, Value = Color.FromArgb("#0D47A1") });

                var pressedState = new VisualState { Name = "Pressed" };
                pressedState.Setters.Add(new Setter { Property = Button.BackgroundColorProperty, Value = Color.FromArgb("#BBDEFB") });
                pressedState.Setters.Add(new Setter { Property = Button.TextColorProperty, Value = Color.FromArgb("#0D47A1") });

                var disabledState = new VisualState { Name = "Disabled" };

                var group = new VisualStateGroup { Name = "CommonStates" };
                group.States.Add(normalState);
                group.States.Add(pointerOverState);
                group.States.Add(pressedState);
                group.States.Add(disabledState);

                var groups = VisualStateManager.GetVisualStateGroups(link);
                groups.Clear();
                groups.Add(group);

                link.Clicked += (_, _) => NavigateToBreadcrumb(idx);
                BreadcrumbBar.Children.Add(link);
            }
        }

        BreadcrumbClearButton.IsVisible = _breadcrumbTrail.Count > 1;
    }

    // --- Busy overlay ---

    private async Task RunBusyAnimationAsync(CancellationToken token)
    {
        const double from = -40;
        const double to = 150;

        while (!token.IsCancellationRequested)
        {
            if (BusyBarMover is null)
            {
                await Task.Delay(100, token);
                continue;
            }

            await MainThread.InvokeOnMainThreadAsync(async () =>
            {
                BusyBarMover.TranslationX = from;
                await BusyBarMover.TranslateTo(to, 0, 1500, Easing.Linear);
            });
        }
    }

    private void StartBusyAnimation()
    {
        if (_busyAnimCts is not null)
            return;

        _busyAnimCts = new CancellationTokenSource();
        _ = Task.Run(() => RunBusyAnimationAsync(_busyAnimCts.Token));
    }

    private void StopBusyAnimation()
    {
        try { _busyAnimCts?.Cancel(); } catch { }
        finally
        {
            _busyAnimCts?.Dispose();
            _busyAnimCts = null;
        }

        MainThread.BeginInvokeOnMainThread(() =>
        {
            if (BusyBarMover is not null)
                BusyBarMover.TranslationX = 0;
        });
    }

    private void SetBusy(bool isBusy)
    {
        BusyOverlay.IsVisible = isBusy;
        BusyOverlay.InputTransparent = !isBusy;

        if (isBusy) StartBusyAnimation();
        else StopBusyAnimation();
    }

    private void SetBusy(bool isBusy, string? message)
    {
        if (BusyMessageLabel is not null)
            BusyMessageLabel.Text = string.IsNullOrWhiteSpace(message) ? "Working..." : message;

        SetBusy(isBusy);
    }

    private void SetMainHostContent(View? view)
    {
        if (view is null)
            return;

        if (ReferenceEquals(_activeHostedView, view))
            return;

        _activeHostedView = view;
        MainHost.Content = view;

        WireBusyIndicator(view);
    }

    private void EnsureInventoryViewAndVm()
    {
        _inventoryListView ??= AppServices.GetRequired<Pages.InventoryListView>();
    }

    /// <summary>
    /// Phone: user tapped a location on the Dashboard ? navigate to Inventory List filtered by CLLI code.
    /// </summary>
    private void OnDashboardLocationDetailRequested(string clliCode)
    {
        _ = MainThread.InvokeOnMainThreadAsync(async () =>
        {
            EnsureInventoryViewAndVm();
            WireInventoryViewLifecycle(_inventoryListView!);
            WireInventoryListEdit(_inventoryListView!);

            var view = _inventoryListView!;
            _viewCache[InventoryListKey] = view;
            _activeKey = InventoryListKey;
            PushBreadcrumb(InventoryListKey, view);
            SetMainHostContent(view);

            // Load the inventory list filtered by the CLLI code
            var listVm = GetInventoryListVm();
            if (listVm is not null)
                await listVm.LoadAsync(clliCode);
        });
    }

    private void WireInventoryViewLifecycle(Pages.InventoryListView view)
    {
        view.Unloaded -= InventoryViewOnUnloaded;
        view.Loaded -= InventoryViewOnLoaded;

        view.Unloaded += InventoryViewOnUnloaded;
        view.Loaded += InventoryViewOnLoaded;
    }

    private void WireInventoryListEdit(Pages.InventoryListView view)
    {
        view.EditRequested -= OnInventoryEditRequested;
        view.EditRequested += OnInventoryEditRequested;
    }

    private InventoryListViewModel? GetInventoryListVm()
    {
        return _inventoryListView?.BindingContext as InventoryListViewModel
            ?? AppServices.Get<InventoryListViewModel>();
    }

    private void WireBusyIndicator(View? view)
    {
        if (_watchedBusyVm is not null)
        {
            _watchedBusyVm.PropertyChanged -= OnWatchedVmPropertyChanged;
            _watchedBusyVm = null;
        }

        SetBusy(false);

        if (view is null)
            return;

        var bc = view.BindingContext;
        INotifyPropertyChanged? target = bc switch
        {
            InventoryListViewModel vm => vm,
            InventoryRecordCrudViewModel crudVm => crudVm.ListVm,
            INotifyPropertyChanged inpc when HasIsBusy(inpc) => inpc,
            _ => null,
        };

        if (target is null)
            return;

        _watchedBusyVm = target;
        _watchedBusyVm.PropertyChanged += OnWatchedVmPropertyChanged;

        SetBusy(GetIsBusy(_watchedBusyVm));
    }

    private static bool HasIsBusy(object obj)
        => obj.GetType().GetProperty("IsBusy")?.PropertyType == typeof(bool);

    private static bool GetIsBusy(object obj)
        => obj.GetType().GetProperty("IsBusy")?.GetValue(obj) is true;

    private void OnWatchedVmPropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs args)
    {
        if (args.PropertyName != "IsBusy")
            return;

        if (sender is null)
            return;

        MainThread.BeginInvokeOnMainThread(() =>
        {
            SetBusy(GetIsBusy(sender));
        });
    }

    private void OnInventoryEditRequested(int inventoryId)
    {
        _ = MainThread.InvokeOnMainThreadAsync(async () =>
        {
            // Permission check: require at least View to open the edit page (Save/Delete are hidden inside if not permitted)
            var session = AppServices.Get<AppSessionService>();
            if (session is not null && !session.CanView)
            {
                await DisplayAlert("Access Denied", "You do not have permission to view inventory records.", "OK");
                return;
            }

            _inventoryEditPage ??= AppServices.GetRequired<Pages.InventoryItemEditPage>();

            _inventoryEditPage.InventoryId = inventoryId;

            _inventoryEditPage.BackRequested -= OnEditBackRequested;
            _inventoryEditPage.BackRequested += OnEditBackRequested;

            _inventoryEditPage.Saved -= OnEditSaved;
            _inventoryEditPage.Saved += OnEditSaved;

            _activeKey = InventoryEditKey;
            PushBreadcrumb(InventoryEditKey, _inventoryEditPage);
            SetMainHostContent(_inventoryEditPage);

            await Task.CompletedTask;
        });
    }

    private void OnEditSaved(int inventoryId)
    {
        _ = MainThread.InvokeOnMainThreadAsync(async () =>
        {
            var listVm = GetInventoryListVm();
            if (listVm is null)
                return;

            SetBusy(true, "Working...");
            try
            {
                await listVm.RefreshEditedRowAsync(inventoryId);
            }
            finally
            {
                SetBusy(listVm.IsBusy);
            }
        });
    }

    private void OnEditBackRequested(object? sender, EventArgs e)
    {
        if (_inventoryListView is null)
            return;

        var editedId = (sender as Pages.InventoryItemEditPage)?.LastLoadedId ?? 0;

        _ = MainThread.InvokeOnMainThreadAsync(async () =>
        {
            var found = false;
            for (var i = _breadcrumbTrail.Count - 1; i >= 0; i--)
            {
                if (_breadcrumbTrail[i].Key == InventoryListKey)
                {
                    NavigateToBreadcrumb(i);
                    found = true;
                    break;
                }
            }

            if (!found)
                await ActivateAsync(InventoryListKey);

            var listVm = GetInventoryListVm();

            if (editedId > 0 && listVm is not null)
            {
                var row = listVm.Rows?.FirstOrDefault(r => r.InventoryID == editedId);
                if (row is not null)
                    listVm.SelectedRow = row;
            }

            SetBusy(listVm?.IsBusy ?? false);
        });
    }

    private void InventoryViewOnLoaded(object? sender, EventArgs e)
    {
        var listVm = GetInventoryListVm();
        if (_activeKey == InventoryListKey && listVm is not null)
            SetBusy(listVm.IsBusy);
    }

    private void InventoryViewOnUnloaded(object? sender, EventArgs e)
    {
        SetBusy(false);
    }

    private void OnNavGroupHeaderTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is not NavGroup group)
            return;

        group.Toggle();

        NavList.ItemsSource = null;
        NavList.ItemsSource = _items;
    }
}

public sealed record NavigationItem(string Title, String Subtitle, String Icon);
