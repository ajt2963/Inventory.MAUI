using System.Collections.ObjectModel;
using Inventory.MAUI.Models;
using Inventory.MAUI.Services;

namespace Inventory.MAUI.ViewModels;

public sealed class InventoryItemEditViewModel : ViewModelBase
{
    private readonly IInventoryItemService _service;
    private readonly IAppSessionService? _session;

    private bool _isBusy;
    private InventoryItem? _original;
    private InventoryItem? _item;

    private AssetOwner? _selectedOwner;
    private AssetType? _selectedType;
    private Category? _selectedCategory;
    private Companies? _selectedCompany;
    private Locations? _selectedLocation;
    private InventoryStorage? _selectedStorage;

    private bool _markForDeletion;

    private Notes? _notes;
    private string? _notesText;

    private bool _isDirty;
    private bool _hasAttemptedSave;

    private bool _suppressChangeTracking;

    public event Action<int>? Saved;

    public InventoryItemEditViewModel(IInventoryItemService service, IAppSessionService session)
    {
        _service = service;
        _session = session;

        Owners = [];
        Types = [];
        Categories = [];
        Companies = [];
        Locations = [];
        Storages = [];

        SaveCommand = new Command(async () => await SaveAsync(), () => !IsBusy && Item is not null && HasEditPermission);
        CancelCommand = new Command(async () => await CancelAsync(), () => !IsBusy);
        DeleteCommand = new Command(async () => await DeleteAsync(), () => !IsBusy && MarkForDeletion && Item?.InventoryID is not null && HasDeletePermission);
    }

    /// <summary>True if the current session has CanEdit permission.</summary>
    public bool HasEditPermission => _session?.CanEdit ?? false;

    /// <summary>True if the current session has CanDelete permission.</summary>
    public bool HasDeletePermission => _session?.CanDelete ?? false;

    public bool IsBusy
    {
        get => _isBusy;
        private set
        {
            if (SetProperty(ref _isBusy, value))
                RaiseAllCanExecuteChanged();
        }
    }

    public bool IsDirty
    {
        get => _isDirty;
        private set => SetProperty(ref _isDirty, value);
    }

    public bool HasAttemptedSave
    {
        get => _hasAttemptedSave;
        private set => SetProperty(ref _hasAttemptedSave, value);
    }

    private bool _isPartNumberInvalid;
    public bool IsPartNumberInvalid { get => _isPartNumberInvalid; private set => SetProperty(ref _isPartNumberInvalid, value); }

    private bool _isOwnerInvalid;
    public bool IsOwnerInvalid { get => _isOwnerInvalid; private set => SetProperty(ref _isOwnerInvalid, value); }

    private bool _isCategoryInvalid;
    public bool IsCategoryInvalid { get => _isCategoryInvalid; private set => SetProperty(ref _isCategoryInvalid, value); }

    private bool _isTypeInvalid;
    public bool IsTypeInvalid { get => _isTypeInvalid; private set => SetProperty(ref _isTypeInvalid, value); }

    private bool _isCompanyInvalid;
    public bool IsCompanyInvalid { get => _isCompanyInvalid; private set => SetProperty(ref _isCompanyInvalid, value); }

    private bool _isLocationInvalid;
    public bool IsLocationInvalid { get => _isLocationInvalid; private set => SetProperty(ref _isLocationInvalid, value); }

    private bool _isStorageInvalid;
    public bool IsStorageInvalid { get => _isStorageInvalid; private set => SetProperty(ref _isStorageInvalid, value); }

    private void MarkDirty()
    {
        if (_suppressChangeTracking)
            return;

        if (!IsBusy)
            IsDirty = true;
    }

    public void MarkClean() => IsDirty = false;

    public InventoryItem? Item
    {
        get => _item;
        private set
        {
            if (SetProperty(ref _item, value))
                RaiseAllCanExecuteChanged();
        }
    }

    public ObservableCollection<AssetOwner> Owners { get; }
    public ObservableCollection<AssetType> Types { get; }
    public ObservableCollection<Category> Categories { get; }
    public ObservableCollection<Companies> Companies { get; }
    public ObservableCollection<Locations> Locations { get; }
    public ObservableCollection<InventoryStorage> Storages { get; }

    public AssetOwner? SelectedOwner
    {
        get => _selectedOwner;
        set
        {
            if (SetProperty(ref _selectedOwner, value))
            {
                if (Item is not null)
                    Item.OwnerID = value?.OwnerID;
                MarkDirty();
                if (!_suppressChangeTracking && HasAttemptedSave) ValidateAndUpdateFlags();
            }
        }
    }

    public AssetType? SelectedType
    {
        get => _selectedType;
        set
        {
            if (SetProperty(ref _selectedType, value))
            {
                if (Item is not null)
                    Item.TypeID = value?.TypeID;
                MarkDirty();
                if (!_suppressChangeTracking && HasAttemptedSave) ValidateAndUpdateFlags();
            }
        }
    }

    public Category? SelectedCategory
    {
        get => _selectedCategory;
        set
        {
            if (SetProperty(ref _selectedCategory, value))
            {
                if (Item is not null)
                    Item.CatID = value?.CatID;
                MarkDirty();
                if (!_suppressChangeTracking && HasAttemptedSave) ValidateAndUpdateFlags();
            }
        }
    }

    public Companies? SelectedCompany
    {
        get => _selectedCompany;
        set
        {
            if (SetProperty(ref _selectedCompany, value))
            {
                if (Item is not null)
                    Item.CompanyID = value?.CompanyID;
                MarkDirty();
                if (!_suppressChangeTracking && HasAttemptedSave) ValidateAndUpdateFlags();
            }
        }
    }

    public Locations? SelectedLocation
    {
        get => _selectedLocation;
        set
        {
            if (SetProperty(ref _selectedLocation, value))
            {
                if (Item is not null)
                    Item.LocationID = value?.LocationID;
                MarkDirty();
                if (!_suppressChangeTracking && HasAttemptedSave) ValidateAndUpdateFlags();
            }
        }
    }

    public InventoryStorage? SelectedStorage
    {
        get => _selectedStorage;
        set
        {
            if (SetProperty(ref _selectedStorage, value))
            {
                if (Item is not null)
                    Item.StorageID = value?.StorageID;
                MarkDirty();
                if (!_suppressChangeTracking && HasAttemptedSave) ValidateAndUpdateFlags();
            }
        }
    }

    public bool MarkForDeletion
    {
        get => _markForDeletion;
        set
        {
            if (SetProperty(ref _markForDeletion, value))
            {
                MarkDirty();
                RaiseAllCanExecuteChanged();
                OnPropertyChanged(nameof(CanDelete));
            }
        }
    }

    public bool CanDelete => HasDeletePermission;

    public Command SaveCommand { get; }
    public Command CancelCommand { get; }
    public Command DeleteCommand { get; }

    public string? NotesText
    {
        get => _notesText;
        set
        {
            if (SetProperty(ref _notesText, value))
                MarkDirty();
        }
    }

    private string? _assetTag;
    public string? AssetTag
    {
        get => _assetTag;
        private set => SetProperty(ref _assetTag, value);
    }

    private static InventoryItem? Clone(InventoryItem? src)
    {
        if (src is null)
            return null;

        return new InventoryItem
        {
            InventoryID = src.InventoryID,
            PartNumber = src.PartNumber,
            SerialNumber = src.SerialNumber,
            Description = src.Description,
            Quantity = src.Quantity,
            BatteryType = src.BatteryType,
            AssetID = src.AssetID,
            OwnerID = src.OwnerID,
            TypeID = src.TypeID,
            CatID = src.CatID,
            CompanyID = src.CompanyID,
            NotesID = src.NotesID,
            StorageID = src.StorageID,
            LocationID = src.LocationID,
            DateModified = src.DateModified,
            ModifiedBy = src.ModifiedBy,
            IsDeleted = src.IsDeleted,
            DeletedAt = src.DeletedAt,
            DeletedBy = src.DeletedBy,
        };
    }

    private void RaiseAllCanExecuteChanged()
    {
        SaveCommand.ChangeCanExecute();
        CancelCommand.ChangeCanExecute();
        DeleteCommand.ChangeCanExecute();
    }

    public Func<string, string, Task<bool>>? ConfirmAsync { get; set; }
    public Func<string, Task>? ToastAsync { get; set; }

    private async Task SaveAsync()
    {
        if (Item is null)
            return;

        HasAttemptedSave = true;
        var errors = ValidateAndUpdateFlags();
        if (errors.Count > 0)
        {
            if (ToastAsync is not null)
                await ToastAsync(string.Join("\n", errors));
            return;
        }

        if (!IsDirty)
        {
            if (ToastAsync is not null)
                await ToastAsync("No changes to save.");
            return;
        }

        if (ConfirmAsync is not null)
        {
            var ok = await ConfirmAsync("Save changes?", "This will update the record in the database.");
            if (!ok)
                return;
        }

        IsBusy = true;
        try
        {
            await _service.UpdateAsync(Item, modifiedBy: _session?.DisplayName ?? Environment.UserName, NotesText);

            var id = Item.InventoryID ?? 0;
            _original = id > 0 ? await _service.GetByIdAsync(id) : null;
            _notes = _original?.Notes;
            AssetTag = _original?.Asset?.AssetTag;

            _suppressChangeTracking = true;
            try
            {
                NotesText = _notes?.InventoryNotes;

                Item = Clone(_original);
                SyncSelectionsFromItem();
                MarkForDeletion = false;
                MarkClean();
            }
            finally
            {
                _suppressChangeTracking = false;
            }

            if (ToastAsync is not null)
                await ToastAsync("Saved.");

            if (id > 0)
                Saved?.Invoke(id);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task CancelAsync()
    {
        if (ConfirmAsync is not null)
        {
            var ok = await ConfirmAsync("Cancel changes?", "Your unsaved changes will be discarded.");
            if (!ok)
                return;
        }

        _suppressChangeTracking = true;
        try
        {
            Item = Clone(_original);
            _notes = _original?.Notes;
            NotesText = _notes?.InventoryNotes;

            SyncSelectionsFromItem();
            MarkForDeletion = false;
            MarkClean();
        }
        finally
        {
            _suppressChangeTracking = false;
        }

        if (ToastAsync is not null)
            await ToastAsync("Canceled.");
    }

    private async Task DeleteAsync()
    {
        if (ToastAsync is not null)
            await ToastAsync("Delete is not supported for this Access schema.");
    }

    private void SyncSelectionsFromItem()
    {
        if (Item is null)
            return;

        SelectedOwner = Owners.FirstOrDefault(o => o.OwnerID == Item.OwnerID);
        SelectedType = Types.FirstOrDefault(t => t.TypeID == Item.TypeID);
        SelectedCategory = Categories.FirstOrDefault(c => c.CatID == Item.CatID);
        SelectedCompany = Companies.FirstOrDefault(c => c.CompanyID == Item.CompanyID);
        SelectedLocation = Locations.FirstOrDefault(l => l.LocationID == Item.LocationID);
        SelectedStorage = Storages.FirstOrDefault(s => s.StorageID == Item.StorageID);
    }

    public async Task LoadAsync(int inventoryId) => await LoadAsync(inventoryId, CancellationToken.None);

    public async Task LoadAsync(int inventoryId, CancellationToken cancellationToken)
    {
        if (IsBusy)
            return;

        var invId = inventoryId;

        IsBusy = true;
        try
        {
            cancellationToken.ThrowIfCancellationRequested();

            var lookups = await _service.GetLookupsAsync();
            cancellationToken.ThrowIfCancellationRequested();

            Owners.Clear(); foreach (var x in lookups.Owners) Owners.Add(x);
            Types.Clear(); foreach (var x in lookups.Types) Types.Add(x);
            Categories.Clear(); foreach (var x in lookups.Categories) Categories.Add(x);
            Companies.Clear(); foreach (var x in lookups.Companies) Companies.Add(x);
            Locations.Clear(); foreach (var x in lookups.Locations) Locations.Add(x);
            Storages.Clear(); foreach (var x in lookups.Storages) Storages.Add(x);

            cancellationToken.ThrowIfCancellationRequested();

            _original = await _service.GetByIdAsync(invId);
            cancellationToken.ThrowIfCancellationRequested();

            _notes = _original?.Notes;
            AssetTag = _original?.Asset?.AssetTag;

            _suppressChangeTracking = true;
            try
            {
                HasAttemptedSave = false;
                ValidateAndUpdateFlags();

                NotesText = _notes?.InventoryNotes;

                Item = Clone(_original);
                MarkForDeletion = false;

                SyncSelectionsFromItem();
                MarkClean();
            }
            finally
            {
                _suppressChangeTracking = false;
            }
        }
        finally
        {
            IsBusy = false;
        }
    }

    private List<string> ValidateAndUpdateFlags()
    {
        var errors = new List<string>();

        IsPartNumberInvalid = HasAttemptedSave && (Item is null || string.IsNullOrWhiteSpace(Item.PartNumber));
        IsOwnerInvalid = HasAttemptedSave && SelectedOwner is null;
        IsCategoryInvalid = HasAttemptedSave && SelectedCategory is null;
        IsTypeInvalid = HasAttemptedSave && SelectedType is null;
        IsCompanyInvalid = HasAttemptedSave && SelectedCompany is null;
        IsLocationInvalid = HasAttemptedSave && SelectedLocation is null;
        IsStorageInvalid = HasAttemptedSave && SelectedStorage is null;

        if (IsPartNumberInvalid) errors.Add("Part Number is required.");
        if (IsOwnerInvalid) errors.Add("Owner is required.");
        if (IsCategoryInvalid) errors.Add("Category is required.");
        if (IsTypeInvalid) errors.Add("Asset Type is required.");
        if (IsCompanyInvalid) errors.Add("Company is required.");
        if (IsLocationInvalid) errors.Add("Location is required.");
        if (IsStorageInvalid) errors.Add("Storage is required.");

        return errors;
    }
}