using System.Collections.ObjectModel;
using System.Windows.Input;
using Inventory.MAUI.Core.ViewModels;
using Inventory.MAUI.Models;
using Inventory.MAUI.Services;

namespace Inventory.MAUI.ViewModels;

public sealed class CalibrationCompletionViewModel : ViewModelBase
{
    private readonly ICalibrationService _service;
    private readonly IAppSessionService _session;

    public CalibrationCompletionViewModel(ICalibrationService service, IAppSessionService session)
    {
        _service = service;
        _session = session;

        CompleteCommand = new AsyncCommand(CompleteAsync, () => !IsBusy && SelectedCount > 0);
        RefreshCommand = new AsyncCommand(LoadAsync);
        SelectAllCommand = new Command(() => SetAllSelected(true));
        SelectNoneCommand = new Command(() => SetAllSelected(false));
        SearchCommand = new Command(ApplyFilter);
        ClearSearchCommand = new Command(() => { SearchText = string.Empty; ApplyFilter(); });
        MoveFirstCommand = new Command(MoveFirst, () => LocationItems.Count > 0);
        MovePreviousCommand = new Command(MovePrevious, () => _focusedIndex > 0);
        MoveNextCommand = new Command(MoveNext, () => _focusedIndex < LocationItems.Count - 1);
        MoveLastCommand = new Command(MoveLast, () => LocationItems.Count > 0);
    }

    /// <summary>Shows an informational dialog (title, message). OK only.</summary>
    public Func<string, string, Task>? AlertAsync { get; set; }

    /// <summary>Shows a confirmation dialog. Returns true if user accepts.</summary>
    public Func<string, string, string, string, Task<bool>>? ConfirmAsync { get; set; }

    // --- Collections ---
    public ObservableCollection<ScheduledLocationGroup> LocationGroups { get; } = [];
    public ObservableCollection<CalibrationSchedule> LocationItems { get; } = [];

    // --- Selected values ---
    private ScheduledLocationGroup? _selectedLocationGroup;
    public ScheduledLocationGroup? SelectedLocationGroup
    {
        get => _selectedLocationGroup;
        set
        {
            if (SetProperty(ref _selectedLocationGroup, value))
                _ = LoadLocationItemsAsync();
        }
    }

    private DateTime _completionDate = DateTime.Today;
    public DateTime CompletionDate
    {
        get => _completionDate;
        set => SetProperty(ref _completionDate, value);
    }

    // --- Search ---
    private string _searchText = string.Empty;
    public string SearchText
    {
        get => _searchText;
        set => SetProperty(ref _searchText, value);
    }

    // --- Navigation ---
    private int _focusedIndex = -1;
    public int FocusedIndex => _focusedIndex;

    private string? _positionText;
    public string? PositionText { get => _positionText; private set => SetProperty(ref _positionText, value); }

    public event Action<int>? FocusedIndexChanged;

    // --- State ---
    private bool _isBusy;
    public bool IsBusy
    {
        get => _isBusy;
        private set
        {
            if (SetProperty(ref _isBusy, value))
                CompleteCommand.RaiseCanExecuteChanged();
        }
    }

    private string? _statusText;
    public string? StatusText { get => _statusText; private set => SetProperty(ref _statusText, value); }

    private int _selectedCount;
    public int SelectedCount
    {
        get => _selectedCount;
        private set
        {
            if (SetProperty(ref _selectedCount, value))
                CompleteCommand.RaiseCanExecuteChanged();
        }
    }

    // --- Commands ---
    public AsyncCommand CompleteCommand { get; }
    public AsyncCommand RefreshCommand { get; }
    public ICommand SelectAllCommand { get; }
    public ICommand SelectNoneCommand { get; }
    public Command SearchCommand { get; }
    public Command ClearSearchCommand { get; }
    public Command MoveFirstCommand { get; }
    public Command MovePreviousCommand { get; }
    public Command MoveNextCommand { get; }
    public Command MoveLastCommand { get; }

    public async Task LoadAsync()
    {
        IsBusy = true;
        StatusText = "Loading scheduled locations...";
        try
        {
            var groups = await _service.GetScheduledLocationsAsync();
            LocationGroups.Clear();
            foreach (var g in groups) LocationGroups.Add(g);

            LocationItems.Clear();
            SelectedLocationGroup = null;
            SelectedCount = 0;

            StatusText = groups.Count > 0
                ? $"{groups.Count} location(s) with pending calibration."
                : "No pending calibration schedules found.";
        }
        catch (Exception ex)
        {
            StatusText = "Failed to load schedules.";
            await ShowAlert("Error", ex.Message);
        }
        finally
        {
            IsBusy = false;
        }
    }

    // --- All items (unfiltered) for search ---
    private List<CalibrationSchedule> _allLocationItems = [];

    private async Task LoadLocationItemsAsync()
    {
        LocationItems.Clear();
        _allLocationItems = [];
        SelectedCount = 0;
        SearchText = string.Empty;
        if (SelectedLocationGroup is null)
            return;

        try
        {
            var items = await _service.GetSchedulesByLocationAsync(SelectedLocationGroup.ClliCode);
            _allLocationItems = items;
            WireSelectionTracking(items);
            foreach (var item in items) LocationItems.Add(item);
            StatusText = $"{items.Count} item(s) at {SelectedLocationGroup.LocationName}.";

            SetFocusedIndex(items.Count > 0 ? 0 : -1);
        }
        catch (Exception ex)
        {
            await ShowAlert("Error", $"Failed to load items: {ex.Message}");
        }
    }

    private void WireSelectionTracking(IReadOnlyList<CalibrationSchedule> items)
    {
        foreach (var item in items)
            item.PropertyChanged += (_, e) =>
            {
                if (e.PropertyName == nameof(CalibrationSchedule.IsSelected))
                    UpdateSelectedCount();
            };
    }

    private async Task CompleteAsync()
    {
        var selected = LocationItems.Where(i => i.IsSelected).ToList();
        if (selected.Count == 0)
        {
            await ShowAlert("No Selection", "Please select at least one item to complete.");
            return;
        }

        var locName = SelectedLocationGroup is not null
            ? $"{SelectedLocationGroup.LocationName} ({SelectedLocationGroup.ClliCode})"
            : "selected location";

        // Confirm with user
        if (ConfirmAsync is not null)
        {
            var proceed = await ConfirmAsync(
                "Confirm Completion",
                $"Mark {selected.Count} item(s) at {locName} as calibrated on {CompletionDate:MM/dd/yyyy}?\n\nCompleted items will be removed from the schedule.",
                "Complete",
                "Cancel");
            if (!proceed)
                return;
        }

        IsBusy = true;
        StatusText = $"Completing {selected.Count} item(s)...";
        try
        {
            var modifiedBy = _session.DisplayName ?? "Unknown";
            await _service.CompleteCalibrationAsync(
                CompletionDate,
                selected,
                modifiedBy);

            await ShowAlert("Completion Successful", $"{selected.Count} item(s) at {locName} marked as calibrated on {CompletionDate:MM/dd/yyyy}.");

            // Reload the location items (some may remain if not all were selected)
            if (SelectedLocationGroup is not null)
            {
                var remaining = await _service.GetSchedulesByLocationAsync(SelectedLocationGroup.ClliCode);
                if (remaining.Count > 0)
                {
                    _allLocationItems = remaining;
                    LocationItems.Clear();
                    SelectedCount = 0;
                    SearchText = string.Empty;
                    WireSelectionTracking(remaining);
                    foreach (var item in remaining) LocationItems.Add(item);
                    StatusText = $"{selected.Count} completed. {remaining.Count} item(s) remaining.";
                    SetFocusedIndex(0);
                }
                else
                {
                    StatusText = $"All items at {locName} completed.";
                    await LoadAsync();
                }
            }
            else
            {
                await LoadAsync();
            }
        }
        catch (Exception ex)
        {
            StatusText = "Completion failed.";
            await ShowAlert("Completion Failed", ex.Message);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private void SetAllSelected(bool selected)
    {
        foreach (var item in LocationItems)
            item.IsSelected = selected;
    }

    private void UpdateSelectedCount()
    {
        SelectedCount = LocationItems.Count(i => i.IsSelected);
    }

    // ?? Search ???????????????????????????????????????????????????????
    private void ApplyFilter()
    {
        var filtered = InMemorySearchFilter.Apply(_allLocationItems, SearchText, GetSearchFields);

        LocationItems.Clear();
        foreach (var item in filtered) LocationItems.Add(item);
        UpdateSelectedCount();
        SetFocusedIndex(LocationItems.Count > 0 ? 0 : -1);
    }

    private static IEnumerable<string?> GetSearchFields(CalibrationSchedule row) =>
    [
        row.ManufacturerName, row.PartNumber, row.SerialNumber,
        row.Description, row.CalLabel, row.CalNotes,
        row.AssetTag, row.InventoryID?.ToString()
    ];

    // ?? Navigation ???????????????????????????????????????????????????
    private void SetFocusedIndex(int value)
    {
        if (_focusedIndex == value) return;
        _focusedIndex = value;
        OnPropertyChanged(nameof(FocusedIndex));
        UpdatePositionText();
        RaiseNavCanExecuteChanged();
        FocusedIndexChanged?.Invoke(_focusedIndex);
    }

    private void UpdatePositionText()
    {
        PositionText = LocationItems.Count == 0
            ? "No items"
            : $"Item {_focusedIndex + 1} of {LocationItems.Count}";
    }

    private void RaiseNavCanExecuteChanged()
    {
        MoveFirstCommand.ChangeCanExecute();
        MovePreviousCommand.ChangeCanExecute();
        MoveNextCommand.ChangeCanExecute();
        MoveLastCommand.ChangeCanExecute();
    }

    private void MoveFirst()
    {
        if (LocationItems.Count > 0) SetFocusedIndex(0);
    }

    private void MovePrevious()
    {
        if (_focusedIndex > 0) SetFocusedIndex(_focusedIndex - 1);
    }

    private void MoveNext()
    {
        if (_focusedIndex < LocationItems.Count - 1) SetFocusedIndex(_focusedIndex + 1);
    }

    private void MoveLast()
    {
        if (LocationItems.Count > 0) SetFocusedIndex(LocationItems.Count - 1);
    }

    private async Task ShowAlert(string title, string message)
    {
        if (AlertAsync is null) return;
        try { await AlertAsync(title, message); } catch { }
    }
}
