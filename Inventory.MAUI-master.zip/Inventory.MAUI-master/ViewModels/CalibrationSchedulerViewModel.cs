using System.Collections.ObjectModel;
using System.Windows.Input;
#if !ANDROID
using ClosedXML.Excel;
#endif
using Inventory.MAUI.Core.ViewModels;
using Inventory.MAUI.Models;
using Inventory.MAUI.Services;

namespace Inventory.MAUI.ViewModels;

public sealed class CalibrationSchedulerViewModel : ViewModelBase
{
    private readonly ICalibrationService _service;
    private readonly IAppSessionService _session;

#if !ANDROID
    private CalibrationExcelBuilder? _excelBuilder;
#endif

    public CalibrationSchedulerViewModel(ICalibrationService service, IAppSessionService session)
    {
        _service = service;
        _session = session;

        LoadItemsCommand = new AsyncCommand(LoadItemsAsync, () => !IsBusy && SelectedLocation is not null);
        SaveScheduleCommand = new AsyncCommand(SaveScheduleAsync, () => !IsBusy);
#if !ANDROID
        ExportExcelCommand = new AsyncCommand(ExportExcelAsync, () => !IsBusy);
#endif
        SelectAllCommand = new Command(() => SetAllSelected(true));
        SelectNoneCommand = new Command(() => SetAllSelected(false));
        SelectEligibleCommand = new Command(SelectEligible);
        SearchCommand = new Command(ApplyFilter);
        ClearSearchCommand = new Command(() => { SearchText = string.Empty; ApplyFilter(); });
        MoveFirstCommand = new Command(MoveFirst, () => Items.Count > 0);
        MovePreviousCommand = new Command(MovePrevious, () => _focusedIndex > 0);
        MoveNextCommand = new Command(MoveNext, () => _focusedIndex < Items.Count - 1);
        MoveLastCommand = new Command(MoveLast, () => Items.Count > 0);
    }

    public event Action? ScheduleSaved;

    /// <summary>Shows an informational dialog (title, message). OK only.</summary>
    public Func<string, string, Task>? AlertAsync { get; set; }

    /// <summary>Shows a confirmation dialog. Returns true if user accepts.</summary>
    public Func<string, string, string, string, Task<bool>>? ConfirmAsync { get; set; }

    /// <summary>Shows an action sheet with multiple choices. Returns the selected option string.</summary>
    public Func<string, string, string, string[], Task<string>>? ActionSheetAsync { get; set; }

    /// <summary>Opens a file save picker and returns the chosen path, or null if cancelled.</summary>
    public Func<Task<string?>>? PickSaveFileAsync { get; set; }

    // --- Collections ---
    public ObservableCollection<Locations> Locations { get; } = [];
    public ObservableCollection<Companies> ServiceProviders { get; } = [];
    public ObservableCollection<CalibrationItemRow> Items { get; } = [];

    // --- Selected values ---
    private Locations? _selectedLocation;
    public Locations? SelectedLocation
    {
        get => _selectedLocation;
        set
        {
            if (SetProperty(ref _selectedLocation, value))
                RaiseCommandCanExecute();
        }
    }

    private Companies? _selectedServiceProvider;
    public Companies? SelectedServiceProvider
    {
        get => _selectedServiceProvider;
        set
        {
            if (SetProperty(ref _selectedServiceProvider, value))
                RaiseCommandCanExecute();
        }
    }

    private DateTime _scheduledDate = DateTime.Today;
    public DateTime ScheduledDate
    {
        get => _scheduledDate;
        set => SetProperty(ref _scheduledDate, value);
    }

    private bool _filterEligibleOnly;
    public bool FilterEligibleOnly
    {
        get => _filterEligibleOnly;
        set
        {
            if (SetProperty(ref _filterEligibleOnly, value))
                ApplyFilter();
        }
    }

    private string _searchText = string.Empty;
    public string SearchText
    {
        get => _searchText;
        set => SetProperty(ref _searchText, value);
    }

    // --- State ---
    private bool _isBusy;
    public bool IsBusy
    {
        get => _isBusy;
        private set
        {
            if (SetProperty(ref _isBusy, value))
                RaiseCommandCanExecute();
        }
    }

    private string? _statusText;
    public string? StatusText { get => _statusText; private set => SetProperty(ref _statusText, value); }

    private int _selectedCount;
    public int SelectedCount { get => _selectedCount; private set => SetProperty(ref _selectedCount, value); }

    // --- Navigation ---
    private int _focusedIndex = -1;
    public int FocusedIndex => _focusedIndex;

    private string? _positionText;
    public string? PositionText { get => _positionText; private set => SetProperty(ref _positionText, value); }

    public event Action<int>? FocusedIndexChanged;

    // --- Commands ---
    public AsyncCommand LoadItemsCommand { get; }
    public AsyncCommand SaveScheduleCommand { get; }
#if !ANDROID
    public AsyncCommand ExportExcelCommand { get; }
#endif
    public ICommand SelectAllCommand { get; }
    public ICommand SelectNoneCommand { get; }
    public ICommand SelectEligibleCommand { get; }
    public Command SearchCommand { get; }
    public Command ClearSearchCommand { get; }
    public Command MoveFirstCommand { get; }
    public Command MovePreviousCommand { get; }
    public Command MoveNextCommand { get; }
    public Command MoveLastCommand { get; }

    // --- All items (unfiltered) ---
    private List<CalibrationItemRow> _allItems = [];

    public async Task InitializeAsync()
    {
        if (Locations.Count > 0)
            return;

        IsBusy = true;
        StatusText = "Loading lookups...";
        try
        {
            var locations = await _service.GetLocationsAsync();
            Locations.Clear();
            foreach (var loc in locations) Locations.Add(loc);

            var providers = await _service.GetServiceProvidersAsync();
            ServiceProviders.Clear();
            foreach (var p in providers) ServiceProviders.Add(p);

            StatusText = "Ready - select a location to load equipment.";
        }
        catch (Exception ex)
        {
            StatusText = "Failed to load lookups.";
            await ShowAlert("Error", ex.Message);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task LoadItemsAsync()
    {
        if (SelectedLocation?.LocationID is not { } locId)
            return;

        IsBusy = true;
        StatusText = $"Loading items for {SelectedLocation.LocationName}...";
        SearchText = string.Empty;
        try
        {
            _allItems = await _service.GetItemsByLocationAsync(locId);

            // Wire selection change tracking
            foreach (var item in _allItems)
                item.PropertyChanged += (_, e) =>
                {
                    if (e.PropertyName == nameof(CalibrationItemRow.IsSelected))
                    {
                        UpdateSelectedCount();
                        RaiseCommandCanExecute();
                    }
                };

            ApplyFilter();
            StatusText = $"{_allItems.Count} items loaded. {_allItems.Count(i => i.IsCalibrationEligible)} eligible.";
        }
        catch (Exception ex)
        {
            StatusText = "Failed to load items.";
            await ShowAlert("Error", ex.Message);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task SaveScheduleAsync()
    {
        // Validate required fields
        var missing = new List<string>();
        if (SelectedLocation is null)
            missing.Add("Location");
        if (SelectedServiceProvider is null)
            missing.Add("Service Provider");
        if (!Items.Any(i => i.IsSelected))
            missing.Add("at least one selected item");

        if (missing.Count > 0)
        {
            await ShowAlert("Cannot Save Schedule",
                $"Please provide the following before saving:\n\n� {string.Join("\n� ", missing)}");
            return;
        }

        // Confirm before saving
        if (ConfirmAsync is not null)
        {
            var proceed = await ConfirmAsync(
                "Confirm Save",
                $"Schedule {SelectedCount} item(s) at {SelectedLocation!.LocationName} for calibration on {ScheduledDate:MM/dd/yyyy} with {SelectedServiceProvider!.CompanyName}?",
                "Save",
                "Cancel");
            if (!proceed)
                return;
        }

        var selected = Items.Where(i => i.IsSelected).ToList();

        IsBusy = true;
        StatusText = "Saving schedule...";
        try
        {
            var modifiedBy = _session.DisplayName ?? "Unknown";

            await _service.SaveScheduleAsync(
                selected,
                ScheduledDate,
                SelectedServiceProvider!,
                SelectedLocation!,
                modifiedBy);

            // Append to Excel workbook for this session
#if !ANDROID
            _excelBuilder ??= new CalibrationExcelBuilder();
            _excelBuilder.AddLocationSheet(
                SelectedLocation!.LocationName ?? "Unknown",
                SelectedLocation!.ClliCode ?? "Unknown",
                ScheduledDate,
                SelectedServiceProvider!.CompanyName,
                selected);
#endif

            RaiseCommandCanExecute();

            StatusText = $"Saved {selected.Count} items for {SelectedLocation!.LocationName}.";
            await ShowAlert("Schedule Saved", $"{selected.Count} item(s) scheduled for calibration at {SelectedLocation!.LocationName}.");

            ScheduleSaved?.Invoke();
        }
        catch (Exception ex)
        {
            StatusText = "Save failed.";
            await ShowAlert("Save Failed", ex.Message);
        }
        finally
        {
            IsBusy = false;
        }
    }

#if !ANDROID
    private async Task ExportExcelAsync()
    {
        if (_excelBuilder is null)
        {
            // Determine what's missing to help the user
            var missing = new List<string>();
            if (SelectedLocation is null)
                missing.Add("Location");
            if (SelectedServiceProvider is null)
                missing.Add("Service Provider");
            if (!Items.Any(i => i.IsSelected))
                missing.Add("at least one selected item");

            var reason = missing.Count > 0
                ? $"No schedule has been saved yet. Please provide the following:\n\n� {string.Join("\n� ", missing)}\n\nThen click Save Schedule before exporting."
                : "No schedule has been saved yet. Click Save Schedule first, then export.";

            await ShowAlert("Nothing to Export", reason);
            return;
        }

        try
        {
            var filePath = PickSaveFileAsync is not null ? await PickSaveFileAsync() : null;
            if (string.IsNullOrWhiteSpace(filePath))
                return;

            // Ensure directory exists
            var dir = Path.GetDirectoryName(filePath);
            if (!string.IsNullOrEmpty(dir))
                Directory.CreateDirectory(dir);

            if (File.Exists(filePath))
            {
                if (ActionSheetAsync is null)
                    return;

                var choice = await ActionSheetAsync(
                    $"'{Path.GetFileName(filePath)}' already exists. What would you like to do?",
                    "Cancel export",
                    null!,
                    [
                        "Append - Add new location sheet(s) to the existing file",
                        "Overwrite - Replace the file with only the current schedule"
                    ]);

                if (choice is not null && choice.StartsWith("Append"))
                {
                    // A 0-byte file is not a valid Excel workbook (the save picker may
                    // create an empty placeholder). Treat it as a fresh save instead.
                    var fileInfo = new FileInfo(filePath);
                    if (fileInfo.Length == 0)
                    {
                        _excelBuilder.SaveTo(filePath);
                        StatusText = $"Excel saved to {filePath}";
                        await ShowAlert("Export Successful",
                            $"The selected file was empty and has been replaced with the current schedule:\n{filePath}");
                    }
                    else
                    {
                        // Save the current session workbook to a memory stream to avoid
                        // temp-file issues (stale handles, zero-byte files, packaging errors).
                        using var sessionStream = new MemoryStream();
                        _excelBuilder.SaveTo(sessionStream);
                        sessionStream.Position = 0;

                        using var sessionWb = new XLWorkbook(sessionStream);
                        using var existingWb = new XLWorkbook(filePath);

                        var added = 0;
                        foreach (var ws in sessionWb.Worksheets)
                        {
                            var sheetName = ws.Name;
                            var baseName = sheetName;
                            var counter = 1;
                            while (existingWb.Worksheets.Any(ews => ews.Name == sheetName))
                            {
                                sheetName = $"{baseName}_{counter++}";
                                if (sheetName.Length > 31)
                                    sheetName = sheetName[..31];
                            }
                            ws.CopyTo(existingWb, sheetName);
                            added++;
                        }

                        // Save to a temp file first, then replace the target � ClosedXML
                        // cannot SaveAs back to the same file it was opened from.
                        var tempPath = Path.Combine(Path.GetTempPath(), $"CalSchedule_temp_{Guid.NewGuid():N}.xlsx");
                        try
                        {
                            existingWb.SaveAs(tempPath);
                            File.Copy(tempPath, filePath, overwrite: true);
                        }
                        finally
                        {
                            try { File.Delete(tempPath); } catch { }
                        }

                        StatusText = $"Appended {added} sheet(s) to {filePath}";
                        await ShowAlert("Export Successful",
                            $"{added} new location sheet(s) appended to:\n{filePath}");
                    }
                }
                else if (choice is not null && choice.StartsWith("Overwrite"))
                {
                    _excelBuilder.SaveTo(filePath);
                    StatusText = $"File overwritten: {filePath}";
                    await ShowAlert("Export Successful",
                        $"File has been overwritten with the current schedule:\n{filePath}");
                }
                else
                {
                    return;
                }
            }
            else
            {
                _excelBuilder.SaveTo(filePath);
                StatusText = $"Excel saved to {filePath}";
                await ShowAlert("Export Successful", $"Workbook saved to:\n{filePath}");
            }
        }
        catch (Exception ex)
        {
            await ShowAlert("Export Failed", ex.Message);
        }
    }
#endif

    private void ApplyFilter()
    {
        var filtered = InMemorySearchFilter.Apply(_allItems, SearchText, GetSearchFields);

        if (FilterEligibleOnly)
            filtered = filtered.Where(i => i.IsCalibrationEligible).ToList();

        Items.Clear();
        foreach (var item in filtered) Items.Add(item);
        UpdateSelectedCount();
        SetFocusedIndex(Items.Count > 0 ? 0 : -1);
    }

    private static IEnumerable<string?> GetSearchFields(CalibrationItemRow row) =>
    [
        row.AssetTag, row.PartNumber, row.SerialNumber, row.Description,
        row.ManufacturerName, row.CategoryName, row.TypeName,
        row.InventoryID.ToString()
    ];

    private void SetAllSelected(bool selected)
    {
        foreach (var item in Items)
            item.IsSelected = selected;
    }

    private void SelectEligible()
    {
        foreach (var item in Items)
            item.IsSelected = item.IsCalibrationEligible;
    }

    private void UpdateSelectedCount()
    {
        SelectedCount = Items.Count(i => i.IsSelected);
    }

    private void RaiseCommandCanExecute()
    {
        LoadItemsCommand.RaiseCanExecuteChanged();
        SaveScheduleCommand.RaiseCanExecuteChanged();
#if !ANDROID
        ExportExcelCommand.RaiseCanExecuteChanged();
#endif
    }

    private void RaiseNavCanExecuteChanged()
    {
        MoveFirstCommand.ChangeCanExecute();
        MovePreviousCommand.ChangeCanExecute();
        MoveNextCommand.ChangeCanExecute();
        MoveLastCommand.ChangeCanExecute();
    }

    private async Task ShowAlert(string title, string message)
    {
        if (AlertAsync is null) return;
        try { await AlertAsync(title, message); } catch { }
    }

    // ?? Navigation ???????????????????????????????????????????????????
    private void SetFocusedIndex(int value)
    {
        if (_focusedIndex == value) return;
        _focusedIndex = value;
        OnPropertyChanged(nameof(FocusedIndex));
        UpdatePositionText();
        RaiseNavCanExecuteChanged();
        FocusedIndexChanged?.Invoke(_focusedIndex);
    }

    private void UpdatePositionText()
    {
        PositionText = Items.Count == 0
            ? "No items"
            : $"Item {_focusedIndex + 1} of {Items.Count}";
    }

    private void MoveFirst()
    {
        if (Items.Count > 0) SetFocusedIndex(0);
    }

    private void MovePrevious()
    {
        if (_focusedIndex > 0) SetFocusedIndex(_focusedIndex - 1);
    }

    private void MoveNext()
    {
        if (_focusedIndex < Items.Count - 1) SetFocusedIndex(_focusedIndex + 1);
    }

    private void MoveLast()
    {
        if (Items.Count > 0) SetFocusedIndex(Items.Count - 1);
    }
}
