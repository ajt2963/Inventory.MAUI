using System.Collections.ObjectModel;
using System.Windows.Input;
using Inventory.MAUI.Models;
using Inventory.MAUI.Services;

namespace Inventory.MAUI.ViewModels;

public sealed class InventoryItemCreateViewModel : ViewModelBase
{
    private readonly IInventoryItemService _service;
    private readonly IAppSessionService? _session;

    public InventoryItemCreateViewModel(IInventoryItemService service, IAppSessionService session)
    {
        _service = service;
        _session = session;

        Item = new InventoryItem();
        Item.PropertyChanged += (_, args) =>
        {
            if (args.PropertyName == nameof(InventoryItem.InventoryID))
                AssetTagPreview = BuildAssetTagPreview(Item.InventoryID);

            if (_hasAttemptedSave)
                ValidateAndUpdateFlags();
        };

        AssetTagPreview = BuildAssetTagPreview(null);

        // Auto-populate Modified By from the current session
        if (session.IsAuthenticated)
            ModifiedBy = session.DisplayName;

        SaveCommand = new Command(async () => await SaveAsync(), () => !IsBusy && CanSave);
        CancelCommand = new Command(() => CancelRequested?.Invoke());
    }

    public event Action? CancelRequested;

    public Func<string, string, Task>? NotifyAsync { get; set; }

    public InventoryItem Item { get; }

    public ObservableCollection<AssetOwner> Owners { get; } = new();
    public ObservableCollection<AssetType> Types { get; } = new();
    public ObservableCollection<Category> Categories { get; } = new();
    public ObservableCollection<Companies> Companies { get; } = new();
    public ObservableCollection<Locations> Locations { get; } = new();
    public ObservableCollection<InventoryStorage> Storages { get; } = new();

    private string? _modifiedBy;
    public string? ModifiedBy
    {
        get => _modifiedBy;
        set
        {
            if (SetProperty(ref _modifiedBy, value) && _hasAttemptedSave)
                ValidateAndUpdateFlags();
        }
    }

    private bool _isBusy;
    public bool IsBusy
    {
        get => _isBusy;
        private set
        {
            if (SetProperty(ref _isBusy, value))
                ((Command)SaveCommand).ChangeCanExecute();
        }
    }

    private string? _statusText;
    public string? StatusText { get => _statusText; private set => SetProperty(ref _statusText, value); }

    private string? _assetTagPreview;
    public string? AssetTagPreview { get => _assetTagPreview; private set => SetProperty(ref _assetTagPreview, value); }

    public ICommand SaveCommand { get; }
    public ICommand CancelCommand { get; }

    private bool _hasAttemptedSave;
    public bool HasAttemptedSave
    {
        get => _hasAttemptedSave;
        private set => SetProperty(ref _hasAttemptedSave, value);
    }

    private bool _isModifiedByInvalid;
    public bool IsModifiedByInvalid { get => _isModifiedByInvalid; private set => SetProperty(ref _isModifiedByInvalid, value); }

    private bool _isPartNumberInvalid;
    public bool IsPartNumberInvalid { get => _isPartNumberInvalid; private set => SetProperty(ref _isPartNumberInvalid, value); }

    private bool _isOwnerInvalid;
    public bool IsOwnerInvalid { get => _isOwnerInvalid; private set => SetProperty(ref _isOwnerInvalid, value); }

    private bool _isCategoryInvalid;
    public bool IsCategoryInvalid { get => _isCategoryInvalid; private set => SetProperty(ref _isCategoryInvalid, value); }

    private bool _isTypeInvalid;
    public bool IsTypeInvalid { get => _isTypeInvalid; private set => SetProperty(ref _isTypeInvalid, value); }

    private bool _isCompanyInvalid;
    public bool IsCompanyInvalid { get => _isCompanyInvalid; private set => SetProperty(ref _isCompanyInvalid, value); }

    private bool _isLocationInvalid;
    public bool IsLocationInvalid { get => _isLocationInvalid; private set => SetProperty(ref _isLocationInvalid, value); }

    private bool _isStorageInvalid;
    public bool IsStorageInvalid { get => _isStorageInvalid; private set => SetProperty(ref _isStorageInvalid, value); }

    private AssetOwner? _selectedOwner;
    public AssetOwner? SelectedOwner
    {
        get => _selectedOwner;
        set
        {
            if (SetProperty(ref _selectedOwner, value))
            {
                Item.OwnerID = value?.OwnerID;
                if (_hasAttemptedSave) ValidateAndUpdateFlags();
            }
        }
    }

    private AssetType? _selectedType;
    public AssetType? SelectedType
    {
        get => _selectedType;
        set
        {
            if (SetProperty(ref _selectedType, value))
            {
                Item.TypeID = value?.TypeID;
                if (_hasAttemptedSave) ValidateAndUpdateFlags();
            }
        }
    }

    private Category? _selectedCategory;
    public Category? SelectedCategory
    {
        get => _selectedCategory;
        set
        {
            if (SetProperty(ref _selectedCategory, value))
            {
                Item.CatID = value?.CatID;
                if (_hasAttemptedSave) ValidateAndUpdateFlags();
            }
        }
    }

    private Companies? _selectedCompany;
    public Companies? SelectedCompany
    {
        get => _selectedCompany;
        set
        {
            if (SetProperty(ref _selectedCompany, value))
            {
                Item.CompanyID = value?.CompanyID;
                if (_hasAttemptedSave) ValidateAndUpdateFlags();
            }
        }
    }

    private Locations? _selectedLocation;
    public Locations? SelectedLocation
    {
        get => _selectedLocation;
        set
        {
            if (SetProperty(ref _selectedLocation, value))
            {
                Item.LocationID = value?.LocationID;
                if (_hasAttemptedSave) ValidateAndUpdateFlags();
            }
        }
    }

    private InventoryStorage? _selectedStorage;
    public InventoryStorage? SelectedStorage
    {
        get => _selectedStorage;
        set
        {
            if (SetProperty(ref _selectedStorage, value))
            {
                Item.StorageID = value?.StorageID;
                if (_hasAttemptedSave) ValidateAndUpdateFlags();
            }
        }
    }

    private DateTime _dateModified = DateTime.Today;
    public DateTime DateModified { get => _dateModified; set => SetProperty(ref _dateModified, value); }

    private string? _userNotes;
    public string? UserNotes { get => _userNotes; set => SetProperty(ref _userNotes, value); }

    private static string BuildAssetTagPreview(int? inventoryId)
        => inventoryId is null
            ? "Asset Tag: UCM-(assigned after save)"
            : $"Asset Tag: UCM-{inventoryId.Value:00000}";

    public async Task InitializeAsync()
    {
        if (Owners.Count > 0)
            return;

        IsBusy = true;
        StatusText = "Loading lookup values...";
        try
        {
            var lookups = await _service.GetLookupsAsync();

            Owners.Clear();
            foreach (var o in lookups.Owners) Owners.Add(o);

            Types.Clear();
            foreach (var t in lookups.Types) Types.Add(t);

            Categories.Clear();
            foreach (var c in lookups.Categories) Categories.Add(c);

            Companies.Clear();
            foreach (var c in lookups.Companies) Companies.Add(c);

            Locations.Clear();
            foreach (var l in lookups.Locations) Locations.Add(l);

            Storages.Clear();
            foreach (var s in lookups.Storages) Storages.Add(s);

            StatusText = "Ready";
        }
        catch (Exception ex)
        {
            StatusText = "Lookup load failed";
            await NotifyAsyncSafe("Error", ex.Message);
            // Do not rethrow; keep the page alive so the user can back out.
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task SaveAsync()
    {
        if (IsBusy)
            return;

        IsBusy = true;
        try
        {
            HasAttemptedSave = true;
            StatusText = "Validating...";

            var errors = ValidateAndUpdateFlags();
            if (errors.Count > 0)
            {
                StatusText = "Validation failed";
                await NotifyAsyncSafe("Please enter the following information:", string.Join("\n", errors));
                return;
            }

            var modifiedBy = ModifiedBy?.Trim();
            if (string.IsNullOrWhiteSpace(modifiedBy))
            {
                StatusText = "Validation failed";
                await NotifyAsyncSafe("Cannot save", "Modified By is required.");
                return;
            }

            // Apply chosen date to the record.
            Item.DateModified = DateModified;

            var newId = await _service.CreateAsync(Item, modifiedBy, UserNotes);

            AssetTagPreview = BuildAssetTagPreview(newId);

            StatusText = "Done";
            await NotifyAsyncSafe("Saved", $"Record created successfully. ID: {newId}");
        }
        catch (Exception ex)
        {
            StatusText = "Save failed";
            await NotifyAsyncSafe("Save failed", ex.Message);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private bool _canSave;
    /// <summary>True if the current session has CanCreate permission.</summary>
    public bool CanSave => _session?.CanCreate ?? false;

    private List<string> ValidateAndUpdateFlags()
    {
        var errors = Validate();

        IsModifiedByInvalid = HasAttemptedSave && string.IsNullOrWhiteSpace(ModifiedBy);
        IsPartNumberInvalid = HasAttemptedSave && string.IsNullOrWhiteSpace(Item.PartNumber);
        IsOwnerInvalid = HasAttemptedSave && SelectedOwner is null;
        IsCategoryInvalid = HasAttemptedSave && SelectedCategory is null;
        IsTypeInvalid = HasAttemptedSave && SelectedType is null;
        IsCompanyInvalid = HasAttemptedSave && SelectedCompany is null;
        IsLocationInvalid = HasAttemptedSave && SelectedLocation is null;
        IsStorageInvalid = HasAttemptedSave && SelectedStorage is null;

        return errors;
    }

    private List<string> Validate()
    {
        var errors = new List<string>();

        if (string.IsNullOrWhiteSpace(ModifiedBy))
            errors.Add("Modified By is required.");

        if (string.IsNullOrWhiteSpace(Item.PartNumber))
            errors.Add("Part Number is required.");

        if (SelectedOwner is null)
            errors.Add("Owner is required.");

        if (SelectedCategory is null)
            errors.Add("Category is required.");

        if (SelectedType is null)
            errors.Add("Asset Type is required.");

        if (SelectedCompany is null)
            errors.Add("Company is required.");

        if (SelectedLocation is null)
            errors.Add("Location is required.");

        if (SelectedStorage is null)
            errors.Add("Storage is required.");

        return errors;
    }

    private async Task NotifyAsyncSafe(string title, string message)
    {
        if (NotifyAsync is null)
            return;

        try
        {
            await NotifyAsync(title, message);
        }
        catch
        {
            // Never allow UI notification failures to crash the app.
        }
    }
}
