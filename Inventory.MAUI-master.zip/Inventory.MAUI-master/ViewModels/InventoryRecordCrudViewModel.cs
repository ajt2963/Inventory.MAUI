using System.Collections.ObjectModel;
using Inventory.MAUI.Core.ViewModels;
using Inventory.MAUI.ViewModels;

namespace Inventory.MAUI.ViewModels;

public sealed class InventoryRecordCrudViewModel : ViewModelBase
{
    public InventoryRecordCrudViewModel(Inventory.MAUI.Core.ViewModels.InventoryListViewModel listVm, InventoryItemEditViewModel editVm)
    {
        ListVm = listVm;
        EditVm = editVm;

        EditVm.Saved -= OnEditSaved;
        EditVm.Saved += OnEditSaved;
    }

    public Inventory.MAUI.Core.ViewModels.InventoryListViewModel ListVm { get; }
    public InventoryItemEditViewModel EditVm { get; }

    public Func<string, string, string, string, string, Task<string>>? ChooseAsync { get; set; }

    public async Task InitializeAsync()
    {
        await ListVm.InitializeAsync();
        await LoadSelectedIntoEditorAsync();
    }

    private async void OnEditSaved(int inventoryId)
    {
        try
        {
            await ListVm.RefreshEditedRowAsync(inventoryId);
        }
        catch
        {
            // Best-effort: list refresh should not break the UX.
        }
    }

    public async Task LoadSelectedIntoEditorAsync()
    {
        var id = ListVm.SelectedRow?.InventoryID;
        if (id is null)
            return;

        await EditVm.LoadAsync(id.Value);
    }

    private async Task<bool> ConfirmSelectionChangeAsync()
    {
        if (!EditVm.IsDirty)
            return true;

        if (ChooseAsync is null)
            return true;

        var choice = await ChooseAsync(
            "Unsaved changes",
            "You have unsaved changes. Save before switching records?",
            "Save",
            "Discard",
            "Cancel");

        if (string.Equals(choice, "Cancel", StringComparison.OrdinalIgnoreCase))
            return false;

        if (string.Equals(choice, "Save", StringComparison.OrdinalIgnoreCase))
        {
            EditVm.SaveCommand.Execute(null);
            while (EditVm.IsBusy)
                await Task.Delay(50);
            return true;
        }

        // Discard
        EditVm.CancelCommand.Execute(null);
        while (EditVm.IsBusy)
            await Task.Delay(50);
        return true;
    }

    public async Task OnSelectionChangedAsync(IReadOnlyList<object> currentSelection)
    {
        var canChange = await ConfirmSelectionChangeAsync();
        if (!canChange)
            return;

        ListVm.OnSelectionChanged(currentSelection);
        await LoadSelectedIntoEditorAsync();
    }
}