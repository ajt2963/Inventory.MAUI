using System.Collections.ObjectModel;
using System.Windows.Input;
using Inventory.MAUI.Models;
using Inventory.MAUI.Services;

namespace Inventory.MAUI.ViewModels;

public sealed class UserAdminViewModel : ViewModelBase
{
    private readonly IAppUserService _userService;
    private readonly AppSessionService _session;

    private bool _isBusy;
    private string? _statusText;

    // User editing
    private AppUser? _selectedUser;
    private string _editAttuid = string.Empty;
    private string _editDisplayName = string.Empty;
    private string _editEmail = string.Empty;
    private AppRole? _editRole;
    private bool _editIsActive = true;
    private bool _isEditingUser;
    private bool _includeInactive;

    // Role editing
    private AppRole? _selectedRole;
    private string _editRoleName = string.Empty;
    private bool _editCanView = true;
    private bool _editCanCreate;
    private bool _editCanEdit;
    private bool _editCanDelete;
    private bool _editCanAdmin;
    private bool _isEditingRole;

    public UserAdminViewModel(IAppUserService userService, AppSessionService session)
    {
        _userService = userService;
        _session = session;

        NewUserCommand = new Command(NewUser);
        EditUserCommand = new Command(EditUser, () => SelectedUser is not null);
        SaveUserCommand = new Command(async () => await SaveUserAsync(), () => !IsBusy);
        CancelUserCommand = new Command(CancelUserEdit);
        DeleteUserCommand = new Command(async () => await DeleteUserAsync(), () => SelectedUser is not null && !IsBusy);
        ToggleInactiveCommand = new Command(async () =>
        {
            IncludeInactive = !IncludeInactive;
            await LoadUsersAsync();
        });
        ResetPasswordCommand = new Command(async () => await ResetPasswordAsync(), () => SelectedUser is not null && !IsBusy);

        NewRoleCommand = new Command(NewRole);
        EditRoleCommand = new Command(EditRole, () => SelectedRole is not null);
        SaveRoleCommand = new Command(async () => await SaveRoleAsync(), () => !IsBusy);
        DeleteRoleCommand = new Command(async () => await DeleteRoleAsync(), () => SelectedRole is not null && !IsBusy);
        CancelRoleCommand = new Command(CancelRoleEdit);

        SelectUserCommand = new Command<AppUser>(OnUserChecked);
        SelectRoleCommand = new Command<AppRole>(OnRoleChecked);
    }

    public Func<string, string, Task>? NotifyAsync { get; set; }
    public Func<string, string, Task<bool>>? ConfirmAsync { get; set; }

    public ObservableCollection<AppUser> Users { get; } = [];
    public ObservableCollection<AppRole> Roles { get; } = [];

    public bool IsBusy
    {
        get => _isBusy;
        private set
        {
            if (SetProperty(ref _isBusy, value))
            {
                ((Command)SaveUserCommand).ChangeCanExecute();
                ((Command)DeleteUserCommand).ChangeCanExecute();
                ((Command)ResetPasswordCommand).ChangeCanExecute();
                ((Command)SaveRoleCommand).ChangeCanExecute();
                ((Command)DeleteRoleCommand).ChangeCanExecute();
            }
        }
    }

    public string? StatusText { get => _statusText; private set => SetProperty(ref _statusText, value); }

    // ---- User list/selection ----

    public AppUser? SelectedUser
    {
        get => _selectedUser;
        set
        {
            if (SetProperty(ref _selectedUser, value))
            {
                ((Command)EditUserCommand).ChangeCanExecute();
                ((Command)DeleteUserCommand).ChangeCanExecute();
                ((Command)ResetPasswordCommand).ChangeCanExecute();
            }
        }
    }

    public bool IncludeInactive
    {
        get => _includeInactive;
        set => SetProperty(ref _includeInactive, value);
    }

    // ---- User editing fields ----

    public bool IsEditingUser { get => _isEditingUser; private set => SetProperty(ref _isEditingUser, value); }
    public string EditAttuid { get => _editAttuid; set => SetProperty(ref _editAttuid, value); }
    public string EditDisplayName { get => _editDisplayName; set => SetProperty(ref _editDisplayName, value); }
    public string EditEmail { get => _editEmail; set => SetProperty(ref _editEmail, value); }
    public AppRole? EditSelectedRole { get => _editRole; set => SetProperty(ref _editRole, value); }
    public bool EditIsActive { get => _editIsActive; set => SetProperty(ref _editIsActive, value); }

    private int _editUserID;

    // ---- Role selection ----

    public AppRole? SelectedRole
    {
        get => _selectedRole;
        set
        {
            if (SetProperty(ref _selectedRole, value))
            {
                ((Command)EditRoleCommand).ChangeCanExecute();
                ((Command)DeleteRoleCommand).ChangeCanExecute();
            }
        }
    }

    // ---- Role editing fields ----

    public bool IsEditingRole { get => _isEditingRole; private set => SetProperty(ref _isEditingRole, value); }
    public string EditRoleName { get => _editRoleName; set => SetProperty(ref _editRoleName, value); }
    public bool EditCanView { get => _editCanView; set => SetProperty(ref _editCanView, value); }
    public bool EditCanCreate { get => _editCanCreate; set => SetProperty(ref _editCanCreate, value); }
    public bool EditCanEdit { get => _editCanEdit; set => SetProperty(ref _editCanEdit, value); }
    public bool EditCanDelete { get => _editCanDelete; set => SetProperty(ref _editCanDelete, value); }
    public bool EditCanAdmin { get => _editCanAdmin; set => SetProperty(ref _editCanAdmin, value); }

    private int _editRoleID;

    // ---- Commands ----

    public ICommand NewUserCommand { get; }
    public ICommand EditUserCommand { get; }
    public ICommand SaveUserCommand { get; }
    public ICommand CancelUserCommand { get; }
    public ICommand DeleteUserCommand { get; }
    public ICommand ToggleInactiveCommand { get; }
    public ICommand ResetPasswordCommand { get; }

    public ICommand NewRoleCommand { get; }
    public ICommand EditRoleCommand { get; }
    public ICommand SaveRoleCommand { get; }
    public ICommand DeleteRoleCommand { get; }
    public ICommand CancelRoleCommand { get; }

    public ICommand SelectUserCommand { get; }
    public ICommand SelectRoleCommand { get; }

    // ---- Initialization ----

    public async Task InitializeAsync()
    {
        if (Users.Count > 0)
            return;

        IsBusy = true;
        StatusText = "Loading...";
        try
        {
            await LoadRolesAsync();
            await LoadUsersAsync();
            StatusText = "Ready";
        }
        catch (Exception ex)
        {
            StatusText = $"Load failed: {ex.Message}";
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task LoadUsersAsync()
    {
        var users = await _userService.GetAllUsersAsync(IncludeInactive);
        Users.Clear();
        foreach (var u in users) Users.Add(u);
    }

    private async Task LoadRolesAsync()
    {
        var roles = await _userService.GetAllRolesAsync();
        Roles.Clear();
        foreach (var r in roles) Roles.Add(r);
    }

    // ---- User CRUD ----

    private void NewUser()
    {
        _editUserID = 0;
        EditAttuid = string.Empty;
        EditDisplayName = string.Empty;
        EditEmail = string.Empty;
        EditSelectedRole = Roles.FirstOrDefault();
        EditIsActive = true;
        IsEditingUser = true;
    }

    private void EditUser()
    {
        if (SelectedUser is null) return;
        _editUserID = SelectedUser.UserID;
        EditAttuid = SelectedUser.ATTUID;
        EditDisplayName = SelectedUser.DisplayName;
        EditEmail = SelectedUser.Email ?? string.Empty;
        EditSelectedRole = Roles.FirstOrDefault(r => r.RoleID == SelectedUser.RoleID);
        EditIsActive = SelectedUser.IsActive;
        IsEditingUser = true;
    }

    private async Task SaveUserAsync()
    {
        if (string.IsNullOrWhiteSpace(EditAttuid))
        {
            await NotifySafe("Validation", "ATTUID is required.");
            return;
        }
        if (string.IsNullOrWhiteSpace(EditDisplayName))
        {
            await NotifySafe("Validation", "Display Name is required.");
            return;
        }
        if (EditSelectedRole is null)
        {
            await NotifySafe("Validation", "A role must be selected.");
            return;
        }

        IsBusy = true;
        try
        {
            var user = new AppUser
            {
                UserID = _editUserID,
                ATTUID = EditAttuid.Trim(),
                DisplayName = EditDisplayName.Trim(),
                Email = string.IsNullOrWhiteSpace(EditEmail) ? null : EditEmail.Trim(),
                RoleID = EditSelectedRole.RoleID,
                IsActive = EditIsActive,
                CreatedAt = _editUserID == 0 ? DateTime.UtcNow : SelectedUser?.CreatedAt ?? DateTime.UtcNow
            };

            await _userService.SaveUserAsync(user);
            IsEditingUser = false;
            await LoadUsersAsync();

            // Refresh session if the edited user is the current user
            if (string.Equals(user.ATTUID, _session.ATTUID, StringComparison.OrdinalIgnoreCase))
                await _session.RefreshAsync(_userService);

            StatusText = _editUserID == 0 ? "User created" : "User updated";
        }
        catch (Exception ex)
        {
            await NotifySafe("Save failed", ex.Message);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private void CancelUserEdit() => IsEditingUser = false;

    private async Task DeleteUserAsync()
    {
        if (SelectedUser is null) return;

        // Prevent deleting yourself
        if (string.Equals(SelectedUser.ATTUID, _session.ATTUID, StringComparison.OrdinalIgnoreCase))
        {
            await NotifySafe("Delete blocked", "You cannot delete your own account.");
            return;
        }

        if (ConfirmAsync is not null)
        {
            var confirmed = await ConfirmAsync("Delete User",
                $"Permanently delete user '{SelectedUser.DisplayName}' ({SelectedUser.ATTUID})?\n\nThis cannot be undone.");
            if (!confirmed) return;
        }

        IsBusy = true;
        try
        {
            await _userService.DeleteUserAsync(SelectedUser.UserID);
            IsEditingUser = false;
            SelectedUser = null;
            await LoadUsersAsync();
            StatusText = "User deleted";
        }
        catch (Exception ex)
        {
            await NotifySafe("Delete failed", ex.Message);
        }
        finally
        {
            IsBusy = false;
        }
    }

    // ---- Role CRUD ----

    private void NewRole()
    {
        _editRoleID = 0;
        EditRoleName = string.Empty;
        EditCanView = true;
        EditCanCreate = false;
        EditCanEdit = false;
        EditCanDelete = false;
        EditCanAdmin = false;
        IsEditingRole = true;
    }

    private void EditRole()
    {
        if (SelectedRole is null) return;
        _editRoleID = SelectedRole.RoleID;
        EditRoleName = SelectedRole.RoleName;
        EditCanView = SelectedRole.CanView;
        EditCanCreate = SelectedRole.CanCreate;
        EditCanEdit = SelectedRole.CanEdit;
        EditCanDelete = SelectedRole.CanDelete;
        EditCanAdmin = SelectedRole.CanAdmin;
        IsEditingRole = true;
    }

    private async Task SaveRoleAsync()
    {
        if (string.IsNullOrWhiteSpace(EditRoleName))
        {
            await NotifySafe("Validation", "Role name is required.");
            return;
        }

        IsBusy = true;
        try
        {
            var role = new AppRole
            {
                RoleID = _editRoleID,
                RoleName = EditRoleName.Trim(),
                CanView = EditCanView,
                CanCreate = EditCanCreate,
                CanEdit = EditCanEdit,
                CanDelete = EditCanDelete,
                CanAdmin = EditCanAdmin
            };

            await _userService.SaveRoleAsync(role);
            IsEditingRole = false;
            await LoadRolesAsync();
            await LoadUsersAsync(); // Refresh user list in case role names changed

            // Refresh session in case current user's role permissions changed
            await _session.RefreshAsync(_userService);

            StatusText = _editRoleID == 0 ? "Role created" : "Role updated";
        }
        catch (Exception ex)
        {
            await NotifySafe("Save failed", ex.Message);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task DeleteRoleAsync()
    {
        if (SelectedRole is null) return;

        if (ConfirmAsync is not null)
        {
            var confirmed = await ConfirmAsync("Delete Role", $"Delete role '{SelectedRole.RoleName}'? This cannot be undone.");
            if (!confirmed) return;
        }

        IsBusy = true;
        try
        {
            await _userService.DeleteRoleAsync(SelectedRole.RoleID);
            IsEditingRole = false;
            await LoadRolesAsync();
            StatusText = "Role deleted";
        }
        catch (Exception ex)
        {
            await NotifySafe("Delete failed", ex.Message);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private void CancelRoleEdit() => IsEditingRole = false;

    private async Task NotifySafe(string title, string message)
    {
        if (NotifyAsync is not null)
        {
            try { await NotifyAsync(title, message); }
            catch { /* never crash on notification failure */ }
        }
    }

    private void OnUserChecked(AppUser user)
    {
        // Uncheck all other users
        foreach (var u in Users)
        {
            if (u != user)
                u.IsSelected = false;
        }

        // Toggle: if unchecked, clear selection
        SelectedUser = user.IsSelected ? user : null;
    }

    private void OnRoleChecked(AppRole role)
    {
        // Uncheck all other roles
        foreach (var r in Roles)
        {
            if (r != role)
                r.IsSelected = false;
        }

        SelectedRole = role.IsSelected ? role : null;
    }

    private async Task ResetPasswordAsync()
    {
        if (SelectedUser is null) return;

        if (ConfirmAsync is not null)
        {
            var confirmed = await ConfirmAsync("Reset Password",
                $"Reset password for '{SelectedUser.DisplayName}' ({SelectedUser.ATTUID})?\n\n" +
                "This will clear their current password and require them to set a new one on next login.");
            if (!confirmed) return;
        }

        IsBusy = true;
        try
        {
            await _userService.AdminResetPasswordAsync(SelectedUser.UserID);
            await LoadUsersAsync();
            StatusText = $"Password reset for {SelectedUser.ATTUID}. They must set a new password on next login.";
        }
        catch (Exception ex)
        {
            await NotifySafe("Reset failed", ex.Message);
        }
        finally
        {
            IsBusy = false;
        }
    }
}
