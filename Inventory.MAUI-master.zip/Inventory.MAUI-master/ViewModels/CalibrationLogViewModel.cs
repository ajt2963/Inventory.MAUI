using System.Windows.Input;
using Inventory.MAUI.Core.Collections;
using Inventory.MAUI.Core.ViewModels;
using Inventory.MAUI.Models;
using Inventory.MAUI.Services;

namespace Inventory.MAUI.ViewModels;

public sealed class CalibrationLogViewModel : ViewModelBase
{
    private readonly ICalibrationService _service;
    private readonly IAppSessionService _session;

    public CalibrationLogViewModel(ICalibrationService service, IAppSessionService session)
    {
        _service = service;
        _session = session;

        RefreshCommand = new AsyncCommand(LoadAsync);
        SaveCommand = new AsyncCommand(SaveAsync, () => !IsBusy && CanEdit);
        SearchCommand = new Command(ApplyFilter);
        ClearSearchCommand = new Command(() => { SearchText = string.Empty; ApplyFilter(); });
        SelectAllCommand = new Command(() => SetAllSelected(true));
        SelectNoneCommand = new Command(() => SetAllSelected(false));
        ToggleEditCommand = new Command<CalibrationLogRow>(ToggleEdit);
        CancelEditCommand = new Command<CalibrationLogRow>(CancelEdit);
        SaveRowCommand = new AsyncCommand<CalibrationLogRow>(SaveRowAsync);
        MoveFirstCommand = new Command(MoveFirst, () => LogEntries.Count > 0);
        MovePreviousCommand = new Command(MovePrevious, () => _focusedIndex > 0);
        MoveNextCommand = new Command(MoveNext, () => _focusedIndex < LogEntries.Count - 1);
        MoveLastCommand = new Command(MoveLast, () => LogEntries.Count > 0);
    }

    public Func<string, string, Task>? AlertAsync { get; set; }
    public Func<string, string, string, string, Task<bool>>? ConfirmAsync { get; set; }

    /// <summary>Raised when the focused row changes so the view can scroll it into view.</summary>
    public event Action<int>? FocusedIndexChanged;

    public RangeObservableCollection<CalibrationLogRow> LogEntries { get; } = [];
    public RangeObservableCollection<Companies> ServiceProviders { get; } = [];

    private List<CalibrationLogRow> _allEntries = [];

    public bool CanEdit => _session.CanEdit;

    private string? _searchText;
    public string? SearchText
    {
        get => _searchText;
        set => SetProperty(ref _searchText, value);
    }

    private bool _isBusy;
    public bool IsBusy
    {
        get => _isBusy;
        private set
        {
            if (SetProperty(ref _isBusy, value))
                SaveCommand.RaiseCanExecuteChanged();
        }
    }

    private string? _statusText;
    public string? StatusText { get => _statusText; private set => SetProperty(ref _statusText, value); }

    private int _selectedCount;
    public int SelectedCount { get => _selectedCount; private set => SetProperty(ref _selectedCount, value); }

    private string? _positionText;
    public string? PositionText { get => _positionText; private set => SetProperty(ref _positionText, value); }

    private int _focusedIndex = -1;
    public int FocusedIndex
    {
        get => _focusedIndex;
        private set
        {
            if (_focusedIndex == value) return;

            // Clear previous
            if (_focusedIndex >= 0 && _focusedIndex < LogEntries.Count)
                LogEntries[_focusedIndex].IsFocused = false;

            _focusedIndex = value;

            // Set new
            if (_focusedIndex >= 0 && _focusedIndex < LogEntries.Count)
                LogEntries[_focusedIndex].IsFocused = true;

            UpdatePositionText();
            RaiseNavCanExecuteChanged();
            FocusedIndexChanged?.Invoke(_focusedIndex);
        }
    }

    public CalibrationLogRow? FocusedRow =>
        _focusedIndex >= 0 && _focusedIndex < LogEntries.Count ? LogEntries[_focusedIndex] : null;

    private CalibrationLogRow? _editingRow;
    public CalibrationLogRow? EditingRow
    {
        get => _editingRow;
        private set
        {
            if (SetProperty(ref _editingRow, value))
                OnPropertyChanged(nameof(IsEditPanelVisible));
        }
    }

    public bool IsEditPanelVisible => _editingRow is not null;

    public ICommand RefreshCommand { get; }
    public AsyncCommand SaveCommand { get; }
    public ICommand SearchCommand { get; }
    public ICommand ClearSearchCommand { get; }
    public ICommand SelectAllCommand { get; }
    public ICommand SelectNoneCommand { get; }
    public ICommand ToggleEditCommand { get; }
    public ICommand CancelEditCommand { get; }
    public ICommand SaveRowCommand { get; }
    public Command MoveFirstCommand { get; }
    public Command MovePreviousCommand { get; }
    public Command MoveNextCommand { get; }
    public Command MoveLastCommand { get; }

    public async Task LoadAsync()
    {
        IsBusy = true;
        StatusText = "Loading calibration log...";
        try
        {
            var entries = await _service.GetCalibrationLogAsync().ConfigureAwait(false);
            var providers = await _service.GetServiceProvidersAsync().ConfigureAwait(false);

            // Ensure any company already referenced by a log entry is in the provider list
            var providerIds = new HashSet<int>(providers.Select(p => p.CompanyID));
            var missingSvcIds = entries
                .Where(e => e.SvcID.HasValue && !providerIds.Contains(e.SvcID.Value))
                .Select(e => e.SvcID!.Value)
                .Distinct()
                .ToList();

            List<Companies> extras = [];
            if (missingSvcIds.Count > 0)
                extras = await _service.GetCompaniesByIdsAsync(missingSvcIds).ConfigureAwait(false);

            // Build a lookup for pre-matching
            var allProviders = providers.Concat(extras).ToList();
            var providerLookup = allProviders.ToDictionary(p => p.CompanyID);

            foreach (var entry in entries)
            {
                if (entry.SvcID.HasValue && providerLookup.TryGetValue(entry.SvcID.Value, out var match))
                    entry.SelectedServiceProvider = match;

                entry.IsDirty = false;
                entry.PropertyChanged += (_, e) =>
                {
                    if (e.PropertyName == nameof(CalibrationLogRow.IsSelected))
                        UpdateSelectedCount();
                };
            }

            _allEntries = entries;

            // Update UI collections on the main thread in one batch
            await MainThread.InvokeOnMainThreadAsync(() =>
            {
                ServiceProviders.ReplaceRange(allProviders);
                ApplyFilter();
            });

            StatusText = $"{_allEntries.Count} calibration record(s).";
        }
        catch (Exception ex)
        {
            StatusText = "Failed to load log.";
            await ShowAlert("Error", ex.Message);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task SaveAsync()
    {
        var dirty = LogEntries.Where(e => e.IsSelected && e.IsDirty).ToList();
        if (dirty.Count == 0)
        {
            await ShowAlert("Nothing to Save", "No selected records have been modified.");
            return;
        }

        if (ConfirmAsync is not null)
        {
            var proceed = await ConfirmAsync(
                "Confirm Save",
                $"Save changes to {dirty.Count} record(s)?",
                "Save",
                "Cancel");
            if (!proceed) return;
        }

        IsBusy = true;
        StatusText = "Saving changes...";
        try
        {
            var modifiedBy = _session.DisplayName ?? "Unknown";
            await _service.UpdateCalibrationLogEntriesAsync(dirty, modifiedBy);

            foreach (var row in dirty)
                row.IsDirty = false;

            StatusText = $"Saved {dirty.Count} record(s).";
            await ShowAlert("Saved", $"{dirty.Count} record(s) updated successfully.");
        }
        catch (Exception ex)
        {
            StatusText = "Save failed.";
            await ShowAlert("Save Failed", ex.Message);
        }
        finally
        {
            IsBusy = false;
        }
    }

    // ?? Search with logical operators ????????????????????????????????
    private void ApplyFilter()
    {
        var filtered = InMemorySearchFilter.Apply(_allEntries, SearchText ?? string.Empty, GetSearchFields);

        LogEntries.ReplaceRange(filtered);
        UpdateSelectedCount();
        FocusedIndex = LogEntries.Count > 0 ? 0 : -1;
    }

    private static IEnumerable<string?> GetSearchFields(CalibrationLogRow row) =>
    [
        row.AssetTag, row.PartNumber, row.SerialNumber, row.Description,
        row.ManufacturerName, row.ServiceProviderName, row.ClliCode,
        row.LocationName, row.CalLabel, row.CalNotes, row.InventoryID?.ToString()
    ];

    // ?? Navigation ???????????????????????????????????????????????????
    private void MoveFirst()
    {
        if (LogEntries.Count > 0) FocusedIndex = 0;
    }

    private void MovePrevious()
    {
        if (_focusedIndex > 0) FocusedIndex--;
    }

    private void MoveNext()
    {
        if (_focusedIndex < LogEntries.Count - 1) FocusedIndex++;
    }

    private void MoveLast()
    {
        if (LogEntries.Count > 0) FocusedIndex = LogEntries.Count - 1;
    }

    private void RaiseNavCanExecuteChanged()
    {
        MoveFirstCommand.ChangeCanExecute();
        MovePreviousCommand.ChangeCanExecute();
        MoveNextCommand.ChangeCanExecute();
        MoveLastCommand.ChangeCanExecute();
    }

    private void UpdatePositionText()
    {
        PositionText = LogEntries.Count == 0
            ? "No records"
            : $"Record {_focusedIndex + 1} of {LogEntries.Count}";
    }

    // ?? Selection / editing helpers ??????????????????????????????????
    private void SetAllSelected(bool selected)
    {
        foreach (var item in LogEntries)
            item.IsSelected = selected;
    }

    private void UpdateSelectedCount()
    {
        SelectedCount = LogEntries.Count(i => i.IsSelected);
    }

    private void ToggleEdit(CalibrationLogRow? row)
    {
        if (row is null || !CanEdit) return;

        if (EditingRow == row)
        {
            EditingRow = null;
            row.IsEditing = false;
        }
        else
        {
            if (EditingRow is not null)
                EditingRow.IsEditing = false;

            row.IsEditing = true;
            row.IsSelected = true;
            EditingRow = row;
        }
    }

    private void CancelEdit(CalibrationLogRow? row)
    {
        if (row is not null)
            row.IsEditing = false;
        EditingRow = null;
    }

    private async Task SaveRowAsync(CalibrationLogRow? row)
    {
        if (row is null || !row.IsDirty) return;

        IsBusy = true;
        StatusText = "Saving...";
        try
        {
            var modifiedBy = _session.DisplayName ?? "Unknown";
            await _service.UpdateCalibrationLogEntriesAsync([row], modifiedBy);
            row.IsDirty = false;
            row.IsEditing = false;
            EditingRow = null;
            StatusText = "Saved successfully.";
        }
        catch (Exception ex)
        {
            StatusText = "Save failed.";
            await ShowAlert("Save Failed", ex.Message);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task ShowAlert(string title, string message)
    {
        if (AlertAsync is null) return;
        try { await AlertAsync(title, message); } catch { }
    }
}
