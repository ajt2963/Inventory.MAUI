using System.Reflection;

namespace Inventory.MAUI.ViewModels;

public sealed class WelcomeViewModel
{
    public string CompanyName { get; } = "AT&T";

    public string ApplicationName { get; } = AppInfo.Current.Name;

    public string Version { get; }

    public string Copyright { get; }

    public WelcomeViewModel()
    {
        var asm = typeof(WelcomeViewModel).Assembly;

        // AppVersion is embedded as custom assembly metadata from the .csproj.
        var appVersion = asm
            .GetCustomAttributes<AssemblyMetadataAttribute>()
            .FirstOrDefault(a => a.Key == "AppVersion")
            ?.Value;

        Version = !string.IsNullOrWhiteSpace(appVersion)
            ? appVersion
            : AppInfo.Current.VersionString;

        var attrCopyright = asm.GetCustomAttribute<AssemblyCopyrightAttribute>()?.Copyright;
        Copyright = !string.IsNullOrWhiteSpace(attrCopyright)
            ? attrCopyright
            : "Copyright AT&T 2026.  All Rights Reserved.";
    }
}
