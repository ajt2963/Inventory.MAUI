using System.Net.Sockets;

namespace Inventory.MAUI.Helpers;

public static class NetworkHelper
{
    public static async Task<(bool Success, string Message)> TestSqlServerConnectionAsync(string host, int port, int timeoutMs = 5000)
    {
        try
        {
            using var cts = new CancellationTokenSource(timeoutMs);
            using var client = new TcpClient();
            
            await client.ConnectAsync(host, port, cts.Token);
            
            return (true, $"Successfully connected to {host}:{port}");
        }
        catch (OperationCanceledException)
        {
            return (false, $"Connection to {host}:{port} timed out after {timeoutMs}ms");
        }
        catch (SocketException ex)
        {
            return (false, $"Socket error connecting to {host}:{port}: {ex.Message}");
        }
        catch (Exception ex)
        {
            return (false, $"Error connecting to {host}:{port}: {ex.Message}");
        }
    }
}
