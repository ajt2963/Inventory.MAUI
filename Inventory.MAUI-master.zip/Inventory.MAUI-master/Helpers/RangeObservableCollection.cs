using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace Inventory.MAUI.Helpers;

/// <summary>
/// ObservableCollection that supports adding/removing multiple items with a single notification.
/// This prevents UI freeze when loading large datasets.
/// </summary>
public class RangeObservableCollection<T> : ObservableCollection<T>
{
    private bool _suppressNotification = false;

    public RangeObservableCollection() : base() { }

    public RangeObservableCollection(IEnumerable<T> collection) : base(collection) { }

    /// <summary>
    /// Adds multiple items and raises a single CollectionChanged event
    /// </summary>
    public void AddRange(IEnumerable<T> items)
    {
        if (items == null)
            return;

        var list = items as IList<T> ?? items.ToList();
        if (list.Count == 0)
            return;

        _suppressNotification = true;

        foreach (var item in list)
        {
            Items.Add(item);
        }

        _suppressNotification = false;
        OnPropertyChanged(new System.ComponentModel.PropertyChangedEventArgs("Count"));
        OnPropertyChanged(new System.ComponentModel.PropertyChangedEventArgs("Item[]"));
        OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
    }

    /// <summary>
    /// Removes multiple items and raises a single CollectionChanged event
    /// </summary>
    public void RemoveRange(IEnumerable<T> items)
    {
        if (items == null)
            return;

        var list = items.ToList();
        if (list.Count == 0)
            return;

        _suppressNotification = true;

        foreach (var item in list)
        {
            Items.Remove(item);
        }

        _suppressNotification = false;
        OnPropertyChanged(new System.ComponentModel.PropertyChangedEventArgs("Count"));
        OnPropertyChanged(new System.ComponentModel.PropertyChangedEventArgs("Item[]"));
        OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
    }

    /// <summary>
    /// Clears and replaces with new items in a single notification
    /// </summary>
    public void ReplaceAll(IEnumerable<T> items)
    {
        if (items == null)
            return;

        _suppressNotification = true;
        Items.Clear();

        foreach (var item in items)
        {
            Items.Add(item);
        }

        _suppressNotification = false;
        OnPropertyChanged(new System.ComponentModel.PropertyChangedEventArgs("Count"));
        OnPropertyChanged(new System.ComponentModel.PropertyChangedEventArgs("Item[]"));
        OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
    }

    /// <summary>
    /// Inserts an item in sorted position using the provided key selector.
    /// Assumes the collection is already sorted ascending by the key.
    /// </summary>
    public void InsertSorted<TKey>(T item, Func<T, TKey> keySelector) where TKey : IComparable<TKey>
    {
        var key = keySelector(item);
        var index = 0;
        while (index < Count && keySelector(this[index]).CompareTo(key) < 0)
        {
            index++;
        }
        Insert(index, item);
    }

    protected override void OnCollectionChanged(NotifyCollectionChangedEventArgs e)
    {
        if (!_suppressNotification)
        {
            base.OnCollectionChanged(e);
        }
    }
}
