# Software Project Management Plan (SPMP)
**Project Name:** Inventory.MAUI
**Standard Compliance:** IEEE 1058
**Date:** [Current Date]

## 1. Overview
### 1.1 Project Summary
The Inventory.MAUI project is a cross-platform inventory management application targeting .NET 9 MAUI. The project aims to provide local and synchronized database operations, secure user authentication, and comprehensive role-based access control.

### 1.2 Evaluation of the SPMP
This document is updated per standard agile sprint cadences.

## 2. Project Organization
### 2.1 Process Model
An Agile Scrum approach will be used with 2-week iterations.
### 2.2 Organizational Structure
- **Product Owner:** Defines requirements and prioritizes backlog.
- **Scrum Master:** Facilitates process.
- **Development Team:** MAUI Developers, QA, Database Administrators.

### 2.3 Organizational Boundaries and Interfaces
Interfaces with external dependencies including IT operations for database hosting and corporate directory synchronization if applicable.

## 3. Managerial Process
### 3.1 Management Objectives and Priorities
Security and proper implementation of the MVVM pattern are paramount.
### 3.2 Assumptions, Dependencies, and Constraints
- **Assumptions:** Target hardware supports modern .NET 9 runtimes.
- **Dependencies:** Entity Framework Core, CommunityToolkit.Mvvm.
- **Constraints:** Must operate efficiently across Windows, macOS, iOS, and Android.
### 3.3 Risk Management
Risks include data synchronization conflicts and cross-platform UI inconsistencies.
### 3.4 Monitoring and Controlling Mechanisms
Managed via Pull Requests, CI/CD pipeline build checks, and unit testing thresholds.
### 3.5 Staffing Plan
Requires developers proficient in XAML, C# 13, and EF Core.

## 4. Technical Process
### 4.1 Methods, Tools, and Techniques
Visual Studio IDE, Git source control, SQLite/SQL Server.
### 4.2 Software Documentation
Includes SPMP, SRS, SDD, and testing specifications.

## 5. Work Packages, Schedule, and Budget
### 5.1 Work Packages
- WP1: User Authentication Module
- WP2: User Administration and RBAC
- WP3: Inventory Core Management
### 5.2 Dependencies
Authentication is an absolute prerequisite to WP2 and WP3.
### 5.3 Resource Requirements
Cloud hosting for database (Azure), test devices (monitors, ipads, android tablets).
### 5.4 Budget and Resource Allocation
As specified per organizational constraints.
### 5.5 Schedule
Defined iteratively in Agile management tools (Jira/Azure DevOps).
