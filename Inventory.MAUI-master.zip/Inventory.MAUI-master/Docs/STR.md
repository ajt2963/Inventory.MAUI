# Software Test Report (STR)
**Project Name:** Inventory.MAUI
**Standard Compliance:** IEEE 829
**Date:** [Execution Date]

## 1. Introduction
This report documents the results of test executions based on the Software Test Description (STD).

## 2. Test Execution Summary
- **Test Build Version:** v0.9.0-rc1
- **Platforms Tested:** Windows 10/11, macOS (Mac Catalyst), Android 14

## 3. Results by Test Case
- **TC_AUTH_01 (Login Success):** [PASS]
- **TC_AUTH_02 (Login Failure):** [PASS]
- **TC_ADMIN_01 (Delete Own Account):** [PASS]
- **TC_ADMIN_02 (Role Creation):** [PASS]
- **TC_UI_01 (Scaling Validation):** [PASS/WARN] (Mac Catalyst required minor margin adjustments, patched in PR #14).

## 4. Defect Logs
- *No critical defects currently active.* 
- *Low Priority:* Text contrast in dark mode on Android differs slightly from specification.

## 5. Approvals
- Signed off by QA. Valid for release to UAT staging.