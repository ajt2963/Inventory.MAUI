# Software Test Description (STD) / Test Cases
**Project Name:** Inventory.MAUI
**Standard Compliance:** IEEE 829
**Date:** [Current Date]

## 1. Introduction
This document defines detailed test procedures extending from the Master Test Plan (MTP_INVENTORY_MAUI_v1.0).

## 2. Test Cases: Authentication
### TC_AUTH_01: Login Success
- **Action:** User enters valid `ATTUID` and correct password, clicks Login.
- **Expected Result:** `PasswordHasher` validates hash; `AppSessionService` stores token; Dashboard view loads.
### TC_AUTH_02: Login Failure (Bad Creds)
- **Action:** User enters valid `ATTUID` and incorrect password.
- **Expected Result:** "Invalid Credentials" message; Access denied.

## 3. Test Cases: Administration
### TC_ADMIN_01: Delete Own Account
- **Action:** Logged-in admin selects their own `ATTUID` in `UserAdminViewModel` and triggers `DeleteUserCommand`.
- **Expected Result:** Execution is intercepted by constraint: "You cannot delete your own account." Payload is not erased.

### TC_ADMIN_02: Role Creation
- **Action:** Admin provides a new Role Name "Auditor" with only `CanView = true`, triggers `SaveRoleCommand`.
- **Expected Result:** EF Core triggers an `INSERT` statement. Data correctly appears in the Roles observable collection.

## 4. Test Cases: UI and Portability
### TC_UI_01: Scaling Validation
- **Action:** App runs on a Windows host and is resized horizontally.
- **Expected Result:** XAML `Grid` implementations scale cleanly without absolute text clipping.