# System Administrator Guide
**Project Name:** Inventory.MAUI
**Version:** 1.0

## 1. Introduction
This guide instructs IT operations and system administrators on configuring and deploying the backend requirements for the Inventory.MAUI client app.

## 2. Configuration (`appsettings.json`)
The application relies on .NET standard configuration patterns injected into the MAUI host. Environment-specific behaviors must be tailored via the `local` json configurations:
- `appsettings.local.json`
- `appsettings.android.local.json` 
- `appsettings.ios.local.json`

**Important:** Do NOT commit your production `local` overrides to source control.

## 3. Database Deployment
The host SQL environment requires initialization using EF Core Migrations based on `InventoryDbContext`.
1. Execute `dotnet ef database update` pointing to the designated secure SQL Server Endpoint.
2. The initial migration generates default fallback Admin credentials.

## 4. Application Distribution
- Windows: Distribute via MSStore or Sideloading MSIX.
- iOS: Enterprise Distribution via Apple Developer Enterprise Program or Intune MDM.
- Android: APK/AAB distribution via Managed Google Play.

## 5. Backup Procedures
Data resides completely off-device in the external SQL instance. Standard DBA backup regimens on the host SQL Server apply. No state is locally unrecoverable.