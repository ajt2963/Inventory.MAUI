# Software Design Description (SDD)
**Project Name:** Inventory.MAUI
**Standard Compliance:** IEEE 1016-2009
**Date:** [Current Date]

## 1. Introduction
### 1.1 Purpose
This SDD details the architectural and component-level software design for the Inventory.MAUI project.

### 1.2 Scope
This scope encompasses the .NET 9 MAUI frontend, business logic layers, and EF Core data context integrations.

## 2. Design Stakeholders and Concerns
### 2.1 Stakeholders
Developers, System Architects, Quality Assurance.
### 2.2 Design Concerns
- Maintain UI consistency regardless of OS.
- Implement robust Role-Based Access Control (RBAC).

## 3. System Architecture
### 3.1 Architecture Overview
The system relies on the MVVM (Model-View-ViewModel) architectural pattern, separating the UI from the underlying logic.

### 3.2 View (XAML)
Declarative layouts representing screens (`LoginPage.xaml`, `UserAdminView.xaml`). Code-behind primarily utilized for initialization bindings.

### 3.3 ViewModel Layer
The ViewModels (`UserAdminViewModel`, etc.) handle commands and business validations. They rely on dependency-injected Services.

### 3.4 Services Layer
Contains application data access such as `IAppUserService` and central state objects like `AppSessionService`. Handles hashing through `PasswordHasher`.

### 3.5 Model Data Context Layer
Managed via Entity Framework Core (`InventoryDbContext`). Encapsulates objects mapped directly to underlying RDBMS.

## 4. Component Design
### 4.1 Dependency Injection
Centralized within `MauiProgram.cs`. All ViewModels and Services exist dynamically resolved by the Host application.

### 4.2 Application Configuration
Handled by hierarchical JSON files: `appsettings.local.json`, `appsettings.android.local.json`, etc.

### 4.3 Database Implementation
Models such as `AppUser` map strictly to Data tables. Validation rules are codified in Context configurations and Data Annotations.

## 5. Security Concept
- Authentication enforces zero-plaintext storage of passwords through cryptographic hashing.
- Role policies (flags: `CanView`, `CanCreate`, `CanAdmin`) orchestrate feature availability per active Session.
