# Software Requirements Specification (SRS)
**Project Name:** Inventory.MAUI
**Standard Compliance:** IEEE 830-1998
**Date:** [Current Date]

## 1. Introduction
### 1.1 Purpose
This document specifies the software requirements for the comprehensive Inventory Management System (Inventory.MAUI).

### 1.2 Scope
Inventory.MAUI is a mobile and desktop companion app allowing staff to manage user roles, and catalogue hardware/inventory resources dynamically across networks.

### 1.3 Definitions, Acronyms, and Abbreviations
- **RBAC:** Role-Based Access Control
- **MAUI:** Multi-platform App UI
- **MVVM:** Model-View-ViewModel

## 2. Overall Description
### 2.1 Product Perspective
A standalone multi-platform application communicating with a central database.

### 2.2 Product Functions
- Authentication: Secure login/logout flows.
- User Admin: Full CRUD operations for Users and Roles.
- Inventory Management: Tracking hardware assets and adjusting attributes/states.

### 2.3 User Classes and Characteristics
- **Administrators:** Possess `CanAdmin` capabilities; total system overhaul capability.
- **Managers:** Possess `CanCreate/Edit/Delete` privileges.
- **Viewers:** Possess `CanView` (read-only) characteristics.

### 2.4 Operating Environment
iOS, Android, Windows 10/11, macOS via Mac Catalyst. Framework target: .NET 9.

### 2.5 Assumptions and Dependencies
Must have real-time or intermittent connection to validate credential payload data through internal network contexts.

## 3. Specific Requirements
### 3.1 External Interfaces
- Data Access: Implemented through EF Core connected to the organizational endpoint.
- UI: Implement components dynamically scaling for small touch screens and large pointer screens.

### 3.2 Functional Requirements
- **FR_01_LOGIN:** Application shall provide an interface enforcing validation of ATTUID and password entries.
- **FR_02_USER_ADMIN:** Application shall provide views mapping to `UserAdminViewModel` permitting authorized entities to edit User details (`EditDisplayName`, `EditEmail`).
- **FR_03_ROLE_CREATION:** Administrator level entities shall define permission groups explicitly mapping functionality variables (`EditCanView`, etc.).
- **FR_04_PW_RESET:** Administrator endpoints shall provide capability to expire and enforce password renewals (via `AdminResetPasswordAsync`).

### 3.3 Security Requirements
- All passwords must transit securely and sit hashed using cryptographic primitives (i.e. `PasswordHasher.cs`).
- Hardcoded sensitive endpoint variables are prohibited; all application settings derive from local environment settings via DI injection.

### 3.4 Software Quality Attributes
- **Usability:** Provide reactive XAML UI components ensuring feedback delays remain under < 200 ms.
- **Reliability:** App shall safeguard UI freezing using non-blocking threads (`async`/`await` Task executions).
