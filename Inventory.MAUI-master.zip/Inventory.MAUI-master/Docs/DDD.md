# Database Design Document (DDD)
**Project Name:** Inventory.MAUI
**Date:** [Current Date]

## 1. Introduction
This document outlines the exhaustive data schemas, entity relationships, constraints, and access patterns used in the Inventory.MAUI database environment modeled within `InventoryDbContext` using Entity Framework Core 9.

## 2. Infrastructure
- **Data Access Layer:** Entity Framework Core (EF Core) 9.0.
- **Context Configuration:** Managed via `InventoryDbContext`. Data configuration connection strings are dynamically injected per platform deployment.
- **Relational Integrity:** Defined selectively leveraging EF Core Fluent API. "Restrict" deletion cascades are heavily enforced.

## 3. Entity Definitions & Schema

### 3.1 Core Inventory Architecture
*   **InventoryItem:** The root physical asset map aggregating overarching asset data.
    *   *Primary Key:* `InventoryID`
    *   *Foreign Links:* Aggregates references to `AssetID`, `TypeID`, `CompanyID`, `StorageID`, `LocationID`, `CatID`, `OwnerID`, and `NotesID`.
*   **Asset:** The specific instance detailing physical properties.
    *   *Primary Key:* `AssetID`
    *   *Foreign Key:* Linked `1:1` or `N:1` via `InventoryItem`.
*   **AssetOwner:** Organizes human or organizational tag mappings to an asset.
    *   *Primary Key:* `OwnerID`
*   **AssetType:** Categorization framework for the specific form factor of the asset.
    *   *Primary Key:* `TypeID`
*   **Category:** Broad categorization indexing (e.g., Electronics, Furniture).
    *   *Primary Key:* `CatID`
*   **AssetUse:** Usage, checkout sequence, and lifecycle logic mapping.
    *   *Primary Key:* `UseLogID`
    *   *Foreign Key:* Linked to `AssetID`.

### 3.2 Supply Chain, Locations & Logistics
*   **Locations:** Generalized site or regional storage environments.
    *   *Primary Key:* `LocationID`
*   **InventoryStorage:** Granular geometric plotting correlating to specific bins, shelves, or cabinets.
    *   *Primary Key:* `StorageID`
    *   *Dynamic Generation:* A `DisplayValue` string is dynamically evaluated on Add/Update saves, deliberately bypassing rigid EF Core tracking (`PropertySaveBehavior.Ignore`).
*   **Shipping:** Logistics manifests binding to utilization logs.
    *   *Primary Key:* `ShippingID`
    *   *Pricing Schema:* `ShipCost` precisely typed as `decimal(18, 2)`.
    *   *Relationships:* Explicitly enforces `DeleteBehavior.Restrict` over `ShipFromID` and `ShipToID` location references to block cascading table purges.
*   **Customs:** International logistics and valuation processing.
    *   *Primary Key:* `CustomsID`
    *   *Pricing Schema:* `CommercialValue` & `PurchasePrice` securely map as `decimal(18, 2)`.

### 3.3 Organizations, Metadata & Maintenance
*   **Companies:** Partner networks, manufacturing targets, or independent vendors. 
    *   *Primary Key:* `CompanyID`
    *   *Properties:* `CompanyName` (Required, Max Length 100).
*   **Roles (Companies):** Base role definitions for company associations (`RoleName` Max Length 100). Generated on add (`RoleID`).
*   **CompanyRoles:** Cross-relational pivot infrastructure establishing secure multi-link `CRID` associations bridging `Roles` to `Companies`. `DeleteBehavior.Restrict` is strictly applied here to preserve audit trails.
*   **Contacts:** Personal liaison details tied to entities or usage logs.
    *   *Primary Key:* `ContactID`
*   **Calibration:** Maintenance tracking framework.
    *   *Primary Key:* `CalInfoID` (Value generated on add).
*   **CalibrationSchedule:** Future maintenance projection lifecycle.
    *   *Primary Key:* `CSID` (Value generated on add).
*   **Projects:** Links inventory usage directly to internal organizational initiatives.
    *   *Primary Key:* `ProjectID`
*   **Notes:** Aggregated generic text storage linked back to parent Inventory mappings.
    *   *Primary Key:* `NotesID`
*   **CTTMInventory:** Specialized tool kit or configuration tracking matrix.
    *   *Primary Key:* `ToolKitID`
*   **ReferenceValues:** System-dependent parameters and drop-downs. Optimized globally via distinct compound unique indexes applied concurrently to `(Domain, Code)` and `(Domain, Display)`.

### 3.4 Identity & User Access Management (IAM)
*   **AppUser:** Internal enterprise authenticators granted client interaction privileges mapping directly to role capabilities.
    *   *Primary Mapping:* `UserID`
    *   *Directory Sync Schema:* `ATTUID` operates as the definitive unique credential index (`IsUnique()`, Required, Max Length 100).
    *   *Properties:* `DisplayName` (Required, Max 150), `Email` (Max 200).
    *   *Cryptography Architecture:* `PasswordHash` and `PasswordSalt` allocated 500 characters.
    *   *Role Enforcement:* Foreign key maps to `RoleID` dynamically linked with `DeleteBehavior.Restrict`.
*   **AppRole:** RBAC definition vectors authorizing the user layer.
    *   *Primary Mapping:* `RoleID`, `RoleName` (Required, Max Length 50).

## 4. Performance Views Architecture
*   **InventoryList:** Has no active tracking key definition (`HasNoKey()`). Architected natively as a database view via `ToView("InventoryList")`. Bypasses EF Core entity orchestration, allowing high-performance read-only payload transfers.
