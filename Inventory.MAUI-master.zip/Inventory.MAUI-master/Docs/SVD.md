# Software Version Description (SVD) / Release Notes
**Project:** Inventory.MAUI

## Version 1.0.0 (Initial Release)
**Release Date:** [Current Date]
**Supported Platforms:** iOS 17+, Android 14+, Mac Catalyst (macOS 14+), Windows 10/11.

### Features
- Implemented robust bi-directional database synchronization using EF Core.
- Established secure login portal utilizing hashing primitives for `PasswordHasher`.
- Integrated `UserAdminViewModel` controlling full suite of CRUD tools for App Users and Roles.

### Bug Fixes
- Addressed XAML padding bug occurring specifically when compiled to iOS target.
- Corrected issue preventing the `IncludedInactive` boolean from refreshing the Users `ObservableCollection`.

### Known Issues
- Network timeout handling is occasionally delayed if connection abruptly drops behind a weak proxy.
- UI scaling on older legacy Android tablet resolutions requires manual scrolling in some data grid structures. 

### Migration Instructions
This release encapsulates the initial data seed. Validate `appsettings.local.json` environment variables before compiling to MSIX / APK.