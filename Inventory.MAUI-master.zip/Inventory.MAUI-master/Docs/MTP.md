# Master Test Plan (MTP)
**Project Name:** Inventory.MAUI
**Standard Compliance:** IEEE 829
**Date:** [Current Date]

## 1. Test Plan Identifier
MTP_INVENTORY_MAUI_v1.0

## 2. Introduction
This plan outlines the testing strategies, resources, and scope for verifying the Inventory.MAUI application built using .NET 9.

## 3. Test Items
- Presentation UIs (Pages vs Modals)
- ViewModels (Specifically `UserAdminViewModel`)
- Authentication / Validation (`PasswordHasher`, `AppSessionService`)
- Infrastructure (Data interactions handling `IAppUserService`)

## 4. Features to Be Tested
- User Login functionality and fail-state handling (lockout, bad credentials routing).
- User Creation, Editing, and Roles Binding.
- Deletion logic ensuring safeguards prevent self-deletion loops ("You cannot delete your own account").

## 5. Features Not to Be Tested
- External DB Host infrastructure reliability (Assumed handled by IT operations).

## 6. Approach
1.  **Unit Testing:** Implement testing leveraging `xUnit` to validate viewmodel logic devoid of UI properties. Focus heavily on RBAC `CanAdmin` booleans yielding expected workflow enablement.
2.  **Integration Testing:** Execute tests assessing EF Core in-memory DB connections versus the Service layers.
3.  **UI Testing:** Manual test matrix runs validating XAML cross-platform fidelity on iPad (iOS), Android Tablet, and Windows Desktop arrays.

## 7. Pass/Fail Criteria
- Tests must complete successfully 100% on logical layers.
- Known non-critical cosmetic UI bugs are permissible upon Product Owner override approvals prior to Sprint Demo.

## 8. Suspension criteria and resumption requirements
- Critical crash directly related to runtime DI container failure halts all ongoing sprint QA immediately till patching resolves core `MauiProgram.cs` builds.

## 9. Hardware & Environmental Requirements
Test Rigs encompassing:
- Physical Android Device (Android 14)
- iOS Physical iPad (iOS 17/18)
- Windows Host (Windows 11) for MSIX local deployment evaluations.

## 10. Approvals
Stakeholders signify agreement verifying adequate test coverage strategies.
