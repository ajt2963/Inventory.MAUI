# User Manual
**Project Name:** Inventory.MAUI

## 1. Getting Started
Welcome to the Inventory Management System. This application enables you to securely track hardware, adjust assets, and manage internal users depending on your permission level.

## 2. Authentication
1. Launch the application.
2. At the login screen, enter your unique identification (ATTUID) and your password.
3. If this is your first time logging in, you will be prompted to alter your password immediately.

## 3. Navigation
The main interface scales to your device. Use the left-side hamburger menu (or bottom tabs on mobile) to navigate between:
- **Dashboard:** At a glance metrics.
- **Inventory List:** Search and edit hardware.
- **Administration:** (Requires Admin Role) Manage system users.

## 4. Account Management (For Admins)
1. Navigate to the **Admin** tab.
2. Select an existing user to edit their profile, re-assign their role, or disable them.
3. Select "New User" to invite a fresh account. You must set a temporary password which they must change upon next login.
4. **Note:** You cannot delete or lockout the account you are currently logged into.

## 5. Security & Session
The application enforces strict session controls. If you are inactive for an extended period, you will be automatically returned to the `LoginPage` to re-validate.