using Android.App;
using Android.Content;
using Android.Provider;

namespace Inventory.MAUI.Services;

/// <summary>
/// Android implementation using Storage Access Framework (SAF).
/// Opens the system "Save As" file picker � user chooses the location.
/// Works on all Android versions with scoped storage (API 29+).
/// </summary>
public sealed class AndroidFileSaveService : IFileSaveService
{
    private static TaskCompletionSource<Android.Net.Uri?>? _pendingResult;
    private const int CreateDocumentRequestCode = 9001;

    public async Task<string?> SaveFileAsync(string suggestedFileName, string content, string mimeType = "text/csv")
    {
        var activity = Platform.CurrentActivity;
        if (activity is null)
            return null;

        _pendingResult = new TaskCompletionSource<Android.Net.Uri?>();

        var intent = new Intent(Intent.ActionCreateDocument);
        intent.AddCategory(Intent.CategoryOpenable);
        intent.SetType(mimeType);
        intent.PutExtra(Intent.ExtraTitle, suggestedFileName);

        activity.StartActivityForResult(intent, CreateDocumentRequestCode);

        var uri = await _pendingResult.Task;
        if (uri is null)
            return null;

        // Write content to the URI the user selected
        using var outputStream = activity.ContentResolver?.OpenOutputStream(uri);
        if (outputStream is null)
            return null;

        var bytes = System.Text.Encoding.UTF8.GetBytes(content);
        await outputStream.WriteAsync(bytes, 0, bytes.Length);
        await outputStream.FlushAsync();

        // Return a friendly display name
        return GetDisplayName(activity, uri) ?? suggestedFileName;
    }

    /// <summary>
    /// Must be called from MainActivity.OnActivityResult to complete the pending save operation.
    /// </summary>
    public static void OnActivityResult(int requestCode, Result resultCode, Intent? data)
    {
        if (requestCode != CreateDocumentRequestCode)
            return;

        if (resultCode == Result.Ok && data?.Data is not null)
            _pendingResult?.TrySetResult(data.Data);
        else
            _pendingResult?.TrySetResult(null);
    }

    private static string? GetDisplayName(Activity activity, Android.Net.Uri uri)
    {
        try
        {
            using var cursor = activity.ContentResolver?.Query(uri, new[] { MediaStore.IMediaColumns.DisplayName }, null, null, null);
            if (cursor is not null && cursor.MoveToFirst())
            {
                var idx = cursor.GetColumnIndex(MediaStore.IMediaColumns.DisplayName);
                if (idx >= 0) return cursor.GetString(idx);
            }
        }
        catch { }
        return null;
    }
}
