using Microsoft.Maui.Handlers;
using Microsoft.Maui.Controls.Handlers.Items;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;

namespace Inventory.MAUI.Platforms.Windows;

internal static class CollectionViewScrollBarMapper
{
    public static void EnableScrollBars()
    {
        // Ensure CollectionView vertical/horizontal scroll bar visibility maps to the underlying WinUI ScrollViewer.
        CollectionViewHandler.Mapper.AppendToMapping("ScrollBarVisibility", (handler, view) =>
        {
            if (handler.PlatformView is not ListViewBase list)
                return;

            var scrollViewer = FindScrollViewer(list);
            if (scrollViewer is null)
                return;

            scrollViewer.VerticalScrollBarVisibility = Microsoft.UI.Xaml.Controls.ScrollBarVisibility.Visible;
            scrollViewer.HorizontalScrollBarVisibility = Microsoft.UI.Xaml.Controls.ScrollBarVisibility.Visible;
        });
    }

    private static ScrollViewer? FindScrollViewer(DependencyObject root)
    {
        if (root is ScrollViewer sv)
            return sv;

        var count = VisualTreeHelper.GetChildrenCount(root);
        for (var i = 0; i < count; i++)
        {
            var child = VisualTreeHelper.GetChild(root, i);
            var found = FindScrollViewer(child);
            if (found is not null)
                return found;
        }

        return null;
    }
}
