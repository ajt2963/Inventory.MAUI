using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Inventory.MAUI.Models;

/// <summary>
/// Key-value store for application-wide configuration settings.
/// Used for password policy, feature flags, SSO/MFA configuration, etc.
/// All values are stored as strings and parsed by the consuming service.
/// </summary>
[Table("SystemSettings")]
public sealed class SystemSetting
{
    [Key, MaxLength(100)]
    public string SettingKey { get; set; } = string.Empty;

    /// <summary>The setting value. JSON for complex types, plain string for simple ones.</summary>
    [MaxLength(4000)]
    public string? SettingValue { get; set; }

    /// <summary>Category for grouping in the admin UI (e.g., "PasswordPolicy", "Mfa", "Sso").</summary>
    [MaxLength(50)]
    public string? Category { get; set; }

    /// <summary>Human-readable description shown in the admin UI.</summary>
    [MaxLength(500)]
    public string? Description { get; set; }

    /// <summary>Last modified timestamp (UTC).</summary>
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Well-known setting key constants.
/// </summary>
public static class SettingKeys
{
    // Password Policy
    public const string PasswordMinLength = "Password.MinLength";
    public const string PasswordMaxLength = "Password.MaxLength";
    public const string PasswordRequireUpper = "Password.RequireUppercase";
    public const string PasswordRequireLower = "Password.RequireLowercase";
    public const string PasswordRequireDigit = "Password.RequireDigit";
    public const string PasswordRequireSpecial = "Password.RequireSpecialChar";
    public const string PasswordHistoryCount = "Password.HistoryCount";
    public const string PasswordExpiryDays = "Password.ExpiryDays";

    // Lockout
    public const string LockoutMaxAttempts = "Lockout.MaxAttempts";
    public const string LockoutDurationMinutes = "Lockout.DurationMinutes";

    // Session
    public const string SessionTimeoutMinutes = "Session.TimeoutMinutes";

    // MFA
    public const string MfaEnabled = "Mfa.Enabled";
    public const string MfaEnforcementMode = "Mfa.EnforcementMode"; // "Optional", "Required", "PerRole"
    public const string MfaMethod = "Mfa.Method"; // "EmailOtp", "Totp"

    // SSO
    public const string SsoEnabled = "Sso.Enabled";
    public const string SsoProviderType = "Sso.ProviderType"; // "OAuth2", "OIDC", "SAML2", "EntraID"
    public const string SsoAuthorityUrl = "Sso.AuthorityUrl";
    public const string SsoClientId = "Sso.ClientId";
    public const string SsoClientSecret = "Sso.ClientSecret";
    public const string SsoTenantId = "Sso.TenantId";
    public const string SsoScopes = "Sso.Scopes";
    public const string SsoRedirectUri = "Sso.RedirectUri";
    public const string SsoIdpMetadataUrl = "Sso.IdpMetadataUrl";
    public const string SsoIdpEntityId = "Sso.IdpEntityId";
    public const string SsoSpEntityId = "Sso.SpEntityId";
    public const string SsoCertificateThumbprint = "Sso.CertificateThumbprint";
    public const string SsoAcsUrl = "Sso.AcsUrl";

    // Categories
    public const string CategoryPassword = "PasswordPolicy";
    public const string CategoryLockout = "Lockout";
    public const string CategorySession = "Session";
    public const string CategoryMfa = "Mfa";
    public const string CategorySso = "Sso";
}
