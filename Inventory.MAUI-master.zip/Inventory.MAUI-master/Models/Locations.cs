using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Inventory.MAUI.Models
{
    public partial class Locations : INotifyPropertyChanged
    {
        private int? _locationID;
        private string? _clliCode;
        private string? _locationName;
        private DateTime? _dateModified;
        private string? _modifiedBy;
        private int? _contactID;

        [Key]
        public int? LocationID
        {
            get => _locationID;
            set { if (_locationID != value) { _locationID = value; OnPropertyChanged(nameof(LocationID)); } }
        }

        public string? ClliCode
        {
            get => _clliCode;
            set { if (_clliCode != value) { _clliCode = value; OnPropertyChanged(nameof(ClliCode)); } }
        }

        public string? LocationName
        {
            get => _locationName;
            set { if (_locationName != value) { _locationName = value; OnPropertyChanged(nameof(LocationName)); } }
        }

        public DateTime? DateModified
        {
            get => _dateModified;
            set { if (_dateModified != value) { _dateModified = value; OnPropertyChanged(nameof(DateModified)); } }
        }

        public string? ModifiedBy
        {
            get => _modifiedBy;
            set { if (_modifiedBy != value) { _modifiedBy = value; OnPropertyChanged(nameof(ModifiedBy)); } }
        }

        public int? ContactID
        {
            get => _contactID;
            set { if (_contactID != value) { _contactID = value; OnPropertyChanged(nameof(ContactID)); } }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
