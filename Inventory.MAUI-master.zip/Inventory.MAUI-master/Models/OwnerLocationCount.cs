namespace Inventory.MAUI.Models
{
    public class OwnerLocationCount
    {
        public string? ClliCode { get; set; }
        public string? LocationName { get; set; }
        public string? OwnerName { get; set; }
        public int Count { get; set; }
    }
}