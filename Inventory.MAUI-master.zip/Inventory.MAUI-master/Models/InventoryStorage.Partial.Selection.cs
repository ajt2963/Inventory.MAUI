using System.ComponentModel.DataAnnotations.Schema;

namespace Inventory.MAUI.Models
{
    public partial class InventoryStorage
    {
        private bool _isSelected;

        [NotMapped]
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected == value) return;
                _isSelected = value;
                OnPropertyChanged(nameof(IsSelected));
            }
        }
    }
}