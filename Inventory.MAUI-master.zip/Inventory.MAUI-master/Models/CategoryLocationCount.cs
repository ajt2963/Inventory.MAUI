namespace Inventory.MAUI.Models
{
    public class CategoryLocationCount
    {
        public string? ClliCode { get; set; }
        public string? LocationName { get; set; }
        public string? CategoryName { get; set; }
        public int Count { get; set; }
    }
}