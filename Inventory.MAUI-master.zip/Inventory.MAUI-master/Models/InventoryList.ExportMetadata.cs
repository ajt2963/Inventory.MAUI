using System.ComponentModel.DataAnnotations.Schema;

namespace Inventory.MAUI.Models
{
    // Metadata / transient properties used only for grouped export & print.
    // EF Core will ignore these because of [NotMapped].
    public partial class InventoryList
    {
        [NotMapped] public bool IsGroupHeader { get; set; }          // True when this is a synthetic group row
        [NotMapped] public int  GroupLevel { get; set; }              // 0=Storage,1=Divider,2=Section,3=Option
        [NotMapped] public string? GroupLabel { get; set; }           // e.g. "Storage: BAY-01"
        [NotMapped] public int? GroupItemCount { get; set; }          // Number of data rows in the group
        [NotMapped] public int? GroupQuantitySum { get; set; }        // Aggregate quantity (used for Storage level)
    }
}   