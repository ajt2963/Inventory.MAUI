using System.Collections.Generic;

namespace Inventory.MAUI.Models.Help
{
    public sealed class HelpTopic
    {
        public string Id { get; set; } = string.Empty;         // Slug or generated
        public string Title { get; set; } = string.Empty;
        public string OriginalTitle { get; set; } = string.Empty;
        public string? HtmlContent { get; set; }               // Body content (no child content)
        public int Level { get; set; }                         // 1 = Heading1, etc.
        public List<HelpTopic> Children { get; } = new();
    }
}