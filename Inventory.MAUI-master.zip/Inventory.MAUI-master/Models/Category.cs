using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Inventory.MAUI.Models
{
    public partial class Category : INotifyPropertyChanged
    {
        //public Category() { }

        [Key]
        public int CatID { get; set; }
        public required string CatName { get; set; }
        public string? Description { get; set; }
        public DateTime DateModified { get; set; }
        public required string ModifiedBy { get; set; }

        private bool _isSelected;

        [NotMapped]
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected != value)
                {
                    _isSelected = value;
                    OnPropertyChanged(nameof(IsSelected));
                }
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string? propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
