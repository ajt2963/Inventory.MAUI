namespace Inventory.MAUI.Models
{
    public class ManufacturerLocationCount
    {
        public string? ClliCode { get; set; }
        public string? LocationName { get; set; }
        public string? ManufacturerName { get; set; }
        public int Count { get; set; }
    }
}