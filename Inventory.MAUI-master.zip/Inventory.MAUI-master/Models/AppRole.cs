using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;

namespace Inventory.MAUI.Models;

[Table("AppRole")]
public class AppRole : INotifyPropertyChanged
{
    private int _roleID;
    private string _roleName = string.Empty;
    private bool _canView = true;
    private bool _canCreate;
    private bool _canEdit;
    private bool _canDelete;
    private bool _canAdmin;
    private bool _isSelected;

    [Key]
    public int RoleID
    {
        get => _roleID;
        set => Set(ref _roleID, value);
    }

    [Required, MaxLength(50)]
    public string RoleName
    {
        get => _roleName;
        set => Set(ref _roleName, value);
    }

    public bool CanView
    {
        get => _canView;
        set => Set(ref _canView, value);
    }

    public bool CanCreate
    {
        get => _canCreate;
        set => Set(ref _canCreate, value);
    }

    public bool CanEdit
    {
        get => _canEdit;
        set => Set(ref _canEdit, value);
    }

    public bool CanDelete
    {
        get => _canDelete;
        set => Set(ref _canDelete, value);
    }

    public bool CanAdmin
    {
        get => _canAdmin;
        set => Set(ref _canAdmin, value);
    }

    [NotMapped]
    public bool IsSelected
    {
        get => _isSelected;
        set => Set(ref _isSelected, value);
    }

    public override string ToString() => RoleName;

    public event PropertyChangedEventHandler? PropertyChanged;

    private bool Set<T>(ref T field, T value, [CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
            return false;
        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        return true;
    }
}
