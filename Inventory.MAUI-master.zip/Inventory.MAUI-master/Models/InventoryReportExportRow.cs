using System;

namespace Inventory.MAUI.Models
{
    // Represents either a group header row OR a data row.
    // If GroupHeader is not null/empty, all other fields are treated as non-rendered for that row.
    public sealed class InventoryReportExportRow
    {
        public string? GroupHeader { get; init; }

        public int? InventoryID { get; init; }
        public string? AssetTag { get; init; }
        public string? CatName { get; init; }
        public string? Type { get; init; }
        public string? PartNumber { get; init; }
        public string? SerialNumber { get; init; }
        public string? Description { get; init; }
        public int? Quantity { get; init; }
        public string? CompanyName { get; init; }
        public string? Storage { get; init; }
        public string? Divider { get; init; }
        public string? Section { get; init; }
        public string? Option { get; init; }
        public string? Owner { get; init; }

        public bool IsGroupHeader => !string.IsNullOrWhiteSpace(GroupHeader);

        public static InventoryReportExportRow CreateGroup(string header)
            => new() { GroupHeader = header };

        public static InventoryReportExportRow CreateData(
            int? inventoryId,
            string? assetTag,
            string? catName,
            string? type,
            string? partNumber,
            string? serialNumber,
            string? description,
            int? quantity,
            string? companyName,
            string? storage,
            string? divider,
            string? section,
            string? option,
            string? owner)
            => new()
            {
                InventoryID = inventoryId,
                AssetTag = assetTag,
                CatName = catName,
                Type = type,
                PartNumber = partNumber,
                SerialNumber = serialNumber,
                Description = description,
                Quantity = quantity,
                CompanyName = companyName,
                Storage = storage,
                Divider = divider,
                Section = section,
                Option = option,
                Owner = owner
            };
    }
}