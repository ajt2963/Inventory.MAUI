using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Inventory.MAUI.Models
{
    public partial class Asset : INotifyPropertyChanged
    {
        [Key]
        public int AssetID { get; set; }
        public int? InventoryID { get; set; }
        public string? AssetTag { get; set; }
        private string? _status;
        private bool _isSelected;

        public string? Status
        {
            get => _status;
            set
            {
                if (_status != value)
                {
                    _status = value;
                    OnPropertyChanged(nameof(Status));
                }
            }
        }

        public DateTime? DateModified { get; set; }
        public string? ModifiedBy { get; set; }

        private string? _toolKitID;

        public string? ToolKitID
        {
            get => _toolKitID;
            set
            {
                if (_toolKitID != value)
                {
                    _toolKitID = value;
                    OnPropertyChanged(nameof(ToolKitID));
                }
            }
        }

        [NotMapped]
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected != value)
                {
                    _isSelected = value;
                    OnPropertyChanged(nameof(IsSelected));
                }
            }
        }

        [ForeignKey("InventoryID")]
        public virtual InventoryItem? InventoryItem { get; set; }

        public Asset Clone() => (Asset)this.MemberwiseClone();

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}