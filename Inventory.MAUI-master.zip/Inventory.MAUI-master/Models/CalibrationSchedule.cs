/*************************************************************
*  Class:        CalibrationSchedule.cs
*  Description:  Tracks scheduled calibration for individual inventory items.
*  Author:       AT2963
*  Created:      2/3/2025 10:04:47 AM
*  Namespace:    Models
*
*************************************************************/
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;

namespace Inventory.MAUI.Models
{
    public class CalibrationSchedule : INotifyPropertyChanged
    {
        [Key]
        public int? CSID { get; set; }
        public DateTime? LastCalDate { get; set; }
        public DateTime? ScheduledDate { get; set; }
        public string? ServiceProviderName { get; set; }
        public string? ClliCode { get; set; }
        public string? LocationName { get; set; }
        public DateTime? DateModified { get; set; }
        public string? ModifiedBy { get; set; }

        [ForeignKey(nameof(InventoryID))]
        public int? InventoryID { get; set; }

        // Display-only properties populated by joins, not stored in the table
        private string? _assetTag;

        [NotMapped]
        public string? AssetTag
        {
            get => _assetTag;
            set
            {
                if (_assetTag != value)
                {
                    _assetTag = value;
                    OnPropertyChanged();
                }
            }
        }

        private string? _manufacturerName;

        [NotMapped]
        public string? ManufacturerName
        {
            get => _manufacturerName;
            set
            {
                if (_manufacturerName != value)
                {
                    _manufacturerName = value;
                    OnPropertyChanged();
                }
            }
        }

        private string? _partNumber;

        [NotMapped]
        public string? PartNumber
        {
            get => _partNumber;
            set
            {
                if (_partNumber != value)
                {
                    _partNumber = value;
                    OnPropertyChanged();
                }
            }
        }

        private string? _serialNumber;

        [NotMapped]
        public string? SerialNumber
        {
            get => _serialNumber;
            set
            {
                if (_serialNumber != value)
                {
                    _serialNumber = value;
                    OnPropertyChanged();
                }
            }
        }

        private string? _description;

        [NotMapped]
        public string? Description
        {
            get => _description;
            set
            {
                if (_description != value)
                {
                    _description = value;
                    OnPropertyChanged();
                }
            }
        }

        private string? _calNotes;

        [NotMapped]
        public string? CalNotes
        {
            get => _calNotes;
            set
            {
                if (_calNotes != value)
                {
                    _calNotes = value;
                    OnPropertyChanged();
                }
            }
        }

        private string? _calLabel;

        [NotMapped]
        public string? CalLabel
        {
            get => _calLabel;
            set
            {
                if (_calLabel != value)
                {
                    _calLabel = value;
                    OnPropertyChanged();
                }
            }
        }

        private bool _isSelected;

        [NotMapped]
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected != value)
                {
                    _isSelected = value;
                    OnPropertyChanged();
                }
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
