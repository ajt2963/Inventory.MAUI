using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Inventory.MAUI.Models
{
    public partial class Notes : INotifyPropertyChanged
    {
        private int? _notesID;
        private string? _inventoryNotes;
        private DateTime? _dateModified;
        private string? _modifiedBy;

        [Key]
        public int? NotesID
        {
            get => _notesID;
            set { if (_notesID != value) { _notesID = value; OnPropertyChanged(nameof(NotesID)); } }
        }

        public string? InventoryNotes
        {
            get => _inventoryNotes;
            set { if (_inventoryNotes != value) { _inventoryNotes = value; OnPropertyChanged(nameof(InventoryNotes)); } }
        }

        public DateTime? DateModified
        {
            get => _dateModified;
            set { if (_dateModified != value) { _dateModified = value; OnPropertyChanged(nameof(DateModified)); } }
        }

        public string? ModifiedBy
        {
            get => _modifiedBy;
            set { if (_modifiedBy != value) { _modifiedBy = value; OnPropertyChanged(nameof(ModifiedBy)); } }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
