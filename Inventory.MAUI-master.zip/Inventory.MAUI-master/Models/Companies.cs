using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace Inventory.MAUI.Models
{
    public partial class Companies : INotifyPropertyChanged
    {
        private int _companyID;
        private string _companyName = string.Empty;
        private string? _companyType;
        private DateTime? _dateModified;
        private string? _modifiedBy;

        [Key]
        public int CompanyID
        {
            get => _companyID;
            set { if (_companyID != value) { _companyID = value; OnPropertyChanged(); } }
        }

        [Required]
        public string CompanyName
        {
            get => _companyName;
            set { if (_companyName != value) { _companyName = value; OnPropertyChanged(); } }
        }

        public string? CompanyType
        {
            get => _companyType;
            set { if (_companyType != value) { _companyType = value; OnPropertyChanged(); } }
        }

        public DateTime? DateModified
        {
            get => _dateModified;
            set { if (_dateModified != value) { _dateModified = value; OnPropertyChanged(); } }
        }

        public string? ModifiedBy
        {
            get => _modifiedBy;
            set { if (_modifiedBy != value) { _modifiedBy = value; OnPropertyChanged(); } }
        }

        // Navigation property for CompanyRoles
        public virtual ICollection<CompanyRoles> CompanyRoles { get; set; } = new List<CompanyRoles>();

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}

