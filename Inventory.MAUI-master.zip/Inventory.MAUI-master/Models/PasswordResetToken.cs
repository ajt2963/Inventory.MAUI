using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Inventory.MAUI.Models;

/// <summary>
/// A time-limited one-time code sent via email for password recovery.
/// Codes expire after a configurable duration and can only be used once.
/// </summary>
[Table("PasswordResetToken")]
public sealed class PasswordResetToken
{
    [Key]
    public long TokenID { get; set; }

    public int UserID { get; set; }

    /// <summary>The 6-digit one-time code sent to the user's email.</summary>
    [Required, MaxLength(10)]
    public string Token { get; set; } = string.Empty;

    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

    /// <summary>When this token expires. After this time it cannot be used.</summary>
    public DateTime ExpiresAtUtc { get; set; }

    /// <summary>When the token was successfully used. Null if unused.</summary>
    public DateTime? UsedAtUtc { get; set; }

    /// <summary>True if the token is still valid (not expired and not used).</summary>
    [NotMapped]
    public bool IsValid => UsedAtUtc is null && ExpiresAtUtc > DateTime.UtcNow;

    [ForeignKey(nameof(UserID))]
    public AppUser? User { get; set; }
}
