/*************************************************************
*  Class:        Roles
*  Description:  Defines Roles that Companies have in relation to the services and products they provide.
*  Author:       at2963
*  Created:      1/3/2025 8:27:11 AM
*  Modified:     [ModificationDate]
*
*  Code generated using Ask AT&T
*  Source:       https://data.att.com/products-and-services/self-service/askAT-and-T
*  Generated:    2024-09-11 13:27:21 UTC
*************************************************************/

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Inventory.MAUI.Models
{
    public partial class Roles : INotifyPropertyChanged
    {
        private int? _roleID;
        private string? _roleName;

        [Key]
        public int? RoleID
        {
            get => _roleID;
            set
            {
                if (_roleID != value)
                {
                    _roleID = value;
                    OnPropertyChanged(nameof(RoleID));
                }
            }
        }

        public string? RoleName
        {
            get => _roleName;
            set
            {
                if (_roleName != value)
                {
                    _roleName = value;
                    OnPropertyChanged(nameof(RoleName));
                }
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
