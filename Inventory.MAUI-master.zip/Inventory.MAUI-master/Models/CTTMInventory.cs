using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;

namespace Inventory.MAUI.Models
{
    public partial class CTTMInventory : INotifyPropertyChanged
    {
        [Key]
        public string? ToolKitID
        {
            get => _toolKitID;
            set { if (_toolKitID != value) { _toolKitID = value; OnPropertyChanged(); } }
        }
        private string? _toolKitID;

        public string? ToolKitName
        {
            get => _toolKitName;
            set { if (_toolKitName != value) { _toolKitName = value; OnPropertyChanged(); } }
        }
        private string? _toolKitName;

        public string? PartNumber
        {
            get => _partNumber;
            set { if (_partNumber != value) { _partNumber = value; OnPropertyChanged(); } }
        }
        private string? _partNumber;

        public string? SerialNumber
        {
            get => _serialNumber;
            set { if (_serialNumber != value) { _serialNumber = value; OnPropertyChanged(); } }
        }
        private string? _serialNumber;

        public string? Status
        {
            get => _status;
            set { if (_status != value) { _status = value; OnPropertyChanged(); } }
        }
        private string? _status;

        public string? PID
        {
            get => _pid;
            set { if (_pid != value) { _pid = value; OnPropertyChanged(); } }
        }
        private string? _pid;

        public string? ToolKitDescription
        {
            get => _toolKitDescription;
            set { if (_toolKitDescription != value) { _toolKitDescription = value; OnPropertyChanged(); } }
        }
        private string? _toolKitDescription;

        public string? PONumber
        {
            get => _poNumber;
            set { if (_poNumber != value) { _poNumber = value; OnPropertyChanged(); } }
        }
        private string? _poNumber;

        public int? PurchaseYear
        {
            get => _purchaseYear;
            set { if (_purchaseYear != value) { _purchaseYear = value; OnPropertyChanged(); } }
        }
        private int? _purchaseYear;

        public string? TagNumber
        {
            get => _tagNumber;
            set { if (_tagNumber != value) { _tagNumber = value; OnPropertyChanged(); } }
        }
        private string? _tagNumber;

        public bool? Valid
        {
            get => _valid;
            set { if (_valid != value) { _valid = value; OnPropertyChanged(); } }
        }
        private bool? _valid;

        public string? ValidatedBy
        {
            get => _validatedBy;
            set { if (_validatedBy != value) { _validatedBy = value; OnPropertyChanged(); } }
        }
        private string? _validatedBy;

        public DateTime? ValidatedOn
        {
            get => _validatedOn;
            set { if (_validatedOn != value) { _validatedOn = value; OnPropertyChanged(); } }
        }
        private DateTime? _validatedOn;

        public string? ValidatedComments
        {
            get => _validatedComments;
            set { if (_validatedComments != value) { _validatedComments = value; OnPropertyChanged(); } }
        }
        private string? _validatedComments;

        public string? EmplATTUID
        {
            get => _emplATTUID;
            set { if (_emplATTUID != value) { _emplATTUID = value; OnPropertyChanged(); } }
        }
        private string? _emplATTUID;

        public string? EmplName
        {
            get => _emplName;
            set { if (_emplName != value) { _emplName = value; OnPropertyChanged(); } }
        }
        private string? _emplName;

        public string? EmplGLC
        {
            get => _emplGLC;
            set { if (_emplGLC != value) { _emplGLC = value; OnPropertyChanged(); } }
        }
        private string? _emplGLC;

        public string? EmplCostCenter
        {
            get => _emplCostCenter;
            set { if (_emplCostCenter != value) { _emplCostCenter = value; OnPropertyChanged(); } }
        }
        private string? _emplCostCenter;

        public string? EmplSupvATTUID
        {
            get => _emplSupvATTUID;
            set { if (_emplSupvATTUID != value) { _emplSupvATTUID = value; OnPropertyChanged(); } }
        }
        private string? _emplSupvATTUID;

        public string? LocationCLLI
        {
            get => _locationCLLI;
            set { if (_locationCLLI != value) { _locationCLLI = value; OnPropertyChanged(); } }
        }
        private string? _locationCLLI;

        public string? CLLI
        {
            get => _clli;
            set { if (_clli != value) { _clli = value; OnPropertyChanged(); } }
        }
        private string? _clli;

        public string? CLLIMgrATTUID
        {
            get => _clliMgrATTUID;
            set { if (_clliMgrATTUID != value) { _clliMgrATTUID = value; OnPropertyChanged(); } }
        }
        private string? _clliMgrATTUID;

        public string? CLLIMgrName
        {
            get => _clliMgrName;
            set { if (_clliMgrName != value) { _clliMgrName = value; OnPropertyChanged(); } }
        }
        private string? _clliMgrName;

        public string? CLLIGLC
        {
            get => _clliGLC;
            set { if (_clliGLC != value) { _clliGLC = value; OnPropertyChanged(); } }
        }
        private string? _clliGLC;

        public string? CLLICostCenter
        {
            get => _clliCostCenter;
            set { if (_clliCostCenter != value) { _clliCostCenter = value; OnPropertyChanged(); } }
        }
        private string? _clliCostCenter;

        public string? CLLISupvATTUID
        {
            get => _clliSupvATTUID;
            set { if (_clliSupvATTUID != value) { _clliSupvATTUID = value; OnPropertyChanged(); } }
        }
        private string? _clliSupvATTUID;

        public bool? Redeployable
        {
            get => _redeployable;
            set { if (_redeployable != value) { _redeployable = value; OnPropertyChanged(); } }
        }
        private bool? _redeployable;

        public DateTime? LastUpdated
        {
            get => _lastUpdated;
            set { if (_lastUpdated != value) { _lastUpdated = value; OnPropertyChanged(); } }
        }
        private DateTime? _lastUpdated;

        public DateTime? DateModified
        {
            get => _dateModified;
            set { if (_dateModified != value) { _dateModified = value; OnPropertyChanged(); } }
        }
        private DateTime? _dateModified;

        public string? ModifiedBy
        {
            get => _modifiedBy;
            set { if (_modifiedBy != value) { _modifiedBy = value; OnPropertyChanged(); } }
        }
        private string? _modifiedBy;

        private bool _isSelected;
        [NotMapped]
        public bool IsSelected
        {
            get => _isSelected;
            set { if (_isSelected != value) { _isSelected = value; OnPropertyChanged(); } }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
