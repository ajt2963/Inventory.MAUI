/*************************************************************
*  Class:        CableSystem
*  Description:  Defines the entity model for a Cable System and its ownership type.
*  Author:       at2963
*  Created:      2/28/2025 9:44 AM
*  Modified:     [ModificationDate]
*
*  Code generated using Ask AT&T
*  Source:       https://data.att.com/products-and-services/self-service/askAT-and-T
*  Generated:    2024-09-11 13:27:21 UTC
*************************************************************/

using System;
using System.Collections.Generic;
using System.Text;

namespace Inventory.MAUI.Models
{
    public class CableSystem
    {
        public int? CableSystemID { get; set; }
        public string? SystemName { get; set; }
        public string? ExpandedName { get; set; }
        public string? OwnershipType { get; set; }
    }
}
