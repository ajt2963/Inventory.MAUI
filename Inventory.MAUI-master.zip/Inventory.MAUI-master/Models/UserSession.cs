using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Inventory.MAUI.Models;

/// <summary>
/// Tracks individual user sessions in the database for audit, admin visibility,
/// and optional concurrent-session limiting.
/// </summary>
[Table("UserSession")]
public sealed class UserSession
{
    [Key]
    public long SessionID { get; set; }

    /// <summary>Unique token identifying this session instance.</summary>
    [Required, MaxLength(64)]
    public string SessionToken { get; set; } = string.Empty;

    public int UserID { get; set; }

    /// <summary>ATTUID captured at session start (denormalized for history).</summary>
    [MaxLength(100)]
    public string? ATTUID { get; set; }

    /// <summary>UTC timestamp when the session was created (login).</summary>
    public DateTime StartedAtUtc { get; set; } = DateTime.UtcNow;

    /// <summary>UTC timestamp of the last recorded activity in this session.</summary>
    public DateTime LastActivityUtc { get; set; } = DateTime.UtcNow;

    /// <summary>UTC timestamp when the session ended. Null means still active.</summary>
    public DateTime? EndedAtUtc { get; set; }

    /// <summary>How the session ended: "Logout", "Expired", "AdminTerminated", etc. Null if active.</summary>
    [MaxLength(50)]
    public string? EndReason { get; set; }

    /// <summary>Device platform (e.g., "WinUI", "Android", "iOS").</summary>
    [MaxLength(50)]
    public string? Platform { get; set; }

    /// <summary>Device model or OS description for admin visibility.</summary>
    [MaxLength(200)]
    public string? DeviceInfo { get; set; }

    /// <summary>True if the session is still active (not ended).</summary>
    [NotMapped]
    public bool IsActive => EndedAtUtc is null;

    [ForeignKey(nameof(UserID))]
    public AppUser? User { get; set; }
}
