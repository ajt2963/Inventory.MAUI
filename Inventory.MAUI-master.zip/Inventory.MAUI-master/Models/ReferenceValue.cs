using System.ComponentModel.DataAnnotations;

namespace Inventory.MAUI.Models
{
    public class ReferenceValue
    {
        [Key]
        public int ReferenceValueId { get; set; }

        [Required, MaxLength(64)]
        public string Domain { get; set; } = string.Empty;   // e.g. ShipMethod, ShipType, ShipStatus

        [Required, MaxLength(64)]
        public string Code { get; set; } = string.Empty;     // Stable internal key (no spaces)

        [Required, MaxLength(128)]
        public string Display { get; set; } = string.Empty;  // UI text

        public int SortOrder { get; set; } 

        public bool IsActive { get; set; } = true;

        [MaxLength(256)]
        public string? Notes { get; set; }
    }
}