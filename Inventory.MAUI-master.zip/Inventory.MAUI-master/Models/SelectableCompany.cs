using System.ComponentModel;

namespace Inventory.MAUI.Models
{
    public class SelectableCompany : INotifyPropertyChanged
    {
        public Companies Company { get; }
        private bool _isSelected;
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected != value)
                {
                    _isSelected = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSelected)));
                }
            }
        }

        public SelectableCompany(Companies company)
        {
            Company = company;
        }

        public event PropertyChangedEventHandler? PropertyChanged;
    }
}