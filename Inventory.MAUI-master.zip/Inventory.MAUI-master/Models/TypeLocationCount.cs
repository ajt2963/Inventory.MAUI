namespace Inventory.MAUI.Models
{
    public class TypeLocationCount
    {
        public string? ClliCode { get; set; }
        public string? LocationName { get; set; }
        public string? TypeName { get; set; }
        public int Count { get; set; }
    }
}