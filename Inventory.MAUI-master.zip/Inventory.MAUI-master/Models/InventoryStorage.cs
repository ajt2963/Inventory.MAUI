using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Inventory.MAUI.Models
{
    public partial class InventoryStorage : INotifyPropertyChanged
    {
        public InventoryStorage() { }

        [Key]
        public int? StorageID
        {
            get => _storageID;
            set { if (_storageID != value) { _storageID = value; OnPropertyChanged(nameof(StorageID)); } }
        }
        private int? _storageID;

        public string? Storage
        {
            get => _storage;
            set { if (_storage != value) { _storage = value; OnPropertyChanged(nameof(Storage)); } }
        }
        private string? _storage;

        public string? Divider
        {
            get => _divider;
            set { if (_divider != value) { _divider = value; OnPropertyChanged(nameof(Divider)); } }
        }
        private string? _divider;

        public string? Section
        {
            get => _section;
            set { if (_section != value) { _section = value; OnPropertyChanged(nameof(Section)); } }
        }
        private string? _section;

        public string? Option
        {
            get => _option;
            set { if (_option != value) { _option = value; OnPropertyChanged(nameof(Option)); } }
        }
        private string? _option;

        public string? StorageNotes
        {
            get => _storageNotes;
            set { if (_storageNotes != value) { _storageNotes = value; OnPropertyChanged(nameof(StorageNotes)); } }
        }
        private string? _storageNotes;

        public DateTime? DateModified
        {
            get => _dateModified;
            set { if (_dateModified != value) { _dateModified = value; OnPropertyChanged(nameof(DateModified)); } }
        }
        private DateTime? _dateModified;

        public string? ModifiedBy
        {
            get => _modifiedBy;
            set { if (_modifiedBy != value) { _modifiedBy = value; OnPropertyChanged(nameof(ModifiedBy)); } }
        }
        private string? _modifiedBy;

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public string? DisplayValue
        {
            get => _displayValue;
            set { if (_displayValue != value) { _displayValue = value; OnPropertyChanged(nameof(DisplayValue)); } }
        }
        private string? _displayValue;

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
