using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Inventory.MAUI.Models
{
    public partial class Contacts : INotifyPropertyChanged
    {
        public Contacts() { }

        [Key]
        public int? ContactID
        {
            get => _contactID;
            set { if (_contactID != value) { _contactID = value; OnPropertyChanged(nameof(ContactID)); } }
        }
        private int? _contactID;

        public string? LastName
        {
            get => _lastName;
            set { if (_lastName != value) { _lastName = value; OnPropertyChanged(nameof(LastName)); } }
        }
        private string? _lastName;

        public string? FirstName
        {
            get => _firstName;
            set { if (_firstName != value) { _firstName = value; OnPropertyChanged(nameof(FirstName)); } }
        }
        private string? _firstName;

        public string? FullName
        {
            get => _fullName;
            set { if (_fullName != value) { _fullName = value; OnPropertyChanged(nameof(FullName)); } }
        }
        private string? _fullName;

        public string? JobTitle
        {
            get => _jobTitle;
            set { if (_jobTitle != value) { _jobTitle = value; OnPropertyChanged(nameof(JobTitle)); } }
        }
        private string? _jobTitle;

        public string? Company
        {
            get => _company;
            set { if (_company != value) { _company = value; OnPropertyChanged(nameof(Company)); } }
        }
        private string? _company;

        public string? BusinessPhone
        {
            get => _businessPhone;
            set { if (_businessPhone != value) { _businessPhone = value; OnPropertyChanged(nameof(BusinessPhone)); } }
        }
        private string? _businessPhone;

        public string? HomePhone
        {
            get => _homePhone;
            set { if (_homePhone != value) { _homePhone = value; OnPropertyChanged(nameof(HomePhone)); } }
        }
        private string? _homePhone;

        public string? MobilePhone
        {
            get => _mobilePhone;
            set { if (_mobilePhone != value) { _mobilePhone = value; OnPropertyChanged(nameof(MobilePhone)); } }
        }
        private string? _mobilePhone;

        public string? FaxNumber
        {
            get => _faxNumber;
            set { if (_faxNumber != value) { _faxNumber = value; OnPropertyChanged(nameof(FaxNumber)); } }
        }
        private string? _faxNumber;

        public string? EmailAddress
        {
            get => _emailAddress;
            set { if (_emailAddress != value) { _emailAddress = value; OnPropertyChanged(nameof(EmailAddress)); } }
        }
        private string? _emailAddress;

        public string? Address
        {
            get => _address;
            set { if (_address != value) { _address = value; OnPropertyChanged(nameof(Address)); } }
        }
        private string? _address;

        public string? City
        {
            get => _city;
            set { if (_city != value) { _city = value; OnPropertyChanged(nameof(City)); } }
        }
        private string? _city;

        public string? StateProvince
        {
            get => _stateProvince;
            set { if (_stateProvince != value) { _stateProvince = value; OnPropertyChanged(nameof(StateProvince)); } }
        }
        private string? _stateProvince;

        public string? ZipPostalCode
        {
            get => _zipPostalCode;
            set { if (_zipPostalCode != value) { _zipPostalCode = value; OnPropertyChanged(nameof(ZipPostalCode)); } }
        }
        private string? _zipPostalCode;

        public string? CountryRegion
        {
            get => _countryRegion;
            set { if (_countryRegion != value) { _countryRegion = value; OnPropertyChanged(nameof(CountryRegion)); } }
        }
        private string? _countryRegion;

        public string? WebPage
        {
            get => _webPage;
            set { if (_webPage != value) { _webPage = value; OnPropertyChanged(nameof(WebPage)); } }
        }
        private string? _webPage;

        public string? ContactNotes
        {
            get => _contactNotes;
            set { if (_contactNotes != value) { _contactNotes = value; OnPropertyChanged(nameof(ContactNotes)); } }
        }
        private string? _contactNotes;

        public string? ContactCategory
        {
            get => _contactCategory;
            set { if (_contactCategory != value) { _contactCategory = value; OnPropertyChanged(nameof(ContactCategory)); } }
        }
        private string? _contactCategory;

        public DateTime? DateModified
        {
            get => _dateModified;
            set { if (_dateModified != value) { _dateModified = value; OnPropertyChanged(nameof(DateModified)); } }
        }
        private DateTime? _dateModified;

        public string? ModifiedBy
        {
            get => _modifiedBy;
            set { if (_modifiedBy != value) { _modifiedBy = value; OnPropertyChanged(nameof(ModifiedBy)); } }
        }
        private string? _modifiedBy;

        [NotMapped]
        public bool IsSelected
        {
            get => _isSelected;
            set { if (_isSelected != value) { _isSelected = value; OnPropertyChanged(nameof(IsSelected)); } }
        }
        private bool _isSelected;

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}