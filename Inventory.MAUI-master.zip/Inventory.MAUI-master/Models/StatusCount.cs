namespace Inventory.MAUI.Models
{
    /// <summary>
    /// DTO: inventory count grouped by Status (used by dashboard).
    /// </summary>
    public class StatusCount
    {
        public string? Status { get; set; }
        public int Count { get; set; }
    }
}