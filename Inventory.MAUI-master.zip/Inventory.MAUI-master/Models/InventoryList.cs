namespace Inventory.MAUI.Models;

// Added 'partial' so this merges with InventoryList.ExportMetadata.cs
public partial class InventoryList
{
    public int? InventoryID { get; set; }
    public string? AssetTag { get; set; }
    public string? ToolKitID { get; set; }
    public string? Status { get; set; }
    public string? CatName { get; set; }
    public string? Type { get; set; }
    public string? CompanyName { get; set; }
    public string? PartNumber { get; set; }
    public string? SerialNumber { get; set; }
    public string? Description { get; set; }
    public int? Quantity { get; set; }
    public string? BatteryType { get; set; }
    public string? ClliCode { get; set; }
    public string? Storage { get; set; }
    public string? Divider { get; set; }
    public string? Section { get; set; }
    public string? Option { get; set; }
    public string? Owner { get; set; }
    public string? InventoryNotes { get; set; }
}