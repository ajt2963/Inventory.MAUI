using Inventory.MAUI.Models;

namespace Inventory.MAUI.Models
{
    public class ShippingValues
    {
        public int ShippingID { get; set; }
        public string? ShipStatus { get; set; }
        public string? ShipType { get; set; }
        public string? ShipMethod { get; set; }
        public string? Notes { get; set; }
        // Add other properties as needed
    }
}