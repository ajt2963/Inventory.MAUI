using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;

namespace Inventory.MAUI.Models;

[Table("AppUser")]
public class AppUser : INotifyPropertyChanged
{
    private int _userID;
    private string _attuid = string.Empty;
    private string _displayName = string.Empty;
    private string? _email;
    private int _roleID;
    private bool _isActive = true;
    private DateTime _createdAt;
    private DateTime? _lastLoginAt;
    private bool _isSelected;
    private string? _passwordHash;
    private string? _passwordSalt;
    private int _failedLoginAttempts;
    private DateTime? _lockoutUntil;
    private bool _mustChangePassword = true;
    private DateTime? _passwordExpiresAt;

    [Key]
    public int UserID
    {
        get => _userID;
        set => Set(ref _userID, value);
    }

    /// <summary>
    /// Windows login name (DOMAIN\user or user@domain).
    /// Used to match the current Windows identity to an app user.
    /// </summary>
    [Required, MaxLength(100)]
    public string ATTUID
    {
        get => _attuid;
        set => Set(ref _attuid, value);
    }

    [Required, MaxLength(150)]
    public string DisplayName
    {
        get => _displayName;
        set => Set(ref _displayName, value);
    }

    [MaxLength(200)]
    public string? Email
    {
        get => _email;
        set => Set(ref _email, value);
    }

    /// <summary>PBKDF2-SHA256 derived key (Base64). Null if password not yet set.</summary>
    [MaxLength(500)]
    public string? PasswordHash
    {
        get => _passwordHash;
        set => Set(ref _passwordHash, value);
    }

    /// <summary>128-bit random salt (Base64).</summary>
    [MaxLength(500)]
    public string? PasswordSalt
    {
        get => _passwordSalt;
        set => Set(ref _passwordSalt, value);
    }

    /// <summary>Consecutive failed login attempts. Resets on successful login.</summary>
    public int FailedLoginAttempts
    {
        get => _failedLoginAttempts;
        set => Set(ref _failedLoginAttempts, value);
    }

    /// <summary>Account is locked until this time (UTC). Null means not locked.</summary>
    public DateTime? LockoutUntil
    {
        get => _lockoutUntil;
        set => Set(ref _lockoutUntil, value);
    }

    /// <summary>True if the user must set a new password on next login.</summary>
    public bool MustChangePassword
    {
        get => _mustChangePassword;
        set => Set(ref _mustChangePassword, value);
    }

    /// <summary>UTC date/time when the current password expires. Null if no expiry set.</summary>
    public DateTime? PasswordExpiresAt
    {
        get => _passwordExpiresAt;
        set => Set(ref _passwordExpiresAt, value);
    }

    public int RoleID
    {
        get => _roleID;
        set => Set(ref _roleID, value);
    }

    public bool IsActive
    {
        get => _isActive;
        set => Set(ref _isActive, value);
    }

    public DateTime CreatedAt
    {
        get => _createdAt;
        set => Set(ref _createdAt, value);
    }

    public DateTime? LastLoginAt
    {
        get => _lastLoginAt;
        set => Set(ref _lastLoginAt, value);
    }

    [NotMapped]
    public bool IsSelected
    {
        get => _isSelected;
        set => Set(ref _isSelected, value);
    }

    [ForeignKey(nameof(RoleID))]
    public virtual AppRole? Role { get; set; }

    public event PropertyChangedEventHandler? PropertyChanged;

    private bool Set<T>(ref T field, T value, [CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
            return false;
        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        return true;
    }
}
