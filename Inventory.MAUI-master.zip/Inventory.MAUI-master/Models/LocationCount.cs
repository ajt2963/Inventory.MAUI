namespace Inventory.MAUI.Models
{
    /// <summary>
    /// DTO: inventory count per location (used by dashboard/reporting).
    /// Extracted from InventoryServiceDashboard.
    /// </summary>
    public class LocationCount
    {
        public int? LocationID { get; set; }
        public string? ClliCode { get; set; }
        public string? LocationName { get; set; }
        public int Count { get; set; }
    }
}