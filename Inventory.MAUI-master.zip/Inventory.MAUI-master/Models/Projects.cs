using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;

namespace Inventory.MAUI.Models
{
    public partial class Projects : INotifyPropertyChanged
    {
        private int? _projectID;
        private string? _description;
        private string? _location;
        private DateTime? _dateModified;
        private string? _modifiedBy;
        private int? _contactID;
        private bool _isSelected;

        [Key]
        public int? ProjectID
        {
            get => _projectID;
            set { if (_projectID != value) { _projectID = value; OnPropertyChanged(); } }
        }

        public string? Description
        {
            get => _description;
            set { if (_description != value) { _description = value; OnPropertyChanged(); } }
        }

        public string? Location
        {
            get => _location;
            set { if (_location != value) { _location = value; OnPropertyChanged(); } }
        }

        public DateTime? DateModified
        {
            get => _dateModified;
            set { if (_dateModified != value) { _dateModified = value; OnPropertyChanged(); } }
        }

        public string? ModifiedBy
        {
            get => _modifiedBy;
            set { if (_modifiedBy != value) { _modifiedBy = value; OnPropertyChanged(); } }
        }

        public int? ContactID
        {
            get => _contactID;
            set { if (_contactID != value) { _contactID = value; OnPropertyChanged(); } }
        }

        [NotMapped]
        public bool IsSelected
        {
            get => _isSelected;
            set { if (_isSelected != value) { _isSelected = value; OnPropertyChanged(); } }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
