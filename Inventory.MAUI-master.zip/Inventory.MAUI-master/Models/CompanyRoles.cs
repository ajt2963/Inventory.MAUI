/*************************************************************
*  Class:        CompanyRoles
*  Description:  An intermediate table that links relationships between Companies and their Roles.
*  Author:       at2963
*  Created:      1/3/2025 8:35:17 AM
*  Modified:     [ModificationDate]
*************************************************************/

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Inventory.MAUI.Models
{
    public partial class CompanyRoles : INotifyPropertyChanged
    {
        [Key]
        public int CRID { get; set; }          // Non-nullable PK

        private int? _companyID;
        public int? CompanyID
        {
            get => _companyID;
            set { if (_companyID != value) { _companyID = value; OnPropertyChanged(nameof(CompanyID)); } }
        }

        private int? _roleID;
        public int? RoleID
        {
            get => _roleID;
            set { if (_roleID != value) { _roleID = value; OnPropertyChanged(nameof(RoleID)); } }
        }

        public string? ModifiedBy { get; set; }
        public DateTime? DateModified { get; set; }

        // Preferred navigation names
        [ForeignKey(nameof(CompanyID))]
        public virtual Companies? Company { get; set; }

        [ForeignKey(nameof(RoleID))]
        public virtual Roles? Role { get; set; }

        // BACKWARD COMPATIBILITY: old code expecting .Companies
        [NotMapped]
        public Companies? Companies
        {
            get => Company;
            set => Company = value;
        }

        private bool _isSelected;
        [NotMapped]
        public bool IsSelected
        {
            get => _isSelected;
            set { if (_isSelected != value) { _isSelected = value; OnPropertyChanged(nameof(IsSelected)); } }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
