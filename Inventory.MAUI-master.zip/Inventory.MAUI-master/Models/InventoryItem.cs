using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;

namespace Inventory.MAUI.Models
{
    public partial class InventoryItem : INotifyPropertyChanged
    {
        private bool _isSelected;

        [NotMapped]
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected != value)
                {
                    _isSelected = value;
                    OnPropertyChanged();
                }
            }
        }

        [Key]
        [Column("inventoryID")]
        public int? InventoryID { get; set; }

        [Column("partNumber")]
        public string? PartNumber { get; set; }

        [Column("serialNumber")]
        public string? SerialNumber { get; set; }

        [Column("description")]
        public string? Description { get; set; }

        [Column("quantity")]
        public int? Quantity { get; set; }

        [Column("batteryType")]
        public string? BatteryType { get; set; }

        [Column("dateModified")]
        public DateTime? DateModified { get; set; }

        [Column("modifiedBy")]
        public string? ModifiedBy { get; set; }

        [Column("assetID")]
        public int? AssetID { get; set; }

        [Column("ownerID")]
        public int? OwnerID { get; set; }

        [Column("typeID")]
        public int? TypeID { get; set; }

        [Column("catID")]
        public int? CatID { get; set; }

        [Column("companyID")]
        public int? CompanyID { get; set; }

        [Column("notesID")]
        public int? NotesID { get; set; }

        [Column("storageID")]
        public int? StorageID { get; set; }

        [Column("locationID")]
        public int? LocationID { get; set; }

        // Not present in Access table (prevent Jet/OleDb missing parameter errors)
        [NotMapped] public bool IsDeleted { get; set; }
        [NotMapped] public DateTime? DeletedAt { get; set; }
        [NotMapped] public string? DeletedBy { get; set; }

        public virtual Asset? Asset { get; set; }
        public virtual AssetOwner? AssetOwner { get; set; }
        public virtual Category? Category { get; set; }
        public virtual AssetType? AssetType { get; set; }
        public virtual Companies? Companies { get; set; }
        public virtual Locations? Locations { get; set; }
        public virtual InventoryStorage? InventoryStorage { get; set; }
        public virtual Notes? Notes { get; set; }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
