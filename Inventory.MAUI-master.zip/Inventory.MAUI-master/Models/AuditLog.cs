using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Inventory.MAUI.Models;

/// <summary>
/// Immutable audit log entry for security and compliance tracking.
/// Covers IAM events (login, logout, password changes, user/role administration)
/// and can be extended to cover data operations.
/// </summary>
[Table("AuditLog")]
public sealed class AuditLog
{
    [Key]
    public long LogID { get; set; }

    /// <summary>UTC timestamp of the event.</summary>
    public DateTime TimestampUtc { get; set; } = DateTime.UtcNow;

    /// <summary>The user who performed the action (FK to AppUser). Null for anonymous/system events.</summary>
    public int? UserID { get; set; }

    /// <summary>ATTUID captured at the time of the event (denormalized for historical accuracy).</summary>
    [MaxLength(100)]
    public string? ATTUID { get; set; }

    /// <summary>
    /// Category of the event.
    /// Examples: Login, LoginFailed, Logout, SessionExpired, PasswordChanged, PasswordReset,
    /// UserCreated, UserModified, UserDeleted, RoleCreated, RoleModified, RoleDeleted.
    /// </summary>
    [Required, MaxLength(50)]
    public string EventType { get; set; } = string.Empty;

    /// <summary>
    /// The type of entity affected (e.g., "AppUser", "AppRole").
    /// Null for events that don't target a specific entity.
    /// </summary>
    [MaxLength(100)]
    public string? EntityType { get; set; }

    /// <summary>
    /// The primary key of the affected entity (stored as string for flexibility).
    /// Null for events that don't target a specific entity.
    /// </summary>
    [MaxLength(50)]
    public string? EntityID { get; set; }

    /// <summary>
    /// Human-readable description or JSON payload with additional details.
    /// </summary>
    [MaxLength(2000)]
    public string? Details { get; set; }

    /// <summary>
    /// The device/platform identifier (e.g., "Windows", "Android").
    /// </summary>
    [MaxLength(50)]
    public string? Platform { get; set; }

    [ForeignKey(nameof(UserID))]
    public AppUser? User { get; set; }
}

/// <summary>
/// Well-known audit event type constants to avoid magic strings.
/// </summary>
public static class AuditEventTypes
{
    // Authentication
    public const string Login = "Login";
    public const string LoginFailed = "LoginFailed";
    public const string Logout = "Logout";
    public const string SessionExpired = "SessionExpired";

    // Password
    public const string PasswordChanged = "PasswordChanged";
    public const string PasswordSet = "PasswordSet";
    public const string PasswordReset = "PasswordReset";

    // User administration
    public const string UserCreated = "UserCreated";
    public const string UserModified = "UserModified";
    public const string UserDeleted = "UserDeleted";
    public const string AccountLocked = "AccountLocked";

    // Role administration
    public const string RoleCreated = "RoleCreated";
    public const string RoleModified = "RoleModified";
    public const string RoleDeleted = "RoleDeleted";

    // System settings
    public const string SettingsChanged = "SettingsChanged";
}
