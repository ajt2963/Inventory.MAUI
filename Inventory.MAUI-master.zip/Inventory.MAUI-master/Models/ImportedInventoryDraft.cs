namespace Inventory.MAUI.Models
{
    // Minimal draft used only for transferring basic inventory entry fields
    public sealed class ImportedInventoryDraft
    {
        public string? PartNumber { get; set; }
        public string? SerialNumber { get; set; }
        public string? Description { get; set; }
        public int? Quantity { get; set; }
        public string? BatteryType { get; set; }
    }
}