namespace Inventory.MAUI.Models
{
    public class SupportContact
    {
        public string? Name { get; set; }
        public string? Role { get; set; } // Optional: e.g., "Admin", "Tech"
        public string? Email { get; set; }
        public string? Phone { get; set; }
        public string? Notes { get; set; }
    }
}