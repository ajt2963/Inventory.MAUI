using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;

namespace Inventory.MAUI.Models
{
    // Single authoritative partial (remove other partial files that duplicate IsSelected / INotifyPropertyChanged)
    public partial class AssetUse : INotifyPropertyChanged
    {
        [Key]
        public int? UseLogID { get; set; }

        private DateTime? _dateOut;
        public DateTime? DateOut
        {
            get => _dateOut;
            set
            {
                if (_dateOut == value) return;
                _dateOut = value;
                OnPropertyChanged();
            }
        }

        private DateTime? _dateIn;
        public DateTime? DateIn
        {
            get => _dateIn;
            set
            {
                if (_dateIn == value) return;
                _dateIn = value;
                OnPropertyChanged();
            }
        }

        private string? _notes;
        public string? Notes
        {
            get => _notes;
            set
            {
                if (_notes == value) return;
                _notes = value;
                OnPropertyChanged();
            }
        }

        private DateTime? _dateModified;
        public DateTime? DateModified
        {
            get => _dateModified;
            set
            {
                if (_dateModified == value) return;
                _dateModified = value;
                OnPropertyChanged();
            }
        }

        private string? _modifiedBy;
        public string? ModifiedBy
        {
            get => _modifiedBy;
            set
            {
                if (_modifiedBy == value) return;
                _modifiedBy = value;
                OnPropertyChanged();
            }
        }

        private int? _assetID;
        public int? AssetID
        {
            get => _assetID;
            set
            {
                if (_assetID == value) return;
                _assetID = value;
                OnPropertyChanged();
            }
        }

        private int? _projectID;
        public int? ProjectID
        {
            get => _projectID;
            set
            {
                if (_projectID == value) return;
                _projectID = value;
                OnPropertyChanged();
            }
        }

        [ForeignKey(nameof(AssetID))]
        public virtual Asset? Asset { get; set; }

        private bool _isSelected;
        [NotMapped]
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected == value) return;
                _isSelected = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
