/*************************************************************
*  Class:        Shipping
*  Description:  Entity mapped to Shipping table (Access / Jet)
*  Author:       [AuthorName]
*  Created:      9/16/2024 8:54:36 AM
*  Modified:     [ModificationDate]
*************************************************************/

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Inventory.MAUI.Models
{
    [Table("Shipping")]
    public partial class Shipping : IDataErrorInfo, INotifyPropertyChanged
    {
        // IMPORTANT:
        //  - Column names explicitly mapped to match Access schema.
        //  - Strings limited to 255 (Short Text).
        //  - Currency mapped via TypeName so provider treats value correctly.
        //  - Navigation properties made nullable & NOT auto-instantiated
        //    to avoid EF interpreting them as new related rows.
        //  - Key made non-nullable (Jet expects a value); use int not int?.

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged(string prop) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));

        [Key]
        [Column("shippingID")]
        public int ShippingID { get; set; }   // Long Integer

        [Column("useLogID")]
        public int? UseLogID { get; set; }    // Long Integer FK
        public AssetUse? AssetUse { get; set; }

        [Column("customsID")]
        public int? CustomsID { get; set; }   // Long Integer FK
        public Customs? Customs { get; set; }

        [Column("companyID")]
        public int? CompanyID { get; set; }   // Long Integer FK

        [ForeignKey(nameof(CompanyID))]
        public Companies? Company { get; set; }   // RENAMED from Companies -> Company (prevents shadow FK)

        private DateTime? _shipDate;
        [Column("shipDate")]
        public DateTime? ShipDate
        {
            get => _shipDate;
            set { _shipDate = value; OnPropertyChanged(nameof(ShipDate)); }
        }

        private string? _trackingNumber;
        [Column("trackingNumber"), MaxLength(255)]
        public string? TrackingNumber
        {
            get => _trackingNumber;
            set { _trackingNumber = value; OnPropertyChanged(nameof(TrackingNumber)); }
        }

        [Column("shipToID")]
        public int? ShipToID { get; set; }
        [ForeignKey(nameof(ShipToID))]
        public Locations? ShipToLocation { get; set; }

        [Column("shipFromID")]
        public int? ShipFromID { get; set; }
        [ForeignKey(nameof(ShipFromID))]
        public Locations? ShipFromLocation { get; set; }

        private string? _shipStatus;
        [Column("shipStatus"), MaxLength(255)]
        public string? ShipStatus
        {
            get => _shipStatus;
            set { _shipStatus = value; OnPropertyChanged(nameof(ShipStatus)); }
        }

        private string? _shipType;
        [Column("shipType"), MaxLength(255)]
        public string? ShipType
        {
            get => _shipType;
            set { _shipType = value; OnPropertyChanged(nameof(ShipType)); }
        }

        private string? _shipMethod;
        [Column("shipMethod"), MaxLength(255)]
        public string? ShipMethod
        {
            get => _shipMethod;
            set { _shipMethod = value; OnPropertyChanged(nameof(ShipMethod)); }
        }

        private decimal? _shipCost;
        [Column("shipCost", TypeName = "currency")]
        public decimal? ShipCost
        {
            get => _shipCost;
            set { _shipCost = value; OnPropertyChanged(nameof(ShipCost)); }
        }

        private string? _notes;
        [Column("notes"), MaxLength(255)]
        public string? Notes
        {
            get => _notes;
            set { _notes = value; OnPropertyChanged(nameof(Notes)); }
        }

        private DateTime? _dateModified;
        [Column("dateModified")]
        public DateTime? DateModified
        {
            get => _dateModified;
            set { _dateModified = value; OnPropertyChanged(nameof(DateModified)); }
        }

        private string? _modifiedBy;
        [Column("modifiedBy"), MaxLength(255)]
        public string? ModifiedBy
        {
            get => _modifiedBy;
            set { _modifiedBy = value; OnPropertyChanged(nameof(ModifiedBy)); }
        }

        public string this[string columnName] =>
            columnName switch
            {
                nameof(DateModified) when !DateModified.HasValue => "Date Modified is required.",
                nameof(ModifiedBy) when string.IsNullOrWhiteSpace(ModifiedBy) => "Modified By is required.",
                _ => string.Empty
            };

        public string Error => string.Empty;
    } 
}