using System;

namespace Inventory.MAUI.Models
{
    public class ShippingExportData
    {
        public string AssetTag { get; set; } = string.Empty;
        public string Manufacturer { get; set; } = string.Empty;
        public string PartNumber { get; set; } = string.Empty;
        public string SerialNumber { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string BatteryType { get; set; } = string.Empty;
        public string ServiceProvider { get; set; } = string.Empty;

        // Keep types that match the domain/table:
        public DateTime? ShippingDate { get; set; }
        public string ShipStatus { get; set; } = string.Empty;
        public string ShipTo { get; set; } = string.Empty;
        public string ShipFrom { get; set; } = string.Empty;
        public string ShipType { get; set; } = string.Empty;
        public string TrackingNumber { get; set; } = string.Empty;
        public string ShipMethod { get; set; } = string.Empty;

        // Keep numeric type for domain model (nullable to reflect DB)
        public decimal? ShipCost { get; set; }

        public string CustomsInfo { get; set; } = string.Empty;
        public string Notes { get; set; } = string.Empty;
    }
}