using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;

namespace Inventory.MAUI.Models
{
    public partial class Calibration : INotifyPropertyChanged
    {
        private bool _isSelected;

        private int? _calInfoID;
        private DateTime? _lastCalDate;
        private DateTime? _calDueDate;
        private DateTime? _calDateSched;
        private DateTime? _calDateCompl;
        private string? _calLabel;
        private string? _calNotes;
        private DateTime? _dateModified;
        private string? _modifiedBy;
        private int? _inventoryID;
        private int? _svcID;

        [Key]
        public int? CalInfoID
        {
            get => _calInfoID;
            set
            {
                if (_calInfoID != value)
                {
                    _calInfoID = value;
                    OnPropertyChanged();
                }
            }
        }

        public DateTime? LastCalDate
        {
            get => _lastCalDate;
            set
            {
                if (_lastCalDate != value)
                {
                    _lastCalDate = value;
                    OnPropertyChanged();
                }
            }
        }

        public DateTime? CalDueDate
        {
            get => _calDueDate;
            set
            {
                if (_calDueDate != value)
                {
                    _calDueDate = value;
                    OnPropertyChanged();
                }
            }
        }

        public DateTime? CalDateSched
        {
            get => _calDateSched;
            set
            {
                if (_calDateSched != value)
                {
                    _calDateSched = value;
                    OnPropertyChanged();
                }
            }
        }

        public DateTime? CalDateCompl
        {
            get => _calDateCompl;
            set
            {
                if (_calDateCompl != value)
                {
                    _calDateCompl = value;
                    OnPropertyChanged();
                }
            }
        }

        public string? CalLabel
        {
            get => _calLabel;
            set
            {
                if (_calLabel != value)
                {
                    _calLabel = value;
                    OnPropertyChanged();
                }
            }
        }

        public string? CalNotes
        {
            get => _calNotes;
            set
            {
                if (_calNotes != value)
                {
                    _calNotes = value;
                    OnPropertyChanged();
                }
            }
        }

        public DateTime? DateModified
        {
            get => _dateModified;
            set
            {
                if (_dateModified != value)
                {
                    _dateModified = value;
                    OnPropertyChanged();
                }
            }
        }

        public string? ModifiedBy
        {
            get => _modifiedBy;
            set
            {
                if (_modifiedBy != value)
                {
                    _modifiedBy = value;
                    OnPropertyChanged();
                }
            }
        }

        [ForeignKey(nameof(InventoryID))]
        public int? InventoryID
        {
            get => _inventoryID;
            set
            {
                if (_inventoryID != value)
                {
                    _inventoryID = value;
                    OnPropertyChanged();
                }
            }
        }

        [ForeignKey(nameof(SvcID))]
        public int? SvcID
        {
            get => _svcID;
            set
            {
                if (_svcID != value)
                {
                    _svcID = value;
                    OnPropertyChanged();
                }
            }
        }

        [NotMapped]
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected != value)
                {
                    _isSelected = value;
                    OnPropertyChanged(nameof(IsSelected));
                }
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
