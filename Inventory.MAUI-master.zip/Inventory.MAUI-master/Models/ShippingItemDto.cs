using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Inventory.MAUI.Models
{
    public class ShippingItemDto : INotifyPropertyChanged
    {
        private int? _inventoryId;
        private string? _manufacturer;
        private string? _partNumber;
        private string? _serialNumber;
        private string? _description;
        private string? _storageDisplay;
        private bool _isSelected;

        public int? InventoryID { get => _inventoryId; set { if (_inventoryId != value) { _inventoryId = value; OnPropertyChanged(); } } }
        public string? Manufacturer { get => _manufacturer; set { if (_manufacturer != value) { _manufacturer = value; OnPropertyChanged(); } } }
        public string? PartNumber { get => _partNumber; set { if (_partNumber != value) { _partNumber = value; OnPropertyChanged(); } } }
        public string? SerialNumber { get => _serialNumber; set { if (_serialNumber != value) { _serialNumber = value; OnPropertyChanged(); } } }
        public string? Description { get => _description; set { if (_description != value) { _description = value; OnPropertyChanged(); } } }
        public string? StorageDisplay { get => _storageDisplay; set { if (_storageDisplay != value) { _storageDisplay = value; OnPropertyChanged(); } } }
        public bool IsSelected { get => _isSelected; set { if (_isSelected != value) { _isSelected = value; OnPropertyChanged(); } } }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? name = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}