namespace Inventory.MAUI.Models
{
    public partial class Projects
    {
        public string DisplayLabel =>
            string.IsNullOrWhiteSpace(Description)
                ? (ProjectID.HasValue ? $"Project {ProjectID}" : "(Unnamed Project)")
                : Description;

        // Optional shim if legacy XAML used ProjectName:
        public string ProjectName => DisplayLabel;
    }
}