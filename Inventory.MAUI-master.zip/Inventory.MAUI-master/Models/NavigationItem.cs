namespace Inventory.MAUI.Models;

public sealed class NavigationItem
{
    public NavigationItem(string title, string? subtitle = null, string? icon = null)
    {
        Title = title;
        Subtitle = subtitle;
        Icon = icon;
    }

    public string Title { get; }
    public string? Subtitle { get; }

    /// <summary>
    /// Image filename from Resources/Images (e.g., "icon_home.png").
    /// </summary>
    public string? Icon { get; }
}
