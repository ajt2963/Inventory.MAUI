using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Inventory.MAUI.Models
{
    public partial class Customs : INotifyPropertyChanged
    {
        public Customs() { }

        [Key]
        public int? CustomsID
        {
            get => _customsID;
            set { if (_customsID != value) { _customsID = value; OnPropertyChanged(nameof(CustomsID)); } }
        }
        private int? _customsID;

        [ForeignKey("Inventory")]
        public int? InventoryID
        {
            get => _inventoryID;
            set { if (_inventoryID != value) { _inventoryID = value; OnPropertyChanged(nameof(InventoryID)); } }
        }
        private int? _inventoryID;

        public string? CountryOfOrigin
        {
            get => _countryOfOrigin;
            set { if (_countryOfOrigin != value) { _countryOfOrigin = value; OnPropertyChanged(nameof(CountryOfOrigin)); } }
        }
        private string? _countryOfOrigin;

        public decimal? PurchasePrice
        {
            get => _purchasePrice;
            set { if (_purchasePrice != value) { _purchasePrice = value; OnPropertyChanged(nameof(PurchasePrice)); } }
        }
        private decimal? _purchasePrice;

        public decimal? CommercialValue
        {
            get => _commercialValue;
            set { if (_commercialValue != value) { _commercialValue = value; OnPropertyChanged(nameof(CommercialValue)); } }
        }
        private decimal? _commercialValue;

        public DateTime? DateModified
        {
            get => _dateModified;
            set { if (_dateModified != value) { _dateModified = value; OnPropertyChanged(nameof(DateModified)); } }
        }
        private DateTime? _dateModified;

        public string? ModifiedBy
        {
            get => _modifiedBy;
            set { if (_modifiedBy != value) { _modifiedBy = value; OnPropertyChanged(nameof(ModifiedBy)); } }
        }
        private string? _modifiedBy;

        [NotMapped]
        public string DisplayValue =>
            $"{CountryOfOrigin ?? ""} | {PurchasePrice?.ToString("C", System.Globalization.CultureInfo.CurrentCulture) ?? ""} | {CommercialValue?.ToString("C", System.Globalization.CultureInfo.CurrentCulture) ?? ""}";

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
