using System.ComponentModel.DataAnnotations.Schema;

namespace Inventory.MAUI.Models
{
    public partial class Customs
    {
        private bool _isSelected;

        [NotMapped]
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected == value) return;
                _isSelected = value;
                // Uses existing OnPropertyChanged(string) defined in Customs.cs
                OnPropertyChanged(nameof(IsSelected));
            }
        }
    }
}