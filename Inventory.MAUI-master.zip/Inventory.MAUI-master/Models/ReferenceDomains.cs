namespace Inventory.MAUI.Models;

public static class ReferenceDomains
{
    public const string ShipMethod      = "ShipMethod";
    public const string ShipType        = "ShipType";
    public const string ShipStatus      = "ShipStatus";
    public const string AssetStatus     = "AssetStatus";
    public const string InventoryStatus = "InventoryStatus";
}