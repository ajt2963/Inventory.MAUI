using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Inventory.MAUI.Models;

/// <summary>
/// Stores previous password hashes to prevent reuse.
/// Only the most recent <see cref="Services.PasswordPolicy.HistoryCount"/> entries
/// per user are checked; older entries can be purged.
/// </summary>
[Table("PasswordHistory")]
public sealed class PasswordHistory
{
    [Key]
    public long HistoryID { get; set; }

    public int UserID { get; set; }

    /// <summary>PBKDF2-SHA256 derived key (Base64) of the previous password.</summary>
    [Required, MaxLength(500)]
    public string PasswordHash { get; set; } = string.Empty;

    /// <summary>Salt used to derive the hash (Base64).</summary>
    [Required, MaxLength(500)]
    public string PasswordSalt { get; set; } = string.Empty;

    /// <summary>When the password was set (UTC).</summary>
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

    [ForeignKey(nameof(UserID))]
    public AppUser? User { get; set; }
}
