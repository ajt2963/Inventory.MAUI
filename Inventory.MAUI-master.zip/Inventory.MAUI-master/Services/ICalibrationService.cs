using System.ComponentModel;
using Inventory.MAUI.Models;

namespace Inventory.MAUI.Services;

/// <summary>
/// Service interface for calibration scheduling, completion, and log queries.
/// </summary>
public interface ICalibrationService
{
    /// <summary>
    /// Returns all inventory items at the given location, joined with their
    /// Calibration record (if any) and manufacturer company name.
    /// </summary>
    Task<List<CalibrationItemRow>> GetItemsByLocationAsync(int locationId);

    /// <summary>Returns all locations that have at least one inventory item.</summary>
    Task<List<Locations>> GetLocationsAsync();

    /// <summary>Returns companies that have the "Service Provider" role.</summary>
    Task<List<Companies>> GetServiceProvidersAsync();

    /// <summary>
    /// Saves schedule entries for the supplied items at a location.
    /// One <see cref="CalibrationSchedule"/> row per item.
    /// </summary>
    Task SaveScheduleAsync(
        IReadOnlyList<CalibrationItemRow> items,
        DateTime scheduledDate,
        Companies serviceProvider,
        Locations location,
        string modifiedBy);

    /// <summary>Returns all pending (not yet completed) schedule entries.</summary>
    Task<List<CalibrationSchedule>> GetPendingSchedulesAsync();

    /// <summary>Returns the distinct locations that have pending schedule entries.</summary>
    Task<List<ScheduledLocationGroup>> GetScheduledLocationsAsync();

    /// <summary>Returns schedule entries for a specific location.</summary>
    Task<List<CalibrationSchedule>> GetSchedulesByLocationAsync(string clliCode);

    /// <summary>
    /// Completes calibration for the selected schedule entries.
    /// Updates the Calibration table and removes the completed CalibrationSchedule rows.
    /// </summary>
    Task CompleteCalibrationAsync(
        DateTime completionDate,
        IReadOnlyList<CalibrationSchedule> selectedItems,
        string modifiedBy);

    /// <summary>Returns all Calibration records with item details for the log view.</summary>
    Task<List<CalibrationLogRow>> GetCalibrationLogAsync();

    /// <summary>Updates one or more Calibration records from edited log rows.</summary>
    Task UpdateCalibrationLogEntriesAsync(IReadOnlyList<CalibrationLogRow> rows, string modifiedBy);

    /// <summary>Returns companies by their IDs (used to backfill picker lists).</summary>
    Task<List<Companies>> GetCompaniesByIdsAsync(IReadOnlyList<int> companyIds);
}

/// <summary>
/// Flattened row joining InventoryItem + Calibration + manufacturer name
/// for the scheduler equipment list.
/// </summary>
public sealed class CalibrationItemRow : INotifyPropertyChanged
{
    public int InventoryID { get; set; }
    public string? AssetTag { get; set; }
    public string? PartNumber { get; set; }
    public string? SerialNumber { get; set; }
    public string? Description { get; set; }
    public string? ManufacturerName { get; set; }
    public string? CategoryName { get; set; }
    public string? TypeName { get; set; }
    public DateTime? LastCalDate { get; set; }
    public DateTime? CalDueDate { get; set; }

    private bool _isSelected;
    public bool IsSelected
    {
        get => _isSelected;
        set
        {
            if (_isSelected != value)
            {
                _isSelected = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSelected)));
            }
        }
    }

    /// <summary>
    /// True when the item meets calibration-eligibility criteria
    /// (test equipment category, known test type, or has been calibrated before).
    /// </summary>
    public bool IsCalibrationEligible { get; set; }

    public event PropertyChangedEventHandler? PropertyChanged;
}

/// <summary>Groups pending schedule entries by location for the completion page.</summary>
public sealed class ScheduledLocationGroup
{
    public string ClliCode { get; set; } = string.Empty;
    public string LocationName { get; set; } = string.Empty;
    public int ItemCount { get; set; }
    public DateTime? ScheduledDate { get; set; }
    public string? ServiceProviderName { get; set; }
}

/// <summary>Flattened row for the calibration log view.</summary>
public sealed class CalibrationLogRow : INotifyPropertyChanged
{
    public int? CalInfoID { get; set; }
    public int? InventoryID { get; set; }
    public string? AssetTag { get; set; }
    public string? PartNumber { get; set; }
    public string? SerialNumber { get; set; }
    public string? Description { get; set; }
    public string? ManufacturerName { get; set; }
    public string? ClliCode { get; set; }
    public string? LocationName { get; set; }

    private int? _svcID;
    public int? SvcID
    {
        get => _svcID;
        set { if (_svcID != value) { _svcID = value; OnPropertyChanged(); } }
    }

    private string? _serviceProviderName;
    public string? ServiceProviderName
    {
        get => _serviceProviderName;
        set { if (_serviceProviderName != value) { _serviceProviderName = value; OnPropertyChanged(); } }
    }

    private Companies? _selectedServiceProvider;
    public Companies? SelectedServiceProvider
    {
        get => _selectedServiceProvider;
        set
        {
            if (_selectedServiceProvider != value)
            {
                _selectedServiceProvider = value;
                OnPropertyChanged();
                if (value is not null)
                {
                    SvcID = value.CompanyID;
                    ServiceProviderName = value.CompanyName;
                    IsDirty = true;
                }
            }
        }
    }

    private DateTime? _lastCalDate;
    public DateTime? LastCalDate
    {
        get => _lastCalDate;
        set { if (_lastCalDate != value) { _lastCalDate = value; OnPropertyChanged(); IsDirty = true; } }
    }

    private DateTime? _calDueDate;
    public DateTime? CalDueDate
    {
        get => _calDueDate;
        set { if (_calDueDate != value) { _calDueDate = value; OnPropertyChanged(); IsDirty = true; } }
    }

    private DateTime? _calDateSched;
    public DateTime? CalDateSched
    {
        get => _calDateSched;
        set { if (_calDateSched != value) { _calDateSched = value; OnPropertyChanged(); IsDirty = true; } }
    }

    private DateTime? _calDateCompl;
    public DateTime? CalDateCompl
    {
        get => _calDateCompl;
        set { if (_calDateCompl != value) { _calDateCompl = value; OnPropertyChanged(); IsDirty = true; } }
    }

    private string? _calLabel;
    public string? CalLabel
    {
        get => _calLabel;
        set { if (_calLabel != value) { _calLabel = value; OnPropertyChanged(); IsDirty = true; } }
    }

    private string? _calNotes;
    public string? CalNotes
    {
        get => _calNotes;
        set { if (_calNotes != value) { _calNotes = value; OnPropertyChanged(); IsDirty = true; } }
    }

    private bool _isSelected;
    public bool IsSelected
    {
        get => _isSelected;
        set { if (_isSelected != value) { _isSelected = value; OnPropertyChanged(); } }
    }

    private bool _isEditing;
    public bool IsEditing
    {
        get => _isEditing;
        set { if (_isEditing != value) { _isEditing = value; OnPropertyChanged(); } }
    }

    private bool _isFocused;
    public bool IsFocused
    {
        get => _isFocused;
        set { if (_isFocused != value) { _isFocused = value; OnPropertyChanged(); } }
    }

    private bool _isDirty;
    public bool IsDirty
    {
        get => _isDirty;
        set { if (_isDirty != value) { _isDirty = value; OnPropertyChanged(); } }
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([System.Runtime.CompilerServices.CallerMemberName] string? name = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
