namespace Inventory.MAUI.Services;

/// <summary>
/// Read-only session information exposed to ViewModels.
/// Separates session state queries from session lifecycle management (SRP).
/// </summary>
public interface IAppSessionService
{
    bool IsAuthenticated { get; }
    bool CanView { get; }
    bool CanCreate { get; }
    bool CanEdit { get; }
    bool CanDelete { get; }
    bool CanAdmin { get; }

    string DisplayName { get; }
    string RoleName { get; }
    string ATTUID { get; }

    event Action? SessionChanged;
}
