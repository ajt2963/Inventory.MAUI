using Inventory.MAUI.Models;

namespace Inventory.MAUI.Services;

/// <summary>
/// Holds the current authenticated user session for the app lifetime.
/// All platforms require explicit ATTUID + password authentication.
/// </summary>
public sealed class AppSessionService : IAppSessionService
{
    private readonly IAuditService _audit;
    private readonly ISessionService _sessionService;
    private readonly ISystemSettingsService _systemSettings;

    private AppUser? _currentUser;
    private AppRole? _currentRole;
    private DateTime _lastActivityUtc = DateTime.UtcNow;
    private string? _sessionToken;

    /// <summary>Default session inactivity timeout (used if settings unavailable).</summary>
    public static readonly TimeSpan DefaultSessionTimeout = TimeSpan.FromMinutes(30);

    public AppSessionService(IAuditService audit, ISessionService sessionService, ISystemSettingsService systemSettings)
    {
        _audit = audit;
        _sessionService = sessionService;
        _systemSettings = systemSettings;
    }

    /// <summary>The currently logged-in user, or null if unresolved/unauthenticated.</summary>
    public AppUser? CurrentUser
    {
        get => _currentUser;
        private set
        {
            _currentUser = value;
            _currentRole = value?.Role;
            _lastActivityUtc = DateTime.UtcNow;
            SessionChanged?.Invoke();
        }
    }

    /// <summary>Convenience accessor for the current role.</summary>
    public AppRole? CurrentRole => _currentRole;

    /// <summary>Raised whenever the session user changes (login, logout, role update).</summary>
    public event Action? SessionChanged;

    // Permission helpers
    public bool IsAuthenticated => CurrentUser is not null && !IsSessionExpired;
    public bool CanView => IsAuthenticated && (_currentRole?.CanView ?? false);
    public bool CanCreate => IsAuthenticated && (_currentRole?.CanCreate ?? false);
    public bool CanEdit => IsAuthenticated && (_currentRole?.CanEdit ?? false);
    public bool CanDelete => IsAuthenticated && (_currentRole?.CanDelete ?? false);
    public bool CanAdmin => IsAuthenticated && (_currentRole?.CanAdmin ?? false);

    public string DisplayName => CurrentUser?.DisplayName ?? "Unknown";
    public string RoleName => CurrentRole?.RoleName ?? "None";
    public string ATTUID => CurrentUser?.ATTUID ?? "N/A";

    /// <summary>True if the user must change their password before using the app.</summary>
    public bool MustChangePassword => CurrentUser?.MustChangePassword ?? false;

    /// <summary>Gets the configured session timeout. Reads from cache (sync-safe).</summary>
    private TimeSpan GetSessionTimeout()
    {
        // Use GetIntAsync with .Result is not ideal, but IsSessionExpired is a sync property.
        // The value is cached in SystemSettingsService, so this won't hit the DB.
        try
        {
            var minutes = _systemSettings.GetIntAsync(
                SettingKeys.SessionTimeoutMinutes, (int)DefaultSessionTimeout.TotalMinutes)
                .GetAwaiter().GetResult();
            return TimeSpan.FromMinutes(minutes);
        }
        catch
        {
            return DefaultSessionTimeout;
        }
    }

    /// <summary>True if the session has expired due to inactivity.</summary>
    public bool IsSessionExpired => CurrentUser is not null
        && (DateTime.UtcNow - _lastActivityUtc) > GetSessionTimeout();

    /// <summary>
    /// Records user activity to reset the inactivity timer.
    /// Call this on significant user interactions.
    /// </summary>
    public void RecordActivity()
    {
        if (CurrentUser is not null)
        {
            _lastActivityUtc = DateTime.UtcNow;

            // Update DB session last-activity (fire-and-forget)
            if (_sessionToken is not null)
                _ = _sessionService.TouchSessionAsync(_sessionToken);
        }
    }

    /// <summary>
    /// Checks session expiry and clears the session if timed out.
    /// Returns true if the session was expired and cleared.
    /// </summary>
    public bool CheckAndExpireSession()
    {
        if (CurrentUser is not null && IsSessionExpired)
        {
            var userId = CurrentUser.UserID;
            var attuid = CurrentUser.ATTUID;
            var token = _sessionToken;

            // Fire-and-forget � audit/session logging must not block session expiry
            var timeout = GetSessionTimeout();
            _ = _audit.LogAsync(
                AuditEventTypes.SessionExpired,
                userId: userId,
                attuid: attuid,
                details: $"Session expired after {timeout.TotalMinutes} min inactivity");

            if (token is not null)
                _ = _sessionService.EndSessionAsync(token, "Expired");

            _sessionToken = null;
            CurrentUser = null; // Triggers SessionChanged via the setter
            return true;
        }
        return false;
    }

    /// <summary>
    /// Authenticates a user by ATTUID and password.
    /// Returns true if authentication succeeded.
    /// </summary>
    public async Task<bool> SignInAsync(IAppUserService userService, string attuid, string password)
    {
        if (string.IsNullOrWhiteSpace(attuid) || string.IsNullOrWhiteSpace(password))
        {
            CurrentUser = null;
            return false;
        }

        var user = await userService.AuthenticateAsync(attuid.Trim(), password);
        if (user is not null)
        {
            _sessionToken = await _sessionService.StartSessionAsync(user.UserID, user.ATTUID);
        }
        CurrentUser = user;
        return user is not null;
    }

    /// <summary>
    /// Sets the initial password for a user who has MustChangePassword = true.
    /// This is the only path for first-time login or after an admin password reset.
    /// </summary>
    public async Task<bool> SetInitialPasswordAsync(IAppUserService userService, string attuid, string newPassword)
    {
        if (string.IsNullOrWhiteSpace(attuid) || string.IsNullOrWhiteSpace(newPassword))
            return false;

        var user = await userService.GetByAttuidAsync(attuid.Trim());
        if (user is null || !user.IsActive || !user.MustChangePassword)
            return false;

        await userService.SetPasswordAsync(user.UserID, newPassword);
        return true;
    }

    /// <summary>
    /// Refreshes the session from the database (e.g., after role change).
    /// </summary>
    public async Task RefreshAsync(IAppUserService userService)
    {
        if (CurrentUser is null)
            return;

        var user = await userService.GetByIdAsync(CurrentUser.UserID);
        CurrentUser = user;
    }

    /// <summary>Clears the session (logout).</summary>
    public void Clear(bool isExplicitLogout = true)
    {
        if (_currentUser is not null)
        {
            var userId = _currentUser.UserID;
            var attuid = _currentUser.ATTUID;
            var token = _sessionToken;

            if (isExplicitLogout)
            {
                // Fire-and-forget � audit logging must not block logout
                _ = _audit.LogAsync(
                    AuditEventTypes.Logout,
                    userId: userId,
                    attuid: attuid,
                    details: "User signed out");
            }

            if (token is not null)
                _ = _sessionService.EndSessionAsync(token, isExplicitLogout ? "Logout" : "Cleared");
        }

        _sessionToken = null;
        CurrentUser = null;
    }

    /// <summary>The current DB-backed session token, or null if not signed in.</summary>
    public string? SessionToken => _sessionToken;
}
