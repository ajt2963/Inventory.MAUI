namespace Inventory.MAUI.Services;

/// <summary>
/// Cross-platform service that saves a file to a user-chosen location.
/// On Android, uses the Storage Access Framework (system file picker).
/// On Windows/iOS/Mac, writes directly to a known directory.
/// </summary>
public interface IFileSaveService
{
    /// <summary>
    /// Saves content to a file. On Android, opens the system "Save As" picker.
    /// Returns the final file path/URI, or null if the user cancelled.
    /// </summary>
    /// <param name="suggestedFileName">Default file name shown in the save dialog.</param>
    /// <param name="content">The file content as a UTF-8 string.</param>
    /// <param name="mimeType">MIME type (e.g., "text/csv").</param>
    Task<string?> SaveFileAsync(string suggestedFileName, string content, string mimeType = "text/csv");
}
