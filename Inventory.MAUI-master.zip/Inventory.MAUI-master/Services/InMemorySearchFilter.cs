namespace Inventory.MAUI.Services;

/// <summary>
/// Reusable in-memory search filter supporting AND, OR, "quoted phrases",
/// and implicit AND (space-separated terms).  Matches any of the text
/// fields returned by a caller-supplied extractor delegate.
/// </summary>
public static class InMemorySearchFilter
{
    /// <summary>
    /// Filters <paramref name="source"/> using logical operators parsed from
    /// <paramref name="searchText"/>.  <paramref name="fieldExtractor"/>
    /// returns the searchable text fields for each item.
    /// </summary>
    public static List<T> Apply<T>(
        IReadOnlyList<T> source,
        string searchText,
        Func<T, IEnumerable<string?>> fieldExtractor)
    {
        if (string.IsNullOrWhiteSpace(searchText))
            return [.. source];

        var tokens = Tokenize(searchText);
        if (tokens.Count == 0) return [.. source];

        var clauses = BuildClauses(tokens);
        if (clauses.Count == 0) return [.. source];

        return source.Where(item => Evaluate(item, clauses, fieldExtractor)).ToList();
    }

    private static bool Evaluate<T>(
        T item,
        List<SearchClause> clauses,
        Func<T, IEnumerable<string?>> fieldExtractor)
    {
        var fields = fieldExtractor(item);
        bool result = MatchesTerm(fields, clauses[0].Value);
        for (var i = 1; i < clauses.Count; i++)
        {
            var matches = MatchesTerm(fields, clauses[i].Value);
            result = clauses[i].JoinWithOr ? (result || matches) : (result && matches);
        }
        return result;
    }

    private static bool MatchesTerm(IEnumerable<string?> fields, string term)
    {
        foreach (var field in fields)
        {
            if (field is not null && field.Contains(term, StringComparison.OrdinalIgnoreCase))
                return true;
        }
        return false;
    }

    // ?? Tokenizer ????????????????????????????????????????????????????

    private enum TokenType { Term, And, Or }
    private sealed record Token(TokenType Type, string Text);
    private sealed record SearchClause(string Value, bool JoinWithOr);

    private static List<Token> Tokenize(string input)
    {
        var tokens = new List<Token>();
        var i = 0;
        while (i < input.Length)
        {
            if (char.IsWhiteSpace(input[i])) { i++; continue; }

            if (input[i] == '"')
            {
                var end = input.IndexOf('"', i + 1);
                if (end < 0) end = input.Length;
                var phrase = input[(i + 1)..end];
                if (phrase.Length > 0)
                    tokens.Add(new Token(TokenType.Term, phrase));
                i = end + 1;
                continue;
            }

            var start = i;
            while (i < input.Length && !char.IsWhiteSpace(input[i]) && input[i] != '"')
                i++;

            var word = input[start..i];
            if (word.Equals("AND", StringComparison.OrdinalIgnoreCase))
                tokens.Add(new Token(TokenType.And, word));
            else if (word.Equals("OR", StringComparison.OrdinalIgnoreCase))
                tokens.Add(new Token(TokenType.Or, word));
            else
                tokens.Add(new Token(TokenType.Term, word));
        }
        return tokens;
    }

    private static List<SearchClause> BuildClauses(List<Token> tokens)
    {
        var clauses = new List<SearchClause>();
        var nextJoinOr = false;

        foreach (var token in tokens)
        {
            if (token.Type == TokenType.And) { nextJoinOr = false; continue; }
            if (token.Type == TokenType.Or) { nextJoinOr = true; continue; }

            clauses.Add(new SearchClause(token.Text, nextJoinOr));
            nextJoinOr = false;
        }
        return clauses;
    }
}
