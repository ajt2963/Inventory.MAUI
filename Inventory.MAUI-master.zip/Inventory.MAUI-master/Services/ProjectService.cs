using Inventory.MAUI.Data;
using Inventory.MAUI.Models;
using Microsoft.EntityFrameworkCore;

namespace Inventory.MAUI.Services;

public sealed class ProjectService : IProjectService
{
    private readonly IDbContextFactory<InventoryDbContext> _contextFactory;

    public ProjectService(IDbContextFactory<InventoryDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<IEnumerable<Projects>> GetAllProjectsAsync()
    {
        await using var context = await _contextFactory.CreateDbContextAsync();
        return await context.Projects.ToListAsync();
    }

    public async Task<Projects?> GetProjectByIdAsync(int id)
    {
        await using var context = await _contextFactory.CreateDbContextAsync();
        return await context.Projects.FindAsync(id);
    }

    public async Task AddAsync(Projects project)
    {
        await using var context = await _contextFactory.CreateDbContextAsync();
        await context.Projects.AddAsync(project);
        await context.SaveChangesAsync();
    }

    public async Task UpdateProjectAsync(Projects project)
    {
        await using var context = await _contextFactory.CreateDbContextAsync();
        context.Projects.Update(project);
        await context.SaveChangesAsync();
    }

    public async Task DeleteProjectAsync(int id)
    {
        await using var context = await _contextFactory.CreateDbContextAsync();
        var project = await context.Projects.FindAsync(id);
        if (project != null)
        {
            context.Projects.Remove(project);
            await context.SaveChangesAsync();
        }
    }

    public Task<IEnumerable<Projects>> GetProjectsAsync() => GetAllProjectsAsync();
}
