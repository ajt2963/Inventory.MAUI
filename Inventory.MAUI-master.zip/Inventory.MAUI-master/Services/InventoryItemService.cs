using Inventory.MAUI.Data;
using Inventory.MAUI.Models;
using Microsoft.EntityFrameworkCore;

namespace Inventory.MAUI.Services;

public sealed class InventoryItemService : IInventoryItemService
{
    private readonly IDbContextFactory<InventoryDbContext> _contextFactory;

    public InventoryItemService(IDbContextFactory<InventoryDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<InventoryItem?> GetByIdAsync(int inventoryId)
    {
        await using var context = await _contextFactory.CreateDbContextAsync();

        return await context.InventoryItem
            .AsNoTracking()
            .IgnoreQueryFilters()
            .Include(i => i.Asset)
            .Include(i => i.AssetOwner)
            .Include(i => i.AssetType)
            .Include(i => i.Category)
            .Include(i => i.Companies)
            .Include(i => i.InventoryStorage)
            .Include(i => i.Locations)
            .Include(i => i.Notes)
            .FirstOrDefaultAsync(i => i.InventoryID == inventoryId);
    }

    public async Task<(IReadOnlyList<AssetOwner> Owners,
        IReadOnlyList<AssetType> Types,
        IReadOnlyList<Category> Categories,
        IReadOnlyList<Companies> Companies,
        IReadOnlyList<Locations> Locations,
        IReadOnlyList<InventoryStorage> Storages)> GetLookupsAsync()
    {
        await using var context = await _contextFactory.CreateDbContextAsync();

        var owners = await context.AssetOwner.AsNoTracking().OrderBy(o => o.Owner).ToListAsync();
        var types = await context.AssetType.AsNoTracking().OrderBy(t => t.Type).ToListAsync();
        var categories = await context.Category.AsNoTracking().OrderBy(c => c.CatName).ToListAsync();
        var companies = await context.Companies.AsNoTracking().OrderBy(c => c.CompanyName).ToListAsync();
        var locations = await context.Locations.AsNoTracking().OrderBy(l => l.LocationName).ToListAsync();
        var storages = await context.InventoryStorage.AsNoTracking().OrderBy(s => s.DisplayValue).ToListAsync();

        return (owners, types, categories, companies, locations, storages);
    }

    public async Task<(IReadOnlyList<Asset> Assets,
        IReadOnlyList<AssetOwner> Owners,
        IReadOnlyList<AssetType> Types,
        IReadOnlyList<Category> Categories,
        IReadOnlyList<Companies> Companies,
        IReadOnlyList<Locations> Locations,
        IReadOnlyList<InventoryStorage> Storages)> GetCreateLookupsAsync()
    {
        try
        {
            await using var context = await _contextFactory.CreateDbContextAsync();

            var assets = await context.Asset.AsNoTracking().OrderBy(a => a.AssetTag).ToListAsync();
            var owners = await context.AssetOwner.AsNoTracking().OrderBy(o => o.Owner).ToListAsync();
            var types = await context.AssetType.AsNoTracking().OrderBy(t => t.Type).ToListAsync();
            var categories = await context.Category.AsNoTracking().OrderBy(c => c.CatName).ToListAsync();
            var companies = await context.Companies.AsNoTracking().OrderBy(c => c.CompanyName).ToListAsync();
            var locations = await context.Locations.AsNoTracking().OrderBy(l => l.LocationName).ToListAsync();
            var storages = await context.InventoryStorage.AsNoTracking().OrderBy(s => s.DisplayValue).ToListAsync();

            return (assets, owners, types, categories, companies, locations, storages);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("Failed to load lookup values.", ex);
        }
    }

    public async Task UpdateAsync(InventoryItem item, string? modifiedBy, string? notesText)
    {
        await using var context = await _contextFactory.CreateDbContextAsync();

        var id = item.InventoryID;
        if (id is null)
            return;

        var tracked = await context.InventoryItem
            .Include(i => i.Notes)
            .FirstOrDefaultAsync(i => i.InventoryID == id);

        if (tracked is null)
            return;

        tracked.PartNumber = item.PartNumber;
        tracked.SerialNumber = item.SerialNumber;
        tracked.Description = item.Description;
        tracked.Quantity = item.Quantity;
        tracked.BatteryType = item.BatteryType;
        tracked.OwnerID = item.OwnerID;
        tracked.TypeID = item.TypeID;
        tracked.CatID = item.CatID;
        tracked.CompanyID = item.CompanyID;
        tracked.LocationID = item.LocationID;
        tracked.StorageID = item.StorageID;
        tracked.DateModified = DateTime.UtcNow;
        tracked.ModifiedBy = modifiedBy;

        if (tracked.Notes is null && tracked.NotesID is null && !string.IsNullOrWhiteSpace(notesText))
        {
            tracked.Notes = new Notes
            {
                InventoryNotes = notesText,
                DateModified = DateTime.UtcNow,
                ModifiedBy = modifiedBy
            };
        }
        else if (tracked.Notes is not null)
        {
            tracked.Notes.InventoryNotes = notesText;
            tracked.Notes.DateModified = DateTime.UtcNow;
            tracked.Notes.ModifiedBy = modifiedBy;
        }

        await context.SaveChangesAsync();
    }

    public async Task SoftDeleteAsync(int inventoryId, string? deletedBy)
    {
        // If soft-delete columns are not present, keep this as a no-op.
        await Task.CompletedTask;
    }

    public async Task<int> CreateAsync(InventoryItem item, string modifiedBy, string? userNotes, CancellationToken cancellationToken = default)
    {
        await using var context = await _contextFactory.CreateDbContextAsync(cancellationToken);

        if (item.InventoryID is not null)
            throw new InvalidOperationException("InventoryID must be null for new records.");

        if (string.IsNullOrWhiteSpace(modifiedBy))
            throw new InvalidOperationException("ModifiedBy is required.");

        if (item.OwnerID is null || item.TypeID is null || item.CatID is null || item.CompanyID is null || item.LocationID is null || item.StorageID is null)
            throw new InvalidOperationException("Owner, Type, Category, Company, Location, and Storage are required.");

        var now = item.DateModified ?? DateTime.Now;

        item.DateModified = now;
        item.ModifiedBy = modifiedBy;

        await using var tx = await context.Database.BeginTransactionAsync(cancellationToken);

        try
        {
            // Notes: always create.
            var preset = $"New record entered {now:MM/dd/yyyy} {modifiedBy}.";
            var prefix = string.IsNullOrWhiteSpace(userNotes) ? string.Empty : userNotes.TrimEnd() + Environment.NewLine + Environment.NewLine;
            var notesText = prefix + preset;

            var notes = new Notes
            {
                InventoryNotes = notesText,
                DateModified = now,
                ModifiedBy = modifiedBy
            };
            context.Notes.Add(notes);
            try
            {
                await context.SaveChangesAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to create Notes record.", ex);
            }

            item.NotesID = notes.NotesID;

            // Create InventoryItem first to get InventoryID.
            context.InventoryItem.Add(item);
            try
            {
                await context.SaveChangesAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to create InventoryItem record.", ex);
            }

            var newInvId = Convert.ToInt32(item.InventoryID!.Value);

            // Asset: always create for new inventory record.
            var asset = new Asset
            {
                InventoryID = newInvId,
                AssetTag = $"UCM-{newInvId:00000}",
                Status = "Active",
                DateModified = now,
                ModifiedBy = modifiedBy
            };
            context.Asset.Add(asset);
            try
            {
                await context.SaveChangesAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to create Asset record.", ex);
            }

            // Link InventoryItem to Asset.
            item.AssetID = asset.AssetID;
            try
            {
                await context.SaveChangesAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to link InventoryItem to Asset.", ex);
            }

            // Calibration: background add only (best-effort).
            try
            {
                context.Calibration.Add(new Calibration
                {
                    InventoryID = newInvId,
                    DateModified = now,
                    ModifiedBy = modifiedBy
                });
                await context.SaveChangesAsync(cancellationToken);
            }
            catch
            {
                // Best-effort: do not block creation.
            }

            await tx.CommitAsync(cancellationToken);
            return newInvId;
        }
        catch
        {
            await tx.RollbackAsync(cancellationToken);
            throw;
        }
    }
}