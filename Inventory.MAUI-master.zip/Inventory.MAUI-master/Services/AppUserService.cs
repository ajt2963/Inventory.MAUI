using Inventory.MAUI.Data;
using Inventory.MAUI.Models;
using Microsoft.EntityFrameworkCore;

namespace Inventory.MAUI.Services;

public sealed class AppUserService : IAppUserService
{
    private readonly IDbContextFactory<InventoryDbContext> _contextFactory;
    private readonly IIdentityService _identityService;
    private readonly IAuditService _audit;
    private readonly ISystemSettingsService _systemSettings;
    private readonly PasswordPolicy _passwordPolicy;

    public AppUserService(
        IDbContextFactory<InventoryDbContext> contextFactory,
        IIdentityService identityService,
        IAuditService audit,
        ISystemSettingsService systemSettings,
        PasswordPolicy passwordPolicy)
    {
        _contextFactory = contextFactory;
        _identityService = identityService;
        _audit = audit;
        _systemSettings = systemSettings;
        _passwordPolicy = passwordPolicy;
    }

    public async Task<AppUser?> GetCurrentUserAsync()
    {
        var shortName = _identityService.GetCurrentShortName();
        if (string.IsNullOrWhiteSpace(shortName))
            return null;

        return await GetByAttuidAsync(shortName);
    }

    public async Task<AppUser?> GetByAttuidAsync(string attuid)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        return await ctx.AppUser
            .Include(u => u.Role)
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.ATTUID == attuid);
    }

    public async Task<AppUser?> GetByIdAsync(int userId)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        return await ctx.AppUser
            .Include(u => u.Role)
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.UserID == userId);
    }

    public async Task<List<AppUser>> GetAllUsersAsync(bool includeInactive = false)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        IQueryable<AppUser> query = ctx.AppUser.Include(u => u.Role).AsNoTracking();

        if (!includeInactive)
            query = query.Where(u => u.IsActive);

        return await query.OrderBy(u => u.DisplayName).ToListAsync();
    }

    public async Task<AppUser> SaveUserAsync(AppUser user)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();

        bool isNew = user.UserID == 0;

        if (isNew)
        {
            user.CreatedAt = DateTime.UtcNow;
            ctx.AppUser.Add(user);
        }
        else
        {
            ctx.AppUser.Update(user);
        }

        await ctx.SaveChangesAsync();

        await _audit.LogAsync(
            isNew ? AuditEventTypes.UserCreated : AuditEventTypes.UserModified,
            userId: user.UserID,
            attuid: user.ATTUID,
            entityType: nameof(AppUser),
            entityId: user.UserID.ToString(),
            details: isNew
                ? $"User '{user.DisplayName}' created with role {user.RoleID}"
                : $"User '{user.DisplayName}' updated");

        // Reload with navigation
        return (await ctx.AppUser
            .Include(u => u.Role)
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.UserID == user.UserID))!;
    }

    public async Task<List<AppRole>> GetAllRolesAsync()
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        return await ctx.AppRole.AsNoTracking().OrderBy(r => r.RoleName).ToListAsync();
    }

    public async Task<AppRole> SaveRoleAsync(AppRole role)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();

        bool isNew = role.RoleID == 0;

        if (isNew)
        {
            ctx.AppRole.Add(role);
        }
        else
        {
            ctx.AppRole.Update(role);
        }

        await ctx.SaveChangesAsync();

        await _audit.LogAsync(
            isNew ? AuditEventTypes.RoleCreated : AuditEventTypes.RoleModified,
            entityType: nameof(AppRole),
            entityId: role.RoleID.ToString(),
            details: $"Role '{role.RoleName}' {(isNew ? "created" : "updated")}");

        return role;
    }

    public async Task DeleteRoleAsync(int roleId)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();

        var usersWithRole = await ctx.AppUser.CountAsync(u => u.RoleID == roleId);
        if (usersWithRole > 0)
            throw new InvalidOperationException($"Cannot delete role: {usersWithRole} user(s) are still assigned to it.");

        var role = await ctx.AppRole.FindAsync(roleId);
        if (role is not null)
        {
            var roleName = role.RoleName;
            ctx.AppRole.Remove(role);
            await ctx.SaveChangesAsync();

            await _audit.LogAsync(
                AuditEventTypes.RoleDeleted,
                entityType: nameof(AppRole),
                entityId: roleId.ToString(),
                details: $"Role '{roleName}' deleted");
        }
    }

    public async Task EnsureSeedDataAsync()
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();

        // Create IAM tables if they don't exist (safe for existing databases).
        await ctx.Database.ExecuteSqlRawAsync("""
            IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'AppRole')
            BEGIN
                CREATE TABLE AppRole (
                    RoleID   INT IDENTITY(1,1) PRIMARY KEY,
                    RoleName NVARCHAR(50)  NOT NULL,
                    CanView   BIT NOT NULL DEFAULT 1,
                    CanCreate BIT NOT NULL DEFAULT 0,
                    CanEdit   BIT NOT NULL DEFAULT 0,
                    CanDelete BIT NOT NULL DEFAULT 0,
                    CanAdmin  BIT NOT NULL DEFAULT 0
                );
            END
            """);

        await ctx.Database.ExecuteSqlRawAsync("""
            IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'AppUser')
            BEGIN
                CREATE TABLE AppUser (
                    UserID              INT IDENTITY(1,1) PRIMARY KEY,
                    ATTUID              NVARCHAR(100) NOT NULL,
                    DisplayName         NVARCHAR(150) NOT NULL,
                    Email               NVARCHAR(200) NULL,
                    PasswordHash        NVARCHAR(500) NULL,
                    PasswordSalt        NVARCHAR(500) NULL,
                    FailedLoginAttempts INT NOT NULL DEFAULT 0,
                    LockoutUntil        DATETIME2 NULL,
                    MustChangePassword  BIT NOT NULL DEFAULT 1,
                    RoleID              INT NOT NULL,
                    IsActive            BIT NOT NULL DEFAULT 1,
                    CreatedAt           DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
                    LastLoginAt         DATETIME2 NULL,
                    CONSTRAINT FK_AppUser_AppRole FOREIGN KEY (RoleID) REFERENCES AppRole(RoleID),
                    CONSTRAINT UQ_AppUser_ATTUID UNIQUE (ATTUID)
                );
            END
            """);

        // Add security columns to existing AppUser tables that were created before this update.
        await ctx.Database.ExecuteSqlRawAsync("""
            IF EXISTS (SELECT * FROM sys.tables WHERE name = 'AppUser')
               AND NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('AppUser') AND name = 'PasswordHash')
            BEGIN
                ALTER TABLE AppUser ADD PasswordHash NVARCHAR(500) NULL;
                ALTER TABLE AppUser ADD PasswordSalt NVARCHAR(500) NULL;
                ALTER TABLE AppUser ADD FailedLoginAttempts INT NOT NULL DEFAULT 0;
                ALTER TABLE AppUser ADD LockoutUntil DATETIME2 NULL;
                ALTER TABLE AppUser ADD MustChangePassword BIT NOT NULL DEFAULT 1;
            END
            """);

        // Create AuditLog table if it doesn't exist.
        await ctx.Database.ExecuteSqlRawAsync("""
            IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'AuditLog')
            BEGIN
                CREATE TABLE AuditLog (
                    LogID        BIGINT IDENTITY(1,1) PRIMARY KEY,
                    TimestampUtc DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
                    UserID       INT NULL,
                    ATTUID       NVARCHAR(100) NULL,
                    EventType    NVARCHAR(50)  NOT NULL,
                    EntityType   NVARCHAR(100) NULL,
                    EntityID     NVARCHAR(50)  NULL,
                    Details      NVARCHAR(2000) NULL,
                    Platform     NVARCHAR(50)  NULL,
                    CONSTRAINT FK_AuditLog_AppUser FOREIGN KEY (UserID) REFERENCES AppUser(UserID) ON DELETE SET NULL
                );

                CREATE INDEX IX_AuditLog_TimestampUtc ON AuditLog (TimestampUtc);
                CREATE INDEX IX_AuditLog_EventType    ON AuditLog (EventType);
                CREATE INDEX IX_AuditLog_UserID       ON AuditLog (UserID);
            END
            """);

        // Create PasswordHistory table if it doesn't exist.
        await ctx.Database.ExecuteSqlRawAsync("""
            IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'PasswordHistory')
            BEGIN
                CREATE TABLE PasswordHistory (
                    HistoryID    BIGINT IDENTITY(1,1) PRIMARY KEY,
                    UserID       INT NOT NULL,
                    PasswordHash NVARCHAR(500) NOT NULL,
                    PasswordSalt NVARCHAR(500) NOT NULL,
                    CreatedAtUtc DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
                    CONSTRAINT FK_PasswordHistory_AppUser FOREIGN KEY (UserID) REFERENCES AppUser(UserID) ON DELETE CASCADE
                );

                CREATE INDEX IX_PasswordHistory_UserID ON PasswordHistory (UserID);
            END
            """);

        // Add PasswordExpiresAt column to existing AppUser tables.
        await ctx.Database.ExecuteSqlRawAsync("""
            IF EXISTS (SELECT * FROM sys.tables WHERE name = 'AppUser')
               AND NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('AppUser') AND name = 'PasswordExpiresAt')
            BEGIN
                ALTER TABLE AppUser ADD PasswordExpiresAt DATETIME2 NULL;
            END
            """);

        // Create UserSession table if it doesn't exist.
        await ctx.Database.ExecuteSqlRawAsync("""
            IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'UserSession')
            BEGIN
                CREATE TABLE UserSession (
                    SessionID       BIGINT IDENTITY(1,1) PRIMARY KEY,
                    SessionToken    NVARCHAR(64) NOT NULL,
                    UserID          INT NOT NULL,
                    ATTUID          NVARCHAR(100) NULL,
                    StartedAtUtc    DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
                    LastActivityUtc DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
                    EndedAtUtc      DATETIME2 NULL,
                    EndReason       NVARCHAR(50) NULL,
                    Platform        NVARCHAR(50) NULL,
                    DeviceInfo      NVARCHAR(200) NULL,
                    CONSTRAINT FK_UserSession_AppUser FOREIGN KEY (UserID) REFERENCES AppUser(UserID) ON DELETE CASCADE,
                    CONSTRAINT UQ_UserSession_Token UNIQUE (SessionToken)
                );

                CREATE INDEX IX_UserSession_UserID ON UserSession (UserID);
                CREATE INDEX IX_UserSession_Active ON UserSession (UserID, EndedAtUtc);
            END
            """);

        // Create PasswordResetToken table if it doesn't exist (Phase 4).
        await ctx.Database.ExecuteSqlRawAsync("""
            IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'PasswordResetToken')
            BEGIN
                CREATE TABLE PasswordResetToken (
                    TokenID      BIGINT IDENTITY(1,1) PRIMARY KEY,
                    UserID       INT NOT NULL,
                    Token        NVARCHAR(10) NOT NULL,
                    CreatedAtUtc DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
                    ExpiresAtUtc DATETIME2 NOT NULL,
                    UsedAtUtc    DATETIME2 NULL,
                    CONSTRAINT FK_PasswordResetToken_AppUser FOREIGN KEY (UserID) REFERENCES AppUser(UserID) ON DELETE CASCADE
                );

                CREATE INDEX IX_PasswordResetToken_UserID ON PasswordResetToken (UserID);
                CREATE INDEX IX_PasswordResetToken_Token  ON PasswordResetToken (Token);
            END
            """);

        // Seed default roles if the table is empty
        if (!await ctx.AppRole.AnyAsync())
        {
            ctx.AppRole.AddRange(
                new AppRole { RoleName = "Admin", CanView = true, CanCreate = true, CanEdit = true, CanDelete = true, CanAdmin = true },
                new AppRole { RoleName = "Editor", CanView = true, CanCreate = true, CanEdit = true, CanDelete = false, CanAdmin = false },
                new AppRole { RoleName = "Viewer", CanView = true, CanCreate = false, CanEdit = false, CanDelete = false, CanAdmin = false }
            );
            await ctx.SaveChangesAsync();
        }

        // Auto-register the current Windows user as Admin if no users exist.
        // The seed user gets MustChangePassword = true and must set their password on first login.
        if (!await ctx.AppUser.AnyAsync())
        {
            var shortName = _identityService.GetCurrentShortName();
            if (!string.IsNullOrWhiteSpace(shortName))
            {
                var adminRole = await ctx.AppRole.FirstAsync(r => r.RoleName == "Admin");
                ctx.AppUser.Add(new AppUser
                {
                    ATTUID = shortName,
                    DisplayName = shortName,
                    RoleID = adminRole.RoleID,
                    IsActive = true,
                    MustChangePassword = true,
                    CreatedAt = DateTime.UtcNow,
                    LastLoginAt = null
                });
                await ctx.SaveChangesAsync();
            }
        }
    }

    public async Task<AppUser?> AuthenticateAsync(string attuid, string password)
    {
        if (string.IsNullOrWhiteSpace(attuid) || string.IsNullOrWhiteSpace(password))
            return null;

        var maxAttempts = await _systemSettings.GetIntAsync(SettingKeys.LockoutMaxAttempts, 5);
        var lockoutMinutes = await _systemSettings.GetIntAsync(SettingKeys.LockoutDurationMinutes, 15);
        var lockoutDuration = TimeSpan.FromMinutes(lockoutMinutes);

        await using var ctx = await _contextFactory.CreateDbContextAsync();
        var user = await ctx.AppUser
            .Include(u => u.Role)
            .FirstOrDefaultAsync(u => u.ATTUID == attuid.Trim());

        if (user is null || !user.IsActive)
        {
            await _audit.LogAsync(
                AuditEventTypes.LoginFailed,
                attuid: attuid.Trim(),
                details: user is null ? "Unknown ATTUID" : "Account inactive");
            return null;
        }

        // Check lockout
        if (user.LockoutUntil.HasValue && user.LockoutUntil.Value > DateTime.UtcNow)
        {
            await _audit.LogAsync(
                AuditEventTypes.LoginFailed,
                userId: user.UserID,
                attuid: user.ATTUID,
                details: $"Account locked until {user.LockoutUntil.Value:u}");
            return null;
        }

        // If password has never been set, deny login (admin must reset, user must set on first login)
        if (string.IsNullOrWhiteSpace(user.PasswordHash) || string.IsNullOrWhiteSpace(user.PasswordSalt))
            return null;

        // Verify password
        if (!PasswordHasher.Verify(password, user.PasswordSalt!, user.PasswordHash!))
        {
            user.FailedLoginAttempts++;
            bool locked = user.FailedLoginAttempts >= maxAttempts;
            if (locked)
            {
                user.LockoutUntil = DateTime.UtcNow.Add(lockoutDuration);
            }
            await ctx.SaveChangesAsync();

            await _audit.LogAsync(
                AuditEventTypes.LoginFailed,
                userId: user.UserID,
                attuid: user.ATTUID,
                details: locked
                    ? $"Bad password � attempt {user.FailedLoginAttempts}, account locked for {lockoutDuration.TotalMinutes} min"
                    : $"Bad password � attempt {user.FailedLoginAttempts} of {maxAttempts}");

            if (locked)
            {
                await _audit.LogAsync(
                    AuditEventTypes.AccountLocked,
                    userId: user.UserID,
                    attuid: user.ATTUID,
                    entityType: nameof(AppUser),
                    entityId: user.UserID.ToString(),
                    details: $"Locked until {user.LockoutUntil.Value:u} after {maxAttempts} failed attempts");
            }

            return null;
        }

        // Successful login � reset lockout counters
        user.FailedLoginAttempts = 0;
        user.LockoutUntil = null;
        user.LastLoginAt = DateTime.UtcNow;

        // Check password expiry � force password change if expired
        if (user.PasswordExpiresAt.HasValue && user.PasswordExpiresAt.Value <= DateTime.UtcNow)
        {
            user.MustChangePassword = true;
        }

        await ctx.SaveChangesAsync();

        await _audit.LogAsync(
            AuditEventTypes.Login,
            userId: user.UserID,
            attuid: user.ATTUID,
            details: user.MustChangePassword
                ? "Authentication successful � password expired, must change"
                : "Authentication successful");

        // Return a detached copy with navigation loaded
        return await ctx.AppUser
            .Include(u => u.Role)
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.UserID == user.UserID);
    }

    public async Task SetPasswordAsync(int userId, string newPassword)
    {
        // Validate against password policy
        var policyError = await _passwordPolicy.ValidateAsync(newPassword);
        if (policyError is not null)
            throw new ArgumentException(policyError);

        await using var ctx = await _contextFactory.CreateDbContextAsync();
        var user = await ctx.AppUser.FindAsync(userId)
            ?? throw new InvalidOperationException("User not found.");

        // Check password history � prevent reuse of last N passwords
        var historyCount = await _passwordPolicy.GetHistoryCountAsync();
        var recentHashes = await ctx.PasswordHistory
            .Where(h => h.UserID == userId)
            .OrderByDescending(h => h.CreatedAtUtc)
            .Take(historyCount)
            .ToListAsync();

        foreach (var prev in recentHashes)
        {
            if (PasswordHasher.Verify(newPassword, prev.PasswordSalt, prev.PasswordHash))
                throw new ArgumentException(
                    $"Cannot reuse any of your last {historyCount} passwords. Please choose a different password.");
        }

        bool isFirstSet = user.MustChangePassword;

        var (salt, hash) = PasswordHasher.HashPassword(newPassword);

        // Archive the current password before overwriting (if one exists)
        if (!string.IsNullOrWhiteSpace(user.PasswordHash) && !string.IsNullOrWhiteSpace(user.PasswordSalt))
        {
            ctx.PasswordHistory.Add(new Models.PasswordHistory
            {
                UserID = userId,
                PasswordHash = user.PasswordHash,
                PasswordSalt = user.PasswordSalt,
                CreatedAtUtc = DateTime.UtcNow
            });
        }

        var expiryDays = await _passwordPolicy.GetExpiryDaysAsync();
        user.PasswordSalt = salt;
        user.PasswordHash = hash;
        user.MustChangePassword = false;
        user.PasswordExpiresAt = expiryDays > 0 ? DateTime.UtcNow.AddDays(expiryDays) : null;
        user.FailedLoginAttempts = 0;
        user.LockoutUntil = null;
        await ctx.SaveChangesAsync();

        await _audit.LogAsync(
            isFirstSet ? AuditEventTypes.PasswordSet : AuditEventTypes.PasswordChanged,
            userId: user.UserID,
            attuid: user.ATTUID,
            entityType: nameof(AppUser),
            entityId: user.UserID.ToString(),
            details: isFirstSet
                ? "Initial password set"
                : $"Password changed by user (expires {user.PasswordExpiresAt:u})");
    }

    public async Task AdminResetPasswordAsync(int userId)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        var user = await ctx.AppUser.FindAsync(userId)
            ?? throw new InvalidOperationException("User not found.");

        user.PasswordHash = null;
        user.PasswordSalt = null;
        user.MustChangePassword = true;
        user.PasswordExpiresAt = null;
        user.FailedLoginAttempts = 0;
        user.LockoutUntil = null;
        await ctx.SaveChangesAsync();

        await _audit.LogAsync(
            AuditEventTypes.PasswordReset,
            userId: user.UserID,
            attuid: user.ATTUID,
            entityType: nameof(AppUser),
            entityId: user.UserID.ToString(),
            details: "Password reset by administrator � user must set new password");
    }

    public async Task RecordLoginAsync(int userId)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        var user = await ctx.AppUser.FindAsync(userId);
        if (user is not null)
        {
            user.LastLoginAt = DateTime.UtcNow;
            await ctx.SaveChangesAsync();
        }
    }

    public async Task DeleteUserAsync(int userId)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        var user = await ctx.AppUser.FindAsync(userId);
        if (user is not null)
        {
            var attuid = user.ATTUID;
            var displayName = user.DisplayName;
            ctx.AppUser.Remove(user);
            await ctx.SaveChangesAsync();

            await _audit.LogAsync(
                AuditEventTypes.UserDeleted,
                userId: userId,
                attuid: attuid,
                entityType: nameof(AppUser),
                entityId: userId.ToString(),
                details: $"User '{displayName}' ({attuid}) deleted");
        }
    }
}
