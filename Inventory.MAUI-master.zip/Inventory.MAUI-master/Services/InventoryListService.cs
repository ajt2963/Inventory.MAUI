using Inventory.MAUI.Data;
using Inventory.MAUI.Models;
using Microsoft.EntityFrameworkCore;

namespace Inventory.MAUI.Services;

public sealed class InventoryListService : IInventoryListService
{
    private readonly IDbContextFactory<InventoryDbContext> _contextFactory;

    public InventoryListService(IDbContextFactory<InventoryDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    private static IQueryable<InventoryList> ApplySearch(IQueryable<InventoryList> query, string? searchText)
    {
        var predicate = SearchExpressionParser.Parse(searchText);
        return predicate is not null ? query.Where(predicate) : query;
    }

    public async Task<int> GetInventoryListCountAsync(string? searchText = null)
    {
        await using var context = await _contextFactory.CreateDbContextAsync();

        IQueryable<InventoryList> query = context.InventoryList.AsNoTracking();

        query = ApplySearch(query, searchText);

        return await query.CountAsync();
    }

    public async Task<InventoryList?> GetByIdAsync(int inventoryId)
    {
        await using var context = await _contextFactory.CreateDbContextAsync();
        return await context.InventoryList.AsNoTracking().FirstOrDefaultAsync(x => x.InventoryID == inventoryId);
    }

    public async Task<IReadOnlyList<InventoryList>> GetInventoryListPageAsync(string? searchText = null, int skip = 0, int take = 200)
    {
        await using var context = await _contextFactory.CreateDbContextAsync();

        IQueryable<InventoryList> query = context.InventoryList.AsNoTracking();

        query = ApplySearch(query, searchText);

        // Deterministic ordering required for Skip/Take.
        query = query.OrderBy(i => i.InventoryID);

        skip = Math.Max(0, skip);
        take = Math.Clamp(take, 1, 5_000);

        return await query.Skip(skip).Take(take).ToListAsync();
    }

    public async Task<List<InventoryList>> GetInventoryListAsync(string? searchText = null, int? take = null)
    {
        await using var context = await _contextFactory.CreateDbContextAsync();

        IQueryable<InventoryList> query = context.InventoryList.AsNoTracking();

        query = ApplySearch(query, searchText);

        query = query.OrderBy(i => i.InventoryID);

        if (take is not null)
        {
            query = query.Take(Math.Clamp(take.Value, 1, 100_000));
        }

        return await query.ToListAsync();
    }

    public async Task<InventoryList?> GetLastAsync(string? searchText = null)
    {
        await using var context = await _contextFactory.CreateDbContextAsync();

        IQueryable<InventoryList> query = context.InventoryList.AsNoTracking();

        query = ApplySearch(query, searchText);

        // Mirror paging ordering, but descending; then take first.
        query = query
            .OrderByDescending(i => i.InventoryID);

        return await query.FirstOrDefaultAsync();
    }

    public async Task<IReadOnlyList<InventoryList>> GetLastPageAsync(string? searchText = null, int take = 250)
    {
        await using var context = await _contextFactory.CreateDbContextAsync();

        IQueryable<InventoryList> query = context.InventoryList.AsNoTracking();

        query = ApplySearch(query, searchText);

        take = Math.Clamp(take, 1, 5_000);

        var desc = await query
            .OrderByDescending(i => i.InventoryID)
            .Take(take)
            .ToListAsync();

        desc.Reverse();
        return desc;
    }

    public async Task<IReadOnlyList<InventoryList>> GetByLocationAsync(string clliCode)
    {
        await using var context = await _contextFactory.CreateDbContextAsync();
        return await context.InventoryList.AsNoTracking()
            .Where(i => i.ClliCode == clliCode)
            .OrderBy(i => i.InventoryID)
            .ToListAsync();
    }

    public async Task<List<(string Name, int Count)>> GetCountByStatusAsync()
    {
        await using var context = await _contextFactory.CreateDbContextAsync();
        var data = await context.InventoryList.AsNoTracking()
            .Where(i => i.Status != null && i.Status != "")
            .GroupBy(i => i.Status!)
            .Select(g => new { Name = g.Key, Count = g.Count() })
            .OrderByDescending(x => x.Count)
            .ToListAsync();
        return data.Select(x => (x.Name, x.Count)).ToList();
    }

    public async Task<List<(string Name, int Count)>> GetCountByLocationAsync()
    {
        await using var context = await _contextFactory.CreateDbContextAsync();
        var data = await context.InventoryList.AsNoTracking()
            .Where(i => i.ClliCode != null && i.ClliCode != "")
            .GroupBy(i => i.ClliCode!)
            .Select(g => new { Name = g.Key, Count = g.Count() })
            .OrderByDescending(x => x.Count)
            .ToListAsync();
        return data.Select(x => (x.Name, x.Count)).ToList();
    }

    public async Task<List<(string Location, string Name, int Count)>> GetCountByFieldPerLocationAsync(string fieldName)
    {
        await using var context = await _contextFactory.CreateDbContextAsync();

        var query = context.InventoryList.AsNoTracking()
            .Where(i => i.ClliCode != null && i.ClliCode != "");

        switch (fieldName)
        {
            case "Owner":
            {
                var data = await query.Where(i => i.Owner != null && i.Owner != "")
                    .GroupBy(i => new { i.ClliCode, i.Owner })
                    .Select(g => new { Location = g.Key.ClliCode!, Name = g.Key.Owner!, Count = g.Count() })
                    .OrderBy(x => x.Location).ThenByDescending(x => x.Count)
                    .ToListAsync();
                return data.Select(x => (x.Location, x.Name, x.Count)).ToList();
            }
            case "CatName":
            {
                var data = await query.Where(i => i.CatName != null && i.CatName != "")
                    .GroupBy(i => new { i.ClliCode, i.CatName })
                    .Select(g => new { Location = g.Key.ClliCode!, Name = g.Key.CatName!, Count = g.Count() })
                    .OrderBy(x => x.Location).ThenByDescending(x => x.Count)
                    .ToListAsync();
                return data.Select(x => (x.Location, x.Name, x.Count)).ToList();
            }
            case "Type":
            {
                var data = await query.Where(i => i.Type != null && i.Type != "")
                    .GroupBy(i => new { i.ClliCode, i.Type })
                    .Select(g => new { Location = g.Key.ClliCode!, Name = g.Key.Type!, Count = g.Count() })
                    .OrderBy(x => x.Location).ThenByDescending(x => x.Count)
                    .ToListAsync();
                return data.Select(x => (x.Location, x.Name, x.Count)).ToList();
            }
            case "CompanyName":
            {
                var data = await query.Where(i => i.CompanyName != null && i.CompanyName != "")
                    .GroupBy(i => new { i.ClliCode, i.CompanyName })
                    .Select(g => new { Location = g.Key.ClliCode!, Name = g.Key.CompanyName!, Count = g.Count() })
                    .OrderBy(x => x.Location).ThenByDescending(x => x.Count)
                    .ToListAsync();
                return data.Select(x => (x.Location, x.Name, x.Count)).ToList();
            }
            default:
                throw new ArgumentException($"Unknown field: {fieldName}", nameof(fieldName));
        }
    }
}
