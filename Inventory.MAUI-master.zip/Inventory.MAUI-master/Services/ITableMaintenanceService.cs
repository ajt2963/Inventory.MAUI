namespace Inventory.MAUI.Services;

/// <summary>
/// Generic CRUD service for lookup/reference tables.
/// </summary>
public interface ITableMaintenanceService<T> where T : class
{
    Task<List<T>> GetAllAsync();
    Task<T?> GetByIdAsync(int id);
    Task<int> AddAsync(T entity);
    Task UpdateAsync(T entity);
    Task DeleteAsync(int id);
}
