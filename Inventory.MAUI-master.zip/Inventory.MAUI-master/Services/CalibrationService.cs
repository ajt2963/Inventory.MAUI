using Inventory.MAUI.Data;
using Inventory.MAUI.Models;
using Microsoft.EntityFrameworkCore;

namespace Inventory.MAUI.Services;

public sealed class CalibrationService : ICalibrationService
{
    private readonly IDbContextFactory<InventoryDbContext> _contextFactory;

    // Calibration-eligible type names (case-insensitive comparison at query time).
    private static readonly HashSet<string> EligibleTypes = new(StringComparer.OrdinalIgnoreCase)
    {
        "Electrical Test Set",
        "Optical Test Set",
        "Transmission Analyzer",
        "Signal Analyzer",
        "Temperature"
    };

    private const string EligibleCategory = "Test Equipment";

    public CalibrationService(IDbContextFactory<InventoryDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<List<CalibrationItemRow>> GetItemsByLocationAsync(int locationId)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();

        // Get the RoleID for "Manufacturer"
        var mfrRoleId = await ctx.Roles
            .Where(r => r.RoleName == "Manufacturer")
            .Select(r => r.RoleID)
            .FirstOrDefaultAsync();

        var query =
            from item in ctx.InventoryItem.AsNoTracking()
            where item.LocationID == locationId
            join asset in ctx.Asset.AsNoTracking() on item.InventoryID equals asset.InventoryID into assetJoin
            from asset in assetJoin.DefaultIfEmpty()
            join cat in ctx.Category.AsNoTracking() on item.CatID equals cat.CatID into catJoin
            from cat in catJoin.DefaultIfEmpty()
            join typ in ctx.AssetType.AsNoTracking() on item.TypeID equals typ.TypeID into typJoin
            from typ in typJoin.DefaultIfEmpty()
            join cal in ctx.Calibration.AsNoTracking() on item.InventoryID equals cal.InventoryID into calJoin
            from cal in calJoin.DefaultIfEmpty()
            join cr in ctx.CompanyRoles.AsNoTracking().Where(cr => cr.RoleID == mfrRoleId)
                on item.CompanyID equals cr.CompanyID into crJoin
            from cr in crJoin.DefaultIfEmpty()
            join co in ctx.Companies.AsNoTracking() on cr.CompanyID equals co.CompanyID into coJoin
            from co in coJoin.DefaultIfEmpty()
            select new CalibrationItemRow
            {
                InventoryID = item.InventoryID ?? 0,
                AssetTag = asset != null ? asset.AssetTag : null,
                PartNumber = item.PartNumber,
                SerialNumber = item.SerialNumber,
                Description = item.Description,
                ManufacturerName = co != null ? co.CompanyName : null,
                CategoryName = cat != null ? cat.CatName : null,
                TypeName = typ != null ? typ.Type : null,
                LastCalDate = cal != null ? cal.LastCalDate : null,
                CalDueDate = cal != null ? cal.CalDueDate : null,
            };

        var rows = await query.ToListAsync();

        // Compute eligibility client-side
        foreach (var row in rows)
        {
            row.IsCalibrationEligible =
                string.Equals(row.CategoryName, EligibleCategory, StringComparison.OrdinalIgnoreCase)
                || (row.TypeName is not null && EligibleTypes.Contains(row.TypeName))
                || row.LastCalDate is not null;
        }

        return rows;
    }

    public async Task<List<Locations>> GetLocationsAsync()
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        return await ctx.Locations.AsNoTracking()
            .OrderBy(l => l.LocationName)
            .ToListAsync();
    }

    public async Task<List<Companies>> GetServiceProvidersAsync()
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();

        var svcRoleId = await ctx.Roles
            .Where(r => r.RoleName == "Service Provider")
            .Select(r => r.RoleID)
            .FirstOrDefaultAsync();

        if (svcRoleId is null or 0)
            return [];

        var companyIds = await ctx.CompanyRoles.AsNoTracking()
            .Where(cr => cr.RoleID == svcRoleId)
            .Select(cr => cr.CompanyID)
            .Distinct()
            .ToListAsync();

        return await ctx.Companies.AsNoTracking()
            .Where(c => companyIds.Contains(c.CompanyID))
            .OrderBy(c => c.CompanyName)
            .ToListAsync();
    }

    public async Task SaveScheduleAsync(
        IReadOnlyList<CalibrationItemRow> items,
        DateTime scheduledDate,
        Companies serviceProvider,
        Locations location,
        string modifiedBy)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        var now = DateTime.Now;

        // Resolve the service provider CompanyID
        int? svcId = await ctx.Companies.AsNoTracking()
            .Where(c => c.CompanyName == serviceProvider.CompanyName)
            .Select(c => (int?)c.CompanyID)
            .FirstOrDefaultAsync();

        foreach (var item in items)
        {
            // CalDueDate = LastCalDate + 2 years if available, otherwise today's date
            var dueDate = item.LastCalDate.HasValue
                ? item.LastCalDate.Value.AddYears(2)
                : DateTime.Today;

            // Insert a CalibrationSchedule row
            ctx.CalibrationSchedule.Add(new CalibrationSchedule
            {
                InventoryID = item.InventoryID,
                LastCalDate = item.LastCalDate,
                ScheduledDate = scheduledDate,
                ServiceProviderName = serviceProvider.CompanyName,
                ClliCode = location.ClliCode,
                LocationName = location.LocationName,
                DateModified = now,
                ModifiedBy = modifiedBy,
            });

            // Update the Calibration table with the scheduled date and due date
            var cal = await ctx.Calibration
                .FirstOrDefaultAsync(c => c.InventoryID == item.InventoryID);

            if (cal is not null)
            {
                cal.CalDateSched = scheduledDate;
                cal.CalDueDate = dueDate;
                cal.SvcID = svcId;
                cal.DateModified = now;
                cal.ModifiedBy = modifiedBy;
            }
            else
            {
                ctx.Calibration.Add(new Calibration
                {
                    InventoryID = item.InventoryID,
                    LastCalDate = item.LastCalDate,
                    CalDateSched = scheduledDate,
                    CalDueDate = dueDate,
                    SvcID = svcId,
                    DateModified = now,
                    ModifiedBy = modifiedBy,
                });
            }
        }

        await ctx.SaveChangesAsync();
    }

    public async Task<List<CalibrationSchedule>> GetPendingSchedulesAsync()
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();

        var mfrRoleId = await ctx.Roles
            .Where(r => r.RoleName == "Manufacturer")
            .Select(r => r.RoleID)
            .FirstOrDefaultAsync();

        var query =
            from s in ctx.CalibrationSchedule.AsNoTracking()
            join item in ctx.InventoryItem.AsNoTracking() on s.InventoryID equals item.InventoryID into itemJoin
            from item in itemJoin.DefaultIfEmpty()
            join asset in ctx.Asset.AsNoTracking() on item.InventoryID equals asset.InventoryID into assetJoin
            from asset in assetJoin.DefaultIfEmpty()
            join cr in ctx.CompanyRoles.AsNoTracking().Where(cr => cr.RoleID == mfrRoleId)
                on item.CompanyID equals cr.CompanyID into crJoin
            from cr in crJoin.DefaultIfEmpty()
            join co in ctx.Companies.AsNoTracking() on cr.CompanyID equals co.CompanyID into coJoin
            from co in coJoin.DefaultIfEmpty()
            orderby s.ClliCode, s.ScheduledDate
            select new
            {
                Schedule = s,
                AssetTag = asset != null ? asset.AssetTag : null,
                PartNumber = item != null ? item.PartNumber : null,
                SerialNumber = item != null ? item.SerialNumber : null,
                Description = item != null ? item.Description : null,
                ManufacturerName = co != null ? co.CompanyName : null,
            };

        var results = await query.ToListAsync();

        foreach (var r in results)
        {
            r.Schedule.AssetTag = r.AssetTag;
            r.Schedule.PartNumber = r.PartNumber;
            r.Schedule.SerialNumber = r.SerialNumber;
            r.Schedule.Description = r.Description;
            r.Schedule.ManufacturerName = r.ManufacturerName;
        }

        return results.Select(r => r.Schedule).ToList();
    }

    public async Task<List<ScheduledLocationGroup>> GetScheduledLocationsAsync()
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();

        return await ctx.CalibrationSchedule.AsNoTracking()
            .GroupBy(s => new { s.ClliCode, s.LocationName })
            .Select(g => new ScheduledLocationGroup
            {
                ClliCode = g.Key.ClliCode ?? string.Empty,
                LocationName = g.Key.LocationName ?? string.Empty,
                ItemCount = g.Count(),
                ScheduledDate = g.Min(s => s.ScheduledDate),
                ServiceProviderName = g.Select(s => s.ServiceProviderName).FirstOrDefault(),
            })
            .OrderBy(g => g.ClliCode)
            .ToListAsync();
    }

    public async Task<List<CalibrationSchedule>> GetSchedulesByLocationAsync(string clliCode)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();

        var mfrRoleId = await ctx.Roles
            .Where(r => r.RoleName == "Manufacturer")
            .Select(r => r.RoleID)
            .FirstOrDefaultAsync();

        var query =
            from s in ctx.CalibrationSchedule.AsNoTracking()
            where s.ClliCode == clliCode
            join item in ctx.InventoryItem.AsNoTracking() on s.InventoryID equals item.InventoryID into itemJoin
            from item in itemJoin.DefaultIfEmpty()
            join asset in ctx.Asset.AsNoTracking() on item.InventoryID equals asset.InventoryID into assetJoin
            from asset in assetJoin.DefaultIfEmpty()
            join cr in ctx.CompanyRoles.AsNoTracking().Where(cr => cr.RoleID == mfrRoleId)
                on item.CompanyID equals cr.CompanyID into crJoin
            from cr in crJoin.DefaultIfEmpty()
            join co in ctx.Companies.AsNoTracking() on cr.CompanyID equals co.CompanyID into coJoin
            from co in coJoin.DefaultIfEmpty()
            orderby item.PartNumber
            select new
            {
                Schedule = s,
                AssetTag = asset != null ? asset.AssetTag : null,
                PartNumber = item != null ? item.PartNumber : null,
                SerialNumber = item != null ? item.SerialNumber : null,
                Description = item != null ? item.Description : null,
                ManufacturerName = co != null ? co.CompanyName : null,
            };

        var results = await query.ToListAsync();

        foreach (var r in results)
        {
            r.Schedule.AssetTag = r.AssetTag;
            r.Schedule.PartNumber = r.PartNumber;
            r.Schedule.SerialNumber = r.SerialNumber;
            r.Schedule.Description = r.Description;
            r.Schedule.ManufacturerName = r.ManufacturerName;
        }

        return results.Select(r => r.Schedule).ToList();
    }

    public async Task CompleteCalibrationAsync(
        DateTime completionDate,
        IReadOnlyList<CalibrationSchedule> selectedItems,
        string modifiedBy)
    {
        if (selectedItems.Count == 0)
            return;

        await using var ctx = await _contextFactory.CreateDbContextAsync();
        var now = DateTime.Now;

        // Collect the CSID values to load tracked entities for removal
        var selectedCsids = selectedItems
            .Where(i => i.CSID is not null)
            .Select(i => i.CSID!.Value)
            .ToHashSet();

        var schedules = await ctx.CalibrationSchedule
            .Where(s => s.CSID != null && selectedCsids.Contains(s.CSID.Value))
            .ToListAsync();

        if (schedules.Count == 0)
            return;

        // Build lookup from the UI items for CalNotes and CalLabel
        var uiLookup = selectedItems.ToDictionary(
            i => i.CSID ?? 0,
            i => (CalNotes: i.CalNotes, CalLabel: i.CalLabel));

        // Resolve the service provider CompanyID
        var svcName = schedules[0].ServiceProviderName;
        int? svcId = null;
        if (!string.IsNullOrWhiteSpace(svcName))
        {
            svcId = await ctx.Companies.AsNoTracking()
                .Where(c => c.CompanyName == svcName)
                .Select(c => (int?)c.CompanyID)
                .FirstOrDefaultAsync();
        }

        foreach (var sched in schedules)
        {
            var ui = uiLookup.GetValueOrDefault(sched.CSID ?? 0);

            // Find existing Calibration record by InventoryID
            var cal = await ctx.Calibration
                .FirstOrDefaultAsync(c => c.InventoryID == sched.InventoryID);

            if (cal is not null)
            {
                cal.CalDateCompl = completionDate;
                cal.LastCalDate = completionDate;
                cal.CalLabel = ui.CalLabel;
                cal.CalNotes = ui.CalNotes;
                cal.SvcID = svcId;
                cal.DateModified = now;
                cal.ModifiedBy = modifiedBy;
            }
            else
            {
                ctx.Calibration.Add(new Calibration
                {
                    InventoryID = sched.InventoryID,
                    CalDateCompl = completionDate,
                    LastCalDate = completionDate,
                    CalDateSched = sched.ScheduledDate,
                    CalLabel = ui.CalLabel,
                    CalNotes = ui.CalNotes,
                    SvcID = svcId,
                    DateModified = now,
                    ModifiedBy = modifiedBy,
                });
            }
        }

        // Remove only the completed schedule entries
        ctx.CalibrationSchedule.RemoveRange(schedules);
        await ctx.SaveChangesAsync();
    }

    public async Task<List<CalibrationLogRow>> GetCalibrationLogAsync()
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();

        // Get "Manufacturer" role ID
        var mfrRoleId = await ctx.Roles
            .Where(r => r.RoleName == "Manufacturer")
            .Select(r => r.RoleID)
            .FirstOrDefaultAsync();

        // Get "Service Provider" role ID
        var svcRoleId = await ctx.Roles
            .Where(r => r.RoleName == "Service Provider")
            .Select(r => r.RoleID)
            .FirstOrDefaultAsync();

        var query =
            from cal in ctx.Calibration.AsNoTracking()
            join item in ctx.InventoryItem.AsNoTracking() on cal.InventoryID equals item.InventoryID into itemJoin
            from item in itemJoin.DefaultIfEmpty()
            join asset in ctx.Asset.AsNoTracking() on item.InventoryID equals asset.InventoryID into assetJoin
            from asset in assetJoin.DefaultIfEmpty()
            join loc in ctx.Locations.AsNoTracking() on item.LocationID equals loc.LocationID into locJoin
            from loc in locJoin.DefaultIfEmpty()
            join cr in ctx.CompanyRoles.AsNoTracking().Where(cr => cr.RoleID == mfrRoleId)
                on item.CompanyID equals cr.CompanyID into crJoin
            from cr in crJoin.DefaultIfEmpty()
            join mfr in ctx.Companies.AsNoTracking() on cr.CompanyID equals mfr.CompanyID into mfrJoin
            from mfr in mfrJoin.DefaultIfEmpty()
            join scr in ctx.CompanyRoles.AsNoTracking().Where(scr => scr.RoleID == svcRoleId)
                on cal.SvcID equals scr.CompanyID into scrJoin
            from scr in scrJoin.DefaultIfEmpty()
            join svc in ctx.Companies.AsNoTracking() on scr.CompanyID equals svc.CompanyID into svcJoin
            from svc in svcJoin.DefaultIfEmpty()
            orderby loc.ClliCode, item.PartNumber
            select new CalibrationLogRow
            {
                CalInfoID = cal.CalInfoID,
                InventoryID = cal.InventoryID,
                SvcID = cal.SvcID,
                AssetTag = asset != null ? asset.AssetTag : null,
                PartNumber = item != null ? item.PartNumber : null,
                SerialNumber = item != null ? item.SerialNumber : null,
                Description = item != null ? item.Description : null,
                ManufacturerName = mfr != null ? mfr.CompanyName : null,
                ServiceProviderName = svc != null ? svc.CompanyName : null,
                ClliCode = loc != null ? loc.ClliCode : null,
                LocationName = loc != null ? loc.LocationName : null,
                LastCalDate = cal.LastCalDate,
                CalDueDate = cal.CalDueDate,
                CalDateSched = cal.CalDateSched,
                CalDateCompl = cal.CalDateCompl,
                CalLabel = cal.CalLabel,
                CalNotes = cal.CalNotes,
            };

        return await query.ToListAsync();
    }

    public async Task UpdateCalibrationLogEntriesAsync(IReadOnlyList<CalibrationLogRow> rows, string modifiedBy)
    {
        if (rows.Count == 0) return;

        await using var ctx = await _contextFactory.CreateDbContextAsync();

        var ids = rows.Where(r => r.CalInfoID.HasValue).Select(r => r.CalInfoID!.Value).ToList();
        var entities = await ctx.Calibration.Where(c => ids.Contains(c.CalInfoID!.Value)).ToListAsync();

        foreach (var entity in entities)
        {
            var row = rows.FirstOrDefault(r => r.CalInfoID == entity.CalInfoID);
            if (row is null) continue;

            entity.LastCalDate = row.LastCalDate;
            entity.CalDueDate = row.CalDueDate;
            entity.CalDateSched = row.CalDateSched;
            entity.CalDateCompl = row.CalDateCompl;
            entity.CalLabel = row.CalLabel;
            entity.CalNotes = row.CalNotes;
            entity.SvcID = row.SvcID;
            entity.DateModified = DateTime.Now;
            entity.ModifiedBy = modifiedBy;
        }

        await ctx.SaveChangesAsync();
    }

    public async Task<List<Companies>> GetCompaniesByIdsAsync(IReadOnlyList<int> companyIds)
    {
        if (companyIds.Count == 0) return [];

        await using var ctx = await _contextFactory.CreateDbContextAsync();
        return await ctx.Companies.AsNoTracking()
            .Where(c => companyIds.Contains(c.CompanyID))
            .OrderBy(c => c.CompanyName)
            .ToListAsync();
    }
}
