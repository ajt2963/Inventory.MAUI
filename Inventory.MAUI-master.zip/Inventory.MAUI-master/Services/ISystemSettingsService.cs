namespace Inventory.MAUI.Services;

/// <summary>
/// Reads and writes application-wide system settings from the database.
/// Values are cached in memory and refreshed on demand.
/// </summary>
public interface ISystemSettingsService
{
    /// <summary>Gets a setting value by key. Returns the default if not found.</summary>
    Task<string?> GetAsync(string key, string? defaultValue = null);

    /// <summary>Gets a setting value as an integer.</summary>
    Task<int> GetIntAsync(string key, int defaultValue);

    /// <summary>Gets a setting value as a boolean.</summary>
    Task<bool> GetBoolAsync(string key, bool defaultValue);

    /// <summary>Sets a setting value. Creates the key if it doesn't exist.</summary>
    Task SetAsync(string key, string? value, string? category = null, string? description = null);

    /// <summary>Gets all settings in a specific category.</summary>
    Task<Dictionary<string, string?>> GetByCategoryAsync(string category);

    /// <summary>Forces a reload of the in-memory cache from the database.</summary>
    Task RefreshCacheAsync();

    /// <summary>Ensures the SystemSettings table and default seed values exist.</summary>
    Task EnsureInitializedAsync();
}
