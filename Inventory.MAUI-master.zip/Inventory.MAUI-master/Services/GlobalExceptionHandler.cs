using System.Diagnostics;

namespace Inventory.MAUI.Services;

public static class GlobalExceptionHandler
{
    public static void Register()
    {
        AppDomain.CurrentDomain.UnhandledException += (_, e) =>
            Report(e.ExceptionObject as Exception, "AppDomain.CurrentDomain.UnhandledException");

        TaskScheduler.UnobservedTaskException += (_, e) =>
        {
            Report(e.Exception, "TaskScheduler.UnobservedTaskException");
            e.SetObserved();
        };

#if WINDOWS
        Microsoft.UI.Xaml.Application.Current.UnhandledException += (_, e) =>
        {
            Report(e.Exception, "Microsoft.UI.Xaml.Application.UnhandledException");
            e.Handled = true;
        };
#endif
    }

    private static void Report(Exception? ex, string source)
    {
        try
        {
            var message = ex is null ? "<null exception>" : ex.ToString();
            Debug.WriteLine($"[{source}] {message}");
        }
        catch
        {
            // never throw from a global handler
        }
    }
}
