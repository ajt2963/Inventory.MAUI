namespace Inventory.MAUI.Services;

/// <summary>
/// Provides typed, null-safe access to registered DI services.
/// Replaces the scattered <c>Application.Current?.Handler?.MauiContext?.Services?.GetService()</c>
/// service-locator pattern that was duplicated across code-behind files.
///
/// This is intentionally a static accessor � MAUI pages created via XAML navigation
/// (AppShell) cannot receive constructor-injected dependencies, so a controlled
/// service-locator is the accepted MAUI pattern for code-behind files.
/// ViewModels should still use constructor injection.
/// </summary>
public static class AppServices
{
    /// <summary>
    /// Gets the app-level <see cref="IServiceProvider"/>, or null if not yet available.
    /// </summary>
    public static IServiceProvider? Current =>
        Application.Current?.Handler?.MauiContext?.Services;

    /// <summary>
    /// Resolves a service of type <typeparamref name="T"/>, or null if unavailable.
    /// </summary>
    public static T? Get<T>() where T : class =>
        Current?.GetService(typeof(T)) as T;

    /// <summary>
    /// Resolves a required service of type <typeparamref name="T"/>.
    /// Throws <see cref="InvalidOperationException"/> if the service provider
    /// is unavailable or the service is not registered.
    /// </summary>
    /// <exception cref="InvalidOperationException"/>
    public static T GetRequired<T>() where T : class =>
        Get<T>() ?? throw new InvalidOperationException(
            $"Service '{typeof(T).Name}' is not available. Ensure the service provider is initialized and the service is registered.");
}
