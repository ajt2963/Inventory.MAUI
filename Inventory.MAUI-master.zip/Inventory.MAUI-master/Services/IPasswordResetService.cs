namespace Inventory.MAUI.Services;

/// <summary>
/// Manages the password recovery flow: generate OTP, send via email, verify, and reset.
/// </summary>
public interface IPasswordResetService
{
    /// <summary>
    /// Initiates password recovery for the given ATTUID.
    /// Generates a 6-digit OTP, stores it, and emails it to the user.
    /// Returns true if the code was sent successfully.
    /// Returns false if the user doesn't exist, has no email, or email delivery failed.
    /// </summary>
    Task<bool> RequestResetAsync(string attuid);

    /// <summary>
    /// Verifies the OTP code for the given ATTUID.
    /// Returns true if the code is valid and has not expired.
    /// </summary>
    Task<bool> VerifyCodeAsync(string attuid, string code);

    /// <summary>
    /// Completes the password reset: verifies the code and sets the new password.
    /// Returns null on success, or an error message on failure.
    /// </summary>
    Task<string?> ResetPasswordAsync(string attuid, string code, string newPassword);

    /// <summary>
    /// True if the email service is configured and password recovery is available.
    /// </summary>
    bool IsAvailable { get; }
}
