#if WINDOWS
using System.Security.Principal;
#endif

namespace Inventory.MAUI.Services;

/// <summary>
/// Windows implementation: reads the current Windows login identity.
/// On non-Windows platforms, falls back to Environment.UserName.
/// </summary>
public sealed class WindowsIdentityService : IIdentityService
{
    public bool IsAutoIdentity => true;

    public string? GetCurrentUserName()
    {
#if WINDOWS
        try
        {
            return WindowsIdentity.GetCurrent().Name;
        }
        catch
        {
            return Environment.UserName;
        }
#else
        return Environment.UserName;
#endif
    }

    public string? GetCurrentShortName()
    {
        var full = GetCurrentUserName();
        if (string.IsNullOrEmpty(full))
            return null;

        // Handle DOMAIN\user format
        var backslash = full.IndexOf('\\');
        if (backslash >= 0)
            return full[(backslash + 1)..];

        // Handle user@domain format
        var at = full.IndexOf('@');
        if (at >= 0)
            return full[..at];

        return full;
    }

    public string? GetCurrentDomain()
    {
        var full = GetCurrentUserName();
        if (string.IsNullOrEmpty(full))
            return null;

        var backslash = full.IndexOf('\\');
        if (backslash >= 0)
            return full[..backslash];

        var at = full.IndexOf('@');
        if (at >= 0)
            return full[(at + 1)..];

        return Environment.UserDomainName;
    }
}
