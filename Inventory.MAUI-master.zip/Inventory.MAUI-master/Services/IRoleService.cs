using Inventory.MAUI.Models;

namespace Inventory.MAUI.Services;

public interface IRoleService
{
    Task<List<Roles>> GetAllRolesAsync();
}
