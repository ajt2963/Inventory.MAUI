using Inventory.MAUI.Models;

namespace Inventory.MAUI.Services;

public interface IProjectService
{
    Task<IEnumerable<Projects>> GetAllProjectsAsync();
    Task<Projects?> GetProjectByIdAsync(int id);
    Task AddAsync(Projects project);
    Task UpdateProjectAsync(Projects project);
    Task DeleteProjectAsync(int id);
    Task<IEnumerable<Projects>> GetProjectsAsync();
}
