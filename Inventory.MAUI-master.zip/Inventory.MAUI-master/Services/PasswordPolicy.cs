using System.Text.RegularExpressions;

namespace Inventory.MAUI.Services;

/// <summary>
/// Centralized password policy enforcement.
/// Reads configuration from ISystemSettingsService for admin-configurable rules.
/// Falls back to hardcoded defaults if settings are unavailable.
/// </summary>
public sealed class PasswordPolicy
{
    private readonly ISystemSettingsService _settings;

    // Defaults used if settings haven't been loaded or DB is unavailable
    public const int DefaultMinLength = 8;
    public const int DefaultMaxLength = 128;
    public const int DefaultHistoryCount = 5;
    public const int DefaultExpiryDays = 90;

    private static readonly Regex UpperCase = new("[A-Z]", RegexOptions.Compiled);
    private static readonly Regex LowerCase = new("[a-z]", RegexOptions.Compiled);
    private static readonly Regex Digit = new("[0-9]", RegexOptions.Compiled);
    private static readonly Regex SpecialChar = new(@"[!@#$%^&*()_+\-=\[\]{};':""\\|,.<>\/?`~]", RegexOptions.Compiled);

    public PasswordPolicy(ISystemSettingsService settings)
    {
        _settings = settings;
    }

    public async Task<int> GetMinLengthAsync() =>
        await _settings.GetIntAsync(Models.SettingKeys.PasswordMinLength, DefaultMinLength);

    public async Task<int> GetMaxLengthAsync() =>
        await _settings.GetIntAsync(Models.SettingKeys.PasswordMaxLength, DefaultMaxLength);

    public async Task<int> GetHistoryCountAsync() =>
        await _settings.GetIntAsync(Models.SettingKeys.PasswordHistoryCount, DefaultHistoryCount);

    public async Task<int> GetExpiryDaysAsync() =>
        await _settings.GetIntAsync(Models.SettingKeys.PasswordExpiryDays, DefaultExpiryDays);

    public async Task<bool> GetRequireUpperAsync() =>
        await _settings.GetBoolAsync(Models.SettingKeys.PasswordRequireUpper, true);

    public async Task<bool> GetRequireLowerAsync() =>
        await _settings.GetBoolAsync(Models.SettingKeys.PasswordRequireLower, true);

    public async Task<bool> GetRequireDigitAsync() =>
        await _settings.GetBoolAsync(Models.SettingKeys.PasswordRequireDigit, true);

    public async Task<bool> GetRequireSpecialAsync() =>
        await _settings.GetBoolAsync(Models.SettingKeys.PasswordRequireSpecial, true);

    /// <summary>
    /// Validates a password against all configurable complexity rules.
    /// Returns null if valid, or a user-friendly error message if invalid.
    /// </summary>
    public async Task<string?> ValidateAsync(string password)
    {
        if (string.IsNullOrWhiteSpace(password))
            return "Password cannot be empty.";

        var minLen = await GetMinLengthAsync();
        var maxLen = await GetMaxLengthAsync();

        if (password.Length < minLen)
            return $"Password must be at least {minLen} characters.";

        if (password.Length > maxLen)
            return $"Password cannot exceed {maxLen} characters.";

        if (await GetRequireUpperAsync() && !UpperCase.IsMatch(password))
            return "Password must contain at least one uppercase letter (A-Z).";

        if (await GetRequireLowerAsync() && !LowerCase.IsMatch(password))
            return "Password must contain at least one lowercase letter (a-z).";

        if (await GetRequireDigitAsync() && !Digit.IsMatch(password))
            return "Password must contain at least one digit (0-9).";

        if (await GetRequireSpecialAsync() && !SpecialChar.IsMatch(password))
            return "Password must contain at least one special character (!@#$%^&* etc.).";

        return null; // Valid
    }

    /// <summary>
    /// Builds a dynamic requirements text based on current settings.
    /// </summary>
    public async Task<string> GetRequirementsTextAsync()
    {
        var minLen = await GetMinLengthAsync();
        var maxLen = await GetMaxLengthAsync();
        var lines = new List<string>
        {
            "Password requirements:",
            $"  {minLen}-{maxLen} characters"
        };

        if (await GetRequireUpperAsync())
            lines.Add("  At least one uppercase letter (A-Z)");
        if (await GetRequireLowerAsync())
            lines.Add("  At least one lowercase letter (a-z)");
        if (await GetRequireDigitAsync())
            lines.Add("  At least one digit (0-9)");
        if (await GetRequireSpecialAsync())
            lines.Add("  At least one special character (!@#$%^&* etc.)");

        return string.Join("\n", lines);
    }
}
