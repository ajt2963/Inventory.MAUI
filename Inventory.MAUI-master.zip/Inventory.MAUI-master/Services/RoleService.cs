using Inventory.MAUI.Data;
using Inventory.MAUI.Models;
using Microsoft.EntityFrameworkCore;

namespace Inventory.MAUI.Services;

public sealed class RoleService : IRoleService
{
    private readonly IDbContextFactory<InventoryDbContext> _contextFactory;

    public RoleService(IDbContextFactory<InventoryDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<List<Roles>> GetAllRolesAsync()
    {
        await using var context = await _contextFactory.CreateDbContextAsync();
        return await context.Roles.ToListAsync();
    }
}
