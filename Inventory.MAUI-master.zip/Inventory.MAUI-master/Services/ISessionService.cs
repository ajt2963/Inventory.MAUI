using Inventory.MAUI.Models;

namespace Inventory.MAUI.Services;

/// <summary>
/// Manages persistent user session records in the database.
/// </summary>
public interface ISessionService
{
    /// <summary>Creates a new session record when a user signs in. Returns the session token.</summary>
    Task<string> StartSessionAsync(int userId, string attuid);

    /// <summary>Updates the last-activity timestamp for the current session.</summary>
    Task TouchSessionAsync(string sessionToken);

    /// <summary>Ends a session (logout, expiry, admin termination).</summary>
    Task EndSessionAsync(string sessionToken, string endReason);

    /// <summary>Gets all active (non-ended) sessions, optionally filtered by user.</summary>
    Task<List<UserSession>> GetActiveSessionsAsync(int? userId = null);

    /// <summary>Gets recent sessions (active and ended) for admin review.</summary>
    Task<List<UserSession>> GetRecentSessionsAsync(int count = 50);

    /// <summary>Terminates all active sessions for a specific user (admin action).</summary>
    Task TerminateUserSessionsAsync(int userId, string reason = "AdminTerminated");
}
