using Inventory.MAUI.Models;

namespace Inventory.MAUI.Services;

public interface IInventoryListService
{
    Task<List<InventoryList>> GetInventoryListAsync(string? searchText = null, int? take = null);

    Task<IReadOnlyList<InventoryList>> GetInventoryListPageAsync(string? searchText = null, int skip = 0, int take = 200);

    Task<int> GetInventoryListCountAsync(string? searchText = null);

    Task<InventoryList?> GetByIdAsync(int inventoryId);

    Task<InventoryList?> GetLastAsync(string? searchText = null);

    Task<IReadOnlyList<InventoryList>> GetLastPageAsync(string? searchText = null, int take = 250);

    // Dashboard aggregate queries � executed as SQL GROUP BY, no full-table load.
    Task<List<(string Name, int Count)>> GetCountByStatusAsync();
    Task<List<(string Name, int Count)>> GetCountByLocationAsync();
    Task<List<(string Location, string Name, int Count)>> GetCountByFieldPerLocationAsync(string fieldName);

    Task<IReadOnlyList<InventoryList>> GetByLocationAsync(string clliCode);
}
