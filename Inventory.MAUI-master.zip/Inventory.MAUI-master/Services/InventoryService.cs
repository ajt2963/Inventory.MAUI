using Inventory.MAUI.Data;
using Microsoft.EntityFrameworkCore;

namespace Inventory.MAUI.Services;

public sealed class InventoryService : IInventoryService
{
    private readonly IDbContextFactory<InventoryDbContext> _contextFactory;

    public InventoryService(IDbContextFactory<InventoryDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public IEnumerable<string> GetValidStatusCodes()
    {
        return ["Available", "CheckedOut", "Maintenance", "Disposed"]; 
    }

    public async Task<IEnumerable<string>> GetAllLocationNamesAsync()
    {
        await using var context = await _contextFactory.CreateDbContextAsync();
        return (await context.Locations
                .Select(l => l.LocationName)
                .Where(name => !string.IsNullOrEmpty(name))
                .Distinct()
                .ToListAsync())
            .Cast<string>();
    }
}
