using Inventory.MAUI.Models;

namespace Inventory.MAUI.Services;

/// <summary>
/// Writes immutable audit log entries for security and compliance.
/// All methods are fire-and-forget safe � audit failures must never
/// block or crash the primary operation.
/// </summary>
public interface IAuditService
{
    /// <summary>
    /// Logs an audit event.
    /// </summary>
    /// <param name="eventType">One of <see cref="AuditEventTypes"/> constants.</param>
    /// <param name="userId">The acting user's ID, or null for anonymous/system events.</param>
    /// <param name="attuid">The acting user's ATTUID (denormalized for historical accuracy).</param>
    /// <param name="entityType">The type of entity affected (e.g., "AppUser"), or null.</param>
    /// <param name="entityId">The primary key of the affected entity, or null.</param>
    /// <param name="details">Human-readable description or additional context.</param>
    Task LogAsync(
        string eventType,
        int? userId = null,
        string? attuid = null,
        string? entityType = null,
        string? entityId = null,
        string? details = null);

    /// <summary>
    /// Retrieves recent audit log entries, newest first.
    /// </summary>
    /// <param name="count">Maximum number of entries to return.</param>
    Task<List<AuditLog>> GetRecentAsync(int count = 100);

    /// <summary>
    /// Retrieves audit log entries for a specific user, newest first.
    /// </summary>
    Task<List<AuditLog>> GetByUserAsync(int userId, int count = 100);

    /// <summary>
    /// Retrieves audit log entries filtered by event type, newest first.
    /// </summary>
    Task<List<AuditLog>> GetByEventTypeAsync(string eventType, int count = 100);

    /// <summary>
    /// Retrieves audit log entries with flexible filtering for the admin Audit Log view.
    /// All parameters are optional � combine as needed.
    /// </summary>
    /// <param name="fromUtc">Start of date range (inclusive).</param>
    /// <param name="toUtc">End of date range (inclusive).</param>
    /// <param name="userId">Filter to a specific user.</param>
    /// <param name="eventType">Filter to a specific event type.</param>
    /// <param name="maxResults">Maximum results to return.</param>
    Task<List<AuditLog>> GetFilteredAsync(
        DateTime? fromUtc = null,
        DateTime? toUtc = null,
        int? userId = null,
        string? eventType = null,
        int maxResults = 500);
}
