namespace Inventory.MAUI.Services;

/// <summary>
/// Android implementation: no automatic identity detection.
/// The user must sign in manually via the login prompt.
/// </summary>
public sealed class AndroidIdentityService : IIdentityService
{
    public bool IsAutoIdentity => false;

    public string? GetCurrentUserName() => null;

    public string? GetCurrentShortName() => null;

    public string? GetCurrentDomain() => null;
}
