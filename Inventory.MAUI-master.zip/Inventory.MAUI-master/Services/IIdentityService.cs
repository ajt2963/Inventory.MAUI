namespace Inventory.MAUI.Services;

/// <summary>
/// Abstracts the platform identity provider.
/// On Windows: reads WindowsIdentity (automatic, no login required).
/// On Android: future login/token-based implementation.
/// </summary>
public interface IIdentityService
{
    /// <summary>
    /// Gets the current user's login name (e.g., "DOMAIN\at2963" on Windows).
    /// Returns null if the identity cannot be determined.
    /// </summary>
    string? GetCurrentUserName();

    /// <summary>
    /// Gets just the short username without the domain prefix (e.g., "at2963").
    /// </summary>
    string? GetCurrentShortName();

    /// <summary>
    /// Gets the domain (e.g., "DOMAIN"), or null if not available.
    /// </summary>
    string? GetCurrentDomain();

    /// <summary>
    /// True if the platform can automatically detect the user (e.g., Windows auth).
    /// False if a manual login is required (e.g., Android).
    /// </summary>
    bool IsAutoIdentity { get; }
}
