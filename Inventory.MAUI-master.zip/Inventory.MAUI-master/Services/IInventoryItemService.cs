using Inventory.MAUI.Models;

namespace Inventory.MAUI.Services;

public interface IInventoryItemService
{
    Task<InventoryItem?> GetByIdAsync(int inventoryId);

    Task UpdateAsync(InventoryItem item, string? modifiedBy, string? notesText);

    Task SoftDeleteAsync(int inventoryId, string? deletedBy);

    Task<int> CreateAsync(
        Models.InventoryItem item,
        string modifiedBy,
        string? userNotes,
        CancellationToken cancellationToken = default);

    Task<(IReadOnlyList<Models.AssetOwner> Owners,
        IReadOnlyList<Models.AssetType> Types,
        IReadOnlyList<Models.Category> Categories,
        IReadOnlyList<Models.Companies> Companies,
        IReadOnlyList<Models.Locations> Locations,
        IReadOnlyList<Models.InventoryStorage> Storages)> GetLookupsAsync();

    Task<(IReadOnlyList<Models.Asset> Assets,
        IReadOnlyList<Models.AssetOwner> Owners,
        IReadOnlyList<Models.AssetType> Types,
        IReadOnlyList<Models.Category> Categories,
        IReadOnlyList<Models.Companies> Companies,
        IReadOnlyList<Models.Locations> Locations,
        IReadOnlyList<Models.InventoryStorage> Storages)> GetCreateLookupsAsync();
}