using System.Security.Cryptography;
using Inventory.MAUI.Data;
using Inventory.MAUI.Models;
using Microsoft.EntityFrameworkCore;

namespace Inventory.MAUI.Services;

/// <summary>
/// Implements the email-OTP password recovery flow.
/// </summary>
public sealed class PasswordResetService : IPasswordResetService
{
    private readonly IDbContextFactory<InventoryDbContext> _contextFactory;
    private readonly IEmailService _emailService;
    private readonly IAppUserService _userService;
    private readonly IAuditService _audit;
    private readonly PasswordPolicy _passwordPolicy;

    /// <summary>OTP codes expire after this duration.</summary>
    private static readonly TimeSpan TokenLifetime = TimeSpan.FromMinutes(15);

    public PasswordResetService(
        IDbContextFactory<InventoryDbContext> contextFactory,
        IEmailService emailService,
        IAppUserService userService,
        IAuditService audit,
        PasswordPolicy passwordPolicy)
    {
        _contextFactory = contextFactory;
        _emailService = emailService;
        _userService = userService;
        _audit = audit;
        _passwordPolicy = passwordPolicy;
    }

    public bool IsAvailable => _emailService.IsConfigured;

    public async Task<bool> RequestResetAsync(string attuid)
    {
        if (string.IsNullOrWhiteSpace(attuid))
            return false;

        var user = await _userService.GetByAttuidAsync(attuid.Trim());
        if (user is null || !user.IsActive || string.IsNullOrWhiteSpace(user.Email))
        {
            // Don't reveal whether the user exists � log internally but return false silently
            await _audit.LogAsync(
                AuditEventTypes.PasswordReset,
                attuid: attuid.Trim(),
                details: user is null
                    ? "Password reset requested for unknown ATTUID"
                    : string.IsNullOrWhiteSpace(user.Email)
                        ? "Password reset requested but user has no email"
                        : "Password reset requested for inactive user");
            return false;
        }

        // Rate limiting � prevent OTP flooding (max 3 requests per user per 15 minutes)
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        var recentWindow = DateTime.UtcNow.Add(-TokenLifetime);
        var recentCount = await ctx.PasswordResetToken
            .CountAsync(t => t.UserID == user.UserID && t.CreatedAtUtc >= recentWindow);

        if (recentCount >= 3)
        {
            await _audit.LogAsync(
                AuditEventTypes.PasswordReset,
                userId: user.UserID,
                attuid: user.ATTUID,
                details: $"Password reset rate limit exceeded ({recentCount} requests in {TokenLifetime.TotalMinutes}m)");
            return false; // Silently reject � don't reveal rate limiting to potential attacker
        }

        // Generate a 6-digit code
        var code = GenerateCode();

        // Invalidate any existing unused tokens for this user
        var existing = await ctx.PasswordResetToken
            .Where(t => t.UserID == user.UserID && t.UsedAtUtc == null)
            .ToListAsync();
        foreach (var t in existing)
            t.UsedAtUtc = DateTime.UtcNow; // Mark as consumed

        // Create new token
        ctx.PasswordResetToken.Add(new PasswordResetToken
        {
            UserID = user.UserID,
            Token = code,
            CreatedAtUtc = DateTime.UtcNow,
            ExpiresAtUtc = DateTime.UtcNow.Add(TokenLifetime)
        });
        await ctx.SaveChangesAsync();

        // Send the code via email
        var sent = await _emailService.SendAsync(
            user.Email,
            "UCOM Inventory � Password Reset Code",
            $"""
            <div style="font-family: Arial, sans-serif; max-width: 480px;">
                <h2 style="color: #0B2239;">Password Reset</h2>
                <p>Hello {user.DisplayName},</p>
                <p>Your password reset code is:</p>
                <div style="font-size: 32px; font-weight: bold; letter-spacing: 8px; 
                            background: #F0F4F8; padding: 16px; text-align: center; 
                            border-radius: 8px; margin: 16px 0;">
                    {code}
                </div>
                <p>This code expires in <strong>{TokenLifetime.TotalMinutes:0} minutes</strong>.</p>
                <p style="color: #888; font-size: 12px;">
                    If you did not request this reset, please ignore this email or contact your administrator.
                </p>
            </div>
            """);

        await _audit.LogAsync(
            AuditEventTypes.PasswordReset,
            userId: user.UserID,
            attuid: user.ATTUID,
            details: sent
                ? $"Password reset code sent to {MaskEmail(user.Email)}"
                : $"Password reset code generated but email delivery failed");

        return sent;
    }

    public async Task<bool> VerifyCodeAsync(string attuid, string code)
    {
        if (string.IsNullOrWhiteSpace(attuid) || string.IsNullOrWhiteSpace(code))
            return false;

        var user = await _userService.GetByAttuidAsync(attuid.Trim());
        if (user is null)
            return false;

        await using var ctx = await _contextFactory.CreateDbContextAsync();
        var token = await ctx.PasswordResetToken
            .Where(t => t.UserID == user.UserID
                     && t.Token == code.Trim()
                     && t.UsedAtUtc == null
                     && t.ExpiresAtUtc > DateTime.UtcNow)
            .FirstOrDefaultAsync();

        return token is not null;
    }

    public async Task<string?> ResetPasswordAsync(string attuid, string code, string newPassword)
    {
        if (string.IsNullOrWhiteSpace(attuid) || string.IsNullOrWhiteSpace(code))
            return "Invalid request.";

        // Validate new password against policy
        var policyError = await _passwordPolicy.ValidateAsync(newPassword);
        if (policyError is not null)
            return policyError;

        var user = await _userService.GetByAttuidAsync(attuid.Trim());
        if (user is null || !user.IsActive)
            return "Invalid request.";

        await using var ctx = await _contextFactory.CreateDbContextAsync();
        var token = await ctx.PasswordResetToken
            .Where(t => t.UserID == user.UserID
                     && t.Token == code.Trim()
                     && t.UsedAtUtc == null
                     && t.ExpiresAtUtc > DateTime.UtcNow)
            .FirstOrDefaultAsync();

        if (token is null)
            return "Invalid or expired code. Please request a new one.";

        // Mark token as used
        token.UsedAtUtc = DateTime.UtcNow;
        await ctx.SaveChangesAsync();

        // Set the new password (this also handles history, expiry, and audit logging)
        try
        {
            await _userService.SetPasswordAsync(user.UserID, newPassword);
        }
        catch (ArgumentException ex)
        {
            return ex.Message;
        }

        await _audit.LogAsync(
            AuditEventTypes.PasswordReset,
            userId: user.UserID,
            attuid: user.ATTUID,
            entityType: nameof(AppUser),
            entityId: user.UserID.ToString(),
            details: "Password reset via email OTP recovery");

        return null; // Success
    }

    /// <summary>Generates a cryptographically random 6-digit code.</summary>
    private static string GenerateCode()
    {
        return RandomNumberGenerator.GetInt32(100_000, 1_000_000).ToString("D6");
    }

    /// <summary>Masks an email address for logging (e.g., "j***@example.com").</summary>
    private static string MaskEmail(string email)
    {
        var at = email.IndexOf('@');
        if (at <= 1) return "***@***";
        return $"{email[0]}***{email[at..]}";
    }
}
