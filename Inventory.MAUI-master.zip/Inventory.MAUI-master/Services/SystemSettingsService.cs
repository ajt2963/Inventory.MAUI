using Inventory.MAUI.Data;
using Inventory.MAUI.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Concurrent;

namespace Inventory.MAUI.Services;

/// <summary>
/// DB-backed system settings with an in-memory cache.
/// Thread-safe for concurrent reads. Writes go straight to DB and update the cache.
/// </summary>
public sealed class SystemSettingsService : ISystemSettingsService
{
    private readonly IDbContextFactory<InventoryDbContext> _contextFactory;
    private readonly ConcurrentDictionary<string, string?> _cache = new(StringComparer.OrdinalIgnoreCase);
    private bool _initialized;

    public SystemSettingsService(IDbContextFactory<InventoryDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<string?> GetAsync(string key, string? defaultValue = null)
    {
        await EnsureCacheLoadedAsync();
        if (!_cache.TryGetValue(key, out var value))
            return defaultValue;

        // Decrypt sensitive values on read
        if (value is not null && SettingsEncryption.IsSensitive(key))
            return SettingsEncryption.Decrypt(value);

        return value;
    }

    public async Task<int> GetIntAsync(string key, int defaultValue)
    {
        var raw = await GetAsync(key);
        return int.TryParse(raw, out var v) ? v : defaultValue;
    }

    public async Task<bool> GetBoolAsync(string key, bool defaultValue)
    {
        var raw = await GetAsync(key);
        return bool.TryParse(raw, out var v) ? v : defaultValue;
    }

    public async Task SetAsync(string key, string? value, string? category = null, string? description = null)
    {
        // Encrypt sensitive values before storing
        var storedValue = value;
        if (!string.IsNullOrEmpty(value) && SettingsEncryption.IsSensitive(key))
            storedValue = SettingsEncryption.Encrypt(value);

        await using var ctx = await _contextFactory.CreateDbContextAsync();

        var existing = await ctx.SystemSettings.FindAsync(key);
        if (existing is not null)
        {
            existing.SettingValue = storedValue;
            existing.UpdatedAtUtc = DateTime.UtcNow;
            if (category is not null) existing.Category = category;
            if (description is not null) existing.Description = description;
        }
        else
        {
            ctx.SystemSettings.Add(new SystemSetting
            {
                SettingKey = key,
                SettingValue = storedValue,
                Category = category,
                Description = description,
                UpdatedAtUtc = DateTime.UtcNow
            });
        }

        await ctx.SaveChangesAsync();
        _cache[key] = storedValue;
    }

    public async Task<Dictionary<string, string?>> GetByCategoryAsync(string category)
    {
        await EnsureCacheLoadedAsync();

        await using var ctx = await _contextFactory.CreateDbContextAsync();
        var items = await ctx.SystemSettings
            .Where(s => s.Category == category)
            .AsNoTracking()
            .ToListAsync();

        return items.ToDictionary(s => s.SettingKey, s => s.SettingValue, StringComparer.OrdinalIgnoreCase);
    }

    public async Task RefreshCacheAsync()
    {
        _cache.Clear();
        _initialized = false;
        await EnsureCacheLoadedAsync();
    }

    public async Task EnsureInitializedAsync()
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();

        // Create the table if it doesn't exist
        await ctx.Database.ExecuteSqlRawAsync("""
            IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'SystemSettings')
            BEGIN
                CREATE TABLE SystemSettings (
                    SettingKey   NVARCHAR(100) NOT NULL PRIMARY KEY,
                    SettingValue NVARCHAR(4000) NULL,
                    Category     NVARCHAR(50) NULL,
                    Description  NVARCHAR(500) NULL,
                    UpdatedAtUtc DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
                );

                CREATE INDEX IX_SystemSettings_Category ON SystemSettings (Category);
            END
            """);

        // Seed defaults if the table is empty
        if (!await ctx.SystemSettings.AnyAsync())
        {
            ctx.SystemSettings.AddRange(
                // Password Policy defaults
                Seed(SettingKeys.PasswordMinLength, "8", SettingKeys.CategoryPassword, "Minimum password length"),
                Seed(SettingKeys.PasswordMaxLength, "128", SettingKeys.CategoryPassword, "Maximum password length"),
                Seed(SettingKeys.PasswordRequireUpper, "true", SettingKeys.CategoryPassword, "Require at least one uppercase letter"),
                Seed(SettingKeys.PasswordRequireLower, "true", SettingKeys.CategoryPassword, "Require at least one lowercase letter"),
                Seed(SettingKeys.PasswordRequireDigit, "true", SettingKeys.CategoryPassword, "Require at least one digit"),
                Seed(SettingKeys.PasswordRequireSpecial, "true", SettingKeys.CategoryPassword, "Require at least one special character"),
                Seed(SettingKeys.PasswordHistoryCount, "5", SettingKeys.CategoryPassword, "Number of previous passwords to prevent reuse (0 = disabled)"),
                Seed(SettingKeys.PasswordExpiryDays, "90", SettingKeys.CategoryPassword, "Days until password expires (0 = never)"),

                // Lockout defaults
                Seed(SettingKeys.LockoutMaxAttempts, "5", SettingKeys.CategoryLockout, "Failed login attempts before lockout"),
                Seed(SettingKeys.LockoutDurationMinutes, "15", SettingKeys.CategoryLockout, "Lockout duration in minutes"),

                // Session defaults
                Seed(SettingKeys.SessionTimeoutMinutes, "30", SettingKeys.CategorySession, "Session inactivity timeout in minutes"),

                // MFA defaults (disabled)
                Seed(SettingKeys.MfaEnabled, "false", SettingKeys.CategoryMfa, "Enable multi-factor authentication"),
                Seed(SettingKeys.MfaEnforcementMode, "Optional", SettingKeys.CategoryMfa, "MFA enforcement: Optional, Required, or PerRole"),
                Seed(SettingKeys.MfaMethod, "EmailOtp", SettingKeys.CategoryMfa, "MFA method: EmailOtp or Totp"),

                // SSO defaults (disabled)
                Seed(SettingKeys.SsoEnabled, "false", SettingKeys.CategorySso, "Enable Single Sign-On"),
                Seed(SettingKeys.SsoProviderType, "", SettingKeys.CategorySso, "SSO provider: OAuth2, OIDC, SAML2, or EntraID"),
                Seed(SettingKeys.SsoAuthorityUrl, "", SettingKeys.CategorySso, "Authority / Issuer URL"),
                Seed(SettingKeys.SsoClientId, "", SettingKeys.CategorySso, "Client ID / Application ID"),
                Seed(SettingKeys.SsoClientSecret, "", SettingKeys.CategorySso, "Client Secret (stored encrypted in production)"),
                Seed(SettingKeys.SsoTenantId, "", SettingKeys.CategorySso, "Azure AD / Entra ID Tenant ID"),
                Seed(SettingKeys.SsoScopes, "openid profile email", SettingKeys.CategorySso, "Requested scopes (space-separated)"),
                Seed(SettingKeys.SsoRedirectUri, "", SettingKeys.CategorySso, "Redirect URI after authentication"),
                Seed(SettingKeys.SsoIdpMetadataUrl, "", SettingKeys.CategorySso, "SAML2: Identity Provider metadata URL"),
                Seed(SettingKeys.SsoIdpEntityId, "", SettingKeys.CategorySso, "SAML2: Identity Provider Entity ID"),
                Seed(SettingKeys.SsoSpEntityId, "", SettingKeys.CategorySso, "SAML2: Service Provider Entity ID"),
                Seed(SettingKeys.SsoCertificateThumbprint, "", SettingKeys.CategorySso, "SAML2: Certificate thumbprint for signature validation"),
                Seed(SettingKeys.SsoAcsUrl, "", SettingKeys.CategorySso, "SAML2: Assertion Consumer Service URL")
            );
            await ctx.SaveChangesAsync();
        }

        await RefreshCacheAsync();
    }

    private async Task EnsureCacheLoadedAsync()
    {
        if (_initialized) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var all = await ctx.SystemSettings.AsNoTracking().ToListAsync();
            foreach (var s in all)
                _cache[s.SettingKey] = s.SettingValue;
            _initialized = true;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[SystemSettings] Cache load failed: {ex.Message}");
        }
    }

    private static SystemSetting Seed(string key, string value, string category, string description) => new()
    {
        SettingKey = key,
        SettingValue = value,
        Category = category,
        Description = description,
        UpdatedAtUtc = DateTime.UtcNow
    };
}
