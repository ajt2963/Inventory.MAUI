using Inventory.MAUI.Data;
using Microsoft.EntityFrameworkCore;

namespace Inventory.MAUI.Services;

/// <summary>
/// Generic implementation of table maintenance operations for lookup tables.
/// Uses EF Core DbContext and relies on reflection to access the correct DbSet.
/// </summary>
public sealed class TableMaintenanceService<T> : ITableMaintenanceService<T> where T : class
{
    private readonly IDbContextFactory<InventoryDbContext> _contextFactory;

    public TableMaintenanceService(IDbContextFactory<InventoryDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<List<T>> GetAllAsync()
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        return await ctx.Set<T>().ToListAsync();
    }

    public async Task<T?> GetByIdAsync(int id)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        return await ctx.Set<T>().FindAsync(id);
    }

    public async Task<int> AddAsync(T entity)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        ctx.Set<T>().Add(entity);
        await ctx.SaveChangesAsync();

        // Try to get the ID from the entity if it has a primary key property
        var idProp = entity.GetType().GetProperty("OwnerID")
                     ?? entity.GetType().GetProperty("TypeID")
                     ?? entity.GetType().GetProperty("CatID")
                     ?? entity.GetType().GetProperty("CompanyID")
                     ?? entity.GetType().GetProperty("LocationID")
                     ?? entity.GetType().GetProperty("StorageID")
                     ?? entity.GetType().GetProperty("AssetID")
                     ?? entity.GetType().GetProperty("NotesID")
                     ?? entity.GetType().GetProperty("ContactID")
                     ?? entity.GetType().GetProperty("RoleID")
                     ?? entity.GetType().GetProperty("CompanyRoleID");

        if (idProp is not null && idProp.GetValue(entity) is int id)
            return id;

        return 0;
    }

    public async Task UpdateAsync(T entity)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        ctx.Set<T>().Update(entity);
        await ctx.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        var entity = await ctx.Set<T>().FindAsync(id);
        if (entity is not null)
        {
            ctx.Set<T>().Remove(entity);
            await ctx.SaveChangesAsync();
        }
    }
}
