using System.Net;
using System.Net.Mail;
using Inventory.MAUI.Configuration;
using Microsoft.Extensions.Options;

namespace Inventory.MAUI.Services;

/// <summary>
/// Sends email via SMTP using System.Net.Mail.
/// Resilient � failures are caught and logged, never crash the app.
/// </summary>
public sealed class EmailService : IEmailService
{
    private readonly SmtpOptions _options;

    public EmailService(IOptions<SmtpOptions> options)
    {
        _options = options.Value;
    }

    public bool IsConfigured =>
        !string.IsNullOrWhiteSpace(_options.Host) &&
        !string.IsNullOrWhiteSpace(_options.FromAddress);

    public async Task<bool> SendAsync(string toAddress, string subject, string htmlBody)
    {
        if (!IsConfigured)
        {
            System.Diagnostics.Debug.WriteLine("[EmailService] SMTP not configured � email not sent.");
            return false;
        }

        try
        {
            using var message = new MailMessage
            {
                From = new MailAddress(_options.FromAddress, _options.FromName),
                Subject = subject,
                Body = htmlBody,
                IsBodyHtml = true
            };
            message.To.Add(toAddress);

            using var client = new SmtpClient(_options.Host, _options.Port)
            {
                EnableSsl = _options.UseSsl,
                DeliveryMethod = SmtpDeliveryMethod.Network
            };

            if (!string.IsNullOrWhiteSpace(_options.Username))
            {
                client.Credentials = new NetworkCredential(_options.Username, _options.Password);
            }

            await client.SendMailAsync(message);
            System.Diagnostics.Debug.WriteLine($"[EmailService] Email sent to {toAddress}: {subject}");
            return true;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[EmailService] Failed to send email to {toAddress}: {ex.Message}");
            return false;
        }
    }
}
