using Inventory.MAUI.Data;
using Inventory.MAUI.Models;
using Microsoft.EntityFrameworkCore;

namespace Inventory.MAUI.Services;

/// <summary>
/// Persists audit log entries to the AuditLog table via EF Core.
/// Write operations are resilient � failures are caught and written to Debug output
/// so they never disrupt the primary user operation.
/// </summary>
public sealed class AuditService : IAuditService
{
    private readonly IDbContextFactory<InventoryDbContext> _contextFactory;

    /// <summary>
    /// Detected once at startup. Stored with every log entry for traceability.
    /// </summary>
    private static readonly string CurrentPlatform = DeviceInfo.Current.Platform.ToString();

    public AuditService(IDbContextFactory<InventoryDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task LogAsync(
        string eventType,
        int? userId = null,
        string? attuid = null,
        string? entityType = null,
        string? entityId = null,
        string? details = null)
    {
        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();

            ctx.AuditLog.Add(new AuditLog
            {
                TimestampUtc = DateTime.UtcNow,
                UserID = userId,
                ATTUID = attuid,
                EventType = eventType,
                EntityType = entityType,
                EntityID = entityId,
                Details = details,
                Platform = CurrentPlatform
            });

            await ctx.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            // Audit logging must never crash the application.
            System.Diagnostics.Debug.WriteLine($"[AuditService] Failed to write audit log: {ex.Message}");
        }
    }

    public async Task<List<AuditLog>> GetRecentAsync(int count = 100)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        return await ctx.AuditLog
            .Include(a => a.User)
            .OrderByDescending(a => a.TimestampUtc)
            .Take(count)
            .AsNoTracking()
            .ToListAsync();
    }

    public async Task<List<AuditLog>> GetByUserAsync(int userId, int count = 100)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        return await ctx.AuditLog
            .Include(a => a.User)
            .Where(a => a.UserID == userId)
            .OrderByDescending(a => a.TimestampUtc)
            .Take(count)
            .AsNoTracking()
            .ToListAsync();
    }

    public async Task<List<AuditLog>> GetByEventTypeAsync(string eventType, int count = 100)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        return await ctx.AuditLog
            .Include(a => a.User)
            .Where(a => a.EventType == eventType)
            .OrderByDescending(a => a.TimestampUtc)
            .Take(count)
            .AsNoTracking()
            .ToListAsync();
    }

    public async Task<List<AuditLog>> GetFilteredAsync(
        DateTime? fromUtc = null,
        DateTime? toUtc = null,
        int? userId = null,
        string? eventType = null,
        int maxResults = 500)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();

        IQueryable<AuditLog> query = ctx.AuditLog.Include(a => a.User).AsNoTracking();

        // Enforce 2-year maximum lookback
        var twoYearsAgo = DateTime.UtcNow.AddYears(-2);
        var effectiveFrom = fromUtc.HasValue && fromUtc.Value > twoYearsAgo ? fromUtc.Value : twoYearsAgo;
        query = query.Where(a => a.TimestampUtc >= effectiveFrom);

        if (toUtc.HasValue)
            query = query.Where(a => a.TimestampUtc <= toUtc.Value);

        if (userId.HasValue)
            query = query.Where(a => a.UserID == userId.Value);

        if (!string.IsNullOrWhiteSpace(eventType))
            query = query.Where(a => a.EventType == eventType);

        return await query
            .OrderByDescending(a => a.TimestampUtc)
            .Take(maxResults)
            .ToListAsync();
    }
}
