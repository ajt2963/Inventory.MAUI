using System.Security.Cryptography;
using System.Text;

namespace Inventory.MAUI.Services;

/// <summary>
/// Provides AES-256-GCM encryption for sensitive settings stored in the database.
/// Uses a machine-specific key derived from a stable device identifier + app-specific salt.
/// This protects secrets at rest � an attacker with DB access cannot read them
/// without access to the device that encrypted them.
/// </summary>
public static class SettingsEncryption
{
    private const int NonceSize = 12;  // AES-GCM standard
    private const int TagSize = 16;    // AES-GCM standard
    private const int KeySize = 32;    // AES-256

    // App-specific salt � not a secret, just ensures uniqueness
    private static readonly byte[] AppSalt = "UCOM-Inventory-Settings-v1"u8.ToArray();

    /// <summary>
    /// Encrypts a plaintext value. Returns a Base64 string containing nonce + ciphertext + tag.
    /// </summary>
    public static string Encrypt(string plaintext)
    {
        if (string.IsNullOrEmpty(plaintext))
            return string.Empty;

        var key = DeriveKey();
        var plaintextBytes = Encoding.UTF8.GetBytes(plaintext);
        var nonce = RandomNumberGenerator.GetBytes(NonceSize);
        var ciphertext = new byte[plaintextBytes.Length];
        var tag = new byte[TagSize];

        using var aes = new AesGcm(key, TagSize);
        aes.Encrypt(nonce, plaintextBytes, ciphertext, tag);

        // Pack: [nonce][ciphertext][tag]
        var result = new byte[NonceSize + ciphertext.Length + TagSize];
        nonce.CopyTo(result, 0);
        ciphertext.CopyTo(result, NonceSize);
        tag.CopyTo(result, NonceSize + ciphertext.Length);

        return Convert.ToBase64String(result);
    }

    /// <summary>
    /// Decrypts a value previously encrypted with Encrypt().
    /// Returns the plaintext, or the original value if decryption fails (backwards compat with unencrypted values).
    /// </summary>
    public static string Decrypt(string encrypted)
    {
        if (string.IsNullOrEmpty(encrypted))
            return string.Empty;

        try
        {
            var data = Convert.FromBase64String(encrypted);
            if (data.Length < NonceSize + TagSize + 1)
                return encrypted; // Too short to be encrypted � return as-is (unencrypted legacy value)

            var key = DeriveKey();
            var nonce = data[..NonceSize];
            var ciphertext = data[NonceSize..^TagSize];
            var tag = data[^TagSize..];
            var plaintext = new byte[ciphertext.Length];

            using var aes = new AesGcm(key, TagSize);
            aes.Decrypt(nonce, ciphertext, tag, plaintext);

            return Encoding.UTF8.GetString(plaintext);
        }
        catch
        {
            // If decryption fails, the value is likely stored in plaintext (pre-encryption migration).
            // Return as-is for backwards compatibility.
            return encrypted;
        }
    }

    /// <summary>
    /// Derives a 256-bit key from a stable device/machine identifier.
    /// </summary>
    private static byte[] DeriveKey()
    {
        // Use a stable identifier that persists across app restarts but is unique per device.
        // On Android: Android ID. On Windows: Machine name + user SID. Fallback: "default".
        var deviceId = GetStableDeviceId();
        var keyMaterial = Encoding.UTF8.GetBytes(deviceId);

        return Rfc2898DeriveBytes.Pbkdf2(
            keyMaterial,
            AppSalt,
            100_000,
            HashAlgorithmName.SHA256,
            KeySize);
    }

    private static string GetStableDeviceId()
    {
        try
        {
            // Combine multiple identifiers for stability
            var parts = new[]
            {
                Environment.MachineName,
                Environment.UserName,
                DeviceInfo.Current.Platform.ToString(),
                DeviceInfo.Current.Model
            };
            return string.Join("|", parts.Where(p => !string.IsNullOrWhiteSpace(p)));
        }
        catch
        {
            return "UCOM-Default-Device-Key";
        }
    }

    /// <summary>
    /// Setting keys that contain secrets and must be encrypted at rest.
    /// </summary>
    public static readonly HashSet<string> SensitiveKeys = new(StringComparer.OrdinalIgnoreCase)
    {
        Models.SettingKeys.SsoClientSecret,
        Models.SettingKeys.SsoCertificateThumbprint
    };

    /// <summary>Returns true if the given setting key should be encrypted.</summary>
    public static bool IsSensitive(string key) => SensitiveKeys.Contains(key);
}
