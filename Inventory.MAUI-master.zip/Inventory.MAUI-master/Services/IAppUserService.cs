using Inventory.MAUI.Models;

namespace Inventory.MAUI.Services;

/// <summary>
/// Service for managing AppUser and AppRole records, and resolving the current session user.
/// </summary>
public interface IAppUserService
{
    /// <summary>
    /// Resolves the current Windows identity to an AppUser record.
    /// Returns null if the user is not registered in the system.
    /// </summary>
    Task<AppUser?> GetCurrentUserAsync();

    /// <summary>
    /// Gets a user by their ATTUID (Windows login name, case-insensitive).
    /// </summary>
    Task<AppUser?> GetByAttuidAsync(string attuid);

    /// <summary>
    /// Gets a user by ID.
    /// </summary>
    Task<AppUser?> GetByIdAsync(int userId);

    /// <summary>
    /// Gets all users, optionally including inactive ones.
    /// </summary>
    Task<List<AppUser>> GetAllUsersAsync(bool includeInactive = false);

    /// <summary>
    /// Creates or updates a user record. Returns the saved user.
    /// </summary>
    Task<AppUser> SaveUserAsync(AppUser user);

    /// <summary>
    /// Gets all roles.
    /// </summary>
    Task<List<AppRole>> GetAllRolesAsync();

    /// <summary>
    /// Creates or updates a role. Returns the saved role.
    /// </summary>
    Task<AppRole> SaveRoleAsync(AppRole role);

    /// <summary>
    /// Deletes a role by ID. Throws if users are still assigned to it.
    /// </summary>
    Task DeleteRoleAsync(int roleId);

    /// <summary>
    /// Ensures seed data exists (default roles). Called at startup.
    /// </summary>
    Task EnsureSeedDataAsync();

    /// <summary>
    /// Updates the LastLoginAt timestamp for the given user.
    /// </summary>
    Task RecordLoginAsync(int userId);

    /// <summary>
    /// Authenticates a user by ATTUID and password.
    /// Returns the user on success, null on failure. Handles lockout and failed-attempt tracking.
    /// </summary>
    Task<AppUser?> AuthenticateAsync(string attuid, string password);

    /// <summary>
    /// Sets or changes a user's password. Stores a PBKDF2-SHA256 hash + random salt.
    /// </summary>
    Task SetPasswordAsync(int userId, string newPassword);

    /// <summary>
    /// Resets a user's password (admin action). Clears the hash and sets MustChangePassword.
    /// </summary>
    Task AdminResetPasswordAsync(int userId);

    /// <summary>
    /// Deletes a user by ID. Cannot delete the currently logged-in user.
    /// </summary>
    Task DeleteUserAsync(int userId);
}
