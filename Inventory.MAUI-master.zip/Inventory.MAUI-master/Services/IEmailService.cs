namespace Inventory.MAUI.Services;

/// <summary>
/// Sends outbound email messages (password recovery codes, notifications).
/// </summary>
public interface IEmailService
{
    /// <summary>
    /// Sends an email. Returns true on success.
    /// </summary>
    Task<bool> SendAsync(string toAddress, string subject, string htmlBody);

    /// <summary>
    /// True if SMTP is configured and email can be sent.
    /// </summary>
    bool IsConfigured { get; }
}
