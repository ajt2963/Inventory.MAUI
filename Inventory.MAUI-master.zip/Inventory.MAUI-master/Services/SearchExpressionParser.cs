using System.Linq.Expressions;
using Inventory.MAUI.Models;

namespace Inventory.MAUI.Services;

/// <summary>
/// Parses search expressions into EF-compatible predicates for InventoryList queries.
///
/// Syntax:
///   term1 term2          ? AND (both must match any column)
///   term1 AND term2      ? AND (explicit)
///   term1 OR term2       ? OR  (either matches)
///   "exact phrase"        ? phrase treated as single term
///   column:value          ? match specific column (e.g., status:active)
///   column:"exact value"  ? match specific column with exact phrase
///
/// Supported column names (case-insensitive):
///   id, assettag, tag, toolkitid, toolkit, status, owner, category, cat,
///   type, assettype, company, manufacturer, partnumber, part, serialnumber, serial,
///   description, desc, qty, quantity, battery, clli, location, storage, divider, section, designator, option
/// </summary>
public static class SearchExpressionParser
{
    public static Expression<Func<InventoryList, bool>>? Parse(string? searchText)
    {
        if (string.IsNullOrWhiteSpace(searchText))
            return null;

        var tokens = Tokenize(searchText);
        if (tokens.Count == 0)
            return null;

        var clauses = BuildClauses(tokens);
        if (clauses.Count == 0)
            return null;

        var param = Expression.Parameter(typeof(InventoryList), "i");
        Expression? combined = null;

        foreach (var clause in clauses)
        {
            var expr = BuildClauseExpression(clause, param);
            if (expr is null) continue;

            combined = combined is null
                ? expr
                : clause.JoinWithOr
                    ? Expression.OrElse(combined, expr)
                    : Expression.AndAlso(combined, expr);
        }

        return combined is null
            ? null
            : Expression.Lambda<Func<InventoryList, bool>>(combined, param);
    }

    private static Expression? BuildClauseExpression(SearchClause clause, ParameterExpression param)
    {
        if (clause.Column is not null)
        {
            var prop = ResolveProperty(clause.Column);
            if (prop is null) return null;

            return BuildContains(param, prop, clause.Value);
        }

        // No column specified � search across all text columns
        Expression? any = null;
        foreach (var prop in AllTextProperties)
        {
            var contains = BuildContains(param, prop, clause.Value);
            any = any is null ? contains : Expression.OrElse(any, contains);
        }
        return any;
    }

    private static Expression BuildContains(ParameterExpression param, string propertyName, string value)
    {
        var prop = Expression.Property(param, propertyName);
        var val = Expression.Constant(value, typeof(string));
        var containsMethod = typeof(string).GetMethod("Contains", [typeof(string)])!;

        // prop != null && prop.Contains(value)
        var notNull = Expression.NotEqual(prop, Expression.Constant(null, typeof(string)));
        var contains = Expression.Call(prop, containsMethod, val);
        return Expression.AndAlso(notNull, contains);
    }

    private sealed record SearchClause(string? Column, string Value, bool JoinWithOr);

    private static List<SearchClause> BuildClauses(List<Token> tokens)
    {
        var clauses = new List<SearchClause>();
        var nextJoinOr = false;

        foreach (var token in tokens)
        {
            if (token.Type == TokenType.And)
            {
                nextJoinOr = false;
                continue;
            }
            if (token.Type == TokenType.Or)
            {
                nextJoinOr = true;
                continue;
            }

            var text = token.Text;
            string? column = null;

            // Check for column:value syntax
            var colonIdx = text.IndexOf(':');
            if (colonIdx > 0 && colonIdx < text.Length - 1)
            {
                var candidateCol = text[..colonIdx];
                if (ResolveProperty(candidateCol) is not null)
                {
                    column = candidateCol;
                    text = text[(colonIdx + 1)..].Trim('"');
                }
            }

            if (!string.IsNullOrWhiteSpace(text))
            {
                clauses.Add(new SearchClause(column, text, nextJoinOr));
                nextJoinOr = false; // default back to AND
            }
        }

        return clauses;
    }

    private enum TokenType { Term, And, Or }
    private sealed record Token(TokenType Type, string Text);

    private static List<Token> Tokenize(string input)
    {
        var tokens = new List<Token>();
        var span = input.AsSpan().Trim();
        var i = 0;

        while (i < span.Length)
        {
            // Skip whitespace
            while (i < span.Length && char.IsWhiteSpace(span[i])) i++;
            if (i >= span.Length) break;

            // Quoted string
            if (span[i] == '"')
            {
                i++;
                var start = i;
                while (i < span.Length && span[i] != '"') i++;
                var text = span[start..i].ToString();
                if (i < span.Length) i++; // skip closing quote
                if (!string.IsNullOrWhiteSpace(text))
                    tokens.Add(new Token(TokenType.Term, text));
                continue;
            }

            // Unquoted word (may include column:value with quoted value)
            {
                var start = i;

                // Check for column:"quoted value" pattern
                while (i < span.Length && !char.IsWhiteSpace(span[i]) && span[i] != '"') i++;

                // If we stopped at a quote and the previous char was ':', consume the quoted part
                if (i < span.Length && span[i] == '"' && i > start && span[i - 1] == ':')
                {
                    i++; // skip opening quote
                    while (i < span.Length && span[i] != '"') i++;
                    if (i < span.Length) i++; // skip closing quote
                }

                var word = span[start..i].ToString();

                if (string.Equals(word, "AND", StringComparison.OrdinalIgnoreCase))
                    tokens.Add(new Token(TokenType.And, word));
                else if (string.Equals(word, "OR", StringComparison.OrdinalIgnoreCase))
                    tokens.Add(new Token(TokenType.Or, word));
                else if (!string.IsNullOrWhiteSpace(word))
                    tokens.Add(new Token(TokenType.Term, word));
            }
        }

        return tokens;
    }

    private static string? ResolveProperty(string name)
    {
        return name.ToLowerInvariant() switch
        {
            "id" => nameof(InventoryList.InventoryID),
            "assettag" or "tag" => nameof(InventoryList.AssetTag),
            "toolkitid" or "toolkit" => nameof(InventoryList.ToolKitID),
            "status" => nameof(InventoryList.Status),
            "owner" => nameof(InventoryList.Owner),
            "category" or "cat" => nameof(InventoryList.CatName),
            "type" or "assettype" => nameof(InventoryList.Type),
            "company" or "manufacturer" => nameof(InventoryList.CompanyName),
            "partnumber" or "part" => nameof(InventoryList.PartNumber),
            "serialnumber" or "serial" => nameof(InventoryList.SerialNumber),
            "description" or "desc" => nameof(InventoryList.Description),
            "qty" or "quantity" => null, // int column, skip for Contains
            "battery" => nameof(InventoryList.BatteryType),
            "clli" or "location" => nameof(InventoryList.ClliCode),
            "storage" => nameof(InventoryList.Storage),
            "divider" => nameof(InventoryList.Divider),
            "section" => nameof(InventoryList.Section),
            "designator" or "option" => nameof(InventoryList.Option),
            _ => null,
        };
    }

    private static readonly string[] AllTextProperties =
    [
        nameof(InventoryList.AssetTag),
        nameof(InventoryList.ToolKitID),
        nameof(InventoryList.PartNumber),
        nameof(InventoryList.SerialNumber),
        nameof(InventoryList.Description),
        nameof(InventoryList.CompanyName),
        nameof(InventoryList.Type),
        nameof(InventoryList.CatName),
        nameof(InventoryList.Storage),
        nameof(InventoryList.Owner),
        nameof(InventoryList.ClliCode),
        nameof(InventoryList.Status),
        nameof(InventoryList.BatteryType),
        nameof(InventoryList.Divider),
        nameof(InventoryList.Section),
        nameof(InventoryList.Option),
    ];
}
