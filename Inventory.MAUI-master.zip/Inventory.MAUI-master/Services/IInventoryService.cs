namespace Inventory.MAUI.Services;

public interface IInventoryService
{
    IEnumerable<string> GetValidStatusCodes();
    Task<IEnumerable<string>> GetAllLocationNamesAsync();
}
