using Inventory.MAUI.Data;
using Microsoft.EntityFrameworkCore;

namespace Inventory.MAUI.Services;

/// <summary>
/// Executes SQL Server BACKUP/RESTORE commands via the existing database connection.
/// All file paths are server-side � the .bak file lives on the SQL Server machine.
/// Detects Azure SQL Database and blocks unsupported operations.
/// </summary>
public sealed class DatabaseService : IDatabaseService
{
    private readonly IDbContextFactory<InventoryDbContext> _contextFactory;
    private readonly IAuditService _audit;
    private bool? _isAzureCache;

    public DatabaseService(IDbContextFactory<InventoryDbContext> contextFactory, IAuditService audit)
    {
        _contextFactory = contextFactory;
        _audit = audit;
    }

    public async Task<string> GetDatabaseNameAsync()
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        return ctx.Database.GetDbConnection().Database;
    }

    public async Task<bool> IsAzureSqlAsync()
    {
        if (_isAzureCache.HasValue)
            return _isAzureCache.Value;

        try
        {
            var info = await GetEnvironmentInfoAsync();
            _isAzureCache = info.IsAzure;
            return info.IsAzure;
        }
        catch
        {
            return false;
        }
    }

    public async Task<DatabaseEnvironmentInfo> GetEnvironmentInfoAsync()
    {
        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var conn = ctx.Database.GetDbConnection();
            await conn.OpenAsync();

            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                SELECT 
                    SERVERPROPERTY('ServerName') AS ServerName,
                    SERVERPROPERTY('Edition') AS Edition,
                    SERVERPROPERTY('ProductVersion') AS Version,
                    DB_NAME() AS DatabaseName,
                    CASE 
                        WHEN SERVERPROPERTY('EngineEdition') = 5 THEN 1  -- Azure SQL Database
                        WHEN SERVERPROPERTY('EngineEdition') = 8 THEN 1  -- Azure SQL Managed Instance
                        ELSE 0
                    END AS IsAzure";
            cmd.CommandTimeout = 10;

            using var reader = await cmd.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                var info = new DatabaseEnvironmentInfo
                {
                    ServerName = reader["ServerName"]?.ToString() ?? "",
                    Edition = reader["Edition"]?.ToString() ?? "",
                    Version = reader["Version"]?.ToString() ?? "",
                    DatabaseName = reader["DatabaseName"]?.ToString() ?? "",
                    IsAzure = Convert.ToInt32(reader["IsAzure"]) == 1
                };
                _isAzureCache = info.IsAzure;
                return info;
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[DB] GetEnvironmentInfo error: {ex.Message}");
        }

        return new DatabaseEnvironmentInfo();
    }

    public async Task<string?> GetDefaultBackupDirectoryAsync()
    {
        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var conn = ctx.Database.GetDbConnection();
            await conn.OpenAsync();

            using var cmd = conn.CreateCommand();
            // Get the SQL Server default backup directory from the registry
            cmd.CommandText = @"
                DECLARE @backupDir NVARCHAR(4000);
                EXEC master.dbo.xp_instance_regread
                    N'HKEY_LOCAL_MACHINE',
                    N'Software\Microsoft\MSSQLServer\MSSQLServer',
                    N'BackupDirectory',
                    @backupDir OUTPUT;
                SELECT @backupDir;";
            cmd.CommandTimeout = 10;

            var result = await cmd.ExecuteScalarAsync();
            return result as string;
        }
        catch
        {
            return null;
        }
    }

    public async Task<List<string>> ListBackupFilesAsync(string directory)
    {
        var files = new List<string>();
        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var conn = ctx.Database.GetDbConnection();
            await conn.OpenAsync();

            using var cmd = conn.CreateCommand();
            // Use xp_cmdshell alternative: read directory via xp_dirtree
            cmd.CommandText = $@"
                CREATE TABLE #DirTree (FileName NVARCHAR(512), Depth INT, IsFile BIT);
                INSERT INTO #DirTree EXEC master.dbo.xp_dirtree @p0, 1, 1;
                SELECT FileName FROM #DirTree WHERE IsFile = 1 AND FileName LIKE '%.bak';
                DROP TABLE #DirTree;";

            // Use parameterized approach for safety
            cmd.CommandText = @"
                CREATE TABLE #DirTree (FileName NVARCHAR(512), Depth INT, IsFile BIT);
                INSERT INTO #DirTree EXEC master.dbo.xp_dirtree @dir, 1, 1;
                SELECT FileName FROM #DirTree WHERE IsFile = 1 AND FileName LIKE '%.bak'
                ORDER BY FileName DESC;
                DROP TABLE #DirTree;";

            var param = cmd.CreateParameter();
            param.ParameterName = "@dir";
            param.Value = directory;
            cmd.Parameters.Add(param);
            cmd.CommandTimeout = 15;

            using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                files.Add(reader.GetString(0));
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[DB] ListBackupFiles error: {ex.Message}");
        }
        return files;
    }

    public async Task<string> BackupDatabaseAsync(string backupPath)
    {
        if (await IsAzureSqlAsync())
            return "BACKUP DATABASE TO DISK is not supported on Azure SQL Database.\nAzure manages backups automatically via point-in-time restore.\nUse the Azure Portal to manage backups.";

        if (string.IsNullOrWhiteSpace(backupPath))
            return "Backup path is required.";

        if (!backupPath.EndsWith(".bak", StringComparison.OrdinalIgnoreCase))
            backupPath += ".bak";

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var dbName = ctx.Database.GetDbConnection().Database;
            var conn = ctx.Database.GetDbConnection();
            await conn.OpenAsync();

            using var cmd = conn.CreateCommand();
            cmd.CommandText = $@"
                BACKUP DATABASE [{dbName}]
                TO DISK = @path
                WITH FORMAT, INIT,
                     NAME = @desc,
                     STATS = 10;";

            var pathParam = cmd.CreateParameter();
            pathParam.ParameterName = "@path";
            pathParam.Value = backupPath;
            cmd.Parameters.Add(pathParam);

            var descParam = cmd.CreateParameter();
            descParam.ParameterName = "@desc";
            descParam.Value = $"{dbName} Full Backup - {DateTime.UtcNow:yyyy-MM-dd HH:mm:ss UTC}";
            cmd.Parameters.Add(descParam);

            cmd.CommandTimeout = 300; // 5 minutes for large databases

            await cmd.ExecuteNonQueryAsync();

            await _audit.LogAsync(
                Models.AuditEventTypes.SettingsChanged,
                details: $"Database backup completed: {backupPath}");

            return $"Backup completed successfully.\n\nDatabase: {dbName}\nFile: {backupPath}\nTime: {DateTime.Now:g}";
        }
        catch (Exception ex)
        {
            await _audit.LogAsync(
                Models.AuditEventTypes.SettingsChanged,
                details: $"Database backup FAILED: {backupPath} � {ex.Message}");

            return $"Backup failed: {ex.Message}";
        }
    }

    public async Task<string> RestoreDatabaseAsync(string backupPath)
    {
        if (await IsAzureSqlAsync())
            return "RESTORE DATABASE FROM DISK is not supported on Azure SQL Database.\nUse the Azure Portal for point-in-time restore or geo-restore.";

        if (string.IsNullOrWhiteSpace(backupPath))
            return "Backup file path is required.";

        string? dbName = null;
        Microsoft.Data.SqlClient.SqlConnection? masterConn = null;

        try
        {
            // Get the target database name from the current connection
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            dbName = ctx.Database.GetDbConnection().Database;

            // Build a connection to the MASTER database so we don't get kicked out when the target DB goes to SINGLE_USER
            var appConnStr = ctx.Database.GetConnectionString()!;
            var builder = new Microsoft.Data.SqlClient.SqlConnectionStringBuilder(appConnStr)
            {
                InitialCatalog = "master"
            };

            masterConn = new Microsoft.Data.SqlClient.SqlConnection(builder.ConnectionString);
            await masterConn.OpenAsync();

            // Step 1: Set target database to single-user mode to kick out other connections
            using (var cmd = masterConn.CreateCommand())
            {
                cmd.CommandText = $@"
                    ALTER DATABASE [{dbName}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;";
                cmd.CommandTimeout = 30;
                await cmd.ExecuteNonQueryAsync();
            }

            // Step 2: Restore the database
            try
            {
                using var cmd = masterConn.CreateCommand();
                cmd.CommandText = $@"
                    RESTORE DATABASE [{dbName}]
                    FROM DISK = @path
                    WITH REPLACE, STATS = 10;";

                var pathParam = cmd.CreateParameter();
                pathParam.ParameterName = "@path";
                pathParam.Value = backupPath;
                cmd.Parameters.Add(pathParam);

                cmd.CommandTimeout = 600; // 10 minutes for large databases

                await cmd.ExecuteNonQueryAsync();
            }
            finally
            {
                // Step 3: Always restore multi-user mode
                try
                {
                    using var cmd = masterConn.CreateCommand();
                    cmd.CommandText = $@"
                        ALTER DATABASE [{dbName}] SET MULTI_USER;";
                    cmd.CommandTimeout = 30;
                    await cmd.ExecuteNonQueryAsync();
                }
                catch
                {
                    // Best effort � if this fails, admin must fix manually via SSMS
                }
            }

            await _audit.LogAsync(
                Models.AuditEventTypes.SettingsChanged,
                details: $"Database restore completed from: {backupPath}");

            return $"Restore completed successfully.\n\nDatabase: {dbName}\nRestored from: {backupPath}\nTime: {DateTime.Now:g}\n\nIMPORTANT: You MUST restart the app now for all changes to take effect.";
        }
        catch (Exception ex)
        {
            await _audit.LogAsync(
                Models.AuditEventTypes.SettingsChanged,
                details: $"Database restore FAILED from: {backupPath} � {ex.Message}");

            return $"Restore failed: {ex.Message}";
        }
        finally
        {
            if (masterConn is not null)
            {
                await masterConn.CloseAsync();
                await masterConn.DisposeAsync();
            }
        }
    }
}
