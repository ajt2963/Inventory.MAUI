namespace Inventory.MAUI.Services;

/// <summary>
/// Default (non-Android) file save implementation.
/// Writes directly to a known directory on Windows, iOS, and macOS.
/// </summary>
public sealed class DefaultFileSaveService : IFileSaveService
{
    public async Task<string?> SaveFileAsync(string suggestedFileName, string content, string mimeType = "text/csv")
    {
        var dir = GetExportDirectory();
        Directory.CreateDirectory(dir);

        var filePath = Path.Combine(dir, suggestedFileName);
        await File.WriteAllTextAsync(filePath, content, System.Text.Encoding.UTF8);
        return filePath;
    }

    private static string GetExportDirectory()
    {
#if WINDOWS
        return @"C:\AppData\logs";
#elif IOS || MACCATALYST
        var docs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        if (!string.IsNullOrWhiteSpace(docs))
            return Path.Combine(docs, "UCOM_Inventory", "logs");

        return Path.Combine(FileSystem.AppDataDirectory, "logs");
#else
        return Path.Combine(FileSystem.AppDataDirectory, "logs");
#endif
    }
}
