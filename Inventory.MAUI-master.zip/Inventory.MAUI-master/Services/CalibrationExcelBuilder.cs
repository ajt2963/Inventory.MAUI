using ClosedXML.Excel;

namespace Inventory.MAUI.Services;

/// <summary>
/// Builds an Excel workbook for calibration schedule exports.
/// Each location is appended as a separate worksheet.
/// </summary>
public sealed class CalibrationExcelBuilder : IDisposable
{
    private XLWorkbook _workbook = new();

    /// <summary>
    /// Loads an existing workbook from disk so new sheets can be appended to it.
    /// </summary>
    public void LoadExisting(string filePath)
    {
        _workbook.Dispose();
        _workbook = new XLWorkbook(filePath);
    }

    /// <summary>
    /// Appends a worksheet for the given location and its scheduled items.
    /// </summary>
    public void AddLocationSheet(
        string locationName,
        string clliCode,
        DateTime scheduledDate,
        string serviceProvider,
        IReadOnlyList<CalibrationItemRow> items)
    {
        // Sanitize sheet name (Excel max 31 chars, no special chars)
        var sheetName = SanitizeSheetName(clliCode);

        // Ensure unique sheet name
        var baseName = sheetName;
        var counter = 1;
        while (_workbook.Worksheets.Any(ws => ws.Name == sheetName))
        {
            sheetName = $"{baseName}_{counter++}";
            if (sheetName.Length > 31)
                sheetName = sheetName[..31];
        }

        var ws = _workbook.Worksheets.Add(sheetName);

        // Column headers
        var headerRow = 1;
        var headers = new[]
        {
            "InventoryID", "Manufacturer", "Part Number", "Serial Number",
            "Description", "CLLICode", "Last Cal Date", "Scheduled Date", "ServiceProviderName"
        };
        for (var i = 0; i < headers.Length; i++)
        {
            var cell = ws.Cell(headerRow, i + 1);
            cell.Value = headers[i];
            cell.Style.Font.Bold = true;
            cell.Style.Fill.BackgroundColor = XLColor.LightGray;
            cell.Style.Border.BottomBorder = XLBorderStyleValues.Thin;
        }

        // Data rows
        var row = headerRow + 1;
        foreach (var item in items)
        {
            ws.Cell(row, 1).Value = item.InventoryID;
            ws.Cell(row, 2).Value = item.ManufacturerName ?? string.Empty;
            ws.Cell(row, 3).Value = item.PartNumber ?? string.Empty;
            ws.Cell(row, 4).Value = item.SerialNumber ?? string.Empty;
            ws.Cell(row, 5).Value = item.Description ?? string.Empty;
            ws.Cell(row, 6).Value = clliCode;
            ws.Cell(row, 7).Value = item.LastCalDate?.ToString("MM/dd/yyyy") ?? string.Empty;
            ws.Cell(row, 8).Value = scheduledDate.ToString("MM/dd/yyyy");
            ws.Cell(row, 9).Value = serviceProvider;
            row++;
        }

        // Auto-fit columns
        ws.Columns().AdjustToContents();
    }

    /// <summary>
    /// Saves the workbook to the specified file path.
    /// </summary>
    public void SaveTo(string filePath)
    {
        _workbook.SaveAs(filePath);
    }

    /// <summary>
    /// Saves the workbook to a stream.
    /// </summary>
    public void SaveTo(Stream stream)
    {
        _workbook.SaveAs(stream);
    }

    public void Dispose() => _workbook.Dispose();

    private static string SanitizeSheetName(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
            return "Sheet";

        // Remove invalid characters for Excel sheet names
        var invalid = new[] { ':', '\\', '/', '?', '*', '[', ']' };
        var sanitized = new string(name.Where(c => !invalid.Contains(c)).ToArray());

        if (sanitized.Length > 31)
            sanitized = sanitized[..31];

        return string.IsNullOrWhiteSpace(sanitized) ? "Sheet" : sanitized;
    }
}
