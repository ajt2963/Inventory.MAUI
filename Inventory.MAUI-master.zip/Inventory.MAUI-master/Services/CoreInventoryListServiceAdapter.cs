using Inventory.MAUI.Core.Models;
using Inventory.MAUI.Core.Services;

namespace Inventory.MAUI.Services;

public sealed class CoreInventoryListServiceAdapter : Inventory.MAUI.Core.Services.IInventoryListService
{
    private readonly IInventoryListService _impl;

    public CoreInventoryListServiceAdapter(IInventoryListService impl)
    {
        _impl = impl;
    }

    public async Task<IReadOnlyList<InventoryList>> GetInventoryListAsync(string? search)
    {
        var list = await _impl.GetInventoryListAsync(search);
        // Models are duplicated across projects; map MAUI model to Core model.
        return list.Select(Map).ToList();
    }

    public async Task<IReadOnlyList<InventoryList>> GetInventoryListPageAsync(string? search, int skip, int take)
    {
        var list = await _impl.GetInventoryListPageAsync(search, skip, take);
        return list.Select(Map).ToList();
    }

    public async Task<InventoryList?> GetByIdAsync(int inventoryId)
    {
        var i = await _impl.GetByIdAsync(inventoryId);
        return i is null ? null : Map(i);
    }

    public async IAsyncEnumerable<InventoryList> StreamInventoryListAsync(string? search)
    {
        var list = await _impl.GetInventoryListAsync(search);
        foreach (var i in list)
            yield return Map(i);
    }

    public async Task<int> GetInventoryListCountAsync(string? search)
    {
        return await _impl.GetInventoryListCountAsync(search);
    }

    public async Task<InventoryList?> GetLastAsync(string? search)
    {
        var i = await _impl.GetLastAsync(search);
        return i is null ? null : Map(i);
    }

    public async Task<IReadOnlyList<InventoryList>> GetLastPageAsync(string? search, int take)
    {
        var list = await _impl.GetLastPageAsync(search, take);
        return list.Select(Map).ToList();
    }

    public Task<List<(string Name, int Count)>> GetCountByStatusAsync()
        => _impl.GetCountByStatusAsync();

    public Task<List<(string Name, int Count)>> GetCountByLocationAsync()
        => _impl.GetCountByLocationAsync();

    public Task<List<(string Location, string Name, int Count)>> GetCountByFieldPerLocationAsync(string fieldName)
        => _impl.GetCountByFieldPerLocationAsync(fieldName);

    public async Task<IReadOnlyList<Core.Models.InventoryList>> GetByLocationAsync(string clliCode)
    {
        var list = await _impl.GetByLocationAsync(clliCode);
        return list.Select(Map).ToList();
    }

    private static Core.Models.InventoryList Map(Inventory.MAUI.Models.InventoryList i) => new()
    {
        InventoryID = i.InventoryID,
        AssetTag = i.AssetTag,
        ToolKitID = i.ToolKitID,
        Status = i.Status,
        Owner = i.Owner,
        CatName = i.CatName,
        Type = i.Type,
        CompanyName = i.CompanyName,
        PartNumber = i.PartNumber,
        SerialNumber = i.SerialNumber,
        Description = i.Description,
        Quantity = i.Quantity,
        BatteryType = i.BatteryType,
        ClliCode = i.ClliCode,
        Storage = i.Storage,
        Divider = i.Divider,
        Section = i.Section,
        Option = i.Option,
        InventoryNotes = i.InventoryNotes,
    };
}
