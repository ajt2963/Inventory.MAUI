using System.Security.Cryptography;

namespace Inventory.MAUI.Services;

/// <summary>
/// Provides PBKDF2-based password hashing and verification using SHA-256.
/// Industry-standard key derivation (RFC 2898) with 128-bit salt and 256-bit derived key.
/// Uses 100,000 iterations per OWASP recommendations.
/// </summary>
public static class PasswordHasher
{
    private const int SaltSize = 16;       // 128-bit salt
    private const int KeySize = 32;        // 256-bit derived key
    private const int Iterations = 100_000; // OWASP recommended minimum

    /// <summary>
    /// Hashes a plaintext password and returns the salt and hash as Base64 strings.
    /// </summary>
    public static (string Salt, string Hash) HashPassword(string password)
    {
        var salt = RandomNumberGenerator.GetBytes(SaltSize);
        var hash = Rfc2898DeriveBytes.Pbkdf2(
            password,
            salt,
            Iterations,
            HashAlgorithmName.SHA256,
            KeySize);

        return (Convert.ToBase64String(salt), Convert.ToBase64String(hash));
    }

    /// <summary>
    /// Verifies a plaintext password against a stored salt and hash.
    /// Uses constant-time comparison to prevent timing attacks.
    /// </summary>
    public static bool Verify(string password, string storedSalt, string storedHash)
    {
        var salt = Convert.FromBase64String(storedSalt);
        var expectedHash = Convert.FromBase64String(storedHash);

        var actualHash = Rfc2898DeriveBytes.Pbkdf2(
            password,
            salt,
            Iterations,
            HashAlgorithmName.SHA256,
            KeySize);

        return CryptographicOperations.FixedTimeEquals(actualHash, expectedHash);
    }
}
