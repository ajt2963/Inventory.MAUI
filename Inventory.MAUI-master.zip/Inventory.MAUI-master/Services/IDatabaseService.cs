namespace Inventory.MAUI.Services;

/// <summary>
/// Provides database administration operations (backup, restore) via SQL Server T-SQL.
/// All file paths refer to locations on the SQL Server machine, not the client device.
/// </summary>
public interface IDatabaseService
{
    /// <summary>
    /// Backs up the database to a .bak file on the SQL Server machine.
    /// </summary>
    /// <param name="backupPath">Full file path on the server (e.g., C:\SQLBackups\UCOM_20250611.bak).</param>
    /// <returns>A status message describing the result.</returns>
    Task<string> BackupDatabaseAsync(string backupPath);

    /// <summary>
    /// Restores the database from a .bak file on the SQL Server machine.
    /// WARNING: This is destructive � all current data will be replaced.
    /// </summary>
    /// <param name="backupPath">Full file path on the server to restore from.</param>
    /// <returns>A status message describing the result.</returns>
    Task<string> RestoreDatabaseAsync(string backupPath);

    /// <summary>
    /// Gets the default backup directory on the SQL Server machine.
    /// </summary>
    Task<string?> GetDefaultBackupDirectoryAsync();

    /// <summary>
    /// Lists existing .bak files in a directory on the SQL Server machine.
    /// </summary>
    Task<List<string>> ListBackupFilesAsync(string directory);

    /// <summary>
    /// Gets the database name from the current connection.
    /// </summary>
    Task<string> GetDatabaseNameAsync();

    /// <summary>
    /// Detects whether the database is hosted on Azure SQL Database.
    /// When true, BACKUP/RESTORE TO DISK is not supported � Azure manages backups automatically.
    /// </summary>
    Task<bool> IsAzureSqlAsync();

    /// <summary>
    /// Gets a description of the SQL Server environment (edition, version, server name).
    /// </summary>
    Task<DatabaseEnvironmentInfo> GetEnvironmentInfoAsync();
}

/// <summary>
/// Describes the SQL Server environment for display in the admin UI.
/// </summary>
public sealed class DatabaseEnvironmentInfo
{
    public string ServerName { get; init; } = "";
    public string Edition { get; init; } = "";
    public string Version { get; init; } = "";
    public string DatabaseName { get; init; } = "";
    public bool IsAzure { get; init; }
}
