using System.Security.Cryptography;
using Inventory.MAUI.Data;
using Inventory.MAUI.Models;
using Microsoft.EntityFrameworkCore;

namespace Inventory.MAUI.Services;

/// <summary>
/// Persists user session lifecycle to the UserSession table.
/// All operations are resilient � failures are logged but never crash the app.
/// </summary>
public sealed class SessionService : ISessionService
{
    private readonly IDbContextFactory<InventoryDbContext> _contextFactory;

    private static readonly string CurrentPlatform = Microsoft.Maui.Devices.DeviceInfo.Current.Platform.ToString();
    private static readonly string CurrentDeviceInfo = BuildDeviceInfo();

    public SessionService(IDbContextFactory<InventoryDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<string> StartSessionAsync(int userId, string attuid)
    {
        var token = GenerateToken();

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            ctx.UserSession.Add(new UserSession
            {
                SessionToken = token,
                UserID = userId,
                ATTUID = attuid,
                StartedAtUtc = DateTime.UtcNow,
                LastActivityUtc = DateTime.UtcNow,
                Platform = CurrentPlatform,
                DeviceInfo = CurrentDeviceInfo
            });
            await ctx.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[SessionService] Failed to start session: {ex.Message}");
        }

        return token;
    }

    public async Task TouchSessionAsync(string sessionToken)
    {
        if (string.IsNullOrWhiteSpace(sessionToken))
            return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var session = await ctx.UserSession
                .FirstOrDefaultAsync(s => s.SessionToken == sessionToken && s.EndedAtUtc == null);

            if (session is not null)
            {
                session.LastActivityUtc = DateTime.UtcNow;
                await ctx.SaveChangesAsync();
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[SessionService] Failed to touch session: {ex.Message}");
        }
    }

    public async Task EndSessionAsync(string sessionToken, string endReason)
    {
        if (string.IsNullOrWhiteSpace(sessionToken))
            return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var session = await ctx.UserSession
                .FirstOrDefaultAsync(s => s.SessionToken == sessionToken && s.EndedAtUtc == null);

            if (session is not null)
            {
                session.EndedAtUtc = DateTime.UtcNow;
                session.EndReason = endReason;
                await ctx.SaveChangesAsync();
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[SessionService] Failed to end session: {ex.Message}");
        }
    }

    public async Task<List<UserSession>> GetActiveSessionsAsync(int? userId = null)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        var query = ctx.UserSession
            .Include(s => s.User)
            .Where(s => s.EndedAtUtc == null)
            .AsNoTracking();

        if (userId.HasValue)
            query = query.Where(s => s.UserID == userId.Value);

        return await query.OrderByDescending(s => s.LastActivityUtc).ToListAsync();
    }

    public async Task<List<UserSession>> GetRecentSessionsAsync(int count = 50)
    {
        await using var ctx = await _contextFactory.CreateDbContextAsync();
        return await ctx.UserSession
            .Include(s => s.User)
            .OrderByDescending(s => s.StartedAtUtc)
            .Take(count)
            .AsNoTracking()
            .ToListAsync();
    }

    public async Task TerminateUserSessionsAsync(int userId, string reason = "AdminTerminated")
    {
        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var activeSessions = await ctx.UserSession
                .Where(s => s.UserID == userId && s.EndedAtUtc == null)
                .ToListAsync();

            foreach (var session in activeSessions)
            {
                session.EndedAtUtc = DateTime.UtcNow;
                session.EndReason = reason;
            }

            await ctx.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[SessionService] Failed to terminate sessions: {ex.Message}");
        }
    }

    /// <summary>Generates a cryptographically random 32-byte session token as a hex string.</summary>
    private static string GenerateToken()
    {
        return Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
    }

    private static string BuildDeviceInfo()
    {
        try
        {
            var di = Microsoft.Maui.Devices.DeviceInfo.Current;
            return $"{di.Manufacturer} {di.Model} ({di.Platform} {di.VersionString})";
        }
        catch
        {
            return "Unknown";
        }
    }
}
