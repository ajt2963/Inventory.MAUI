using Microsoft.Maui.Graphics;

namespace Inventory.MAUI;

public sealed class ProgressRingDrawable : IDrawable
{
    public float Progress01 { get; set; }

    public float StrokeSize { get; set; } = 6;

    public Color TrackColor { get; set; } = Color.FromArgb("#E6E6E6");

    public Color ProgressColor { get; set; } = Color.FromArgb("#2E7D32");

    public void Draw(ICanvas canvas, RectF dirtyRect)
    {
        canvas.SaveState();

        var size = MathF.Min(dirtyRect.Width, dirtyRect.Height);
        var left = dirtyRect.X + (dirtyRect.Width - size) / 2f;
        var top = dirtyRect.Y + (dirtyRect.Height - size) / 2f;
        var rect = new RectF(left, top, size, size);

        var radiusInset = StrokeSize / 2f;
        rect = rect.Inflate(-radiusInset, -radiusInset);

        // Track
        canvas.StrokeColor = TrackColor;
        canvas.StrokeSize = StrokeSize;
        canvas.StrokeLineCap = LineCap.Round;
        canvas.DrawArc(rect, 0, 360, false, false);

        // Progress
        var p = Math.Clamp(Progress01, 0f, 1f);
        if (p > 0)
        {
            canvas.StrokeColor = ProgressColor;

            // Start at top (-90 degrees), sweep clockwise.
            var start = -90f;
            var sweep = 360f * p;
            canvas.DrawArc(rect, start, start + sweep, false, false);
        }

        canvas.RestoreState();
    }
}
