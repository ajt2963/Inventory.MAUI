namespace Inventory.MAUI.Pages;

public partial class InventoryRecordCrudPage : ContentPage
{
    public InventoryRecordCrudPage(InventoryRecordCrudView view)
    {
        InitializeComponent();
        Content = view;
    }
}
