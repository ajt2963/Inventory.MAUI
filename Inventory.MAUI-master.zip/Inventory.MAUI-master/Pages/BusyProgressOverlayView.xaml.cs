namespace Inventory.MAUI.Pages;

public partial class BusyProgressOverlayView : ContentView
{
    public BusyProgressOverlayView()
    {
        InitializeComponent();
    }
}
