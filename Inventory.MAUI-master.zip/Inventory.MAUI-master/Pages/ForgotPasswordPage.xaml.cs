using Inventory.MAUI.Services;

namespace Inventory.MAUI.Pages;

public partial class ForgotPasswordPage : ContentPage
{
    private readonly IPasswordResetService _resetService;
    private readonly PasswordPolicy _passwordPolicy;
    private string? _attuid;

    private IDispatcherTimer? _newPasswordRevealTimer;
    private IDispatcherTimer? _confirmPasswordRevealTimer;
    private static readonly TimeSpan RevealDuration = TimeSpan.FromSeconds(3);

    /// <summary>Raised when the password has been successfully reset.</summary>
    public event Action? PasswordResetCompleted;

    /// <summary>Raised when the user cancels and wants to go back to login.</summary>
    public event Action? Cancelled;

    public ForgotPasswordPage(IPasswordResetService resetService, PasswordPolicy passwordPolicy)
    {
        InitializeComponent();
        _resetService = resetService;
        _passwordPolicy = passwordPolicy;
    }

    private void ShowError(string message)
    {
        ErrorLabel.Text = message;
        ErrorBanner.IsVisible = true;
        ErrorBanner.BackgroundColor = Color.FromArgb("#FFEBEE");
        ErrorBanner.Stroke = new SolidColorBrush(Color.FromArgb("#EF9A9A"));
        ErrorLabel.TextColor = Color.FromArgb("#C62828");
    }

    private void ShowSuccess(string message)
    {
        ErrorLabel.Text = message;
        ErrorBanner.IsVisible = true;
        ErrorBanner.BackgroundColor = Color.FromArgb("#E8F5E9");
        ErrorBanner.Stroke = new SolidColorBrush(Color.FromArgb("#A5D6A7"));
        ErrorLabel.TextColor = Color.FromArgb("#2E7D32");
    }

    private void ClearError()
    {
        ErrorBanner.IsVisible = false;
        ErrorLabel.Text = string.Empty;
    }

    private async void OnRequestCodeClicked(object? sender, EventArgs e)
    {
        ClearError();

        var attuid = AttuidEntry.Text?.Trim();
        if (string.IsNullOrWhiteSpace(attuid))
        {
            ShowError("ATTUID is required.");
            AttuidEntry.Focus();
            return;
        }

        _attuid = attuid;
        RequestCodeButton.IsEnabled = false;

        try
        {
            if (!_resetService.IsAvailable)
            {
                ShowError("Self-service password recovery is not currently available.\nPlease contact your system administrator to reset your password.");
                return;
            }

            var sent = await _resetService.RequestResetAsync(attuid);
            if (sent)
            {
                ShowSuccess("A reset code has been sent to your registered email address.");
                SwitchToResetMode();
                CodeEntry.Focus();
            }
            else
            {
                ShowError("Unable to send reset code. Make sure your ATTUID is correct and you have an email address on file.");
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[IAM] Password reset request error: {ex.Message}");
            ShowError("An unexpected error occurred. Please try again.");
        }
        finally
        {
            RequestCodeButton.IsEnabled = true;
        }
    }

    private void SwitchToResetMode()
    {
        RequestSection.IsVisible = false;
        ResetSection.IsVisible = true;
        TitleLabel.Text = "Enter Reset Code";
        InstructionLabel.Text = $"A 6-digit code has been sent to your email. It expires in 15 minutes.";
    }

    private void OnCodeCompleted(object? sender, EventArgs e) => NewPasswordEntry.Focus();
    private void OnNewPasswordCompleted(object? sender, EventArgs e) => ConfirmPasswordEntry.Focus();

    private async void OnResetPasswordClicked(object? sender, EventArgs e)
    {
        ClearError();

        var code = CodeEntry.Text?.Trim();
        var newPassword = NewPasswordEntry.Text;
        var confirmPassword = ConfirmPasswordEntry.Text;

        if (string.IsNullOrWhiteSpace(code) || code.Length != 6)
        {
            ShowError("Please enter the 6-digit reset code.");
            CodeEntry.Focus();
            return;
        }

        if (string.IsNullOrWhiteSpace(newPassword))
        {
            ShowError("New password is required.");
            NewPasswordEntry.Focus();
            return;
        }

        var policyError = await _passwordPolicy.ValidateAsync(newPassword);
        if (policyError is not null)
        {
            ShowError(policyError);
            NewPasswordEntry.Focus();
            return;
        }

        if (newPassword != confirmPassword)
        {
            ShowError("Passwords do not match.");
            ConfirmPasswordEntry.Text = string.Empty;
            ConfirmPasswordEntry.Focus();
            return;
        }

        ResetPasswordButton.IsEnabled = false;
        HideAllPasswords();

        try
        {
            var error = await _resetService.ResetPasswordAsync(_attuid!, code, newPassword);
            if (error is null)
            {
                ShowSuccess("Your password has been reset successfully. You can now sign in.");

                // Clear fields
                CodeEntry.Text = string.Empty;
                NewPasswordEntry.Text = string.Empty;
                ConfirmPasswordEntry.Text = string.Empty;

                // Auto-navigate back after a brief delay
                await Task.Delay(1500);
                PasswordResetCompleted?.Invoke();
            }
            else
            {
                ShowError(error);
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[IAM] Password reset error: {ex.Message}");
            ShowError("An unexpected error occurred. Please try again.");
        }
        finally
        {
            ResetPasswordButton.IsEnabled = true;
        }
    }

    private async void OnResendCodeTapped(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(_attuid))
            return;

        ClearError();

        try
        {
            var sent = await _resetService.RequestResetAsync(_attuid);
            if (sent)
                ShowSuccess("A new code has been sent to your email.");
            else
                ShowError("Unable to resend code. Please try again.");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[IAM] Resend code error: {ex.Message}");
            ShowError("An unexpected error occurred.");
        }
    }

    private void OnCancelClicked(object? sender, EventArgs e)
    {
        HideAllPasswords();
        Cancelled?.Invoke();
    }

    private void OnToggleNewPasswordVisibility(object? sender, EventArgs e)
    {
        _newPasswordRevealTimer = ToggleVisibility(NewPasswordEntry, NewPasswordEyeButton, _newPasswordRevealTimer);
    }

    private void OnToggleConfirmPasswordVisibility(object? sender, EventArgs e)
    {
        _confirmPasswordRevealTimer = ToggleVisibility(ConfirmPasswordEntry, ConfirmPasswordEyeButton, _confirmPasswordRevealTimer);
    }

    private IDispatcherTimer? ToggleVisibility(Entry entry, ImageButton eyeButton, IDispatcherTimer? timer)
    {
        if (entry.IsPassword)
        {
            entry.IsPassword = false;
            eyeButton.Source = "eye_on.png";

            timer?.Stop();
            var newTimer = Dispatcher.CreateTimer();
            newTimer.Interval = RevealDuration;
            newTimer.IsRepeating = false;
            newTimer.Tick += (_, _) =>
            {
                MainThread.BeginInvokeOnMainThread(() => HidePassword(entry, eyeButton));
            };
            newTimer.Start();
            return newTimer;
        }
        else
        {
            HidePassword(entry, eyeButton);
            timer?.Stop();
            return null;
        }
    }

    private static void HidePassword(Entry entry, ImageButton eyeButton)
    {
        entry.IsPassword = true;
        eyeButton.Source = "eye_off.png";
    }

    private void HideAllPasswords()
    {
        _newPasswordRevealTimer?.Stop();
        _newPasswordRevealTimer = null;
        HidePassword(NewPasswordEntry, NewPasswordEyeButton);

        _confirmPasswordRevealTimer?.Stop();
        _confirmPasswordRevealTimer = null;
        HidePassword(ConfirmPasswordEntry, ConfirmPasswordEyeButton);
    }
}
