using Inventory.MAUI.ViewModels;

namespace Inventory.MAUI.Pages;

public partial class CalibrationLogView : ContentView
{
    private readonly CalibrationLogViewModel _vm;
    private Task? _initTask;

    public CalibrationLogView(CalibrationLogViewModel vm)
    {
        InitializeComponent();
        _vm = vm;
        BindingContext = _vm;

        _vm.AlertAsync = async (title, message) =>
        {
            var page = Application.Current?.Windows.FirstOrDefault()?.Page;
            if (page is not null)
                await page.DisplayAlert(title, message, "OK");
        };

        _vm.ConfirmAsync = async (title, message, accept, cancel) =>
        {
            var page = Application.Current?.Windows.FirstOrDefault()?.Page;
            if (page is null) return false;
            return await page.DisplayAlert(title, message, accept, cancel);
        };

        _vm.FocusedIndexChanged += OnFocusedIndexChanged;

        Loaded += (_, _) =>
        {
            _initTask ??= _vm.LoadAsync();
        };
    }

    private void OnFocusedIndexChanged(int index)
    {
        if (index < 0 || _vm.LogEntries.Count == 0) return;

        MainThread.BeginInvokeOnMainThread(() =>
        {
            try
            {
                if (DeviceInfo.Platform == DevicePlatform.Android)
                    AndroidCardList.ScrollTo(index, position: ScrollToPosition.Center, animate: false);
                else
                    DesktopList.ScrollTo(index, position: ScrollToPosition.Center, animate: false);
            }
            catch { }
        });
    }
}
