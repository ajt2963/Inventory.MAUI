using Inventory.MAUI.ViewModels;

namespace Inventory.MAUI.Pages;

public partial class CalibrationCompletionView : ContentView
{
    private readonly CalibrationCompletionViewModel _vm;
    private Task? _initTask;

    public CalibrationCompletionView(CalibrationCompletionViewModel vm)
    {
        InitializeComponent();
        _vm = vm;
        BindingContext = _vm;

        _vm.AlertAsync = async (title, message) =>
        {
            var page = Application.Current?.Windows.FirstOrDefault()?.Page;
            if (page is not null)
                await page.DisplayAlert(title, message, "OK");
        };

        _vm.ConfirmAsync = async (title, message, accept, cancel) =>
        {
            var page = Application.Current?.Windows.FirstOrDefault()?.Page;
            if (page is null) return false;
            return await page.DisplayAlert(title, message, accept, cancel);
        };

        Loaded += (_, _) =>
        {
            _initTask ??= _vm.LoadAsync();
        };
    }
}
