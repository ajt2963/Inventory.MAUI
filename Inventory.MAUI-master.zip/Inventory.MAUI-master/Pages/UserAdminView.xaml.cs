using Inventory.MAUI.Models;
using Inventory.MAUI.ViewModels;

namespace Inventory.MAUI.Pages;

public partial class UserAdminView : ContentView
{
    private readonly UserAdminViewModel _vm;
    private Task? _initTask;

    public UserAdminView(UserAdminViewModel vm)
    {
        InitializeComponent();
        _vm = vm;
        BindingContext = _vm;

        _vm.NotifyAsync = async (title, message) =>
        {
            var page = Application.Current?.Windows.FirstOrDefault()?.Page;
            if (page is not null)
                await page.DisplayAlert(title, message, "OK");
        };

        _vm.ConfirmAsync = async (title, message) =>
        {
            var page = Application.Current?.Windows.FirstOrDefault()?.Page;
            if (page is null) return false;
            return await page.DisplayAlert(title, message, "Yes", "No");
        };

        Loaded += (_, _) => { _initTask ??= _vm.InitializeAsync(); };
    }

    public Task EnsureInitializedAsync() => _initTask ??= _vm.InitializeAsync();

    private void OnUserCheckChanged(object? sender, CheckedChangedEventArgs e)
    {
        if (sender is CheckBox cb && cb.BindingContext is AppUser user)
            _vm.SelectUserCommand.Execute(user);
    }

    private void OnRoleCheckChanged(object? sender, CheckedChangedEventArgs e)
    {
        if (sender is CheckBox cb && cb.BindingContext is AppRole role)
            _vm.SelectRoleCommand.Execute(role);
    }
}
