using Inventory.MAUI.Models;
using Inventory.MAUI.Services;

namespace Inventory.MAUI.Pages;

public partial class DatabaseUtilitiesView : ContentView
{
    private readonly IDatabaseService _dbService;
    private readonly IAuditService _audit;
    private readonly AppSessionService _session;

    private string _activeTab = "Backup";
    private Task? _initTask;

    public DatabaseUtilitiesView(
        IDatabaseService dbService,
        IAuditService audit,
        AppSessionService session)
    {
        InitializeComponent();
        _dbService = dbService;
        _audit = audit;
        _session = session;

        BuildTabBar();
        ActivateTab("Backup");
    }

    public async Task EnsureInitializedAsync()
    {
        _initTask ??= LoadActiveTabAsync();
        await _initTask;
    }

    private void BuildTabBar()
    {
        var tabs = new[] { "Backup", "Restore", "Replication" };
        foreach (var tab in tabs)
        {
            var btn = new Button
            {
                Text = tab,
                FontSize = 12,
                HeightRequest = 34,
                Padding = new Thickness(14, 0),
                CornerRadius = 0,
                BorderWidth = 0,
                BackgroundColor = Colors.Transparent,
                TextColor = Color.FromArgb("#555")
            };
            btn.Clicked += (_, _) => ActivateTab(tab);
            DbTabBar.Add(btn);
        }
        UpdateTabStyles();
    }

    private void ActivateTab(string tab)
    {
        _activeTab = tab;
        UpdateTabStyles();
        _initTask = LoadActiveTabAsync();
    }

    private void UpdateTabStyles()
    {
        foreach (var child in DbTabBar)
        {
            if (child is Button btn)
            {
                var isActive = btn.Text == _activeTab;
                btn.BackgroundColor = isActive ? Color.FromArgb("#E3F2FD") : Colors.Transparent;
                btn.TextColor = isActive ? Color.FromArgb("#1565C0") : Color.FromArgb("#555");
                btn.FontAttributes = isActive ? FontAttributes.Bold : FontAttributes.None;
            }
        }
    }

    private async Task LoadActiveTabAsync()
    {
        View content = _activeTab switch
        {
            "Backup" => await BuildBackupViewAsync(),
            "Restore" => await BuildRestoreViewAsync(),
            "Replication" => BuildReplicationView(),
            _ => new Label { Text = "Unknown tab", Padding = new Thickness(16) }
        };

        DbTabContent.Content = content;
    }

    // ??? Backup Tab ????????????????????????????????????????????????????

    private async Task<View> BuildBackupViewAsync()
    {
        var envInfo = await _dbService.GetEnvironmentInfoAsync();

        if (envInfo.IsAzure)
            return BuildAzureNotSupportedView("Backup", envInfo);

        var dbName = envInfo.DatabaseName;
        var defaultDir = await _dbService.GetDefaultBackupDirectoryAsync() ?? @"C:\SQLBackups";
        var timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        var suggestedFile = $"{dbName.Replace(" ", "_")}_{timestamp}.bak";
        var suggestedPath = Path.Combine(defaultDir, suggestedFile);

        var pathEntry = new Entry
        {
            Text = suggestedPath,
            Placeholder = @"e.g., C:\SQLBackups\UCOM_Inventory_20250611.bak",
            HeightRequest = 32,
            FontSize = 13
        };

        var statusLabel = new Label { FontSize = 12, Margin = new Thickness(0, 4) };

        var backupButton = new Button
        {
            Text = "Start Backup",
            HeightRequest = 38,
            FontSize = 13,
            Padding = new Thickness(20, 0),
            BackgroundColor = Color.FromArgb("#1565C0"),
            TextColor = Colors.White
        };
        backupButton.Clicked += async (_, _) =>
        {
            var path = pathEntry.Text?.Trim();
            if (string.IsNullOrWhiteSpace(path))
            {
                statusLabel.TextColor = Color.FromArgb("#C62828");
                statusLabel.Text = "Please enter a backup file path.";
                return;
            }

            var page = Application.Current?.Windows.FirstOrDefault()?.Page;
            if (page is not null)
            {
                var confirm = await page.DisplayAlert("Confirm Backup",
                    $"Back up database '{dbName}' to:\n\n{path}\n\nThis file will be created on the SQL Server machine.",
                    "Backup", "Cancel");
                if (!confirm) return;
            }

            backupButton.IsEnabled = false;
            statusLabel.TextColor = Color.FromArgb("#666");
            statusLabel.Text = "Backup in progress... This may take a few minutes.";

            var result = await _dbService.BackupDatabaseAsync(path);

            var success = result.StartsWith("Backup completed", StringComparison.OrdinalIgnoreCase);
            statusLabel.TextColor = success ? Color.FromArgb("#2E7D32") : Color.FromArgb("#C62828");
            statusLabel.Text = result;
            backupButton.IsEnabled = true;

            if (success && page is not null)
                await page.DisplayAlert("Backup Successful", result, "OK");
        };

        return new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = new Thickness(16),
                Spacing = 12,
                Children =
                {
                    new Label { Text = "Database Backup", FontAttributes = FontAttributes.Bold, FontSize = 18 },
                    BuildEnvironmentInfoPanel(envInfo),
                    new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5") },
                    new Label
                    {
                        Text = "The backup file will be saved on the SQL Server machine.\nEnter the full server-side file path below.",
                        FontSize = 12, TextColor = Color.FromArgb("#666")
                    },
                    new Label { Text = "Backup file path (on server):", FontSize = 13, FontAttributes = FontAttributes.Bold },
                    pathEntry,
                    backupButton,
                    statusLabel,
                    new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5") },
                    new Label
                    {
                        Text = "Requirements:\n" +
                               "  \u2022 The SQL login must have db_backupoperator role or higher\n" +
                               "  \u2022 The destination folder must exist on the SQL Server\n" +
                               "  \u2022 SQL Server service account must have write access to the folder",
                        FontSize = 11, TextColor = Color.FromArgb("#888")
                    }
                }
            }
        };
    }

    // ??? Restore Tab ???????????????????????????????????????????????????

    private async Task<View> BuildRestoreViewAsync()
    {
        var envInfo = await _dbService.GetEnvironmentInfoAsync();

        if (envInfo.IsAzure)
            return BuildAzureNotSupportedView("Restore", envInfo);

        var dbName = envInfo.DatabaseName;
        var defaultDir = await _dbService.GetDefaultBackupDirectoryAsync() ?? @"C:\SQLBackups";

        var pathEntry = new Entry
        {
            Text = "",
            Placeholder = @"e.g., C:\SQLBackups\UCOM_Inventory_20250611.bak",
            HeightRequest = 32,
            FontSize = 13
        };

        var statusLabel = new Label { FontSize = 12, Margin = new Thickness(0, 4) };

        // List available backups
        var backupListLabel = new Label
        {
            Text = $"Available backups in: {defaultDir}",
            FontSize = 13, FontAttributes = FontAttributes.Bold
        };
        var backupList = new VerticalStackLayout { Spacing = 2 };

        var files = await _dbService.ListBackupFilesAsync(defaultDir);
        if (files.Count == 0)
        {
            backupList.Children.Add(new Label
            {
                Text = "No .bak files found in the default backup directory.",
                FontSize = 11, TextColor = Color.FromArgb("#888")
            });
        }
        else
        {
            foreach (var file in files)
            {
                var fullPath = Path.Combine(defaultDir, file);
                var fileBtn = new Button
                {
                    Text = file,
                    FontSize = 11,
                    HeightRequest = 28,
                    Padding = new Thickness(10, 0),
                    BackgroundColor = Color.FromArgb("#F5F5F5"),
                    TextColor = Color.FromArgb("#333"),
                    HorizontalOptions = LayoutOptions.Start
                };
                fileBtn.Clicked += (_, _) => pathEntry.Text = fullPath;
                backupList.Children.Add(fileBtn);
            }
        }

        var restoreButton = new Button
        {
            Text = "Restore Database",
            HeightRequest = 38,
            FontSize = 13,
            Padding = new Thickness(20, 0),
            BackgroundColor = Color.FromArgb("#C62828"),
            TextColor = Colors.White
        };
        restoreButton.Clicked += async (_, _) =>
        {
            var path = pathEntry.Text?.Trim();
            if (string.IsNullOrWhiteSpace(path))
            {
                statusLabel.TextColor = Color.FromArgb("#C62828");
                statusLabel.Text = "Please enter or select a backup file path.";
                return;
            }

            var page = Application.Current?.Windows.FirstOrDefault()?.Page;
            if (page is null) return;

            var confirm1 = await page.DisplayAlert("WARNING: Destructive Operation",
                $"Restoring from a backup will REPLACE ALL CURRENT DATA in '{dbName}'.\n\n" +
                $"Restore from:\n{path}\n\n" +
                "All connected users will be disconnected.\n\nAre you sure?",
                "Continue", "Cancel");
            if (!confirm1) return;

            var confirm2 = await page.DisplayAlert("Final Confirmation",
                "Type 'RESTORE' in your mind. This cannot be undone.\n\nProceed with restore?",
                "Yes, Restore Now", "Cancel");
            if (!confirm2) return;

            restoreButton.IsEnabled = false;
            statusLabel.TextColor = Color.FromArgb("#666");
            statusLabel.Text = "Restore in progress... All other connections will be terminated. This may take several minutes.";

            var result = await _dbService.RestoreDatabaseAsync(path);

            var success = result.StartsWith("Restore completed", StringComparison.OrdinalIgnoreCase);
            statusLabel.TextColor = success ? Color.FromArgb("#2E7D32") : Color.FromArgb("#C62828");
            statusLabel.Text = result;
            restoreButton.IsEnabled = true;

            await page.DisplayAlert(
                success ? "Restore Successful" : "Restore Failed",
                result, "OK");
        };

        return new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = new Thickness(16),
                Spacing = 12,
                Children =
                {
                    new Label { Text = "Database Restore", FontAttributes = FontAttributes.Bold, FontSize = 18 },
                    BuildEnvironmentInfoPanel(envInfo),
                    new Border
                    {
                        Stroke = Color.FromArgb("#C62828"),
                        StrokeThickness = 1,
                        BackgroundColor = Color.FromArgb("#FFF3F0"),
                        Padding = new Thickness(12),
                        Content = new Label
                        {
                            Text = "\u26a0 WARNING: Restoring a database is a destructive operation.\n" +
                                   "All current data will be replaced with the backup contents.\n" +
                                   "All active connections will be terminated.",
                            FontSize = 12, TextColor = Color.FromArgb("#C62828")
                        }
                    },
                    new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5") },
                    backupListLabel,
                    backupList,
                    new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5") },
                    new Label { Text = "Backup file path (on server):", FontSize = 13, FontAttributes = FontAttributes.Bold },
                    pathEntry,
                    restoreButton,
                    statusLabel,
                    new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5") },
                    new Label
                    {
                        Text = "Requirements:\n" +
                               "  \u2022 The SQL login must have dbcreator server role or sysadmin\n" +
                               "  \u2022 The .bak file must exist on the SQL Server machine\n" +
                               "  \u2022 The backup must be from the same or older SQL Server version",
                        FontSize = 11, TextColor = Color.FromArgb("#888")
                    }
                }
            }
        };
    }

    // ??? Replication Tab ???????????????????????????????????????????????

    private static View BuildReplicationView()
    {
        return new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = new Thickness(16),
                Spacing = 12,
                Children =
                {
                    new Label { Text = "Database Replication", FontAttributes = FontAttributes.Bold, FontSize = 18 },
                    new Border
                    {
                        Stroke = Color.FromArgb("#E65100"),
                        StrokeThickness = 1,
                        BackgroundColor = Color.FromArgb("#FFF8E1"),
                        Padding = new Thickness(12),
                        Content = new Label
                        {
                            Text = "Database replication is not yet available.\n\n" +
                                   "This feature will provide the ability to export and import the database " +
                                   "to another SQL Server instance for disaster recovery, " +
                                   "site synchronization, or read-only reporting purposes.\n\n" +
                                   "Configuration options will be available here once implemented.",
                            FontSize = 12, TextColor = Color.FromArgb("#E65100")
                        }
                    },
                    new Label
                    {
                        Text = "Planned capabilities:\n" +
                               "  \u2022 Export database to portable SQL script\n" +
                               "  \u2022 Import from SQL script into a target server\n" +
                               "  \u2022 Scheduled automated replication\n" +
                               "  \u2022 Conflict resolution for bidirectional sync",
                        FontSize = 12, TextColor = Color.FromArgb("#666")
                    }
                }
            }
        };
    }

    // ??? Azure SQL Info View ???????????????????????????????????????????

    private static View BuildAzureNotSupportedView(string operation, DatabaseEnvironmentInfo env)
    {
        return new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = new Thickness(16),
                Spacing = 12,
                Children =
                {
                    new Label { Text = $"Database {operation}", FontAttributes = FontAttributes.Bold, FontSize = 18 },
                    BuildEnvironmentInfoPanel(env),
                    new Border
                    {
                        Stroke = Color.FromArgb("#1565C0"),
                        StrokeThickness = 1,
                        BackgroundColor = Color.FromArgb("#E3F2FD"),
                        Padding = new Thickness(12),
                        Content = new Label
                        {
                            Text = $"BACKUP/RESTORE TO DISK is not available on Azure SQL Database.\n\n" +
                                   "Azure manages database backups automatically. You can:\n\n" +
                                   "  \u2022 Point-in-time restore (up to 35 days) via Azure Portal\n" +
                                   "  \u2022 Long-term retention (LTR) backups via Azure Portal\n" +
                                   "  \u2022 Geo-restore from geo-redundant backups\n" +
                                   "  \u2022 Export to BACPAC via Azure Portal or SqlPackage CLI\n" +
                                   "  \u2022 Copy database using CREATE DATABASE ... AS COPY OF\n\n" +
                                   "These operations must be performed through the Azure Portal or Azure CLI.",
                            FontSize = 12, TextColor = Color.FromArgb("#1565C0")
                        }
                    },
                    new Label
                    {
                        Text = "Azure Portal: https://portal.azure.com\n" +
                               "Navigate to: SQL databases > your database > Backups",
                        FontSize = 11, TextColor = Color.FromArgb("#666")
                    }
                }
            }
        };
    }

    private static View BuildEnvironmentInfoPanel(DatabaseEnvironmentInfo env)
    {
        return new Border
        {
            Stroke = Color.FromArgb("#DDD"),
            StrokeThickness = 1,
            BackgroundColor = Color.FromArgb("#FAFAFA"),
            Padding = new Thickness(12),
            Content = new VerticalStackLayout
            {
                Spacing = 4,
                Children =
                {
                    new Label { Text = "Server Environment", FontAttributes = FontAttributes.Bold, FontSize = 14 },
                    InfoRow("Server:", env.ServerName),
                    InfoRow("Edition:", env.Edition),
                    InfoRow("Version:", env.Version),
                    InfoRow("Database:", env.DatabaseName),
                    InfoRow("Type:", env.IsAzure ? "Azure SQL Database" : "On-Premises / Local SQL Server")
                }
            }
        };
    }

    private static View InfoRow(string label, string value)
    {
        return new HorizontalStackLayout
        {
            Spacing = 8,
            Children =
            {
                new Label { Text = label, FontSize = 12, FontAttributes = FontAttributes.Bold, WidthRequest = 80 },
                new Label { Text = value, FontSize = 12, TextColor = Color.FromArgb("#444") }
            }
        };
    }
}
