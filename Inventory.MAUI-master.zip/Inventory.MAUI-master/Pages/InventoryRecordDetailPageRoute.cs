using Inventory.MAUI.Models;

namespace Inventory.MAUI.Pages;

public static class InventoryRecordDetailPageRoute
{
    public const string Route = nameof(InventoryRecordDetailPage);

    public static IDictionary<string, object> CreateParameters(InventoryList record)
        => new Dictionary<string, object> { ["Record"] = record };
}
