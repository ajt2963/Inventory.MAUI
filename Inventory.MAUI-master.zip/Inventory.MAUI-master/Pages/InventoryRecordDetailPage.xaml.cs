using Inventory.MAUI.Models;

namespace Inventory.MAUI.Pages;

[QueryProperty(nameof(Record), "Record")]
public partial class InventoryRecordDetailPage : ContentPage
{
    private InventoryList? _record;

    public InventoryList? Record
    {
        get => _record;
        set
        {
            _record = value;
            BindingContext = value;
        }
    }

    public InventoryRecordDetailPage()
    {
        InitializeComponent();
    }

    public InventoryRecordDetailPage(InventoryList record) : this()
    {
        Record = record;
    }
}
