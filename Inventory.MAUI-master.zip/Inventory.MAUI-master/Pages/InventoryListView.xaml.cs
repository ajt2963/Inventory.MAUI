using Inventory.MAUI.Core.ViewModels;

namespace Inventory.MAUI.Pages;

public partial class InventoryListView : ContentView
{
    private readonly InventoryListViewModel _viewModel;
    private Task? _initTask;

    private bool _loadedHandlerWired;

#if WINDOWS
    private Microsoft.UI.Xaml.Controls.Control? _nativeControl;
    private DateTime _lastKeyAtUtc;
    private Windows.System.VirtualKey? _lastKey;
    private bool _keyboardReady;
    private bool _focusRequested;
    private bool _wired;

    private DateTime _lastEndHandledAtUtc;
#endif

    private bool _scrollToEndPending;
    private CancellationTokenSource? _repeatCts;

    /// <summary>
    /// Returns the platform-appropriate CollectionView.
    /// On Android we use a separate CollectionView (not wrapped in ScrollView)
    /// to preserve RecyclerView virtualization.
    /// </summary>
    private CollectionView ActiveList =>
#if ANDROID
        AndroidInventoryList;
#else
        InventoryList;
#endif

    public InventoryListView(InventoryListViewModel viewModel)
    {
        InitializeComponent();
        _viewModel = viewModel;
        BindingContext = _viewModel;

        _viewModel.DebugLog = static msg => System.Diagnostics.Debug.WriteLine(msg);

        // Disable infinite scroll; navigation uses explicit paging/windowing and should not race with auto-append.
        ActiveList.RemainingItemsThreshold = -1;
        ActiveList.RemainingItemsThresholdReached -= OnRemainingItemsThresholdReached;

        // Prevent buttons from becoming default/focused targets that can be activated by Enter/Space after key navigation.
        // (MAUI Button doesn't expose IsTabStop; we handle this by refocusing the list after navigation.)

        // After any navigation, we re-focus the list so keyboard input doesn't accidentally activate a focused button.

        if (!_loadedHandlerWired)
        {
            _loadedHandlerWired = true;
            Loaded += (_, _) => { _initTask ??= InitializeOnceAsync(); };
        }

        // Apply permission-based visibility on load
        Loaded += OnApplyPermissions;
    }

    private void OnApplyPermissions(object? sender, EventArgs e)
    {
        Loaded -= OnApplyPermissions;

        var session = Services.AppServices.Get<Services.AppSessionService>();
        var canEdit = session?.CanEdit ?? false;
        PhoneEditButton.IsVisible = canEdit;
    }

    private void RefocusList()
    {
#if WINDOWS
        MainThread.BeginInvokeOnMainThread(EnsureKeyboardWiredAndFocused);
#endif
    }

#if WINDOWS
    private void EnsureKeyboardWiredAndFocused()
    {
        _nativeControl ??= InventoryList.Handler?.PlatformView as Microsoft.UI.Xaml.Controls.Control;
        if (_nativeControl is null)
            return;

        if (!_wired)
        {
            _wired = true;
            _nativeControl.IsTabStop = true;

            _nativeControl.PreviewKeyDown -= OnNativePreviewKeyDown;
            _nativeControl.PreviewKeyDown += OnNativePreviewKeyDown;

            _nativeControl.GotFocus -= OnNativeGotFocus;
            _nativeControl.GotFocus += OnNativeGotFocus;
        }

        _lastKey = null;
        _lastKeyAtUtc = DateTime.MinValue;

        if (!_focusRequested)
        {
            _focusRequested = true;
            _nativeControl.Focus(Microsoft.UI.Xaml.FocusState.Programmatic);
        }
    }

    private void OnNativeGotFocus(object sender, Microsoft.UI.Xaml.RoutedEventArgs e)
    {
        // Reset debounce state when focus enters the list so the very first key press is never suppressed.
        _lastKey = null;
        _lastKeyAtUtc = DateTime.MinValue;

        if (_viewModel.SelectedRow is null && _viewModel.Rows.Count > 0)
            _viewModel.SelectedRow = _viewModel.Rows[0];
    }

    private void OnNativePreviewKeyDown(object sender, Microsoft.UI.Xaml.Input.KeyRoutedEventArgs e)
    {
        // Ensure we have a deterministic selection.
        if (_viewModel.SelectedRow is null && _viewModel.Rows.Count > 0)
            _viewModel.SelectedRow = _viewModel.Rows[0];

        var key = e.Key;

        if (_keyboardReady && ShouldDebounce(key))
        {
            e.Handled = true;
            return;
        }

        switch (key)
        {
            case Windows.System.VirtualKey.Up:
            case Windows.System.VirtualKey.Down:
            case Windows.System.VirtualKey.Home:
            case Windows.System.VirtualKey.End:
            case Windows.System.VirtualKey.PageUp:
            case Windows.System.VirtualKey.PageDown:
                e.Handled = true;
                break;
            default:
                return;
        }

        // Route to existing logic.
        OnKeyNavigate(key);
    }
#endif

    private async Task InitializeOnceAsync()
    {
        try
        {
            System.Diagnostics.Debug.WriteLine("Starting ViewModel.InitializeAsync...");
            await _viewModel.InitializeAsync();
            System.Diagnostics.Debug.WriteLine("ViewModel.InitializeAsync completed successfully");

            if (_viewModel.SelectedRow is not null)
                ActiveList.ScrollTo(_viewModel.SelectedRow, position: ScrollToPosition.Center, animate: false);

#if WINDOWS
            MainThread.BeginInvokeOnMainThread(() =>
            {
                EnsureKeyboardWiredAndFocused();
                _keyboardReady = true;
            });
#endif
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"InventoryListView InitializeOnceAsync failed: {ex.GetType().Name}: {ex.Message}");
            System.Diagnostics.Debug.WriteLine($"Stack trace: {ex.StackTrace}");
            
            await MainThread.InvokeOnMainThreadAsync(async () =>
            {
                await Application.Current?.MainPage?.DisplayAlert(
                    "Error Loading Data",
                    $"Unable to load inventory data.\n\nError: {ex.Message}\n\nType: {ex.GetType().Name}",
                    "OK");
            });
        }
    }

#if WINDOWS
    private bool ShouldDebounce(Windows.System.VirtualKey key)
    {
        var now = DateTime.UtcNow;

        // Page/Home/End trigger window reloads so keep a wider debounce.
        // Up/Down are lightweight local moves � allow faster repeat to match touch feel.
        var minIntervalMs = key is Windows.System.VirtualKey.PageUp or Windows.System.VirtualKey.PageDown
            or Windows.System.VirtualKey.Home or Windows.System.VirtualKey.End
            ? 120
            : 16;

        if (_lastKey == key && (now - _lastKeyAtUtc).TotalMilliseconds < minIntervalMs)
            return true;

        _lastKey = key;
        _lastKeyAtUtc = now;
        return false;
    }

    private bool ShouldSuppressHome()
        => (DateTime.UtcNow - _lastEndHandledAtUtc) < TimeSpan.FromMilliseconds(600);
#endif

    public Task EnsureInitializedAsync() => _initTask ??= InitializeOnceAsync();

    private void OnRemainingItemsThresholdReached(object? sender, EventArgs e)
    {
        if (_viewModel.CanLoadMore)
            _ = RunExclusiveAsync(() => _viewModel.LoadMoreCommand.ExecuteAsync());
    }

    private void OnSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        _viewModel.OnSelectionChanged(e.CurrentSelection);

        if (_scrollToEndPending && _viewModel.SelectedRow is not null)
        {
            _scrollToEndPending = false;
            ScheduleScrollToEndOverrides();
        }

        // After clicking a row with the mouse, ensure the list retains keyboard focus
        // so arrow keys work immediately without an extra click.
        RefocusList();
    }

    private void ScheduleScrollToEndOverrides()
    {
#if WINDOWS
        // Use native WinUI ScrollViewer for reliable scroll-to-bottom.
        // MAUI's CollectionView.ScrollTo uses MakeVisible which doesn't always reach the true bottom.
        // We must keep retrying because ScrollableHeight grows as items are realized by the virtualizing panel.
        MainThread.BeginInvokeOnMainThread(() =>
        {
            var attempts = 0;
            void TryScroll()
            {
                attempts++;
                try
                {
                    if (InventoryList.Handler?.PlatformView is Microsoft.UI.Xaml.Controls.ListViewBase list)
                    {
                        var sv = FindScrollViewer(list);
                        if (sv is not null && sv.ScrollableHeight > 0)
                        {
                            sv.ChangeView(null, sv.ScrollableHeight, null, disableAnimation: true);
                        }
                    }
                }
                catch { }

                // Keep retrying � ScrollableHeight may still be growing as items virtualize in.
                if (attempts < 20)
                    Dispatcher.DispatchDelayed(TimeSpan.FromMilliseconds(attempts <= 5 ? 30 : 80), TryScroll);
            }

            TryScroll();
        });
#else
        for (var delayMs = 50; delayMs <= 600; delayMs += 100)
        {
            var d = delayMs;
            Dispatcher.DispatchDelayed(TimeSpan.FromMilliseconds(d), () =>
            {
                if (_viewModel.Rows.Count == 0) return;
                try
                {
                    ActiveList.ScrollTo(_viewModel.Rows.Count - 1, position: ScrollToPosition.End, animate: false);
                }
                catch { }
            });
        }
#endif
    }

#if WINDOWS
    private static Microsoft.UI.Xaml.Controls.ScrollViewer? FindScrollViewer(Microsoft.UI.Xaml.DependencyObject root)
    {
        if (root is Microsoft.UI.Xaml.Controls.ScrollViewer sv) return sv;
        var count = Microsoft.UI.Xaml.Media.VisualTreeHelper.GetChildrenCount(root);
        for (var i = 0; i < count; i++)
        {
            var found = FindScrollViewer(Microsoft.UI.Xaml.Media.VisualTreeHelper.GetChild(root, i));
            if (found is not null) return found;
        }
        return null;
    }
#endif

    private Task _actionGate = Task.CompletedTask;

    private Task RunExclusiveAsync(Func<Task> action)
    {
        if (!_actionGate.IsCompleted)
            return _actionGate;

        return _actionGate = action();
    }

    private void OnSearchClicked(object sender, EventArgs e)
        => _ = RunExclusiveAsync(() => _viewModel.SearchCommand.ExecuteAsync());

    private void OnClearClicked(object sender, EventArgs e)
        => _ = RunExclusiveAsync(() => _viewModel.ClearCommand.ExecuteAsync());

    private void OnMoveFirstClicked(object sender, EventArgs e)
        => _ = RunExclusiveAsync(async () =>
        {
            await _viewModel.MoveToFirstAsync();
            ScrollSelectionIntoView(ScrollToPosition.Start);
            RefocusList();
        });

    private void OnMoveLastClicked(object sender, EventArgs e)
        => _ = RunExclusiveAsync(async () =>
        {
            _scrollToEndPending = true;
            await _viewModel.MoveToLastAsync();
            ScrollToLastItem();
            RefocusList();
        });

    public event Action<int>? EditRequested;

    private void OnEditClicked(object sender, EventArgs e)
    {
        var session = Services.AppServices.Get<Services.AppSessionService>();
        if (session is not null && !session.CanEdit)
            return;

        var id = _viewModel.SelectedRow?.InventoryID;
        if (id is null)
            return;

        EditRequested?.Invoke(id.Value);
    }

    private void OnRowDoubleTapped(object sender, TappedEventArgs e)
    {
        var session = Services.AppServices.Get<Services.AppSessionService>();
        if (session is not null && !session.CanEdit)
            return;

        if (e.Parameter is Inventory.MAUI.Core.ViewModels.InventoryListRow row && row.InventoryID is not null)
        {
            EditRequested?.Invoke(row.InventoryID.Value);
            return;
        }

        var id = _viewModel.SelectedRow?.InventoryID;
        if (id is null)
            return;

        EditRequested?.Invoke(id.Value);
    }

#if WINDOWS
    private void OnRootLoaded(object? sender, EventArgs e)
    {
        if (_wired)
            return;

        var attempts = 0;
        void TryWire()
        {
            attempts++;
            if (InventoryList.Handler?.PlatformView is Microsoft.UI.Xaml.Controls.Control)
            {
                EnsureKeyboardWiredAndFocused();
                return;
            }

            if (attempts < 10)
                Dispatcher.DispatchDelayed(TimeSpan.FromMilliseconds(50), TryWire);
        }

        TryWire();
    }
#else
    private void OnRootLoaded(object? sender, EventArgs e)
    {
    }
#endif

#if WINDOWS
    private async Task PageMoveAsync(int direction)
    {
        var viewportHeight = ActiveList.Height;
        var rowHeight = 34d;
        var pageSize = viewportHeight > 0 ? Math.Max(1, (int)(viewportHeight / rowHeight) - 1) : 20;

        if (_viewModel.Rows.Count == 0)
            return;

        var current = _viewModel.SelectedRowIndex;
        if (current < 0)
            current = 0;

        var target = current + (direction * pageSize);

        if (direction < 0)
        {
            while (target < _viewModel.SelectedRowIndex)
                await _viewModel.MovePreviousAsync();
        }
        else
        {
            while (target > _viewModel.SelectedRowIndex)
                await _viewModel.MoveNextAsync();
        }

        ScrollSelectionIntoView();
    }
#endif

    private void ScrollSelectionIntoView(ScrollToPosition position)
    {
        if (_viewModel.SelectedRow is null)
            return;

        MainThread.BeginInvokeOnMainThread(() =>
        {
            try
            {
                ActiveList.ScrollTo(_viewModel.SelectedRow, position: position, animate: false);
            }
            catch
            {
            }
        });
    }

    private void ScrollSelectionIntoView()
        => ScrollSelectionIntoView(ScrollToPosition.Center);

#if WINDOWS
    private void OnKeyNavigate(Windows.System.VirtualKey key)
    {
        switch (key)
        {
            case Windows.System.VirtualKey.End:
                _lastEndHandledAtUtc = DateTime.UtcNow;

                RefocusList();

                _ = RunExclusiveAsync(async () =>
                {
                    _scrollToEndPending = true;
                    await _viewModel.MoveToLastAsync();
                    ScrollToLastItem();
                    RefocusList();
                });
                break;

            case Windows.System.VirtualKey.Home:
                if (ShouldSuppressHome())
                    return;

                RefocusList();

                _ = RunExclusiveAsync(async () =>
                {
                    await _viewModel.MoveToFirstAsync();
                    ScrollSelectionIntoView();
                    RefocusList();
                });
                break;

            case Windows.System.VirtualKey.Up:
                {
                    var idx = _viewModel.SelectedRowIndex;
                    if (idx > 0)
                    {
                        // Fast local move � synchronous, no gate contention.
                        _viewModel.SelectedRow = _viewModel.Rows[idx - 1];
                        ScrollSelectionIntoView();
                    }
                    else
                    {
                        _ = RunExclusiveAsync(async () =>
                        {
                            await _viewModel.MovePreviousAsync();
                            ScrollSelectionIntoView();
                        });
                    }
                    break;
                }

            case Windows.System.VirtualKey.Down:
                {
                    var idx = _viewModel.SelectedRowIndex;
                    if (idx >= 0 && idx < _viewModel.Rows.Count - 1)
                    {
                        // Fast local move � synchronous, no gate contention.
                        _viewModel.SelectedRow = _viewModel.Rows[idx + 1];
                        ScrollSelectionIntoView();
                    }
                    else
                    {
                        _ = RunExclusiveAsync(async () =>
                        {
                            await _viewModel.MoveNextAsync();
                            ScrollSelectionIntoView();
                        });
                    }
                    break;
                }

            case Windows.System.VirtualKey.PageUp:
                _ = RunExclusiveAsync(async () => await PageMoveAsync(direction: -1));
                break;

            case Windows.System.VirtualKey.PageDown:
                _ = RunExclusiveAsync(async () => await PageMoveAsync(direction: +1));
                break;
        }
    }
#endif

    private void ScrollToLastItem()
    {
        if (_viewModel.Rows.Count == 0)
            return;

        var lastIndex = _viewModel.Rows.Count - 1;

        MainThread.BeginInvokeOnMainThread(() =>
        {
            try
            {
                ActiveList.ScrollTo(lastIndex, position: ScrollToPosition.End, animate: false);
            }
            catch { }
        });
    }

    private void OnMovePreviousPressed(object sender, EventArgs e)
        => StartRepeatNavigation(isNext: false);

    private void OnMovePreviousReleased(object sender, EventArgs e)
        => StopRepeatNavigation();

    private void OnMoveNextPressed(object sender, EventArgs e)
        => StartRepeatNavigation(isNext: true);

    private void OnMoveNextReleased(object sender, EventArgs e)
        => StopRepeatNavigation();

    private void StartRepeatNavigation(bool isNext)
    {
        StopRepeatNavigation();
        _repeatCts = new CancellationTokenSource();
        _ = RepeatNavigationLoopAsync(isNext, _repeatCts.Token);
    }

    private void StopRepeatNavigation()
    {
        try { _repeatCts?.Cancel(); } catch { }
        _repeatCts?.Dispose();
        _repeatCts = null;
    }

    private async Task RepeatNavigationLoopAsync(bool isNext, CancellationToken token)
    {
        const int initialDelayMs = 300;
        const int repeatDelayMs = 120;

        try
        {
            // First move immediately
            await PerformSingleMove(isNext);

            // Wait longer before starting repeat
            await Task.Delay(initialDelayMs, token);

            // Repeat while held
            while (!token.IsCancellationRequested)
            {
                await PerformSingleMove(isNext);
                await Task.Delay(repeatDelayMs, token);
            }
        }
        catch (OperationCanceledException)
        {
            // Expected when button is released
        }
    }

    private async Task PerformSingleMove(bool isNext)
    {
        if (isNext)
            await _viewModel.MoveNextAsync();
        else
            await _viewModel.MovePreviousAsync();

        ScrollSelectionIntoView();
    }
}
