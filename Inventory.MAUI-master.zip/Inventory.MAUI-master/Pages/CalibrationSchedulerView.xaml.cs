using Inventory.MAUI.ViewModels;

namespace Inventory.MAUI.Pages;

public partial class CalibrationSchedulerView : ContentView
{
    private readonly CalibrationSchedulerViewModel _vm;
    private Task? _initTask;

    public CalibrationSchedulerView(CalibrationSchedulerViewModel vm)
    {
        InitializeComponent();
        _vm = vm;
        BindingContext = _vm;

        _vm.AlertAsync = async (title, message) =>
        {
            var page = Application.Current?.Windows.FirstOrDefault()?.Page;
            if (page is not null)
                await page.DisplayAlert(title, message, "OK");
        };

        _vm.ConfirmAsync = async (title, message, accept, cancel) =>
        {
            var page = Application.Current?.Windows.FirstOrDefault()?.Page;
            if (page is null) return false;
            return await page.DisplayAlert(title, message, accept, cancel);
        };

#if !ANDROID
        _vm.ActionSheetAsync = async (title, cancel, destruction, buttons) =>
        {
            var page = Application.Current?.Windows.FirstOrDefault()?.Page;
            if (page is null) return cancel;
            return await page.DisplayActionSheet(title, cancel, destruction, buttons);
        };

        _vm.PickSaveFileAsync = PickSaveFileAsync;
#endif

        Loaded += (_, _) =>
        {
            _initTask ??= _vm.InitializeAsync();
        };
    }

#if !ANDROID
    private static string GetDefaultExcelFolder()
    {
#if WINDOWS
        return @"C:\AppData\Excel";
#else
        return Path.Combine(FileSystem.AppDataDirectory, "Excel");
#endif
    }

    private static async Task<string?> PickSaveFileAsync()
    {
        var excelFolder = GetDefaultExcelFolder();
        Directory.CreateDirectory(excelFolder);

#if WINDOWS
        var picker = new Windows.Storage.Pickers.FileSavePicker
        {
            SuggestedStartLocation = Windows.Storage.Pickers.PickerLocationId.DocumentsLibrary,
            SuggestedFileName = $"CalibrationSchedule_{DateTime.Today:yyyyMMdd}",
        };
        picker.FileTypeChoices.Add("Excel Workbook", [".xlsx"]);

        var defaultFolder = await Windows.Storage.StorageFolder.GetFolderFromPathAsync(excelFolder);
        if (defaultFolder is not null)
            picker.SuggestedStartLocation = Windows.Storage.Pickers.PickerLocationId.DocumentsLibrary;

        var hwnd = ((MauiWinUIWindow)Application.Current!.Windows[0].Handler!.PlatformView!).WindowHandle;
        WinRT.Interop.InitializeWithWindow.Initialize(picker, hwnd);

        var file = await picker.PickSaveFileAsync();
        return file?.Path;
#else
        var fileName = $"CalibrationSchedule_{DateTime.Today:yyyyMMdd}.xlsx";
        var filePath = Path.Combine(excelFolder, fileName);
        await Task.CompletedTask;
        return filePath;
#endif
    }
#endif
}
