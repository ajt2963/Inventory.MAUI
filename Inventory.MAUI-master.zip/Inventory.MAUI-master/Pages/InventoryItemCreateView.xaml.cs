using Inventory.MAUI.ViewModels;

namespace Inventory.MAUI.Pages;

public partial class InventoryItemCreateView : ContentView
{
    private readonly InventoryItemCreateViewModel _vm;
    private Task? _initTask;

    public InventoryItemCreateView(InventoryItemCreateViewModel vm)
    {
        InitializeComponent();
        _vm = vm;
        BindingContext = _vm;

        _vm.NotifyAsync = async (title, message) =>
        {
            var page = Application.Current?.Windows.FirstOrDefault()?.Page;
            if (page is not null)
                await page.DisplayAlert(title, message, "OK");
        };

        Loaded += (_, _) =>
        {
            _initTask ??= _vm.InitializeAsync();
        };
    }
}
