using Inventory.MAUI.Core.ViewModels;
using Microsoft.Maui.Controls.Shapes;

namespace Inventory.MAUI.Pages;

public partial class DashboardView : ContentView
{
    private readonly DashboardViewModel _viewModel;
    private Task? _initTask;

    /// <summary>
    /// Raised on phone when a location is tapped.
    /// The subscriber (MainPage) should navigate to the Inventory List filtered by this CLLI code.
    /// </summary>
    public event Action<string>? LocationDetailRequested;

    // Data-grid column definitions (desktop/tablet only)
    private const double GridRowWidth = 1654;
    private static readonly int[] ColWidths =
        [60, 100, 100, 80, 100, 120, 140, 120, 120, 120, 60, 100, 100, 80, 70, 200];
    private static readonly string[] ColHeaders =
        ["ID", "Asset Tag", "ToolKit ID", "Status", "Owner", "Category",
         "Type", "Company", "Part #", "Serial #", "Qty", "Storage",
         "Divider", "Section", "Option", "Description"];
    private static readonly string[] ColBindings =
        ["InventoryID", "AssetTag", "ToolKitID", "Status", "Owner", "CatName",
         "Type", "CompanyName", "PartNumber", "SerialNumber", "Quantity", "Storage",
         "Divider", "Section", "Option", "Description"];

    private static bool IsPhone => DeviceInfo.Current.Idiom == DeviceIdiom.Phone;

    public DashboardView(DashboardViewModel viewModel)
    {
        InitializeComponent();
        _viewModel = viewModel;
        BindingContext = _viewModel;

        if (IsPhone)
            BuildPhoneUi();
        else
            BuildDesktopUi();

        Loaded += (_, _) => { _initTask ??= _viewModel.InitializeAsync(); };
    }

    public Task EnsureInitializedAsync() => _initTask ??= _viewModel.InitializeAsync();

    // ================================================================
    //  Desktop / Tablet layout (unchanged from previous implementation)
    // ================================================================

    private void BuildDesktopUi()
    {
        var root = new Grid
        {
            RowDefinitions =
            [
                new RowDefinition(GridLength.Auto),   // header
                new RowDefinition(GridLength.Auto),   // stat row
                new RowDefinition(GridLength.Star)    // data grid
            ],
            RowSpacing = 12,
            Padding = new Thickness(20)
        };

        root.Add(BuildHeader(), 0, 0);
        root.Add(BuildDesktopStatRow(), 0, 1);
        root.Add(BuildDataGridSection(), 0, 2);

        RootGrid.Children.Add(root);
    }

    // ================================================================
    //  Phone layout: single CollectionView with all sections stacked
    // ================================================================

    private void BuildPhoneUi()
    {
        var root = new Grid
        {
            RowDefinitions =
            [
                new RowDefinition(GridLength.Auto),   // header
                new RowDefinition(GridLength.Star)    // scrollable stat sections
            ],
            RowSpacing = 10,
            Padding = new Thickness(12, 12, 12, 8)
        };

        root.Add(BuildHeader(isPhone: true), 0, 0);
        root.Add(BuildPhoneStatSections(), 0, 1);

        RootGrid.Children.Add(root);
    }

    /// <summary>
    /// All 6 stat sections stacked vertically inside a single CollectionView.
    /// Each section is a "card" � a bordered panel with its own title and scrollable content.
    /// Using a CollectionView as the outer scroll container avoids LayoutCycleException.
    /// </summary>
    private View BuildPhoneStatSections()
    {
        // Build each section as a standalone View, wrap them in a flat list,
        // and render them through a CollectionView for native scrolling.
        var sections = new List<View>
        {
            BuildPhoneTotalStatusCard(),
            BuildPhoneLocationCard(),
            BuildPhoneGroupCard("Owner / Location",
                "#E65100", "#1976D2", "#FFF3E0", "#F57C00",
                nameof(DashboardViewModel.OwnerByLocation)),
            BuildPhoneGroupCard("Category / Location",
                "#2E7D32", "#2E7D32", "#E8F5E9", "#2E7D32",
                nameof(DashboardViewModel.CategoryByLocation)),
            BuildPhoneGroupCard("Type / Location",
                "#0277BD", "#0277BD", "#E1F5FE", "#0277BD",
                nameof(DashboardViewModel.TypeByLocation)),
            BuildPhoneGroupCard("Manufacturer / Location",
                "#C62828", "#C62828", "#FFEBEE", "#C62828",
                nameof(DashboardViewModel.ManufacturerByLocation)),
        };

        // Use a VerticalStackLayout inside a CollectionView with a single item
        // to avoid nesting multiple CollectionViews (which can cause issues on Android).
        // Instead, use a plain VerticalStackLayout wrapped in a single-item CollectionView.
        var stack = new VerticalStackLayout { Spacing = 12 };
        foreach (var section in sections)
            stack.Children.Add(section);

        // Wrap in a CollectionView for native vertical scrolling (no MAUI ScrollView)
        var cv = new CollectionView
        {
            SelectionMode = SelectionMode.None,
            Header = stack
        };

        return cv;
    }

    // ---- Phone section cards -------------------------------------------

    private Border BuildPhoneTotalStatusCard()
    {
        var stack = new VerticalStackLayout { Spacing = 10 };
        stack.Children.Add(Lbl("Total Inventory Count", 16, "#1976D2", bold: true));

        var count = Lbl("", 32, "#1976D2", bold: true);
        count.SetBinding(Label.TextProperty, nameof(DashboardViewModel.TotalInventoryCount));
        stack.Children.Add(count);

        stack.Children.Add(new BoxView { HeightRequest = 1, BackgroundColor = C("#E0E0E0"), Margin = new Thickness(0, 4) });
        stack.Children.Add(Lbl("By Status", 14, "#555555", bold: true));

        var items = new VerticalStackLayout { Spacing = 2 };
        BindableLayout.SetItemTemplate(items, new DataTemplate(() =>
        {
            var g = RowGrid(8);
            var n = Lbl("", 13); n.SetBinding(Label.TextProperty, "Status"); g.Add(n, 0);
            g.Add(Badge("#E3F2FD", "#1976D2", 8, 3, 12), 1);
            return g;
        }));
        items.SetBinding(BindableLayout.ItemsSourceProperty, nameof(DashboardViewModel.StatusStats));
        stack.Children.Add(items);

        return PhoneCard(stack, "#1976D2");
    }

    private Border BuildPhoneLocationCard()
    {
        var stack = new VerticalStackLayout { Spacing = 10 };
        stack.Children.Add(Lbl("Item Count by Location", 16, "#7B1FA2", bold: true));
        stack.Children.Add(new Label
        {
            Text = "Tap a location to browse its inventory",
            FontSize = 11, TextColor = C("#999999")
        });

        var items = new VerticalStackLayout { Spacing = 2 };
        BindableLayout.SetItemTemplate(items, new DataTemplate(() =>
        {
            var g = RowGrid(8);
            var n = new Label
            {
                FontSize = 13, TextColor = C("#7B1FA2"), TextDecorations = TextDecorations.Underline,
                VerticalOptions = LayoutOptions.Center, LineBreakMode = LineBreakMode.TailTruncation
            };
            n.SetBinding(Label.TextProperty, "Location");

            var tap = new TapGestureRecognizer();
            tap.SetBinding(TapGestureRecognizer.CommandParameterProperty, "Location");
            tap.Tapped += OnPhoneLocationTapped;
            n.GestureRecognizers.Add(tap);

            g.Add(n, 0);
            g.Add(Badge("#F3E5F5", "#7B1FA2", 8, 3, 12), 1);
            return g;
        }));
        items.SetBinding(BindableLayout.ItemsSourceProperty, nameof(DashboardViewModel.LocationStats));
        stack.Children.Add(items);

        return PhoneCard(stack, "#7B1FA2");
    }

    private Border BuildPhoneGroupCard(string title, string strokeHex, string locColorHex,
        string badgeBgHex, string badgeFgHex, string bindingPath)
    {
        var stack = new VerticalStackLayout { Spacing = 10 };
        stack.Children.Add(Lbl(title, 16, strokeHex, bold: true));

        var outer = new VerticalStackLayout { Spacing = 4 };
        BindableLayout.SetItemTemplate(outer, new DataTemplate(() =>
        {
            var group = new VerticalStackLayout { Spacing = 4, Padding = new Thickness(0, 6) };

            var loc = Lbl("", 14, locColorHex, bold: true);
            loc.SetBinding(Label.TextProperty, "Location");
            group.Children.Add(loc);

            var inner = new VerticalStackLayout { Spacing = 1 };
            BindableLayout.SetItemTemplate(inner, new DataTemplate(() =>
            {
                var g = new Grid
                {
                    ColumnDefinitions = [new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto)],
                    ColumnSpacing = 8, Padding = new Thickness(12, 2, 4, 2)
                };
                var n = Lbl("", 12); n.SetBinding(Label.TextProperty, "Name"); g.Add(n, 0);
                g.Add(Badge(badgeBgHex, badgeFgHex, 8, 2, 11), 1);
                return g;
            }));
            inner.SetBinding(BindableLayout.ItemsSourceProperty, ".");
            group.Children.Add(inner);

            group.Children.Add(new BoxView { HeightRequest = 1, BackgroundColor = C("#F0F0F0"), Margin = new Thickness(0, 2) });
            return group;
        }));
        outer.SetBinding(BindableLayout.ItemsSourceProperty, bindingPath);
        stack.Children.Add(outer);

        return PhoneCard(stack, strokeHex);
    }

    private void OnPhoneLocationTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is string location && !string.IsNullOrWhiteSpace(location))
            LocationDetailRequested?.Invoke(location);
    }

    private static Border PhoneCard(View content, string strokeHex)
    {
        return new Border
        {
            Stroke = Color.FromArgb(strokeHex),
            StrokeThickness = 2,
            BackgroundColor = Colors.White,
            Padding = new Thickness(16),
            StrokeShape = new RoundRectangle { CornerRadius = 8 },
            Content = content
        };
    }

    // ================================================================
    //  Desktop / Tablet section builders
    // ================================================================

    private static View BuildHeader(bool isPhone = false)
    {
        var g = new Grid
        {
            ColumnDefinitions =
            [
                new ColumnDefinition(GridLength.Star),
                new ColumnDefinition(GridLength.Auto)
            ]
        };

        g.Add(new Label
        {
            Text = "Inventory Dashboard",
            FontAttributes = FontAttributes.Bold,
            FontSize = isPhone ? 20 : 24
        }, 0);

        var btn = new Button
        {
            Text = "Refresh",
            HeightRequest = isPhone ? 36 : 32,
            Padding = new Thickness(12, 0),
            FontSize = isPhone ? 13 : 12,
            VerticalOptions = LayoutOptions.Center
        };
        btn.SetBinding(Button.CommandProperty, nameof(DashboardViewModel.RefreshCommand));
        g.Add(btn, 1);

        return g;
    }

    private View BuildDesktopStatRow()
    {
        var g = new Grid
        {
            ColumnDefinitions =
            [
                new ColumnDefinition(GridLength.Star),
                new ColumnDefinition(GridLength.Star),
                new ColumnDefinition(GridLength.Star),
                new ColumnDefinition(GridLength.Star),
                new ColumnDefinition(GridLength.Star),
                new ColumnDefinition(GridLength.Star)
            ],
            ColumnSpacing = 8,
            HeightRequest = 300
        };

        g.Add(BuildTotalStatusSection(), 0);
        g.Add(BuildLocationSection(), 1);
        g.Add(BuildGroupSection("Owner / Location",
            "#E65100", "#1976D2", "#FFF3E0", "#F57C00",
            nameof(DashboardViewModel.OwnerByLocation)), 2);
        g.Add(BuildGroupSection("Category / Location",
            "#2E7D32", "#2E7D32", "#E8F5E9", "#2E7D32",
            nameof(DashboardViewModel.CategoryByLocation)), 3);
        g.Add(BuildGroupSection("Type / Location",
            "#0277BD", "#0277BD", "#E1F5FE", "#0277BD",
            nameof(DashboardViewModel.TypeByLocation)), 4);
        g.Add(BuildGroupSection("Manufacturer / Location",
            "#C62828", "#C62828", "#FFEBEE", "#C62828",
            nameof(DashboardViewModel.ManufacturerByLocation)), 5);

        return g;
    }

    // Section 1: Total + Status (desktop)
    private Border BuildTotalStatusSection()
    {
        var header = new VerticalStackLayout { Spacing = 6 };
        header.Children.Add(Lbl("Total Inventory", 13, "#1976D2", bold: true));

        var count = Lbl("", 28, "#1976D2", bold: true);
        count.SetBinding(Label.TextProperty, nameof(DashboardViewModel.TotalInventoryCount));
        header.Children.Add(count);

        header.Children.Add(new BoxView { HeightRequest = 1, BackgroundColor = C("#E0E0E0") });
        header.Children.Add(Lbl("By Status", 11, "#555555", bold: true));

        var cv = new CollectionView { SelectionMode = SelectionMode.None };
        cv.ItemTemplate = new DataTemplate(() =>
        {
            var g = RowGrid();
            var n = Lbl("", 11); n.SetBinding(Label.TextProperty, "Status"); g.Add(n, 0);
            g.Add(Badge("#E3F2FD", "#1976D2"), 1);
            return g;
        });
        cv.SetBinding(ItemsView.ItemsSourceProperty, nameof(DashboardViewModel.StatusStats));

        return WrapDesktopSection(header, cv, "#1976D2");
    }

    // Section 2: By Location (desktop � inline data grid)
    private Border BuildLocationSection()
    {
        var header = new VerticalStackLayout { Spacing = 6 };
        header.Children.Add(Lbl("By Location", 13, "#7B1FA2", bold: true));
        header.Children.Add(new Label { Text = "Click a location to view items below", FontSize = 9, TextColor = C("#999999") });

        var cv = new CollectionView { SelectionMode = SelectionMode.None };
        cv.ItemTemplate = new DataTemplate(() =>
        {
            var g = RowGrid();
            var n = new Label
            {
                FontSize = 11, TextColor = C("#7B1FA2"), TextDecorations = TextDecorations.Underline,
                VerticalOptions = LayoutOptions.Center, LineBreakMode = LineBreakMode.TailTruncation
            };
            n.SetBinding(Label.TextProperty, "Location");
            var tap = new TapGestureRecognizer();
            tap.SetBinding(TapGestureRecognizer.CommandProperty,
                new Binding(nameof(DashboardViewModel.LocationDetailCommand), source: _viewModel));
            tap.SetBinding(TapGestureRecognizer.CommandParameterProperty, "Location");
            n.GestureRecognizers.Add(tap);
            g.Add(n, 0);
            g.Add(Badge("#F3E5F5", "#7B1FA2"), 1);
            return g;
        });
        cv.SetBinding(ItemsView.ItemsSourceProperty, nameof(DashboardViewModel.LocationStats));

        return WrapDesktopSection(header, cv, "#7B1FA2");
    }

    // Sections 3-6: grouped by location (desktop)
    private Border BuildGroupSection(string title, string strokeHex, string locColorHex,
        string badgeBgHex, string badgeFgHex, string bindingPath)
    {
        var header = new VerticalStackLayout { Spacing = 4 };
        header.Children.Add(Lbl(title, 13, strokeHex, bold: true));

        var cv = new CollectionView
        {
            SelectionMode = SelectionMode.None,
            IsGrouped = true
        };

        cv.GroupHeaderTemplate = new DataTemplate(() =>
        {
            var loc = Lbl("", 11, locColorHex, bold: true);
            loc.SetBinding(Label.TextProperty, "Location");
            loc.Padding = new Thickness(0, 4, 0, 0);
            return loc;
        });

        cv.GroupFooterTemplate = new DataTemplate(() =>
            new BoxView { HeightRequest = 1, BackgroundColor = C("#F0F0F0") });

        cv.ItemTemplate = new DataTemplate(() =>
        {
            var g = new Grid
            {
                ColumnDefinitions = [new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto)],
                ColumnSpacing = 4, Padding = new Thickness(8, 1, 2, 1)
            };
            var n = Lbl("", 10); n.SetBinding(Label.TextProperty, "Name"); g.Add(n, 0);
            g.Add(Badge(badgeBgHex, badgeFgHex, 4, 1, 9), 1);
            return g;
        });

        cv.SetBinding(ItemsView.ItemsSourceProperty, bindingPath);

        return WrapDesktopSection(header, cv, strokeHex);
    }

    private static Border WrapDesktopSection(View fixedHeader, CollectionView scrollableList, string strokeHex)
    {
        var layout = new Grid
        {
            RowDefinitions =
            [
                new RowDefinition(GridLength.Auto),
                new RowDefinition(GridLength.Star)
            ],
            RowSpacing = 4
        };
        layout.Add(fixedHeader, 0, 0);
        layout.Add(scrollableList, 0, 1);

        return new Border
        {
            Stroke = Color.FromArgb(strokeHex),
            StrokeThickness = 2,
            BackgroundColor = Colors.White,
            Padding = new Thickness(10),
            StrokeShape = new RoundRectangle { CornerRadius = 6 },
            Content = layout
        };
    }

    // ---- Data grid using CollectionView (desktop/tablet only) -----------

    private View BuildDataGridSection()
    {
        var titleLabel = new Label
        {
            FontAttributes = FontAttributes.Bold,
            FontSize = 16,
            TextColor = C("#7B1FA2")
        };
        var fs = new FormattedString();
        fs.Spans.Add(new Span { Text = "Inventory Items at: " });
        var locSpan = new Span { FontAttributes = FontAttributes.Bold };
        locSpan.SetBinding(Span.TextProperty, nameof(DashboardViewModel.SelectedLocation));
        fs.Spans.Add(locSpan);
        titleLabel.FormattedText = fs;

        var cv = new CollectionView
        {
            SelectionMode = SelectionMode.None,
            BackgroundColor = Colors.White
        };

        cv.Header = BuildCollectionViewHeader();

        cv.ItemTemplate = new DataTemplate(() =>
        {
            var g = new Grid
            {
                ColumnSpacing = 8,
                Padding = new Thickness(6, 4),
                BackgroundColor = Colors.White
            };
            for (int i = 0; i < ColWidths.Length; i++)
            {
                g.ColumnDefinitions.Add(new ColumnDefinition(new GridLength(ColWidths[i], GridUnitType.Absolute)));
                var lbl = new Label
                {
                    FontSize = 10,
                    VerticalOptions = LayoutOptions.Center,
                    LineBreakMode = (i == ColWidths.Length - 1) ? LineBreakMode.TailTruncation : LineBreakMode.NoWrap
                };
                lbl.SetBinding(Label.TextProperty, ColBindings[i]);
                g.Add(lbl, i);
            }
            return g;
        });

        cv.SetBinding(ItemsView.ItemsSourceProperty, nameof(DashboardViewModel.LocationItems));

        var layout = new Grid
        {
            RowDefinitions =
            [
                new RowDefinition(GridLength.Auto),
                new RowDefinition(GridLength.Star)
            ],
            RowSpacing = 8
        };
        layout.Add(titleLabel, 0, 0);
        layout.Add(cv, 0, 1);

        var border = new Border
        {
            Stroke = C("#7B1FA2"),
            StrokeThickness = 2,
            BackgroundColor = Colors.White,
            Padding = new Thickness(12),
            StrokeShape = new RoundRectangle { CornerRadius = 6 },
            Content = layout
        };
        border.SetBinding(IsVisibleProperty, nameof(DashboardViewModel.HasLocationItems));

        return border;
    }

    private static View BuildCollectionViewHeader()
    {
        var g = new Grid
        {
            ColumnSpacing = 8,
            Padding = new Thickness(6),
            BackgroundColor = C("#F2F2F2")
        };
        for (int i = 0; i < ColWidths.Length; i++)
        {
            g.ColumnDefinitions.Add(new ColumnDefinition(new GridLength(ColWidths[i], GridUnitType.Absolute)));
            g.Add(new Label
            {
                Text = ColHeaders[i],
                FontAttributes = FontAttributes.Bold,
                FontSize = 11
            }, i);
        }
        return g;
    }

    // ---- Helpers --------------------------------------------------------

    private static Color C(string hex) => Color.FromArgb(hex);

    private static Label Lbl(string text, double size, string? colorHex = null, bool bold = false)
    {
        var lbl = new Label
        {
            Text = text,
            FontSize = size,
            VerticalOptions = LayoutOptions.Center,
            LineBreakMode = LineBreakMode.TailTruncation
        };
        if (bold) lbl.FontAttributes = FontAttributes.Bold;
        if (colorHex is not null) lbl.TextColor = C(colorHex);
        return lbl;
    }

    private static Grid RowGrid(double colSpacing = 4) => new()
    {
        ColumnDefinitions = [new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto)],
        ColumnSpacing = colSpacing,
        Padding = new Thickness(2)
    };

    private static Border Badge(string bgHex, string fgHex, double hPad = 6, double vPad = 2, double fontSize = 10)
    {
        var border = new Border
        {
            BackgroundColor = C(bgHex),
            Padding = new Thickness(hPad, vPad),
            StrokeThickness = 0
        };
        var lbl = new Label { FontAttributes = FontAttributes.Bold, FontSize = fontSize, TextColor = C(fgHex) };
        lbl.SetBinding(Label.TextProperty, "Count");
        border.Content = lbl;
        return border;
    }
}
