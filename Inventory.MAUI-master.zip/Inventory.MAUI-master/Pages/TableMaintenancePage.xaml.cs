using Inventory.MAUI.Data;
using Inventory.MAUI.Models;
using Inventory.MAUI.Services;
using Inventory.MAUI.Helpers;
using Microsoft.EntityFrameworkCore;
using System.Collections.ObjectModel;
using System.Globalization;

namespace Inventory.MAUI.Pages;

public static class Extensions
{
    public static T Apply<T>(this T obj, Action<T> action)
    {
        action(obj);
        return obj;
    }
}

public class NotePreviewConverter : IValueConverter
{
    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is string note && !string.IsNullOrEmpty(note))
        {
            return note.Length > 50 ? note.Substring(0, 50) + "..." : note;
        }
        return "(Empty)";
    }

    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}

public partial class TableMaintenancePage : ContentView
{
    private readonly IDbContextFactory<InventoryDbContext> _contextFactory;
    private readonly AppSessionService _session;

    private string _activeTab = "AssetOwner";
    private RangeObservableCollection<AssetOwner> _owners = [];
    private RangeObservableCollection<Category> _categories = [];
    private RangeObservableCollection<AssetType> _types = [];
    private RangeObservableCollection<Companies> _companies = [];
    private RangeObservableCollection<Locations> _locations = [];
    private RangeObservableCollection<InventoryStorage> _storages = [];
    private RangeObservableCollection<Asset> _assets = [];
    private RangeObservableCollection<Notes> _notes = [];
    private RangeObservableCollection<Models.Contacts> _contacts = [];
    private RangeObservableCollection<Roles> _roles = [];
    private RangeObservableCollection<CompanyRoles> _companyRoles = [];
    private RangeObservableCollection<CTTMInventory> _cttmInventory = [];

    // Pagination support for large tables
    private const int PAGE_SIZE = 200;
    private bool _isLoadingAssets = false;
    private bool _isLoadingNotes = false;
    private bool _isLoadingCTTM = false;
    private int _assetsLoadedCount = 0;
    private int _notesLoadedCount = 0;
    private int _cttmLoadedCount = 0;
    private int _assetsTotalCount = 0;
    private int _notesTotalCount = 0;
    private int _cttmTotalCount = 0;
    private Label? _assetsStatusLabel;
    private Label? _notesStatusLabel;
    private Label? _cttmStatusLabel;

    // Search/filter support
    private string _ownerSearchText = "";
    private string _categorySearchText = "";
    private string _typeSearchText = "";
    private string _companySearchText = "";
    private string _locationSearchText = "";
    private string _storageSearchText = "";
    private string _assetSearchText = "";
    private string _noteSearchText = "";

    public TableMaintenancePage(
        IDbContextFactory<InventoryDbContext> contextFactory,
        AppSessionService session)
    {
        InitializeComponent();
        _contextFactory = contextFactory;
        _session = session;

        BuildTabBar();

        // Build all views once at startup (in background to keep UI responsive)
        _ = InitializeAllTabsAsync();
    }

    private void BuildTabBar()
    {
        var tabs = new[] { "AssetOwner", "Category", "AssetType", "Companies", "Locations", "Storage", "Asset", "Notes", "Contacts", "Roles", "CompanyRoles", "CTTMInventory" };
        foreach (var tab in tabs)
        {
            var btn = new Button
            {
                Text = GetTabDisplayName(tab),
                FontSize = 11,
                HeightRequest = 32,
                Padding = new Thickness(12, 0),
                CornerRadius = 0,
                BorderWidth = 0,
                BackgroundColor = Colors.Transparent,
                TextColor = Color.FromArgb("#555")
            };
            btn.Clicked += (_, _) => ActivateTab(tab);
            TmTabBar.Add(btn);
        }
        UpdateTabStyles();
    }

    private static string GetTabDisplayName(string tab) => tab switch
    {
        "AssetOwner" => "Asset Owners",
        "AssetType" => "Asset Types",
        "Storage" => "Storage Locations",
        "CompanyRoles" => "Company Roles",
        "CTTMInventory" => "CTTM Inventory",
        _ => tab
    };

    private void ActivateTab(string tab)
    {
        _activeTab = tab;
        UpdateTabStyles();
        UpdateTabVisibility();
    }

    private void UpdateTabVisibility()
    {
        // Just toggle visibility - views are already built
        AssetOwnerView.IsVisible = _activeTab == "AssetOwner";
        CategoryView.IsVisible = _activeTab == "Category";
        AssetTypeView.IsVisible = _activeTab == "AssetType";
        CompaniesView.IsVisible = _activeTab == "Companies";
        LocationsView.IsVisible = _activeTab == "Locations";
        StorageView.IsVisible = _activeTab == "Storage";
        AssetView.IsVisible = _activeTab == "Asset";
        NotesView.IsVisible = _activeTab == "Notes";
        ContactsView.IsVisible = _activeTab == "Contacts";
        RolesView.IsVisible = _activeTab == "Roles";
        CompanyRolesView.IsVisible = _activeTab == "CompanyRoles";
        CTTMInventoryView.IsVisible = _activeTab == "CTTMInventory";
    }

    private void UpdateTabStyles()
    {
        foreach (var child in TmTabBar)
        {
            if (child is Button btn)
            {
                var tabKey = btn.Text switch
                {
                    "Asset Owners" => "AssetOwner",
                    "Asset Types" => "AssetType",
                    "Storage Locations" => "Storage",
                    "Company Roles" => "CompanyRoles",
                    "CTTM Inventory" => "CTTMInventory",
                    _ => btn.Text
                };
                var isActive = tabKey == _activeTab;
                btn.BackgroundColor = isActive ? Color.FromArgb("#E3F2FD") : Colors.Transparent;
                btn.TextColor = isActive ? Color.FromArgb("#1565C0") : Color.FromArgb("#555");
                btn.FontAttributes = isActive ? FontAttributes.Bold : FontAttributes.None;
            }
        }
    }

    private async Task InitializeAllTabsAsync()
    {
        // Build all views on UI thread (required for MAUI controls)
        // Use Task.Yield() between each to keep UI responsive
        try
        {
            AssetOwnerView.Content = await BuildAssetOwnerViewAsync();
            await Task.Yield();

            CategoryView.Content = await BuildCategoryViewAsync();
            await Task.Yield();

            AssetTypeView.Content = await BuildAssetTypeViewAsync();
            await Task.Yield();

            CompaniesView.Content = await BuildCompaniesViewAsync();
            await Task.Yield();

            LocationsView.Content = await BuildLocationsViewAsync();
            await Task.Yield();

            StorageView.Content = await BuildStorageViewAsync();
            await Task.Yield();

            AssetView.Content = await BuildAssetViewAsync();
            await Task.Yield();

            NotesView.Content = await BuildNotesViewAsync();
            await Task.Yield();

            ContactsView.Content = await BuildContactsViewAsync();
            RolesView.Content = await BuildRolesViewAsync();
            CompanyRolesView.Content = await BuildCompanyRolesViewAsync();

            await Task.Yield();
            CTTMInventoryView.Content = await BuildCTTMInventoryViewAsync();

            // Show the first tab
            UpdateTabVisibility();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"InitializeAllTabsAsync error: {ex.Message}");
        }
    }

    // ─── Helper: Create properly constrained container for CollectionView scrolling ───

    private static Grid CreateScrollableContainer(View header, CollectionView collectionView, bool includeDivider = true, View? footer = null, View? columnHeader = null)
    {
        var rows = new RowDefinitionCollection
        {
            new RowDefinition(GridLength.Auto)
        };
        if (includeDivider)
            rows.Add(new RowDefinition(GridLength.Auto));
        if (columnHeader != null)
            rows.Add(new RowDefinition(GridLength.Auto));
        rows.Add(new RowDefinition(GridLength.Star));
        if (footer != null)
            rows.Add(new RowDefinition(GridLength.Auto));

        var container = new Grid
        {
            RowDefinitions = rows,
            Padding = new Thickness(16),
            RowSpacing = 8
        };

        var nextRow = 0;

        Grid.SetRow(header, nextRow++);
        container.Add(header);

        if (includeDivider)
        {
            var divider = new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5") };
            Grid.SetRow(divider, nextRow++);
            container.Add(divider);
        }

        if (columnHeader != null)
        {
            Grid.SetRow(columnHeader, nextRow++);
            container.Add(columnHeader);
        }

        Grid.SetRow(collectionView, nextRow++);
        container.Add(collectionView);

        if (footer != null)
        {
            Grid.SetRow(footer, nextRow);
            container.Add(footer);
        }

        return container;
    }

    // ─── Asset Owner Tab ───────────────────────────────────────────────

    private async Task<View> BuildAssetOwnerViewAsync()
    {
        var addBtn = new Button { Text = "+ Add", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#1565C0"), TextColor = Colors.White };
        addBtn.Clicked += async (_, _) => await AddAssetOwnerAsync();

        var searchEntry = new Entry 
        { 
            Placeholder = "Search by name...", 
            FontSize = 12, 
            HeightRequest = 32,
            WidthRequest = 300,
            BackgroundColor = Colors.White,
            Margin = new Thickness(0, 0, 12, 0)
        };
        searchEntry.TextChanged += (s, e) =>
        {
            _ownerSearchText = e.NewTextValue?.ToLower() ?? "";
            // Simple filter - could be optimized with ICollectionView
            var filtered = string.IsNullOrWhiteSpace(_ownerSearchText)
                ? _owners
                : new RangeObservableCollection<AssetOwner>(_owners.Where(o => o.Owner?.ToLower().Contains(_ownerSearchText) == true));

            if (DeviceInfo.Current.Platform == DevicePlatform.WinUI)
            {
                var cv = ((AssetOwnerView.Content as Grid)?.Children.LastOrDefault() as CollectionView);
                    if (cv != null) cv.ItemsSource = filtered;
            }
        };

        var headerRow = new HorizontalStackLayout
        {
            Spacing = 12,
            Children =
            {
                new Label { Text = "Asset Owners", FontAttributes = FontAttributes.Bold, FontSize = 16, VerticalOptions = LayoutOptions.Center },
                searchEntry,
                addBtn,
                new Label { Text = $"{_owners.Count} total", FontSize = 12, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center }
            }
        };

        // Start loading data in background if needed (don't await)
        if (_owners.Count == 0)
        {
            _ = Task.Run(async () =>
            {
                try
                {
                    await using var ctx = await _contextFactory.CreateDbContextAsync();
                    var data = await ctx.AssetOwner.AsNoTracking().OrderBy(o => o.OwnerID).ToListAsync();

                    // Add all items with single notification
                    await MainThread.InvokeOnMainThreadAsync(() => _owners.AddRange(data));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"LoadAssetOwners error: {ex.Message}");
                }
            });
        }

        // Windows: Use CollectionView for virtualization
        if (DeviceInfo.Current.Platform == DevicePlatform.WinUI)
        {
            var collectionView = new CollectionView
            {
                ItemsSource = _owners,
                SelectionMode = SelectionMode.Single,
                SelectedItem = null,
                ItemTemplate = new DataTemplate(() =>
                {
                    var grid = new Grid
                    {
                        ColumnDefinitions =
                        {
                            new ColumnDefinition(new GridLength(60)),
                            new ColumnDefinition(GridLength.Star),
                            new ColumnDefinition(new GridLength(150)),
                            new ColumnDefinition(new GridLength(120)),
                            new ColumnDefinition(new GridLength(150))
                        },
                        Padding = new Thickness(4),
                        ColumnSpacing = 4
                    };

                    var idLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#999"), VerticalOptions = LayoutOptions.Center };
                    idLabel.SetBinding(Label.TextProperty, nameof(AssetOwner.OwnerID));

                    var nameLabel = new Label { FontSize = 12, VerticalOptions = LayoutOptions.Center };
                    nameLabel.SetBinding(Label.TextProperty, nameof(AssetOwner.Owner));

                    var dateLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    dateLabel.SetBinding(Label.TextProperty, new Binding(nameof(AssetOwner.DateModified), stringFormat: "{0:MM/dd/yyyy}"));

                    var modByLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    modByLabel.SetBinding(Label.TextProperty, nameof(AssetOwner.ModifiedBy));

                    var editBtn = new Button { Text = "Edit", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                    editBtn.SetBinding(Button.CommandParameterProperty, ".");
                    editBtn.Command = new Command<AssetOwner>(async o => await EditAssetOwnerAsync(o));

                    var deleteBtn = new Button { Text = "Delete", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                    deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                    deleteBtn.Command = new Command<AssetOwner>(async o => await DeleteAssetOwnerAsync(o));

                    var actions = new HorizontalStackLayout { Spacing = 4 };
                    actions.Add(editBtn);
                    actions.Add(deleteBtn);

                    // Double-click gesture
                    var doubleTap = new TapGestureRecognizer { NumberOfTapsRequired = 2 };
                    doubleTap.SetBinding(TapGestureRecognizer.CommandParameterProperty, ".");
                    doubleTap.Command = new Command<AssetOwner>(async o => await EditAssetOwnerAsync(o));
                    nameLabel.GestureRecognizers.Add(doubleTap);

                    grid.Add(idLabel, 0);
                    grid.Add(nameLabel, 1);
                    grid.Add(dateLabel, 2);
                    grid.Add(modByLabel, 3);
                    grid.Add(actions, 4);

                    return grid;
                })
            };

            var colHeader = new Grid
            {
                ColumnDefinitions =
                {
                    new ColumnDefinition(new GridLength(60)),
                    new ColumnDefinition(GridLength.Star),
                    new ColumnDefinition(new GridLength(150)),
                    new ColumnDefinition(new GridLength(120)),
                    new ColumnDefinition(new GridLength(150))
                },
                Padding = new Thickness(4),
                ColumnSpacing = 4,
                BackgroundColor = Color.FromArgb("#F5F5F5"),
                Children =
                {
                    new Label { Text = "ID", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 0)),
                    new Label { Text = "Owner Name", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 1)),
                    new Label { Text = "Date Modified", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 2)),
                    new Label { Text = "Modified By", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 3)),
                    new Label { Text = "Actions", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 4))
                }
            };

            return CreateScrollableContainer(headerRow, collectionView, columnHeader: colHeader);
        }

        // Mobile: Card-based scrolling layout (also use CollectionView)
        var mobileCollection = new CollectionView
        {
            ItemsSource = _owners,
            SelectionMode = SelectionMode.Single,
            ItemTemplate = new DataTemplate(() =>
            {
                var border = new Border
                {
                    Stroke = Color.FromArgb("#DDD"),
                    StrokeThickness = 1,
                    Padding = new Thickness(12, 8),
                    Margin = new Thickness(0, 4),
                    BackgroundColor = Colors.White
                };

                var nameLabel = new Label { FontSize = 13, VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.FillAndExpand };
                nameLabel.SetBinding(Label.TextProperty, nameof(AssetOwner.Owner));

                var metaLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#888"), VerticalOptions = LayoutOptions.Center };
                metaLabel.SetBinding(Label.TextProperty, new Binding(".", stringFormat: "Modified: {0:MM/dd/yyyy} by {1}", source: new[] { nameof(AssetOwner.DateModified), nameof(AssetOwner.ModifiedBy) }));

                var editBtn = new Button { Text = "Edit", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                editBtn.SetBinding(Button.CommandParameterProperty, ".");
                editBtn.Command = new Command<AssetOwner>(async o => await EditAssetOwnerAsync(o));

                var deleteBtn = new Button { Text = "Delete", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                deleteBtn.Command = new Command<AssetOwner>(async o => await DeleteAssetOwnerAsync(o));

                var stack = new HorizontalStackLayout { Spacing = 8 };
                stack.Add(nameLabel);
                stack.Add(metaLabel);
                stack.Add(editBtn);
                stack.Add(deleteBtn);

                border.Content = stack;
                return border;
            })
        };

        return CreateScrollableContainer(headerRow, mobileCollection, includeDivider: false);
    }

    private async Task AddAssetOwnerAsync()
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var ownerName = await page.DisplayPromptAsync("Add Asset Owner", "Enter owner name:");
        if (string.IsNullOrWhiteSpace(ownerName)) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var newOwner = new AssetOwner
            {
                Owner = ownerName.Trim(),
                DateModified = DateTime.Now,
                ModifiedBy = _session.ATTUID ?? "system"
            };
            ctx.AssetOwner.Add(newOwner);
            await ctx.SaveChangesAsync();

            // Insert in sorted position
            _owners.InsertSorted(newOwner, o => o.OwnerID);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task EditAssetOwnerAsync(AssetOwner owner)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var newName = await page.DisplayPromptAsync("Edit Asset Owner", "Edit owner name:", initialValue: owner.Owner);
        if (string.IsNullOrWhiteSpace(newName) || newName == owner.Owner) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            owner.Owner = newName.Trim();
            owner.DateModified = DateTime.Now;
            owner.ModifiedBy = _session.ATTUID ?? "system";
            ctx.AssetOwner.Update(owner);
            await ctx.SaveChangesAsync();

            // Item already updated in ObservableCollection via reference - no reload needed
            // Force UI refresh by removing and re-adding
            var index = _owners.IndexOf(owner);
            if (index >= 0)
            {
                _owners.RemoveAt(index);
                _owners.Insert(index, owner);
            }
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task DeleteAssetOwnerAsync(AssetOwner owner)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var confirm = await page.DisplayAlert("Confirm Delete", $"Delete owner '{owner.Owner}'?\n\nWarning: This may fail if inventory items reference this owner.", "Delete", "Cancel");
        if (!confirm) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            ctx.AssetOwner.Remove(owner);
            await ctx.SaveChangesAsync();

            // Remove from collection instead of reloading entire tab
            _owners.Remove(owner);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Delete Failed", $"Cannot delete: {ex.Message}\n\nThis owner is likely referenced by inventory items.", "OK");
        }
    }

    // ─── Category Tab ──────────────────────────────────────────────────

    private async Task<View> BuildCategoryViewAsync()
    {
        var addBtn = new Button { Text = "+ Add", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#1565C0"), TextColor = Colors.White };
        addBtn.Clicked += async (_, _) => await AddCategoryAsync();

        CollectionView? collectionViewRef = null;

        var searchEntry = new Entry { Placeholder = "Search categories...", FontSize = 12, HeightRequest = 32, WidthRequest = 250, BackgroundColor = Colors.White, Margin = new Thickness(0, 0, 12, 0) };
        searchEntry.TextChanged += (s, e) =>
        {
            _categorySearchText = e.NewTextValue?.ToLower() ?? "";
            if (collectionViewRef == null) return;
            collectionViewRef.ItemsSource = string.IsNullOrWhiteSpace(_categorySearchText)
                ? _categories
                : new RangeObservableCollection<Category>(_categories.Where(c => c.CatName?.ToLower().Contains(_categorySearchText) == true || c.Description?.ToLower().Contains(_categorySearchText) == true));
        };

        var scrollTopBtn = new Button { Text = "↑ Top", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
        scrollTopBtn.Clicked += (_, _) => { if (collectionViewRef != null && _categories.Count > 0) collectionViewRef.ScrollTo(0, position: ScrollToPosition.Start, animate: true); };

        var headerRow = new HorizontalStackLayout
        {
            Spacing = 12,
            Children =
            {
                new Label { Text = "Categories", FontAttributes = FontAttributes.Bold, FontSize = 16, VerticalOptions = LayoutOptions.Center },
                searchEntry,
                addBtn,
                scrollTopBtn,
                new Label { Text = $"{_categories.Count} total", FontSize = 12, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center }
            }
        };

        // Start loading data in background if needed
        if (_categories.Count == 0)
        {
            _ = Task.Run(async () =>
            {
                try
                {
                    await using var ctx = await _contextFactory.CreateDbContextAsync();
                    var data = await ctx.Category.AsNoTracking().OrderBy(c => c.CatID).ToListAsync();

                    await MainThread.InvokeOnMainThreadAsync(() => _categories.AddRange(data));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"LoadCategories error: {ex.Message}");
                }
            });
        }

        // Windows: Use CollectionView for virtualization
        if (DeviceInfo.Current.Platform == DevicePlatform.WinUI)
        {
            var collectionView = new CollectionView
            {
                ItemsSource = _categories,
                SelectionMode = SelectionMode.Single,
                ItemTemplate = new DataTemplate(() =>
                {
                    var grid = new Grid
                    {
                        ColumnDefinitions =
                        {
                            new ColumnDefinition(new GridLength(60)),
                            new ColumnDefinition(new GridLength(200)),
                            new ColumnDefinition(GridLength.Star),
                            new ColumnDefinition(new GridLength(150)),
                            new ColumnDefinition(new GridLength(120)),
                            new ColumnDefinition(new GridLength(150))
                        },
                        Padding = new Thickness(4),
                        ColumnSpacing = 4
                    };

                    var idLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#999"), VerticalOptions = LayoutOptions.Center };
                    idLabel.SetBinding(Label.TextProperty, nameof(Category.CatID));

                    var nameLabel = new Label { FontSize = 12, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center };
                    nameLabel.SetBinding(Label.TextProperty, nameof(Category.CatName));

                    var descLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    descLabel.SetBinding(Label.TextProperty, nameof(Category.Description));

                    var dateLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    dateLabel.SetBinding(Label.TextProperty, new Binding(nameof(Category.DateModified), stringFormat: "{0:MM/dd/yyyy}"));

                    var modByLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    modByLabel.SetBinding(Label.TextProperty, nameof(Category.ModifiedBy));

                    var editBtn = new Button { Text = "Edit", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                    editBtn.SetBinding(Button.CommandParameterProperty, ".");
                    editBtn.Command = new Command<Category>(async c => await EditCategoryAsync(c));

                    var deleteBtn = new Button { Text = "Delete", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                    deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                    deleteBtn.Command = new Command<Category>(async c => await DeleteCategoryAsync(c));

                    var actions = new HorizontalStackLayout { Spacing = 4 };
                    actions.Add(editBtn);
                    actions.Add(deleteBtn);

                    var doubleTap = new TapGestureRecognizer { NumberOfTapsRequired = 2 };
                    doubleTap.SetBinding(TapGestureRecognizer.CommandParameterProperty, ".");
                    doubleTap.Command = new Command<Category>(async c => await EditCategoryAsync(c));
                    nameLabel.GestureRecognizers.Add(doubleTap);

                    grid.Add(idLabel, 0);
                    grid.Add(nameLabel, 1);
                    grid.Add(descLabel, 2);
                    grid.Add(dateLabel, 3);
                    grid.Add(modByLabel, 4);
                    grid.Add(actions, 5);

                    return grid;
                })
            };

            var colHeader = new Grid
            {
                ColumnDefinitions =
                {
                    new ColumnDefinition(new GridLength(60)),
                    new ColumnDefinition(new GridLength(200)),
                    new ColumnDefinition(GridLength.Star),
                    new ColumnDefinition(new GridLength(150)),
                    new ColumnDefinition(new GridLength(120)),
                    new ColumnDefinition(new GridLength(150))
                },
                Padding = new Thickness(4),
                ColumnSpacing = 4,
                BackgroundColor = Color.FromArgb("#F5F5F5"),
                Children =
                {
                    new Label { Text = "ID", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 0)),
                    new Label { Text = "Category Name", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 1)),
                    new Label { Text = "Description", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 2)),
                    new Label { Text = "Date Modified", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 3)),
                    new Label { Text = "Modified By", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 4)),
                    new Label { Text = "Actions", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 5))
                }
            };

            collectionViewRef = collectionView;
            return CreateScrollableContainer(headerRow, collectionView, columnHeader: colHeader);
        }

        // Mobile: Use CollectionView
        var mobileCollection = new CollectionView
        {
            ItemsSource = _categories,
            SelectionMode = SelectionMode.Single,
            ItemTemplate = new DataTemplate(() =>
            {
                var border = new Border
                {
                    Stroke = Color.FromArgb("#DDD"),
                    StrokeThickness = 1,
                    Padding = new Thickness(12, 8),
                    Margin = new Thickness(0, 4),
                    BackgroundColor = Colors.White
                };

                var nameLabel = new Label { FontSize = 13, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.FillAndExpand };
                nameLabel.SetBinding(Label.TextProperty, nameof(Category.CatName));

                var descLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666") };
                descLabel.SetBinding(Label.TextProperty, nameof(Category.Description));

                var metaLabel = new Label { FontSize = 10, TextColor = Color.FromArgb("#AAA") };
                metaLabel.SetBinding(Label.TextProperty, new Binding(".", stringFormat: "Modified: {0:MM/dd/yyyy} by {1}"));

                var editBtn = new Button { Text = "Edit", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                editBtn.SetBinding(Button.CommandParameterProperty, ".");
                editBtn.Command = new Command<Category>(async c => await EditCategoryAsync(c));

                var deleteBtn = new Button { Text = "Delete", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                deleteBtn.Command = new Command<Category>(async c => await DeleteCategoryAsync(c));

                var topStack = new HorizontalStackLayout { Spacing = 8 };
                topStack.Add(nameLabel);
                topStack.Add(editBtn);
                topStack.Add(deleteBtn);

                var content = new VerticalStackLayout { Spacing = 4 };
                content.Add(topStack);
                content.Add(descLabel);
                content.Add(metaLabel);

                border.Content = content;
                return border;
            })
        };

        return CreateScrollableContainer(headerRow, mobileCollection, includeDivider: false);
    }

    private async Task AddCategoryAsync()
    {
        var dialog = new CategoryEditDialog();
        await Application.Current!.MainPage!.Navigation.PushModalAsync(dialog);

        if (dialog.Result is null) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            dialog.Result.DateModified = DateTime.Now;
            dialog.Result.ModifiedBy = _session.ATTUID ?? "system";
            ctx.Category.Add(dialog.Result);
            await ctx.SaveChangesAsync();

            // Add to collection instead of reloading
            _categories.InsertSorted(dialog.Result, c => c.CatID);
        }
        catch (Exception ex)
        {
            var page = Application.Current?.MainPage;
            if (page is not null)
                await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task EditCategoryAsync(Category cat)
    {
        var dialog = new CategoryEditDialog(cat);
        await Application.Current!.MainPage!.Navigation.PushModalAsync(dialog);

        if (dialog.Result is null) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            cat.DateModified = DateTime.Now;
            cat.ModifiedBy = _session.ATTUID ?? "system";
            ctx.Category.Update(cat);
            await ctx.SaveChangesAsync();

            // Update in place
            var index = _categories.IndexOf(cat);
            if (index >= 0)
            {
                _categories.RemoveAt(index);
                _categories.Insert(index, cat);
            }
        }
        catch (Exception ex)
        {
            var page = Application.Current?.MainPage;
            if (page is not null)
                await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task DeleteCategoryAsync(Category cat)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var confirm = await page.DisplayAlert("Confirm Delete", $"Delete category '{cat.CatName}'?\n\nWarning: This may fail if inventory items reference this category.", "Delete", "Cancel");
        if (!confirm) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            ctx.Category.Remove(cat);
            await ctx.SaveChangesAsync();

            // Remove from collection
            _categories.Remove(cat);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Delete Failed", $"Cannot delete: {ex.Message}\n\nThis category is likely referenced by inventory items.", "OK");
        }
    }

    // ─── AssetType Tab ─────────────────────────────────────────────────

    private async Task<View> BuildAssetTypeViewAsync()
    {
        var addBtn = new Button { Text = "+ Add", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#1565C0"), TextColor = Colors.White };
        addBtn.Clicked += async (_, _) => await AddAssetTypeAsync();

        CollectionView? collectionViewRef = null;

        var searchEntry = new Entry { Placeholder = "Search types...", FontSize = 12, HeightRequest = 32, WidthRequest = 250, BackgroundColor = Colors.White, Margin = new Thickness(0, 0, 12, 0) };
        searchEntry.TextChanged += (s, e) =>
        {
            _typeSearchText = e.NewTextValue?.ToLower() ?? "";
            if (collectionViewRef == null) return;
            collectionViewRef.ItemsSource = string.IsNullOrWhiteSpace(_typeSearchText)
                ? _types
                : new RangeObservableCollection<AssetType>(_types.Where(t => t.Type?.ToLower().Contains(_typeSearchText) == true || t.Description?.ToLower().Contains(_typeSearchText) == true));
        };

        var scrollTopBtn = new Button { Text = "↑ Top", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
        scrollTopBtn.Clicked += (_, _) => { if (collectionViewRef != null && _types.Count > 0) collectionViewRef.ScrollTo(0, position: ScrollToPosition.Start, animate: true); };

        var headerRow = new HorizontalStackLayout
        {
            Spacing = 12,
            Children =
            {
                new Label { Text = "Asset Types", FontAttributes = FontAttributes.Bold, FontSize = 16, VerticalOptions = LayoutOptions.Center },
                searchEntry,
                addBtn,
                scrollTopBtn,
                new Label { Text = $"{_types.Count} total", FontSize = 12, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center }
            }
        };

        // Start loading data in background if needed
        if (_types.Count == 0)
        {
            _ = Task.Run(async () =>
            {
                try
                {
                    await using var ctx = await _contextFactory.CreateDbContextAsync();
                    var data = await ctx.AssetType.AsNoTracking().OrderBy(t => t.TypeID).ToListAsync();

                    await MainThread.InvokeOnMainThreadAsync(() => _types.AddRange(data));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"LoadAssetTypes error: {ex.Message}");
                }
            });
        }

        if (DeviceInfo.Current.Platform == DevicePlatform.WinUI)
        {
            var collectionView = new CollectionView
            {
                ItemsSource = _types,
                SelectionMode = SelectionMode.Single,
                ItemTemplate = new DataTemplate(() =>
                {
                    var grid = new Grid
                    {
                        ColumnDefinitions =
                        {
                            new ColumnDefinition(new GridLength(60)),
                            new ColumnDefinition(new GridLength(200)),
                            new ColumnDefinition(GridLength.Star),
                            new ColumnDefinition(new GridLength(150)),
                            new ColumnDefinition(new GridLength(120)),
                            new ColumnDefinition(new GridLength(150))
                        },
                        Padding = new Thickness(4),
                        ColumnSpacing = 4
                    };

                    var idLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#999"), VerticalOptions = LayoutOptions.Center };
                    idLabel.SetBinding(Label.TextProperty, nameof(AssetType.TypeID));

                    var nameLabel = new Label { FontSize = 12, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center };
                    nameLabel.SetBinding(Label.TextProperty, nameof(AssetType.Type));

                    var descLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    descLabel.SetBinding(Label.TextProperty, nameof(AssetType.Description));

                    var dateLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    dateLabel.SetBinding(Label.TextProperty, new Binding(nameof(AssetType.DateModified), stringFormat: "{0:MM/dd/yyyy}"));

                    var modByLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    modByLabel.SetBinding(Label.TextProperty, nameof(AssetType.ModifiedBy));

                    var editBtn = new Button { Text = "Edit", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                    editBtn.SetBinding(Button.CommandParameterProperty, ".");
                    editBtn.Command = new Command<AssetType>(async t => await EditAssetTypeAsync(t));

                    var deleteBtn = new Button { Text = "Delete", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                    deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                    deleteBtn.Command = new Command<AssetType>(async t => await DeleteAssetTypeAsync(t));

                    var actions = new HorizontalStackLayout { Spacing = 4 };
                    actions.Add(editBtn);
                    actions.Add(deleteBtn);

                    var doubleTap = new TapGestureRecognizer { NumberOfTapsRequired = 2 };
                    doubleTap.SetBinding(TapGestureRecognizer.CommandParameterProperty, ".");
                    doubleTap.Command = new Command<AssetType>(async t => await EditAssetTypeAsync(t));
                    nameLabel.GestureRecognizers.Add(doubleTap);

                    grid.Add(idLabel, 0);
                    grid.Add(nameLabel, 1);
                    grid.Add(descLabel, 2);
                    grid.Add(dateLabel, 3);
                    grid.Add(modByLabel, 4);
                    grid.Add(actions, 5);

                    return grid;
                })
            };

            var colHeader = new Grid
            {
                ColumnDefinitions =
                {
                    new ColumnDefinition(new GridLength(60)),
                    new ColumnDefinition(new GridLength(200)),
                    new ColumnDefinition(GridLength.Star),
                    new ColumnDefinition(new GridLength(150)),
                    new ColumnDefinition(new GridLength(120)),
                    new ColumnDefinition(new GridLength(150))
                },
                Padding = new Thickness(4),
                ColumnSpacing = 4,
                BackgroundColor = Color.FromArgb("#F5F5F5"),
                Children =
                {
                    new Label { Text = "ID", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 0)),
                    new Label { Text = "Type", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 1)),
                    new Label { Text = "Description", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 2)),
                    new Label { Text = "Date Modified", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 3)),
                    new Label { Text = "Modified By", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 4)),
                    new Label { Text = "Actions", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 5))
                }
            };

            collectionViewRef = collectionView;
            return CreateScrollableContainer(headerRow, collectionView, columnHeader: colHeader);
        }

        var mobileCollection = new CollectionView
        {
            ItemsSource = _types,
            SelectionMode = SelectionMode.Single,
            ItemTemplate = new DataTemplate(() =>
            {
                var border = new Border
                {
                    Stroke = Color.FromArgb("#DDD"),
                    StrokeThickness = 1,
                    Padding = new Thickness(12, 8),
                    Margin = new Thickness(0, 4),
                    BackgroundColor = Colors.White
                };

                var nameLabel = new Label { FontSize = 13, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.FillAndExpand };
                nameLabel.SetBinding(Label.TextProperty, nameof(AssetType.Type));

                var descLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666") };
                descLabel.SetBinding(Label.TextProperty, nameof(AssetType.Description));

                var metaLabel = new Label { FontSize = 10, TextColor = Color.FromArgb("#AAA") };
                metaLabel.SetBinding(Label.TextProperty, new Binding(".", stringFormat: "Modified: {0:MM/dd/yyyy} by {1}"));

                var editBtn = new Button { Text = "Edit", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                editBtn.SetBinding(Button.CommandParameterProperty, ".");
                editBtn.Command = new Command<AssetType>(async t => await EditAssetTypeAsync(t));

                var deleteBtn = new Button { Text = "Delete", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                deleteBtn.Command = new Command<AssetType>(async t => await DeleteAssetTypeAsync(t));

                var topStack = new HorizontalStackLayout { Spacing = 8 };
                topStack.Add(nameLabel);
                topStack.Add(editBtn);
                topStack.Add(deleteBtn);

                var content = new VerticalStackLayout { Spacing = 4 };
                content.Add(topStack);
                content.Add(descLabel);
                content.Add(metaLabel);

                border.Content = content;
                return border;
            })
        };

        return CreateScrollableContainer(headerRow, mobileCollection, includeDivider: false);
    }

    private async Task AddAssetTypeAsync()
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var name = await page.DisplayPromptAsync("Add Asset Type", "Enter type name:");
        if (string.IsNullOrWhiteSpace(name)) return;

        var desc = await page.DisplayPromptAsync("Add Asset Type", "Enter description (optional):");

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var newType = new AssetType { Type = name.Trim(), Description = desc?.Trim(), DateModified = DateTime.Now, ModifiedBy = _session.ATTUID ?? "system" };
            ctx.AssetType.Add(newType);
            await ctx.SaveChangesAsync();

            // Insert in sorted position
            _types.InsertSorted(newType, t => t.TypeID);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task EditAssetTypeAsync(AssetType type)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var newName = await page.DisplayPromptAsync("Edit Asset Type", "Edit type name:", initialValue: type.Type);
        if (string.IsNullOrWhiteSpace(newName)) return;

        var newDesc = await page.DisplayPromptAsync("Edit Asset Type", "Edit description:", initialValue: type.Description);

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            type.Type = newName.Trim();
            type.Description = newDesc?.Trim();
            type.DateModified = DateTime.Now;
            type.ModifiedBy = _session.ATTUID ?? "system";
            ctx.AssetType.Update(type);
            await ctx.SaveChangesAsync();

            // Update in place
            var index = _types.IndexOf(type);
            if (index >= 0)
            {
                _types.RemoveAt(index);
                _types.Insert(index, type);
            }
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task DeleteAssetTypeAsync(AssetType type)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var confirm = await page.DisplayAlert("Confirm Delete", $"Delete type '{type.Type}'?", "Delete", "Cancel");
        if (!confirm) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            ctx.AssetType.Remove(type);
            await ctx.SaveChangesAsync();

            // Remove from collection
            _types.Remove(type);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Delete Failed", $"Cannot delete: {ex.Message}", "OK");
        }
    }

    // ─── Companies Tab ─────────────────────────────────────────────────

    private async Task<View> BuildCompaniesViewAsync()
    {
        var addBtn = new Button { Text = "+ Add", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#1565C0"), TextColor = Colors.White };
        addBtn.Clicked += async (_, _) => await AddCompanyAsync();

        CollectionView? collectionViewRef = null;

        var searchEntry = new Entry { Placeholder = "Search companies...", FontSize = 12, HeightRequest = 32, WidthRequest = 250, BackgroundColor = Colors.White, Margin = new Thickness(0, 0, 12, 0) };
        searchEntry.TextChanged += (s, e) =>
        {
            _companySearchText = e.NewTextValue?.ToLower() ?? "";
            if (collectionViewRef == null) return;
            collectionViewRef.ItemsSource = string.IsNullOrWhiteSpace(_companySearchText)
                ? _companies
                : new RangeObservableCollection<Companies>(_companies.Where(c => c.CompanyName?.ToLower().Contains(_companySearchText) == true || c.CompanyType?.ToLower().Contains(_companySearchText) == true));
        };

        var scrollTopBtn = new Button { Text = "↑ Top", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
        scrollTopBtn.Clicked += (_, _) => { if (collectionViewRef != null && _companies.Count > 0) collectionViewRef.ScrollTo(0, position: ScrollToPosition.Start, animate: true); };

        var headerRow = new HorizontalStackLayout
        {
            Spacing = 12,
            Children =
            {
                new Label { Text = "Companies", FontAttributes = FontAttributes.Bold, FontSize = 16, VerticalOptions = LayoutOptions.Center },
                searchEntry,
                addBtn,
                scrollTopBtn,
                new Label { Text = $"{_companies.Count} total", FontSize = 12, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center }
            }
        };

        // Start loading data in background if needed
        if (_companies.Count == 0)
        {
            _ = Task.Run(async () =>
            {
                try
                {
                    await using var ctx = await _contextFactory.CreateDbContextAsync();
                    var data = await ctx.Companies.AsNoTracking().OrderBy(c => c.CompanyID).ToListAsync();

                    await MainThread.InvokeOnMainThreadAsync(() => _companies.AddRange(data));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"LoadCompanies error: {ex.Message}");
                }
            });
        }

        if (DeviceInfo.Current.Platform == DevicePlatform.WinUI)
        {
            var collectionView = new CollectionView
            {
                ItemsSource = _companies,
                SelectionMode = SelectionMode.Single,
                ItemTemplate = new DataTemplate(() =>
                {
                    var grid = new Grid
                    {
                        ColumnDefinitions =
                        {
                            new ColumnDefinition(new GridLength(60)),
                            new ColumnDefinition(new GridLength(200)),
                            new ColumnDefinition(GridLength.Star),
                            new ColumnDefinition(new GridLength(150)),
                            new ColumnDefinition(new GridLength(120)),
                            new ColumnDefinition(new GridLength(150))
                        },
                        Padding = new Thickness(4),
                        ColumnSpacing = 4
                    };

                    var idLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#999"), VerticalOptions = LayoutOptions.Center };
                    idLabel.SetBinding(Label.TextProperty, nameof(Companies.CompanyID));

                    var nameLabel = new Label { FontSize = 12, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center };
                    nameLabel.SetBinding(Label.TextProperty, nameof(Companies.CompanyName));

                    var typeLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    typeLabel.SetBinding(Label.TextProperty, nameof(Companies.CompanyType));

                    var dateLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    dateLabel.SetBinding(Label.TextProperty, new Binding(nameof(Companies.DateModified), stringFormat: "{0:MM/dd/yyyy}"));

                    var modByLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    modByLabel.SetBinding(Label.TextProperty, nameof(Companies.ModifiedBy));

                    var editBtn = new Button { Text = "Edit", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                    editBtn.SetBinding(Button.CommandParameterProperty, ".");
                    editBtn.Command = new Command<Companies>(async c => await EditCompanyAsync(c));

                    var deleteBtn = new Button { Text = "Delete", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                    deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                    deleteBtn.Command = new Command<Companies>(async c => await DeleteCompanyAsync(c));

                    var actions = new HorizontalStackLayout { Spacing = 4 };
                    actions.Add(editBtn);
                    actions.Add(deleteBtn);

                    var doubleTap = new TapGestureRecognizer { NumberOfTapsRequired = 2 };
                    doubleTap.SetBinding(TapGestureRecognizer.CommandParameterProperty, ".");
                    doubleTap.Command = new Command<Companies>(async c => await EditCompanyAsync(c));
                    nameLabel.GestureRecognizers.Add(doubleTap);

                    grid.Add(idLabel, 0);
                    grid.Add(nameLabel, 1);
                    grid.Add(typeLabel, 2);
                    grid.Add(dateLabel, 3);
                    grid.Add(modByLabel, 4);
                    grid.Add(actions, 5);

                    return grid;
                })
            };

            var colHeader = new Grid
            {
                ColumnDefinitions =
                {
                    new ColumnDefinition(new GridLength(60)),
                    new ColumnDefinition(new GridLength(200)),
                    new ColumnDefinition(GridLength.Star),
                    new ColumnDefinition(new GridLength(150)),
                    new ColumnDefinition(new GridLength(120)),
                    new ColumnDefinition(new GridLength(150))
                },
                Padding = new Thickness(4),
                ColumnSpacing = 4,
                BackgroundColor = Color.FromArgb("#F5F5F5"),
                Children =
                {
                    new Label { Text = "ID", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 0)),
                    new Label { Text = "Company Name", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 1)),
                    new Label { Text = "Company Type", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 2)),
                    new Label { Text = "Date Modified", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 3)),
                    new Label { Text = "Modified By", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 4)),
                    new Label { Text = "Actions", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 5))
                }
            };

            collectionViewRef = collectionView;
            return CreateScrollableContainer(headerRow, collectionView, columnHeader: colHeader);
        }

        var mobileCollection = new CollectionView
        {
            ItemsSource = _companies,
            SelectionMode = SelectionMode.Single,
            ItemTemplate = new DataTemplate(() =>
            {
                var border = new Border
                {
                    Stroke = Color.FromArgb("#DDD"),
                    StrokeThickness = 1,
                    Padding = new Thickness(12, 8),
                    Margin = new Thickness(0, 4),
                    BackgroundColor = Colors.White
                };

                var nameLabel = new Label { FontSize = 13, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.FillAndExpand };
                nameLabel.SetBinding(Label.TextProperty, nameof(Companies.CompanyName));

                var typeLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#888"), VerticalOptions = LayoutOptions.Center };
                typeLabel.SetBinding(Label.TextProperty, nameof(Companies.CompanyType));

                var editBtn = new Button { Text = "Edit", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                editBtn.SetBinding(Button.CommandParameterProperty, ".");
                editBtn.Command = new Command<Companies>(async c => await EditCompanyAsync(c));

                var deleteBtn = new Button { Text = "Delete", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                deleteBtn.Command = new Command<Companies>(async c => await DeleteCompanyAsync(c));

                var stack = new HorizontalStackLayout { Spacing = 8 };
                stack.Add(nameLabel);
                stack.Add(typeLabel);
                stack.Add(editBtn);
                stack.Add(deleteBtn);

                border.Content = stack;
                return border;
            })
        };

        return CreateScrollableContainer(headerRow, mobileCollection, includeDivider: false);
    }

    private async Task AddCompanyAsync()
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var name = await page.DisplayPromptAsync("Add Company", "Enter company name:");
        if (string.IsNullOrWhiteSpace(name)) return;

        var type = await page.DisplayPromptAsync("Add Company", "Enter company type (optional):");

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var newCompany = new Companies { CompanyName = name.Trim(), CompanyType = type?.Trim(), DateModified = DateTime.Now, ModifiedBy = _session.ATTUID ?? "system" };
            ctx.Companies.Add(newCompany);
            await ctx.SaveChangesAsync();

            // Insert in sorted position
            _companies.InsertSorted(newCompany, c => c.CompanyID);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task EditCompanyAsync(Companies company)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var newName = await page.DisplayPromptAsync("Edit Company", "Edit company name:", initialValue: company.CompanyName);
        if (string.IsNullOrWhiteSpace(newName)) return;

        var newType = await page.DisplayPromptAsync("Edit Company", "Edit company type:", initialValue: company.CompanyType);

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            company.CompanyName = newName.Trim();
            company.CompanyType = newType?.Trim();
            company.DateModified = DateTime.Now;
            company.ModifiedBy = _session.ATTUID ?? "system";
            ctx.Companies.Update(company);
            await ctx.SaveChangesAsync();

            // Update in place
            var index = _companies.IndexOf(company);
            if (index >= 0)
            {
                _companies.RemoveAt(index);
                _companies.Insert(index, company);
            }
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task DeleteCompanyAsync(Companies company)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var confirm = await page.DisplayAlert("Confirm Delete", $"Delete company '{company.CompanyName}'?", "Delete", "Cancel");
        if (!confirm) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            ctx.Companies.Remove(company);
            await ctx.SaveChangesAsync();

            // Remove from collection
            _companies.Remove(company);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Delete Failed", $"Cannot delete: {ex.Message}", "OK");
        }
    }

    private async Task<View> BuildLocationsViewAsync()
    {
        var addBtn = new Button { Text = "+ Add", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#1565C0"), TextColor = Colors.White };
        addBtn.Clicked += async (_, _) => await AddLocationAsync();

        CollectionView? collectionViewRef = null;

        var searchEntry = new Entry { Placeholder = "Search locations...", FontSize = 12, HeightRequest = 32, WidthRequest = 250, BackgroundColor = Colors.White, Margin = new Thickness(0, 0, 12, 0) };
        searchEntry.TextChanged += (s, e) =>
        {
            _locationSearchText = e.NewTextValue?.ToLower() ?? "";
            if (collectionViewRef == null) return;
            collectionViewRef.ItemsSource = string.IsNullOrWhiteSpace(_locationSearchText)
                ? _locations
                : new RangeObservableCollection<Locations>(_locations.Where(l => l.LocationName?.ToLower().Contains(_locationSearchText) == true || l.ClliCode?.ToLower().Contains(_locationSearchText) == true));
        };

        var scrollTopBtn = new Button { Text = "↑ Top", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
        scrollTopBtn.Clicked += (_, _) => { if (collectionViewRef != null && _locations.Count > 0) collectionViewRef.ScrollTo(0, position: ScrollToPosition.Start, animate: true); };

        var headerRow = new HorizontalStackLayout
        {
            Spacing = 12,
            Children =
            {
                new Label { Text = "Locations", FontAttributes = FontAttributes.Bold, FontSize = 16, VerticalOptions = LayoutOptions.Center },
                searchEntry,
                addBtn,
                scrollTopBtn,
                new Label { Text = $"{_locations.Count} total", FontSize = 12, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center }
            }
        };

        // Start loading data in background if needed
        if (_locations.Count == 0)
        {
            _ = Task.Run(async () =>
            {
                try
                {
                    await using var ctx = await _contextFactory.CreateDbContextAsync();
                    var data = await ctx.Locations.AsNoTracking().OrderBy(l => l.LocationID).ToListAsync();

                    await MainThread.InvokeOnMainThreadAsync(() => _locations.AddRange(data));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"LoadLocations error: {ex.Message}");
                }
            });
        }

        if (DeviceInfo.Current.Platform == DevicePlatform.WinUI)
        {
            var collectionView = new CollectionView
            {
                ItemsSource = _locations,
                SelectionMode = SelectionMode.Single,
                ItemTemplate = new DataTemplate(() =>
                {
                    var grid = new Grid
                    {
                        ColumnDefinitions =
                        {
                            new ColumnDefinition(new GridLength(60)),
                            new ColumnDefinition(new GridLength(200)),
                            new ColumnDefinition(GridLength.Star),
                            new ColumnDefinition(new GridLength(150)),
                            new ColumnDefinition(new GridLength(120)),
                            new ColumnDefinition(new GridLength(150))
                        },
                        Padding = new Thickness(4),
                        ColumnSpacing = 4
                    };

                    var idLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#999"), VerticalOptions = LayoutOptions.Center };
                    idLabel.SetBinding(Label.TextProperty, nameof(Locations.LocationID));

                    var nameLabel = new Label { FontSize = 12, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center };
                    nameLabel.SetBinding(Label.TextProperty, nameof(Locations.LocationName));

                    var clliLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    clliLabel.SetBinding(Label.TextProperty, nameof(Locations.ClliCode));

                    var dateLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    dateLabel.SetBinding(Label.TextProperty, new Binding(nameof(Locations.DateModified), stringFormat: "{0:MM/dd/yyyy}"));

                    var modByLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    modByLabel.SetBinding(Label.TextProperty, nameof(Locations.ModifiedBy));

                    var editBtn = new Button { Text = "Edit", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                    editBtn.SetBinding(Button.CommandParameterProperty, ".");
                    editBtn.Command = new Command<Locations>(async l => await EditLocationAsync(l));

                    var deleteBtn = new Button { Text = "Delete", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                    deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                    deleteBtn.Command = new Command<Locations>(async l => await DeleteLocationAsync(l));

                    var actions = new HorizontalStackLayout { Spacing = 4 };
                    actions.Add(editBtn);
                    actions.Add(deleteBtn);

                    var doubleTap = new TapGestureRecognizer { NumberOfTapsRequired = 2 };
                    doubleTap.SetBinding(TapGestureRecognizer.CommandParameterProperty, ".");
                    doubleTap.Command = new Command<Locations>(async l => await EditLocationAsync(l));
                    nameLabel.GestureRecognizers.Add(doubleTap);

                    grid.Add(idLabel, 0);
                    grid.Add(nameLabel, 1);
                    grid.Add(clliLabel, 2);
                    grid.Add(dateLabel, 3);
                    grid.Add(modByLabel, 4);
                    grid.Add(actions, 5);

                    return grid;
                })
            };

            var colHeader = new Grid
            {
                ColumnDefinitions =
                {
                    new ColumnDefinition(new GridLength(60)),
                    new ColumnDefinition(new GridLength(200)),
                    new ColumnDefinition(GridLength.Star),
                    new ColumnDefinition(new GridLength(150)),
                    new ColumnDefinition(new GridLength(120)),
                    new ColumnDefinition(new GridLength(150))
                },
                Padding = new Thickness(4),
                ColumnSpacing = 4,
                BackgroundColor = Color.FromArgb("#F5F5F5"),
                Children =
                {
                    new Label { Text = "ID", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 0)),
                    new Label { Text = "Location Name", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 1)),
                    new Label { Text = "CLLI Code", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 2)),
                    new Label { Text = "Date Modified", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 3)),
                    new Label { Text = "Modified By", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 4)),
                    new Label { Text = "Actions", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 5))
                }
            };

            collectionViewRef = collectionView;
            return CreateScrollableContainer(headerRow, collectionView, columnHeader: colHeader);
        }

        var mobileCollection = new CollectionView
        {
            ItemsSource = _locations,
            SelectionMode = SelectionMode.Single,
            ItemTemplate = new DataTemplate(() =>
            {
                var border = new Border
                {
                    Stroke = Color.FromArgb("#DDD"),
                    StrokeThickness = 1,
                    Padding = new Thickness(12, 8),
                    Margin = new Thickness(0, 4),
                    BackgroundColor = Colors.White
                };

                var nameLabel = new Label { FontSize = 13, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.FillAndExpand };
                nameLabel.SetBinding(Label.TextProperty, nameof(Locations.LocationName));

                var clliLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#888"), VerticalOptions = LayoutOptions.Center };
                clliLabel.SetBinding(Label.TextProperty, nameof(Locations.ClliCode));

                var editBtn = new Button { Text = "Edit", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                editBtn.SetBinding(Button.CommandParameterProperty, ".");
                editBtn.Command = new Command<Locations>(async l => await EditLocationAsync(l));

                var deleteBtn = new Button { Text = "Delete", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                deleteBtn.Command = new Command<Locations>(async l => await DeleteLocationAsync(l));

                var stack = new HorizontalStackLayout { Spacing = 8 };
                stack.Add(nameLabel);
                stack.Add(clliLabel);
                stack.Add(editBtn);
                stack.Add(deleteBtn);

                border.Content = stack;
                return border;
            })
        };

        return CreateScrollableContainer(headerRow, mobileCollection, includeDivider: false);
    }

    private async Task AddLocationAsync()
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var name = await page.DisplayPromptAsync("Add Location", "Enter location name:");
        if (string.IsNullOrWhiteSpace(name)) return;

        var clli = await page.DisplayPromptAsync("Add Location", "Enter CLLI code (optional):");

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var newLocation = new Locations { LocationName = name.Trim(), ClliCode = clli?.Trim(), DateModified = DateTime.Now, ModifiedBy = _session.ATTUID ?? "system" };
            ctx.Locations.Add(newLocation);
            await ctx.SaveChangesAsync();

            // Insert in sorted position
            _locations.InsertSorted(newLocation, l => l.LocationID ?? 0);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task EditLocationAsync(Locations location)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var newName = await page.DisplayPromptAsync("Edit Location", "Edit location name:", initialValue: location.LocationName);
        if (string.IsNullOrWhiteSpace(newName)) return;

        var newClli = await page.DisplayPromptAsync("Edit Location", "Edit CLLI code:", initialValue: location.ClliCode);

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            location.LocationName = newName.Trim();
            location.ClliCode = newClli?.Trim();
            location.DateModified = DateTime.Now;
            location.ModifiedBy = _session.ATTUID ?? "system";
            ctx.Locations.Update(location);
            await ctx.SaveChangesAsync();

            // Update in place
            var index = _locations.IndexOf(location);
            if (index >= 0)
            {
                _locations.RemoveAt(index);
                _locations.Insert(index, location);
            }
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task DeleteLocationAsync(Locations location)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var confirm = await page.DisplayAlert("Confirm Delete", $"Delete location '{location.LocationName}'?", "Delete", "Cancel");
        if (!confirm) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            ctx.Locations.Remove(location);
            await ctx.SaveChangesAsync();

            // Remove from collection
            _locations.Remove(location);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Delete Failed", $"Cannot delete: {ex.Message}", "OK");
        }
    }

    private async Task<View> BuildStorageViewAsync()
    {
        var addBtn = new Button { Text = "+ Add", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#1565C0"), TextColor = Colors.White };
        addBtn.Clicked += async (_, _) => await AddStorageAsync();

        CollectionView? collectionViewRef = null;

        var searchEntry = new Entry { Placeholder = "Search storage...", FontSize = 12, HeightRequest = 32, WidthRequest = 250, BackgroundColor = Colors.White, Margin = new Thickness(0, 0, 12, 0) };
        searchEntry.TextChanged += (s, e) =>
        {
            _storageSearchText = e.NewTextValue?.ToLower() ?? "";
            if (collectionViewRef == null) return;
            collectionViewRef.ItemsSource = string.IsNullOrWhiteSpace(_storageSearchText)
                ? _storages
                : new RangeObservableCollection<InventoryStorage>(_storages.Where(s2 => s2.Storage?.ToLower().Contains(_storageSearchText) == true || s2.Divider?.ToLower().Contains(_storageSearchText) == true));
        };

        var scrollTopBtn = new Button { Text = "↑ Top", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
        scrollTopBtn.Clicked += (_, _) => { if (collectionViewRef != null && _storages.Count > 0) collectionViewRef.ScrollTo(0, position: ScrollToPosition.Start, animate: true); };

        var headerRow = new HorizontalStackLayout
        {
            Spacing = 12,
            Children =
            {
                new Label { Text = "Storage Locations", FontAttributes = FontAttributes.Bold, FontSize = 16, VerticalOptions = LayoutOptions.Center },
                searchEntry,
                addBtn,
                scrollTopBtn,
                new Label { Text = $"{_storages.Count} total", FontSize = 12, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center }
            }
        };

        // Start loading data in background if needed
        if (_storages.Count == 0)
        {
            _ = Task.Run(async () =>
            {
                try
                {
                    await using var ctx = await _contextFactory.CreateDbContextAsync();
                    var data = await ctx.InventoryStorage.AsNoTracking().OrderBy(s => s.StorageID).ToListAsync();

                    await MainThread.InvokeOnMainThreadAsync(() => _storages.AddRange(data));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"LoadStorage error: {ex.Message}");
                }
            });
        }

        if (DeviceInfo.Current.Platform == DevicePlatform.WinUI)
        {
            var collectionView = new CollectionView
            {
                ItemsSource = _storages,
                SelectionMode = SelectionMode.Single,
                ItemTemplate = new DataTemplate(() =>
                {
                    var grid = new Grid
                    {
                        ColumnDefinitions =
                        {
                            new ColumnDefinition(new GridLength(60)),
                            new ColumnDefinition(new GridLength(200)),
                            new ColumnDefinition(GridLength.Star),
                            new ColumnDefinition(new GridLength(150)),
                            new ColumnDefinition(new GridLength(120)),
                            new ColumnDefinition(new GridLength(150))
                        },
                        Padding = new Thickness(4),
                        ColumnSpacing = 4
                    };

                    var idLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#999"), VerticalOptions = LayoutOptions.Center };
                    idLabel.SetBinding(Label.TextProperty, nameof(InventoryStorage.StorageID));

                    var nameLabel = new Label { FontSize = 12, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center };
                    nameLabel.SetBinding(Label.TextProperty, nameof(InventoryStorage.Storage));

                    var dividerLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    dividerLabel.SetBinding(Label.TextProperty, nameof(InventoryStorage.Divider));

                    var dateLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    dateLabel.SetBinding(Label.TextProperty, new Binding(nameof(InventoryStorage.DateModified), stringFormat: "{0:MM/dd/yyyy}"));

                    var modByLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    modByLabel.SetBinding(Label.TextProperty, nameof(InventoryStorage.ModifiedBy));

                    var editBtn = new Button { Text = "Edit", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                    editBtn.SetBinding(Button.CommandParameterProperty, ".");
                    editBtn.Command = new Command<InventoryStorage>(async s => await EditStorageAsync(s));

                    var deleteBtn = new Button { Text = "Delete", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                    deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                    deleteBtn.Command = new Command<InventoryStorage>(async s => await DeleteStorageAsync(s));

                    var actions = new HorizontalStackLayout { Spacing = 4 };
                    actions.Add(editBtn);
                    actions.Add(deleteBtn);

                    var doubleTap = new TapGestureRecognizer { NumberOfTapsRequired = 2 };
                    doubleTap.SetBinding(TapGestureRecognizer.CommandParameterProperty, ".");
                    doubleTap.Command = new Command<InventoryStorage>(async s => await EditStorageAsync(s));
                    nameLabel.GestureRecognizers.Add(doubleTap);

                    grid.Add(idLabel, 0);
                    grid.Add(nameLabel, 1);
                    grid.Add(dividerLabel, 2);
                    grid.Add(dateLabel, 3);
                    grid.Add(modByLabel, 4);
                    grid.Add(actions, 5);

                    return grid;
                })
            };

            var colHeader = new Grid
            {
                ColumnDefinitions =
                {
                    new ColumnDefinition(new GridLength(60)),
                    new ColumnDefinition(new GridLength(200)),
                    new ColumnDefinition(GridLength.Star),
                    new ColumnDefinition(new GridLength(150)),
                    new ColumnDefinition(new GridLength(120)),
                    new ColumnDefinition(new GridLength(150))
                },
                Padding = new Thickness(4),
                ColumnSpacing = 4,
                BackgroundColor = Color.FromArgb("#F5F5F5"),
                Children =
                {
                    new Label { Text = "ID", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 0)),
                    new Label { Text = "Storage Name", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 1)),
                    new Label { Text = "Divider", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 2)),
                    new Label { Text = "Date Modified", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 3)),
                    new Label { Text = "Modified By", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 4)),
                    new Label { Text = "Actions", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 5))
                }
            };

            collectionViewRef = collectionView;
            return CreateScrollableContainer(headerRow, collectionView, columnHeader: colHeader);
        }

        var mobileCollection = new CollectionView
        {
            ItemsSource = _storages,
            SelectionMode = SelectionMode.Single,
            ItemTemplate = new DataTemplate(() =>
            {
                var border = new Border
                {
                    Stroke = Color.FromArgb("#DDD"),
                    StrokeThickness = 1,
                    Padding = new Thickness(12, 8),
                    Margin = new Thickness(0, 4),
                    BackgroundColor = Colors.White
                };

                var nameLabel = new Label { FontSize = 13, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.FillAndExpand };
                nameLabel.SetBinding(Label.TextProperty, nameof(InventoryStorage.Storage));

                var dividerLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#888"), VerticalOptions = LayoutOptions.Center };
                dividerLabel.SetBinding(Label.TextProperty, nameof(InventoryStorage.Divider));

                var editBtn = new Button { Text = "Edit", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                editBtn.SetBinding(Button.CommandParameterProperty, ".");
                editBtn.Command = new Command<InventoryStorage>(async s => await EditStorageAsync(s));

                var deleteBtn = new Button { Text = "Delete", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                deleteBtn.Command = new Command<InventoryStorage>(async s => await DeleteStorageAsync(s));

                var stack = new HorizontalStackLayout { Spacing = 8 };
                stack.Add(nameLabel);
                stack.Add(dividerLabel);
                stack.Add(editBtn);
                stack.Add(deleteBtn);

                border.Content = stack;
                return border;
            })
        };

        return CreateScrollableContainer(headerRow, mobileCollection, includeDivider: false);
    }

    private async Task AddStorageAsync()
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var name = await page.DisplayPromptAsync("Add Storage", "Enter storage name:");
        if (string.IsNullOrWhiteSpace(name)) return;

        var divider = await page.DisplayPromptAsync("Add Storage", "Enter divider (optional):");

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var newStorage = new InventoryStorage { Storage = name.Trim(), Divider = divider?.Trim(), DateModified = DateTime.Now, ModifiedBy = _session.ATTUID ?? "system" };
            ctx.InventoryStorage.Add(newStorage);
            await ctx.SaveChangesAsync();

            // Insert in sorted position
            _storages.InsertSorted(newStorage, s => s.StorageID ?? 0);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task EditStorageAsync(InventoryStorage storage)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var newName = await page.DisplayPromptAsync("Edit Storage", "Edit storage name:", initialValue: storage.Storage);
        if (string.IsNullOrWhiteSpace(newName)) return;

        var newDivider = await page.DisplayPromptAsync("Edit Storage", "Edit divider:", initialValue: storage.Divider);

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            storage.Storage = newName.Trim();
            storage.Divider = newDivider?.Trim();
            storage.DateModified = DateTime.Now;
            storage.ModifiedBy = _session.ATTUID ?? "system";
            ctx.InventoryStorage.Update(storage);
            await ctx.SaveChangesAsync();

            // Update in place
            var index = _storages.IndexOf(storage);
            if (index >= 0)
            {
                _storages.RemoveAt(index);
                _storages.Insert(index, storage);
            }
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task DeleteStorageAsync(InventoryStorage storage)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var confirm = await page.DisplayAlert("Confirm Delete", $"Delete storage '{storage.Storage}'?", "Delete", "Cancel");
        if (!confirm) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            ctx.InventoryStorage.Remove(storage);
            await ctx.SaveChangesAsync();

            // Remove from collection
            _storages.Remove(storage);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Delete Failed", $"Cannot delete: {ex.Message}", "OK");
        }
    }

    private async Task<View> BuildAssetViewAsync()
    {
        var addBtn = new Button { Text = "+ Add", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#1565C0"), TextColor = Colors.White };
        addBtn.Clicked += async (_, _) => await AddAssetAsync();

        var searchEntry = new Entry 
        { 
            Placeholder = "Search assets...", 
            FontSize = 12, 
            HeightRequest = 32,
            WidthRequest = 240,
            BackgroundColor = Colors.White
        };

        CollectionView? collectionViewRef = null;

        var searchGoBtn = new Button { Text = "Go", FontSize = 11, HeightRequest = 28, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#1976D2"), TextColor = Colors.White };
        var searchClearBtn = new Button { Text = "Clear", FontSize = 11, HeightRequest = 28, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#E0E0E0"), TextColor = Color.FromArgb("#333") };

        searchGoBtn.Clicked += (_, _) =>
        {
            _assetSearchText = searchEntry.Text?.ToLower() ?? "";
            if (collectionViewRef == null) return;
            collectionViewRef.ItemsSource = string.IsNullOrWhiteSpace(_assetSearchText)
                ? _assets
                : new RangeObservableCollection<Asset>(_assets.Where(a =>
                    a.AssetTag?.ToLower().Contains(_assetSearchText) == true ||
                    a.Status?.ToLower().Contains(_assetSearchText) == true));
        };

        searchClearBtn.Clicked += (_, _) =>
        {
            searchEntry.Text = "";
            _assetSearchText = "";
            if (collectionViewRef != null) collectionViewRef.ItemsSource = _assets;
        };

        var headerRow = new HorizontalStackLayout
        {
            Spacing = 8,
            Children =
            {
                new Label { Text = "Assets", FontAttributes = FontAttributes.Bold, FontSize = 16, VerticalOptions = LayoutOptions.Center },
                addBtn
            }
        };

        // ─── Footer nav bar (matches InventoryList / CalibrationLog pattern) ───
        _assetsStatusLabel = new Label { Text = "Loading...", FontSize = 12, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };

        var moveFirstBtn = new Button { Text = "|<", FontSize = 12, HeightRequest = 32, WidthRequest = 40, Padding = new Thickness(0) };
        var movePrevBtn = new Button { Text = "<", FontSize = 12, HeightRequest = 32, WidthRequest = 40, Padding = new Thickness(0) };
        var moveNextBtn = new Button { Text = ">", FontSize = 12, HeightRequest = 32, WidthRequest = 40, Padding = new Thickness(0) };
        var moveLastBtn = new Button { Text = ">|", FontSize = 12, HeightRequest = 32, WidthRequest = 40, Padding = new Thickness(0) };

        moveFirstBtn.Clicked += (_, _) =>
        {
            if (collectionViewRef != null && _assets.Count > 0)
            {
                collectionViewRef.SelectedItem = _assets[0];
                collectionViewRef.ScrollTo(0, position: ScrollToPosition.Start, animate: false);
            }
        };
        movePrevBtn.Clicked += (_, _) =>
        {
            if (collectionViewRef?.SelectedItem is Asset sel)
            {
                var idx = _assets.IndexOf(sel);
                if (idx > 0)
                {
                    collectionViewRef.SelectedItem = _assets[idx - 1];
                    collectionViewRef.ScrollTo(idx - 1, position: ScrollToPosition.Center, animate: false);
                }
            }
        };
        moveNextBtn.Clicked += (_, _) =>
        {
            if (collectionViewRef?.SelectedItem is Asset sel)
            {
                var idx = _assets.IndexOf(sel);
                if (idx >= 0 && idx < _assets.Count - 1)
                {
                    collectionViewRef.SelectedItem = _assets[idx + 1];
                    collectionViewRef.ScrollTo(idx + 1, position: ScrollToPosition.Center, animate: false);
                }
            }
        };
        moveLastBtn.Clicked += (_, _) =>
        {
            if (collectionViewRef != null && _assets.Count > 0)
            {
                collectionViewRef.SelectedItem = _assets[^1];
                collectionViewRef.ScrollTo(_assets.Count - 1, position: ScrollToPosition.End, animate: false);
            }
        };

        var loadMoreBtn = new Button { Text = "Load More", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#E3F2FD"), TextColor = Color.FromArgb("#1565C0") };
        loadMoreBtn.Clicked += async (_, _) => { await LoadMoreAssetsAsync(); UpdateAssetsStatus(); };

        var loadAllBtn = new Button { Text = "Load All", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#FFF3E0"), TextColor = Color.FromArgb("#E65100") };
        loadAllBtn.Clicked += async (_, _) =>
        {
            while (_assetsLoadedCount < _assetsTotalCount)
            {
                await LoadMoreAssetsAsync();
                UpdateAssetsStatus();
            }
        };

        var footerBar = new Border
        {
            Stroke = Color.FromArgb("#DDD"),
            StrokeThickness = 1,
            BackgroundColor = Colors.White,
            Padding = new Thickness(8),
            Content = new Grid
            {
                ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Auto) },
                ColumnSpacing = 8,
                Children =
                {
                    _assetsStatusLabel.Apply(l => Grid.SetColumn(l, 0)),
                    new HorizontalStackLayout
                    {
                        Spacing = 4,
                        Children = { searchEntry, searchGoBtn, searchClearBtn }
                    }.Apply(s => Grid.SetColumn(s, 1)),
                    new HorizontalStackLayout
                    {
                        Spacing = 4,
                        Children = { moveFirstBtn, movePrevBtn, moveNextBtn, moveLastBtn }
                    }.Apply(s => Grid.SetColumn(s, 2)),
                    new HorizontalStackLayout
                    {
                        Spacing = 4,
                        Children = { loadMoreBtn, loadAllBtn }
                    }.Apply(s => Grid.SetColumn(s, 3))
                }
            }
        };

        // Get total count and start loading first page
        if (_assets.Count == 0)
        {
            _assetsLoadedCount = 0;
            _isLoadingAssets = false;
            _ = Task.Run(async () =>
            {
                await using var ctx = await _contextFactory.CreateDbContextAsync();
                _assetsTotalCount = await ctx.Asset.CountAsync();
                await MainThread.InvokeOnMainThreadAsync(() => UpdateAssetsStatus());
            });
            _ = LoadMoreAssetsAsync().ContinueWith(_ => MainThread.BeginInvokeOnMainThread(UpdateAssetsStatus));
        }
        else
        {
            UpdateAssetsStatus();
        }

        // Windows: Use CollectionView for virtualization
        if (DeviceInfo.Current.Platform == DevicePlatform.WinUI)
        {
            var collectionView = new CollectionView
            {
                ItemsSource = _assets,
                SelectionMode = SelectionMode.Single,
                SelectedItem = null,
                RemainingItemsThreshold = 20,
                RemainingItemsThresholdReachedCommand = new Command(async () => await LoadMoreAssetsAsync()),
                ItemTemplate = new DataTemplate(() =>
                {
                    var grid = new Grid
                    {
                        ColumnDefinitions =
                        {
                            new ColumnDefinition(new GridLength(60)),
                            new ColumnDefinition(new GridLength(200)),
                            new ColumnDefinition(GridLength.Star),
                            new ColumnDefinition(new GridLength(150)),
                            new ColumnDefinition(new GridLength(120)),
                            new ColumnDefinition(new GridLength(150))
                        },
                        Padding = new Thickness(4),
                        ColumnSpacing = 4
                    };

                    var idLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#999"), VerticalOptions = LayoutOptions.Center };
                    idLabel.SetBinding(Label.TextProperty, nameof(Asset.AssetID));

                    var tagLabel = new Label { FontSize = 12, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center };
                    tagLabel.SetBinding(Label.TextProperty, nameof(Asset.AssetTag));

                    var statusLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    statusLabel.SetBinding(Label.TextProperty, nameof(Asset.Status));

                    var dateLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    dateLabel.SetBinding(Label.TextProperty, new Binding(nameof(Asset.DateModified), stringFormat: "{0:MM/dd/yyyy}"));

                    var modByLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    modByLabel.SetBinding(Label.TextProperty, nameof(Asset.ModifiedBy));

                    var editBtn = new Button { Text = "Edit", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                    editBtn.SetBinding(Button.CommandParameterProperty, ".");
                    editBtn.Command = new Command<Asset>(async a => await EditAssetAsync(a));

                    var deleteBtn = new Button { Text = "Delete", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                    deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                    deleteBtn.Command = new Command<Asset>(async a => await DeleteAssetAsync(a));

                    var actions = new HorizontalStackLayout { Spacing = 4 };
                    actions.Add(editBtn);
                    actions.Add(deleteBtn);

                    // Double-click gesture
                    var doubleTap = new TapGestureRecognizer { NumberOfTapsRequired = 2 };
                    doubleTap.SetBinding(TapGestureRecognizer.CommandParameterProperty, ".");
                    doubleTap.Command = new Command<Asset>(async a => await EditAssetAsync(a));
                    tagLabel.GestureRecognizers.Add(doubleTap);

                    grid.Add(idLabel, 0);
                    grid.Add(tagLabel, 1);
                    grid.Add(statusLabel, 2);
                    grid.Add(dateLabel, 3);
                    grid.Add(modByLabel, 4);
                    grid.Add(actions, 5);

                    return grid;
                })
            };

            var colHeader = new Grid
            {
                ColumnDefinitions =
                {
                    new ColumnDefinition(new GridLength(60)),
                    new ColumnDefinition(new GridLength(200)),
                    new ColumnDefinition(GridLength.Star),
                    new ColumnDefinition(new GridLength(150)),
                    new ColumnDefinition(new GridLength(120)),
                    new ColumnDefinition(new GridLength(150))
                },
                Padding = new Thickness(4),
                ColumnSpacing = 4,
                BackgroundColor = Color.FromArgb("#F5F5F5"),
                Children =
                {
                    new Label { Text = "ID", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 0)),
                    new Label { Text = "Asset Tag", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 1)),
                    new Label { Text = "Status", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 2)),
                    new Label { Text = "Date Modified", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 3)),
                    new Label { Text = "Modified By", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 4)),
                    new Label { Text = "Actions", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 5))
                }
            };

            collectionViewRef = collectionView;

            return CreateScrollableContainer(headerRow, collectionView, footer: footerBar, columnHeader: colHeader);
        }

        // Mobile: Use CollectionView
        var mobileCollection = new CollectionView
        {
            ItemsSource = _assets,
            SelectionMode = SelectionMode.Single,
            RemainingItemsThreshold = 20,
            RemainingItemsThresholdReachedCommand = new Command(async () => await LoadMoreAssetsAsync()),
            ItemTemplate = new DataTemplate(() =>
            {
                var border = new Border
                {
                    Stroke = Color.FromArgb("#DDD"),
                    StrokeThickness = 1,
                    Padding = new Thickness(12, 8),
                    Margin = new Thickness(0, 4),
                    BackgroundColor = Colors.White
                };

                var nameLabel = new Label { FontSize = 13, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.FillAndExpand };
                nameLabel.SetBinding(Label.TextProperty, nameof(Asset.AssetTag));

                var statusLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#888"), VerticalOptions = LayoutOptions.Center };
                statusLabel.SetBinding(Label.TextProperty, nameof(Asset.Status));

                var editBtn = new Button { Text = "Edit", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                editBtn.SetBinding(Button.CommandParameterProperty, ".");
                editBtn.Command = new Command<Asset>(async a => await EditAssetAsync(a));

                var deleteBtn = new Button { Text = "Delete", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                deleteBtn.Command = new Command<Asset>(async a => await DeleteAssetAsync(a));

                var stack = new HorizontalStackLayout { Spacing = 8 };
                stack.Add(nameLabel);
                stack.Add(statusLabel);
                stack.Add(editBtn);
                stack.Add(deleteBtn);

                border.Content = stack;
                return border;
            })
        };

        return CreateScrollableContainer(headerRow, mobileCollection, includeDivider: false, footer: footerBar);
    }

    private async Task AddAssetAsync()
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var tag = await page.DisplayPromptAsync("Add Asset", "Enter asset tag:");
        if (string.IsNullOrWhiteSpace(tag)) return;

        var status = await page.DisplayPromptAsync("Add Asset", "Enter status (optional):");

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var newAsset = new Asset { AssetTag = tag.Trim(), Status = status?.Trim(), DateModified = DateTime.Now, ModifiedBy = _session.ATTUID ?? "system" };
            ctx.Asset.Add(newAsset);
            await ctx.SaveChangesAsync();

            // Add to collection
            _assets.Add(newAsset);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task EditAssetAsync(Asset asset)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var newTag = await page.DisplayPromptAsync("Edit Asset", "Edit asset tag:", initialValue: asset.AssetTag);
        if (string.IsNullOrWhiteSpace(newTag)) return;

        var newStatus = await page.DisplayPromptAsync("Edit Asset", "Edit status:", initialValue: asset.Status);

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            asset.AssetTag = newTag.Trim();
            asset.Status = newStatus?.Trim();
            asset.DateModified = DateTime.Now;
            asset.ModifiedBy = _session.ATTUID ?? "system";
            ctx.Asset.Update(asset);
            await ctx.SaveChangesAsync();

            // Update in place
            var index = _assets.IndexOf(asset);
            if (index >= 0)
            {
                _assets.RemoveAt(index);
                _assets.Insert(index, asset);
            }
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task DeleteAssetAsync(Asset asset)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var confirm = await page.DisplayAlert("Confirm Delete", $"Delete asset '{asset.AssetTag}'?", "Delete", "Cancel");
        if (!confirm) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            ctx.Asset.Remove(asset);
            await ctx.SaveChangesAsync();

            // Remove from collection
            _assets.Remove(asset);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Delete Failed", $"Cannot delete: {ex.Message}", "OK");
        }
    }

    private async Task<View> BuildNotesViewAsync()
    {
        var addBtn = new Button { Text = "+ Add", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#1565C0"), TextColor = Colors.White };
        addBtn.Clicked += async (_, _) => await AddNoteAsync();

        var searchEntry = new Entry 
        { 
            Placeholder = "Search notes...", 
            FontSize = 12, 
            HeightRequest = 32,
            WidthRequest = 240,
            BackgroundColor = Colors.White
        };

        CollectionView? collectionViewRef = null;

        var searchGoBtn = new Button { Text = "Go", FontSize = 11, HeightRequest = 28, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#1976D2"), TextColor = Colors.White };
        var searchClearBtn = new Button { Text = "Clear", FontSize = 11, HeightRequest = 28, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#E0E0E0"), TextColor = Color.FromArgb("#333") };

        searchGoBtn.Clicked += (_, _) =>
        {
            _noteSearchText = searchEntry.Text?.ToLower() ?? "";
            if (collectionViewRef == null) return;
            collectionViewRef.ItemsSource = string.IsNullOrWhiteSpace(_noteSearchText)
                ? _notes
                : new RangeObservableCollection<Notes>(_notes.Where(n =>
                    n.InventoryNotes?.ToLower().Contains(_noteSearchText) == true));
        };

        searchClearBtn.Clicked += (_, _) =>
        {
            searchEntry.Text = "";
            _noteSearchText = "";
            if (collectionViewRef != null) collectionViewRef.ItemsSource = _notes;
        };

        var headerRow = new HorizontalStackLayout
        {
            Spacing = 8,
            Children =
            {
                new Label { Text = "Notes", FontAttributes = FontAttributes.Bold, FontSize = 16, VerticalOptions = LayoutOptions.Center },
                addBtn
            }
        };

        // ─── Footer nav bar (matches InventoryList / CalibrationLog pattern) ───
        _notesStatusLabel = new Label { Text = "Loading...", FontSize = 12, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };

        var moveFirstBtn = new Button { Text = "|<", FontSize = 12, HeightRequest = 32, WidthRequest = 40, Padding = new Thickness(0) };
        var movePrevBtn = new Button { Text = "<", FontSize = 12, HeightRequest = 32, WidthRequest = 40, Padding = new Thickness(0) };
        var moveNextBtn = new Button { Text = ">", FontSize = 12, HeightRequest = 32, WidthRequest = 40, Padding = new Thickness(0) };
        var moveLastBtn = new Button { Text = ">|", FontSize = 12, HeightRequest = 32, WidthRequest = 40, Padding = new Thickness(0) };

        moveFirstBtn.Clicked += (_, _) =>
        {
            if (collectionViewRef != null && _notes.Count > 0)
            {
                collectionViewRef.SelectedItem = _notes[0];
                collectionViewRef.ScrollTo(0, position: ScrollToPosition.Start, animate: false);
            }
        };
        movePrevBtn.Clicked += (_, _) =>
        {
            if (collectionViewRef?.SelectedItem is Notes sel)
            {
                var idx = _notes.IndexOf(sel);
                if (idx > 0)
                {
                    collectionViewRef.SelectedItem = _notes[idx - 1];
                    collectionViewRef.ScrollTo(idx - 1, position: ScrollToPosition.Center, animate: false);
                }
            }
        };
        moveNextBtn.Clicked += (_, _) =>
        {
            if (collectionViewRef?.SelectedItem is Notes sel)
            {
                var idx = _notes.IndexOf(sel);
                if (idx >= 0 && idx < _notes.Count - 1)
                {
                    collectionViewRef.SelectedItem = _notes[idx + 1];
                    collectionViewRef.ScrollTo(idx + 1, position: ScrollToPosition.Center, animate: false);
                }
            }
        };
        moveLastBtn.Clicked += (_, _) =>
        {
            if (collectionViewRef != null && _notes.Count > 0)
            {
                collectionViewRef.SelectedItem = _notes[^1];
                collectionViewRef.ScrollTo(_notes.Count - 1, position: ScrollToPosition.End, animate: false);
            }
        };

        var loadMoreBtn = new Button { Text = "Load More", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#E3F2FD"), TextColor = Color.FromArgb("#1565C0") };
        loadMoreBtn.Clicked += async (_, _) => { await LoadMoreNotesAsync(); UpdateNotesStatus(); };

        var loadAllBtn = new Button { Text = "Load All", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#FFF3E0"), TextColor = Color.FromArgb("#E65100") };
        loadAllBtn.Clicked += async (_, _) =>
        {
            while (_notesLoadedCount < _notesTotalCount)
            {
                await LoadMoreNotesAsync();
                UpdateNotesStatus();
            }
        };

        var footerBar = new Border
        {
            Stroke = Color.FromArgb("#DDD"),
            StrokeThickness = 1,
            BackgroundColor = Colors.White,
            Padding = new Thickness(8),
            Content = new Grid
            {
                ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Auto) },
                ColumnSpacing = 8,
                Children =
                {
                    _notesStatusLabel.Apply(l => Grid.SetColumn(l, 0)),
                    new HorizontalStackLayout
                    {
                        Spacing = 4,
                        Children = { searchEntry, searchGoBtn, searchClearBtn }
                    }.Apply(s => Grid.SetColumn(s, 1)),
                    new HorizontalStackLayout
                    {
                        Spacing = 4,
                        Children = { moveFirstBtn, movePrevBtn, moveNextBtn, moveLastBtn }
                    }.Apply(s => Grid.SetColumn(s, 2)),
                    new HorizontalStackLayout
                    {
                        Spacing = 4,
                        Children = { loadMoreBtn, loadAllBtn }
                    }.Apply(s => Grid.SetColumn(s, 3))
                }
            }
        };

        // Get total count and start loading first page
        if (_notes.Count == 0)
        {
            _notesLoadedCount = 0;
            _isLoadingNotes = false;
            _ = Task.Run(async () =>
            {
                await using var ctx = await _contextFactory.CreateDbContextAsync();
                _notesTotalCount = await ctx.Notes.CountAsync();
                await MainThread.InvokeOnMainThreadAsync(() => UpdateNotesStatus());
            });
            _ = LoadMoreNotesAsync().ContinueWith(_ => MainThread.BeginInvokeOnMainThread(UpdateNotesStatus));
        }
        else
        {
            UpdateNotesStatus();
        }

        // Windows: Use CollectionView for virtualization
        if (DeviceInfo.Current.Platform == DevicePlatform.WinUI)
        {
            var collectionView = new CollectionView
            {
                ItemsSource = _notes,
                SelectionMode = SelectionMode.Single,
                SelectedItem = null,
                RemainingItemsThreshold = 20,
                RemainingItemsThresholdReachedCommand = new Command(async () => await LoadMoreNotesAsync()),
                ItemTemplate = new DataTemplate(() =>
                {
                    var outerBorder = new Border
                    {
                        BackgroundColor = Colors.Transparent,
                        Padding = new Thickness(0)
                    };

                    var grid = new Grid
                    {
                        ColumnDefinitions =
                        {
                            new ColumnDefinition(new GridLength(60)),
                            new ColumnDefinition(new GridLength(200)),
                            new ColumnDefinition(GridLength.Star),
                            new ColumnDefinition(new GridLength(150)),
                            new ColumnDefinition(new GridLength(120)),
                            new ColumnDefinition(new GridLength(150))
                        },
                        Padding = new Thickness(4),
                        ColumnSpacing = 4
                    };

                    outerBorder.Content = grid;

                    // Visual state for selection
                    VisualStateManager.SetVisualStateGroups(outerBorder, new VisualStateGroupList
                    {
                        new VisualStateGroup
                        {
                            Name = "CommonStates",
                            States =
                            {
                                new VisualState
                                {
                                    Name = "Normal"
                                },
                                new VisualState
                                {
                                    Name = "Selected",
                                    Setters =
                                    {
                                        new Setter { Property = Border.BackgroundColorProperty, Value = Color.FromArgb("#E3F2FD") }
                                    }
                                }
                            }
                        }
                    });

                    var idLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#999"), VerticalOptions = LayoutOptions.Center };
                    idLabel.SetBinding(Label.TextProperty, nameof(Notes.NotesID));

                    var previewLabel = new Label { FontSize = 12, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center };
                    previewLabel.SetBinding(Label.TextProperty, new Binding(nameof(Notes.InventoryNotes), converter: new NotePreviewConverter()));

                    var emptyLabel = new Label { Text = "", FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };

                    var dateLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    dateLabel.SetBinding(Label.TextProperty, new Binding(nameof(Notes.DateModified), stringFormat: "{0:MM/dd/yyyy}"));

                    var modByLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    modByLabel.SetBinding(Label.TextProperty, nameof(Notes.ModifiedBy));

                    var editBtn = new Button { Text = "Edit", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                    editBtn.SetBinding(Button.CommandParameterProperty, ".");
                    editBtn.Command = new Command<Notes>(async n => await EditNoteAsync(n));

                    var deleteBtn = new Button { Text = "Delete", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                    deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                    deleteBtn.Command = new Command<Notes>(async n => await DeleteNoteAsync(n));

                    var actions = new HorizontalStackLayout { Spacing = 4 };
                    actions.Add(editBtn);
                    actions.Add(deleteBtn);

                    // Double-click gesture
                    var doubleTap = new TapGestureRecognizer { NumberOfTapsRequired = 2 };
                    doubleTap.SetBinding(TapGestureRecognizer.CommandParameterProperty, ".");
                    doubleTap.Command = new Command<Notes>(async n => await EditNoteAsync(n));
                    previewLabel.GestureRecognizers.Add(doubleTap);

                    grid.Add(idLabel, 0);
                    grid.Add(previewLabel, 1);
                    grid.Add(emptyLabel, 2);
                    grid.Add(dateLabel, 3);
                    grid.Add(modByLabel, 4);
                    grid.Add(actions, 5);

                    return outerBorder;
                })
            };

            var colHeader = new Grid
            {
                ColumnDefinitions =
                {
                    new ColumnDefinition(new GridLength(60)),
                    new ColumnDefinition(new GridLength(200)),
                    new ColumnDefinition(GridLength.Star),
                    new ColumnDefinition(new GridLength(150)),
                    new ColumnDefinition(new GridLength(120)),
                    new ColumnDefinition(new GridLength(150))
                },
                Padding = new Thickness(4),
                ColumnSpacing = 4,
                BackgroundColor = Color.FromArgb("#F5F5F5"),
                Children =
                {
                    new Label { Text = "ID", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 0)),
                    new Label { Text = "Note Preview", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 1)),
                    new Label { Text = "", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 2)),
                    new Label { Text = "Date Modified", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 3)),
                    new Label { Text = "Modified By", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 4)),
                    new Label { Text = "Actions", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 5))
                }
            };

            collectionViewRef = collectionView;

            return CreateScrollableContainer(headerRow, collectionView, footer: footerBar, columnHeader: colHeader);
        }

        // Mobile: Use CollectionView
        var mobileCollection = new CollectionView
        {
            ItemsSource = _notes,
            SelectionMode = SelectionMode.Single,
            RemainingItemsThreshold = 20,
            RemainingItemsThresholdReachedCommand = new Command(async () => await LoadMoreNotesAsync()),
            ItemTemplate = new DataTemplate(() =>
            {
                var border = new Border
                {
                    Stroke = Color.FromArgb("#DDD"),
                    StrokeThickness = 1,
                    Padding = new Thickness(12, 8),
                    Margin = new Thickness(0, 4),
                    BackgroundColor = Colors.White
                };

                var previewLabel = new Label { FontSize = 13, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.FillAndExpand };
                previewLabel.SetBinding(Label.TextProperty, new Binding(nameof(Notes.InventoryNotes), converter: new NotePreviewConverter()));

                var editBtn = new Button { Text = "Edit", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                editBtn.SetBinding(Button.CommandParameterProperty, ".");
                editBtn.Command = new Command<Notes>(async n => await EditNoteAsync(n));

                var deleteBtn = new Button { Text = "Delete", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                deleteBtn.Command = new Command<Notes>(async n => await DeleteNoteAsync(n));

                var stack = new HorizontalStackLayout { Spacing = 8 };
                stack.Add(previewLabel);
                stack.Add(editBtn);
                stack.Add(deleteBtn);

                border.Content = stack;
                return border;
            })
        };

        return CreateScrollableContainer(headerRow, mobileCollection, includeDivider: false, footer: footerBar);
    }

    private async Task AddNoteAsync()
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var noteText = await page.DisplayPromptAsync("Add Note", "Enter note text:");
        if (string.IsNullOrWhiteSpace(noteText)) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var newNote = new Notes { InventoryNotes = noteText.Trim(), DateModified = DateTime.Now, ModifiedBy = _session.ATTUID ?? "system" };
            ctx.Notes.Add(newNote);
            await ctx.SaveChangesAsync();

            // Add to beginning of collection (since sorted by date desc)
            _notes.Insert(0, newNote);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task EditNoteAsync(Notes note)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var newText = await page.DisplayPromptAsync("Edit Note", "Edit note text:", initialValue: note.InventoryNotes);
        if (string.IsNullOrWhiteSpace(newText)) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            note.InventoryNotes = newText.Trim();
            note.DateModified = DateTime.Now;
            note.ModifiedBy = _session.ATTUID ?? "system";
            ctx.Notes.Update(note);
            await ctx.SaveChangesAsync();

            // Update in place and move to top (since sorted by date desc)
            _notes.Remove(note);
            _notes.Insert(0, note);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task DeleteNoteAsync(Notes note)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var confirm = await page.DisplayAlert("Confirm Delete", "Delete this note?", "Delete", "Cancel");
        if (!confirm) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            ctx.Notes.Remove(note);
            await ctx.SaveChangesAsync();

            // Remove from collection
            _notes.Remove(note);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Delete Failed", $"Cannot delete: {ex.Message}", "OK");
        }
    }

    // ─── Contacts Tab ─────────────────────────────────────────────────

    private async Task<View> BuildContactsViewAsync()
    {
        var addBtn = new Button { Text = "+ Add", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#1565C0"), TextColor = Colors.White };
        addBtn.Clicked += async (_, _) => await AddContactAsync();

        CollectionView? collectionViewRef = null;

        var searchEntry = new Entry { Placeholder = "Search contacts...", FontSize = 12, HeightRequest = 32, WidthRequest = 250, BackgroundColor = Colors.White, Margin = new Thickness(0, 0, 12, 0) };
        searchEntry.TextChanged += (s, e) =>
        {
            var text = e.NewTextValue?.ToLower() ?? "";
            if (collectionViewRef == null) return;
            collectionViewRef.ItemsSource = string.IsNullOrWhiteSpace(text)
                ? _contacts
                : new RangeObservableCollection<Models.Contacts>(_contacts.Where(c =>
                    c.FullName?.ToLower().Contains(text) == true ||
                    c.Company?.ToLower().Contains(text) == true ||
                    c.EmailAddress?.ToLower().Contains(text) == true));
        };

        var scrollTopBtn = new Button { Text = "↑ Top", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
        scrollTopBtn.Clicked += (_, _) => { if (collectionViewRef != null && _contacts.Count > 0) collectionViewRef.ScrollTo(0, position: ScrollToPosition.Start, animate: true); };

        var headerRow = new HorizontalStackLayout
        {
            Spacing = 12,
            Children =
            {
                new Label { Text = "Contacts", FontAttributes = FontAttributes.Bold, FontSize = 16, VerticalOptions = LayoutOptions.Center },
                searchEntry,
                addBtn,
                scrollTopBtn,
                new Label { Text = $"{_contacts.Count} total", FontSize = 12, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center }
            }
        };

        if (_contacts.Count == 0)
        {
            _ = Task.Run(async () =>
            {
                try
                {
                    await using var ctx = await _contextFactory.CreateDbContextAsync();
                    var data = await ctx.Contacts.AsNoTracking().OrderBy(c => c.ContactID).ToListAsync();
                    await MainThread.InvokeOnMainThreadAsync(() => _contacts.AddRange(data));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"LoadContacts error: {ex.Message}");
                }
            });
        }

        if (DeviceInfo.Current.Platform == DevicePlatform.WinUI)
        {
            var collectionView = new CollectionView
            {
                ItemsSource = _contacts,
                SelectionMode = SelectionMode.Single,
                ItemTemplate = new DataTemplate(() =>
                {
                    var grid = new Grid
                    {
                        ColumnDefinitions =
                        {
                            new ColumnDefinition(new GridLength(60)),
                            new ColumnDefinition(new GridLength(180)),
                            new ColumnDefinition(new GridLength(150)),
                            new ColumnDefinition(new GridLength(120)),
                            new ColumnDefinition(GridLength.Star),
                            new ColumnDefinition(new GridLength(120)),
                            new ColumnDefinition(new GridLength(150))
                        },
                        Padding = new Thickness(4),
                        ColumnSpacing = 4
                    };

                    var idLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#999"), VerticalOptions = LayoutOptions.Center };
                    idLabel.SetBinding(Label.TextProperty, nameof(Models.Contacts.ContactID));

                    var nameLabel = new Label { FontSize = 12, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center };
                    nameLabel.SetBinding(Label.TextProperty, nameof(Models.Contacts.FullName));

                    var companyLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    companyLabel.SetBinding(Label.TextProperty, nameof(Models.Contacts.Company));

                    var phoneLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    phoneLabel.SetBinding(Label.TextProperty, nameof(Models.Contacts.BusinessPhone));

                    var emailLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center, LineBreakMode = LineBreakMode.TailTruncation };
                    emailLabel.SetBinding(Label.TextProperty, nameof(Models.Contacts.EmailAddress));

                    var modByLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    modByLabel.SetBinding(Label.TextProperty, nameof(Models.Contacts.ModifiedBy));

                    var editBtn = new Button { Text = "Edit", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                    editBtn.SetBinding(Button.CommandParameterProperty, ".");
                    editBtn.Command = new Command<Models.Contacts>(async c => await EditContactAsync(c));

                    var deleteBtn = new Button { Text = "Delete", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                    deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                    deleteBtn.Command = new Command<Models.Contacts>(async c => await DeleteContactAsync(c));

                    var actions = new HorizontalStackLayout { Spacing = 4 };
                    actions.Add(editBtn);
                    actions.Add(deleteBtn);

                    var doubleTap = new TapGestureRecognizer { NumberOfTapsRequired = 2 };
                    doubleTap.SetBinding(TapGestureRecognizer.CommandParameterProperty, ".");
                    doubleTap.Command = new Command<Models.Contacts>(async c => await EditContactAsync(c));
                    nameLabel.GestureRecognizers.Add(doubleTap);

                    grid.Add(idLabel, 0);
                    grid.Add(nameLabel, 1);
                    grid.Add(companyLabel, 2);
                    grid.Add(phoneLabel, 3);
                    grid.Add(emailLabel, 4);
                    grid.Add(modByLabel, 5);
                    grid.Add(actions, 6);

                    return grid;
                })
            };

            var colHeader = new Grid
            {
                ColumnDefinitions =
                {
                    new ColumnDefinition(new GridLength(60)),
                    new ColumnDefinition(new GridLength(180)),
                    new ColumnDefinition(new GridLength(150)),
                    new ColumnDefinition(new GridLength(120)),
                    new ColumnDefinition(GridLength.Star),
                    new ColumnDefinition(new GridLength(120)),
                    new ColumnDefinition(new GridLength(150))
                },
                Padding = new Thickness(4),
                ColumnSpacing = 4,
                BackgroundColor = Color.FromArgb("#F5F5F5"),
                Children =
                {
                    new Label { Text = "ID", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 0)),
                    new Label { Text = "Full Name", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 1)),
                    new Label { Text = "Company", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 2)),
                    new Label { Text = "Phone", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 3)),
                    new Label { Text = "Email", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 4)),
                    new Label { Text = "Modified By", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 5)),
                    new Label { Text = "Actions", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 6))
                }
            };

            collectionViewRef = collectionView;
            return CreateScrollableContainer(headerRow, collectionView, columnHeader: colHeader);
        }

        var mobileCollection = new CollectionView
        {
            ItemsSource = _contacts,
            SelectionMode = SelectionMode.Single,
            ItemTemplate = new DataTemplate(() =>
            {
                var border = new Border { Stroke = Color.FromArgb("#DDD"), StrokeThickness = 1, Padding = new Thickness(12, 8), Margin = new Thickness(0, 4), BackgroundColor = Colors.White };

                var nameLabel = new Label { FontSize = 13, FontAttributes = FontAttributes.Bold };
                nameLabel.SetBinding(Label.TextProperty, nameof(Models.Contacts.FullName));

                var companyLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666") };
                companyLabel.SetBinding(Label.TextProperty, nameof(Models.Contacts.Company));

                var emailLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#888") };
                emailLabel.SetBinding(Label.TextProperty, nameof(Models.Contacts.EmailAddress));

                var editBtn = new Button { Text = "Edit", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                editBtn.SetBinding(Button.CommandParameterProperty, ".");
                editBtn.Command = new Command<Models.Contacts>(async c => await EditContactAsync(c));

                var deleteBtn = new Button { Text = "Delete", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                deleteBtn.Command = new Command<Models.Contacts>(async c => await DeleteContactAsync(c));

                var btns = new HorizontalStackLayout { Spacing = 4 };
                btns.Add(editBtn);
                btns.Add(deleteBtn);

                var content = new VerticalStackLayout { Spacing = 4 };
                content.Add(nameLabel);
                content.Add(companyLabel);
                content.Add(emailLabel);
                content.Add(btns);

                border.Content = content;
                return border;
            })
        };

        return CreateScrollableContainer(headerRow, mobileCollection, includeDivider: false);
    }

    private async Task AddContactAsync()
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var firstName = await page.DisplayPromptAsync("Add Contact", "First name:");
        if (string.IsNullOrWhiteSpace(firstName)) return;

        var lastName = await page.DisplayPromptAsync("Add Contact", "Last name:");
        var company = await page.DisplayPromptAsync("Add Contact", "Company (optional):");
        var email = await page.DisplayPromptAsync("Add Contact", "Email (optional):");
        var phone = await page.DisplayPromptAsync("Add Contact", "Business phone (optional):");

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var contact = new Models.Contacts
            {
                FirstName = firstName.Trim(),
                LastName = lastName?.Trim(),
                FullName = $"{firstName.Trim()} {lastName?.Trim()}".Trim(),
                Company = company?.Trim(),
                EmailAddress = email?.Trim(),
                BusinessPhone = phone?.Trim(),
                DateModified = DateTime.Now,
                ModifiedBy = _session.ATTUID ?? "system"
            };
            ctx.Contacts.Add(contact);
            await ctx.SaveChangesAsync();

            _contacts.InsertSorted(contact, c => c.ContactID ?? 0);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task EditContactAsync(Models.Contacts contact)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var firstName = await page.DisplayPromptAsync("Edit Contact", "First name:", initialValue: contact.FirstName);
        if (string.IsNullOrWhiteSpace(firstName)) return;

        var lastName = await page.DisplayPromptAsync("Edit Contact", "Last name:", initialValue: contact.LastName);
        var company = await page.DisplayPromptAsync("Edit Contact", "Company:", initialValue: contact.Company);
        var email = await page.DisplayPromptAsync("Edit Contact", "Email:", initialValue: contact.EmailAddress);
        var phone = await page.DisplayPromptAsync("Edit Contact", "Business phone:", initialValue: contact.BusinessPhone);

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            contact.FirstName = firstName.Trim();
            contact.LastName = lastName?.Trim();
            contact.FullName = $"{firstName.Trim()} {lastName?.Trim()}".Trim();
            contact.Company = company?.Trim();
            contact.EmailAddress = email?.Trim();
            contact.BusinessPhone = phone?.Trim();
            contact.DateModified = DateTime.Now;
            contact.ModifiedBy = _session.ATTUID ?? "system";
            ctx.Contacts.Update(contact);
            await ctx.SaveChangesAsync();

            var index = _contacts.IndexOf(contact);
            if (index >= 0) { _contacts.RemoveAt(index); _contacts.Insert(index, contact); }
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task DeleteContactAsync(Models.Contacts contact)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var confirm = await page.DisplayAlert("Confirm Delete", $"Delete contact '{contact.FullName}'?", "Delete", "Cancel");
        if (!confirm) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            ctx.Contacts.Remove(contact);
            await ctx.SaveChangesAsync();
            _contacts.Remove(contact);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Delete Failed", $"Cannot delete: {ex.Message}", "OK");
        }
    }

    // ─── Roles Tab ─────────────────────────────────────────────────────

    private async Task<View> BuildRolesViewAsync()
    {
        var addBtn = new Button { Text = "+ Add", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#1565C0"), TextColor = Colors.White };
        addBtn.Clicked += async (_, _) => await AddRoleAsync();

        CollectionView? collectionViewRef = null;

        var searchEntry = new Entry { Placeholder = "Search roles...", FontSize = 12, HeightRequest = 32, WidthRequest = 250, BackgroundColor = Colors.White, Margin = new Thickness(0, 0, 12, 0) };
        searchEntry.TextChanged += (s, e) =>
        {
            var text = e.NewTextValue?.ToLower() ?? "";
            if (collectionViewRef == null) return;
            collectionViewRef.ItemsSource = string.IsNullOrWhiteSpace(text)
                ? _roles
                : new RangeObservableCollection<Roles>(_roles.Where(r => r.RoleName?.ToLower().Contains(text) == true));
        };

        var scrollTopBtn = new Button { Text = "↑ Top", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
        scrollTopBtn.Clicked += (_, _) => { if (collectionViewRef != null && _roles.Count > 0) collectionViewRef.ScrollTo(0, position: ScrollToPosition.Start, animate: true); };

        var headerRow = new HorizontalStackLayout
        {
            Spacing = 12,
            Children =
            {
                new Label { Text = "Roles", FontAttributes = FontAttributes.Bold, FontSize = 16, VerticalOptions = LayoutOptions.Center },
                searchEntry,
                addBtn,
                scrollTopBtn,
                new Label { Text = $"{_roles.Count} total", FontSize = 12, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center }
            }
        };

        if (_roles.Count == 0)
        {
            _ = Task.Run(async () =>
            {
                try
                {
                    await using var ctx = await _contextFactory.CreateDbContextAsync();
                    var data = await ctx.Roles.AsNoTracking().OrderBy(r => r.RoleID).ToListAsync();
                    await MainThread.InvokeOnMainThreadAsync(() => _roles.AddRange(data));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"LoadRoles error: {ex.Message}");
                }
            });
        }

        if (DeviceInfo.Current.Platform == DevicePlatform.WinUI)
        {
            var collectionView = new CollectionView
            {
                ItemsSource = _roles,
                SelectionMode = SelectionMode.Single,
                ItemTemplate = new DataTemplate(() =>
                {
                    var grid = new Grid
                    {
                        ColumnDefinitions =
                        {
                            new ColumnDefinition(new GridLength(60)),
                            new ColumnDefinition(GridLength.Star),
                            new ColumnDefinition(new GridLength(150))
                        },
                        Padding = new Thickness(4),
                        ColumnSpacing = 4
                    };

                    var idLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#999"), VerticalOptions = LayoutOptions.Center };
                    idLabel.SetBinding(Label.TextProperty, nameof(Roles.RoleID));

                    var nameLabel = new Label { FontSize = 12, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center };
                    nameLabel.SetBinding(Label.TextProperty, nameof(Roles.RoleName));

                    var editBtn = new Button { Text = "Edit", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                    editBtn.SetBinding(Button.CommandParameterProperty, ".");
                    editBtn.Command = new Command<Roles>(async r => await EditRoleAsync(r));

                    var deleteBtn = new Button { Text = "Delete", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                    deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                    deleteBtn.Command = new Command<Roles>(async r => await DeleteRoleAsync(r));

                    var actions = new HorizontalStackLayout { Spacing = 4 };
                    actions.Add(editBtn);
                    actions.Add(deleteBtn);

                    var doubleTap = new TapGestureRecognizer { NumberOfTapsRequired = 2 };
                    doubleTap.SetBinding(TapGestureRecognizer.CommandParameterProperty, ".");
                    doubleTap.Command = new Command<Roles>(async r => await EditRoleAsync(r));
                    nameLabel.GestureRecognizers.Add(doubleTap);

                    grid.Add(idLabel, 0);
                    grid.Add(nameLabel, 1);
                    grid.Add(actions, 2);

                    return grid;
                })
            };

            var colHeader = new Grid
            {
                ColumnDefinitions =
                {
                    new ColumnDefinition(new GridLength(60)),
                    new ColumnDefinition(GridLength.Star),
                    new ColumnDefinition(new GridLength(150))
                },
                Padding = new Thickness(4),
                ColumnSpacing = 4,
                BackgroundColor = Color.FromArgb("#F5F5F5"),
                Children =
                {
                    new Label { Text = "ID", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 0)),
                    new Label { Text = "Role Name", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 1)),
                    new Label { Text = "Actions", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 2))
                }
            };

            collectionViewRef = collectionView;
            return CreateScrollableContainer(headerRow, collectionView, columnHeader: colHeader);
        }

        var mobileCollection = new CollectionView
        {
            ItemsSource = _roles,
            SelectionMode = SelectionMode.Single,
            ItemTemplate = new DataTemplate(() =>
            {
                var border = new Border { Stroke = Color.FromArgb("#DDD"), StrokeThickness = 1, Padding = new Thickness(12, 8), Margin = new Thickness(0, 4), BackgroundColor = Colors.White };
                var nameLabel = new Label { FontSize = 13, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.FillAndExpand };
                nameLabel.SetBinding(Label.TextProperty, nameof(Roles.RoleName));

                var editBtn = new Button { Text = "Edit", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                editBtn.SetBinding(Button.CommandParameterProperty, ".");
                editBtn.Command = new Command<Roles>(async r => await EditRoleAsync(r));

                var deleteBtn = new Button { Text = "Delete", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                deleteBtn.Command = new Command<Roles>(async r => await DeleteRoleAsync(r));

                var stack = new HorizontalStackLayout { Spacing = 8 };
                stack.Add(nameLabel);
                stack.Add(editBtn);
                stack.Add(deleteBtn);

                border.Content = stack;
                return border;
            })
        };

        return CreateScrollableContainer(headerRow, mobileCollection, includeDivider: false);
    }

    private async Task AddRoleAsync()
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var name = await page.DisplayPromptAsync("Add Role", "Enter role name:");
        if (string.IsNullOrWhiteSpace(name)) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var role = new Roles { RoleName = name.Trim() };
            ctx.Roles.Add(role);
            await ctx.SaveChangesAsync();

            _roles.InsertSorted(role, r => r.RoleID ?? 0);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task EditRoleAsync(Roles role)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var newName = await page.DisplayPromptAsync("Edit Role", "Edit role name:", initialValue: role.RoleName);
        if (string.IsNullOrWhiteSpace(newName) || newName == role.RoleName) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            role.RoleName = newName.Trim();
            ctx.Roles.Update(role);
            await ctx.SaveChangesAsync();

            var index = _roles.IndexOf(role);
            if (index >= 0) { _roles.RemoveAt(index); _roles.Insert(index, role); }
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task DeleteRoleAsync(Roles role)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var confirm = await page.DisplayAlert("Confirm Delete", $"Delete role '{role.RoleName}'?\n\nWarning: This may fail if company roles reference this role.", "Delete", "Cancel");
        if (!confirm) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            ctx.Roles.Remove(role);
            await ctx.SaveChangesAsync();
            _roles.Remove(role);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Delete Failed", $"Cannot delete: {ex.Message}", "OK");
        }
    }

    // ─── Company Roles Tab ─────────────────────────────────────────────

    private async Task<View> BuildCompanyRolesViewAsync()
    {
        var addBtn = new Button { Text = "+ Add", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#1565C0"), TextColor = Colors.White };
        addBtn.Clicked += async (_, _) => await AddCompanyRoleAsync();

        CollectionView? collectionViewRef = null;

        var searchEntry = new Entry { Placeholder = "Search company roles...", FontSize = 12, HeightRequest = 32, WidthRequest = 250, BackgroundColor = Colors.White, Margin = new Thickness(0, 0, 12, 0) };
        searchEntry.TextChanged += (s, e) =>
        {
            var text = e.NewTextValue?.ToLower() ?? "";
            if (collectionViewRef == null) return;
            collectionViewRef.ItemsSource = string.IsNullOrWhiteSpace(text)
                ? _companyRoles
                : new RangeObservableCollection<CompanyRoles>(_companyRoles.Where(cr =>
                    cr.Company?.CompanyName?.ToLower().Contains(text) == true ||
                    cr.Role?.RoleName?.ToLower().Contains(text) == true));
        };

        var scrollTopBtn = new Button { Text = "↑ Top", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
        scrollTopBtn.Clicked += (_, _) => { if (collectionViewRef != null && _companyRoles.Count > 0) collectionViewRef.ScrollTo(0, position: ScrollToPosition.Start, animate: true); };

        var headerRow = new HorizontalStackLayout
        {
            Spacing = 12,
            Children =
            {
                new Label { Text = "Company Roles", FontAttributes = FontAttributes.Bold, FontSize = 16, VerticalOptions = LayoutOptions.Center },
                searchEntry,
                addBtn,
                scrollTopBtn,
                new Label { Text = $"{_companyRoles.Count} total", FontSize = 12, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center }
            }
        };

        if (_companyRoles.Count == 0)
        {
            _ = Task.Run(async () =>
            {
                try
                {
                    await using var ctx = await _contextFactory.CreateDbContextAsync();
                    var data = await ctx.CompanyRoles
                        .AsNoTracking()
                        .Include(cr => cr.Company)
                        .Include(cr => cr.Role)
                        .OrderBy(cr => cr.CRID)
                        .ToListAsync();
                    await MainThread.InvokeOnMainThreadAsync(() => _companyRoles.AddRange(data));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"LoadCompanyRoles error: {ex.Message}");
                }
            });
        }

        if (DeviceInfo.Current.Platform == DevicePlatform.WinUI)
        {
            var collectionView = new CollectionView
            {
                ItemsSource = _companyRoles,
                SelectionMode = SelectionMode.Single,
                ItemTemplate = new DataTemplate(() =>
                {
                    var grid = new Grid
                    {
                        ColumnDefinitions =
                        {
                            new ColumnDefinition(new GridLength(60)),
                            new ColumnDefinition(GridLength.Star),
                            new ColumnDefinition(GridLength.Star),
                            new ColumnDefinition(new GridLength(120)),
                            new ColumnDefinition(new GridLength(150)),
                            new ColumnDefinition(new GridLength(150))
                        },
                        Padding = new Thickness(4),
                        ColumnSpacing = 4
                    };

                    var idLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#999"), VerticalOptions = LayoutOptions.Center };
                    idLabel.SetBinding(Label.TextProperty, nameof(CompanyRoles.CRID));

                    var companyLabel = new Label { FontSize = 12, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center };
                    companyLabel.SetBinding(Label.TextProperty, "Company.CompanyName");

                    var roleLabel = new Label { FontSize = 12, VerticalOptions = LayoutOptions.Center };
                    roleLabel.SetBinding(Label.TextProperty, "Role.RoleName");

                    var dateLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    dateLabel.SetBinding(Label.TextProperty, new Binding(nameof(CompanyRoles.DateModified), stringFormat: "{0:MM/dd/yyyy}"));

                    var modByLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    modByLabel.SetBinding(Label.TextProperty, nameof(CompanyRoles.ModifiedBy));

                    var editBtn = new Button { Text = "Edit", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                    editBtn.SetBinding(Button.CommandParameterProperty, ".");
                    editBtn.Command = new Command<CompanyRoles>(async cr => await EditCompanyRoleAsync(cr));

                    var deleteBtn = new Button { Text = "Delete", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                    deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                    deleteBtn.Command = new Command<CompanyRoles>(async cr => await DeleteCompanyRoleAsync(cr));

                    var actions = new HorizontalStackLayout { Spacing = 4 };
                    actions.Add(editBtn);
                    actions.Add(deleteBtn);

                    var doubleTap = new TapGestureRecognizer { NumberOfTapsRequired = 2 };
                    doubleTap.SetBinding(TapGestureRecognizer.CommandParameterProperty, ".");
                    doubleTap.Command = new Command<CompanyRoles>(async cr => await EditCompanyRoleAsync(cr));
                    companyLabel.GestureRecognizers.Add(doubleTap);

                    grid.Add(idLabel, 0);
                    grid.Add(companyLabel, 1);
                    grid.Add(roleLabel, 2);
                    grid.Add(dateLabel, 3);
                    grid.Add(modByLabel, 4);
                    grid.Add(actions, 5);

                    return grid;
                })
            };

            var colHeader = new Grid
            {
                ColumnDefinitions =
                {
                    new ColumnDefinition(new GridLength(60)),
                    new ColumnDefinition(GridLength.Star),
                    new ColumnDefinition(GridLength.Star),
                    new ColumnDefinition(new GridLength(120)),
                    new ColumnDefinition(new GridLength(150)),
                    new ColumnDefinition(new GridLength(150))
                },
                Padding = new Thickness(4),
                ColumnSpacing = 4,
                BackgroundColor = Color.FromArgb("#F5F5F5"),
                Children =
                {
                    new Label { Text = "ID", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 0)),
                    new Label { Text = "Company", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 1)),
                    new Label { Text = "Role", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 2)),
                    new Label { Text = "Date Modified", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 3)),
                    new Label { Text = "Modified By", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 4)),
                    new Label { Text = "Actions", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 5))
                }
            };

            collectionViewRef = collectionView;
            return CreateScrollableContainer(headerRow, collectionView, columnHeader: colHeader);
        }

        var mobileCollection = new CollectionView
        {
            ItemsSource = _companyRoles,
            SelectionMode = SelectionMode.Single,
            ItemTemplate = new DataTemplate(() =>
            {
                var border = new Border { Stroke = Color.FromArgb("#DDD"), StrokeThickness = 1, Padding = new Thickness(12, 8), Margin = new Thickness(0, 4), BackgroundColor = Colors.White };

                var companyLabel = new Label { FontSize = 13, FontAttributes = FontAttributes.Bold };
                companyLabel.SetBinding(Label.TextProperty, "Company.CompanyName");

                var roleLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666") };
                roleLabel.SetBinding(Label.TextProperty, "Role.RoleName");

                var editBtn = new Button { Text = "Edit", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                editBtn.SetBinding(Button.CommandParameterProperty, ".");
                editBtn.Command = new Command<CompanyRoles>(async cr => await EditCompanyRoleAsync(cr));

                var deleteBtn = new Button { Text = "Delete", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                deleteBtn.Command = new Command<CompanyRoles>(async cr => await DeleteCompanyRoleAsync(cr));

                var btns = new HorizontalStackLayout { Spacing = 4 };
                btns.Add(editBtn);
                btns.Add(deleteBtn);

                var content = new VerticalStackLayout { Spacing = 4 };
                content.Add(companyLabel);
                content.Add(roleLabel);
                content.Add(btns);

                border.Content = content;
                return border;
            })
        };

        return CreateScrollableContainer(headerRow, mobileCollection, includeDivider: false);
    }

    private async Task AddCompanyRoleAsync()
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        // Pick company from loaded list
        var companyNames = _companies.Select(c => c.CompanyName ?? $"ID:{c.CompanyID}").ToArray();
        if (companyNames.Length == 0)
        {
            await page.DisplayAlert("No Companies", "Please add companies first.", "OK");
            return;
        }

        var selectedCompany = await page.DisplayActionSheet("Select Company", "Cancel", null, companyNames);
        if (string.IsNullOrWhiteSpace(selectedCompany) || selectedCompany == "Cancel") return;
        var company = _companies.FirstOrDefault(c => c.CompanyName == selectedCompany || $"ID:{c.CompanyID}" == selectedCompany);
        if (company == null) return;

        // Pick role from loaded list
        var roleNames = _roles.Select(r => r.RoleName ?? $"ID:{r.RoleID}").ToArray();
        if (roleNames.Length == 0)
        {
            await page.DisplayAlert("No Roles", "Please add roles first.", "OK");
            return;
        }

        var selectedRole = await page.DisplayActionSheet("Select Role", "Cancel", null, roleNames);
        if (string.IsNullOrWhiteSpace(selectedRole) || selectedRole == "Cancel") return;
        var role = _roles.FirstOrDefault(r => r.RoleName == selectedRole || $"ID:{r.RoleID}" == selectedRole);
        if (role == null) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var cr = new CompanyRoles
            {
                CompanyID = company.CompanyID,
                RoleID = role.RoleID,
                DateModified = DateTime.Now,
                ModifiedBy = _session.ATTUID ?? "system"
            };
            ctx.CompanyRoles.Add(cr);
            await ctx.SaveChangesAsync();

            // Attach nav properties for display
            cr.Company = company;
            cr.Role = role;

            _companyRoles.InsertSorted(cr, x => x.CRID);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task EditCompanyRoleAsync(CompanyRoles companyRole)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var currentCompanyName = companyRole.Company?.CompanyName ?? $"ID:{companyRole.CompanyID}";
        var currentRoleName = companyRole.Role?.RoleName ?? $"ID:{companyRole.RoleID}";

        // Pick new company (show current selection in prompt)
        var companyNames = _companies.Select(c => c.CompanyName ?? $"ID:{c.CompanyID}").ToArray();
        if (companyNames.Length == 0)
        {
            await page.DisplayAlert("No Companies", "Please add companies first.", "OK");
            return;
        }

        var selectedCompany = await page.DisplayActionSheet($"Select Company (current: {currentCompanyName})", "Cancel", null, companyNames);
        if (string.IsNullOrWhiteSpace(selectedCompany) || selectedCompany == "Cancel") return;
        var company = _companies.FirstOrDefault(c => c.CompanyName == selectedCompany || $"ID:{c.CompanyID}" == selectedCompany);
        if (company == null) return;

        // Pick new role (show current selection in prompt)
        var roleNames = _roles.Select(r => r.RoleName ?? $"ID:{r.RoleID}").ToArray();
        if (roleNames.Length == 0)
        {
            await page.DisplayAlert("No Roles", "Please add roles first.", "OK");
            return;
        }

        var selectedRole = await page.DisplayActionSheet($"Select Role (current: {currentRoleName})", "Cancel", null, roleNames);
        if (string.IsNullOrWhiteSpace(selectedRole) || selectedRole == "Cancel") return;
        var role = _roles.FirstOrDefault(r => r.RoleName == selectedRole || $"ID:{r.RoleID}" == selectedRole);
        if (role == null) return;

        // Skip if nothing changed
        if (company.CompanyID == companyRole.CompanyID && role.RoleID == companyRole.RoleID) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            companyRole.CompanyID = company.CompanyID;
            companyRole.RoleID = role.RoleID;
            companyRole.DateModified = DateTime.Now;
            companyRole.ModifiedBy = _session.ATTUID ?? "system";
            ctx.CompanyRoles.Update(companyRole);
            await ctx.SaveChangesAsync();

            // Update nav properties for display
            companyRole.Company = company;
            companyRole.Role = role;

            // Refresh in collection
            var index = _companyRoles.IndexOf(companyRole);
            if (index >= 0) { _companyRoles.RemoveAt(index); _companyRoles.Insert(index, companyRole); }
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task DeleteCompanyRoleAsync(CompanyRoles companyRole)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var companyName = companyRole.Company?.CompanyName ?? $"ID:{companyRole.CompanyID}";
        var roleName = companyRole.Role?.RoleName ?? $"ID:{companyRole.RoleID}";
        var confirm = await page.DisplayAlert("Confirm Delete", $"Remove role '{roleName}' from company '{companyName}'?", "Delete", "Cancel");
        if (!confirm) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            ctx.CompanyRoles.Remove(companyRole);
            await ctx.SaveChangesAsync();
            _companyRoles.Remove(companyRole);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Delete Failed", $"Cannot delete: {ex.Message}", "OK");
        }
    }

    // ─── CTTM Inventory Tab ──────────────────────────────────────────

    private async Task<View> BuildCTTMInventoryViewAsync()
    {
        var addBtn = new Button { Text = "+ Add", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#1565C0"), TextColor = Colors.White };
        addBtn.Clicked += async (_, _) => await AddCTTMAsync();

        var searchEntry = new Entry { Placeholder = "Search CTTM...", FontSize = 12, HeightRequest = 32, WidthRequest = 240, BackgroundColor = Colors.White };

        CollectionView? collectionViewRef = null;

        var searchGoBtn = new Button { Text = "Go", FontSize = 11, HeightRequest = 28, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#1976D2"), TextColor = Colors.White };
        var searchClearBtn = new Button { Text = "Clear", FontSize = 11, HeightRequest = 28, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#E0E0E0"), TextColor = Color.FromArgb("#333") };

        searchGoBtn.Clicked += (_, _) =>
        {
            var text = searchEntry.Text?.ToLower() ?? "";
            if (collectionViewRef == null) return;
            collectionViewRef.ItemsSource = string.IsNullOrWhiteSpace(text)
                ? _cttmInventory
                : new RangeObservableCollection<CTTMInventory>(_cttmInventory.Where(c =>
                    c.ToolKitID?.ToLower().Contains(text) == true ||
                    c.ToolKitName?.ToLower().Contains(text) == true ||
                    c.PartNumber?.ToLower().Contains(text) == true ||
                    c.SerialNumber?.ToLower().Contains(text) == true ||
                    c.EmplName?.ToLower().Contains(text) == true));
        };

        searchClearBtn.Clicked += (_, _) =>
        {
            searchEntry.Text = "";
            if (collectionViewRef != null) collectionViewRef.ItemsSource = _cttmInventory;
        };

        var headerRow = new HorizontalStackLayout
        {
            Spacing = 8,
            Children =
            {
                new Label { Text = "CTTM Inventory", FontAttributes = FontAttributes.Bold, FontSize = 16, VerticalOptions = LayoutOptions.Center },
                addBtn
            }
        };

        _cttmStatusLabel = new Label { Text = "Loading...", FontSize = 12, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };

        var moveFirstBtn = new Button { Text = "|<", FontSize = 12, HeightRequest = 32, WidthRequest = 40, Padding = new Thickness(0) };
        var movePrevBtn = new Button { Text = "<", FontSize = 12, HeightRequest = 32, WidthRequest = 40, Padding = new Thickness(0) };
        var moveNextBtn = new Button { Text = ">", FontSize = 12, HeightRequest = 32, WidthRequest = 40, Padding = new Thickness(0) };
        var moveLastBtn = new Button { Text = ">|", FontSize = 12, HeightRequest = 32, WidthRequest = 40, Padding = new Thickness(0) };

        moveFirstBtn.Clicked += (_, _) => { if (collectionViewRef != null && _cttmInventory.Count > 0) { collectionViewRef.SelectedItem = _cttmInventory[0]; collectionViewRef.ScrollTo(0, position: ScrollToPosition.Start, animate: false); } };
        movePrevBtn.Clicked += (_, _) => { if (collectionViewRef?.SelectedItem is CTTMInventory sel) { var idx = _cttmInventory.IndexOf(sel); if (idx > 0) { collectionViewRef.SelectedItem = _cttmInventory[idx - 1]; collectionViewRef.ScrollTo(idx - 1, position: ScrollToPosition.Center, animate: false); } } };
        moveNextBtn.Clicked += (_, _) => { if (collectionViewRef?.SelectedItem is CTTMInventory sel) { var idx = _cttmInventory.IndexOf(sel); if (idx >= 0 && idx < _cttmInventory.Count - 1) { collectionViewRef.SelectedItem = _cttmInventory[idx + 1]; collectionViewRef.ScrollTo(idx + 1, position: ScrollToPosition.Center, animate: false); } } };
        moveLastBtn.Clicked += (_, _) => { if (collectionViewRef != null && _cttmInventory.Count > 0) { collectionViewRef.SelectedItem = _cttmInventory[^1]; collectionViewRef.ScrollTo(_cttmInventory.Count - 1, position: ScrollToPosition.End, animate: false); } };

        var loadMoreBtn = new Button { Text = "Load More", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#E3F2FD"), TextColor = Color.FromArgb("#1565C0") };
        loadMoreBtn.Clicked += async (_, _) => { await LoadMoreCTTMAsync(); UpdateCTTMStatus(); };

        var loadAllBtn = new Button { Text = "Load All", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#FFF3E0"), TextColor = Color.FromArgb("#E65100") };
        loadAllBtn.Clicked += async (_, _) => { while (_cttmLoadedCount < _cttmTotalCount) { await LoadMoreCTTMAsync(); UpdateCTTMStatus(); } };

        var footerBar = new Border
        {
            Stroke = Color.FromArgb("#DDD"),
            StrokeThickness = 1,
            BackgroundColor = Colors.White,
            Padding = new Thickness(8),
            Content = new Grid
            {
                ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Auto) },
                ColumnSpacing = 8,
                Children =
                {
                    _cttmStatusLabel.Apply(l => Grid.SetColumn(l, 0)),
                    new HorizontalStackLayout { Spacing = 4, Children = { searchEntry, searchGoBtn, searchClearBtn } }.Apply(s => Grid.SetColumn(s, 1)),
                    new HorizontalStackLayout { Spacing = 4, Children = { moveFirstBtn, movePrevBtn, moveNextBtn, moveLastBtn } }.Apply(s => Grid.SetColumn(s, 2)),
                    new HorizontalStackLayout { Spacing = 4, Children = { loadMoreBtn, loadAllBtn } }.Apply(s => Grid.SetColumn(s, 3))
                }
            }
        };

        if (_cttmInventory.Count == 0)
        {
            _cttmLoadedCount = 0;
            _isLoadingCTTM = false;
            _ = Task.Run(async () =>
            {
                await using var ctx = await _contextFactory.CreateDbContextAsync();
                _cttmTotalCount = await ctx.CTTMInventory.CountAsync();
                await MainThread.InvokeOnMainThreadAsync(() => UpdateCTTMStatus());
            });
            _ = LoadMoreCTTMAsync().ContinueWith(_ => MainThread.BeginInvokeOnMainThread(UpdateCTTMStatus));
        }
        else
        {
            UpdateCTTMStatus();
        }

        if (DeviceInfo.Current.Platform == DevicePlatform.WinUI)
        {
            var collectionView = new CollectionView
            {
                ItemsSource = _cttmInventory,
                SelectionMode = SelectionMode.Single,
                SelectedItem = null,
                RemainingItemsThreshold = 20,
                RemainingItemsThresholdReachedCommand = new Command(async () => await LoadMoreCTTMAsync()),
                ItemTemplate = new DataTemplate(() =>
                {
                    var grid = new Grid
                    {
                        ColumnDefinitions =
                        {
                            new ColumnDefinition(new GridLength(100)),
                            new ColumnDefinition(new GridLength(160)),
                            new ColumnDefinition(new GridLength(120)),
                            new ColumnDefinition(new GridLength(120)),
                            new ColumnDefinition(new GridLength(80)),
                            new ColumnDefinition(GridLength.Star),
                            new ColumnDefinition(new GridLength(120)),
                            new ColumnDefinition(new GridLength(150))
                        },
                        Padding = new Thickness(4),
                        ColumnSpacing = 4
                    };

                    var idLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#999"), VerticalOptions = LayoutOptions.Center };
                    idLabel.SetBinding(Label.TextProperty, nameof(CTTMInventory.ToolKitID));

                    var nameLabel = new Label { FontSize = 12, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center };
                    nameLabel.SetBinding(Label.TextProperty, nameof(CTTMInventory.ToolKitName));

                    var partLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    partLabel.SetBinding(Label.TextProperty, nameof(CTTMInventory.PartNumber));

                    var serialLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    serialLabel.SetBinding(Label.TextProperty, nameof(CTTMInventory.SerialNumber));

                    var statusLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    statusLabel.SetBinding(Label.TextProperty, nameof(CTTMInventory.Status));

                    var emplLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    emplLabel.SetBinding(Label.TextProperty, nameof(CTTMInventory.EmplName));

                    var modByLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666"), VerticalOptions = LayoutOptions.Center };
                    modByLabel.SetBinding(Label.TextProperty, nameof(CTTMInventory.ModifiedBy));

                    var editBtn = new Button { Text = "Edit", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                    editBtn.SetBinding(Button.CommandParameterProperty, ".");
                    editBtn.Command = new Command<CTTMInventory>(async c => await EditCTTMAsync(c));

                    var deleteBtn = new Button { Text = "Delete", FontSize = 10, HeightRequest = 24, Padding = new Thickness(8, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                    deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                    deleteBtn.Command = new Command<CTTMInventory>(async c => await DeleteCTTMAsync(c));

                    var actions = new HorizontalStackLayout { Spacing = 4 };
                    actions.Add(editBtn);
                    actions.Add(deleteBtn);

                    var doubleTap = new TapGestureRecognizer { NumberOfTapsRequired = 2 };
                    doubleTap.SetBinding(TapGestureRecognizer.CommandParameterProperty, ".");
                    doubleTap.Command = new Command<CTTMInventory>(async c => await EditCTTMAsync(c));
                    nameLabel.GestureRecognizers.Add(doubleTap);

                    grid.Add(idLabel, 0);
                    grid.Add(nameLabel, 1);
                    grid.Add(partLabel, 2);
                    grid.Add(serialLabel, 3);
                    grid.Add(statusLabel, 4);
                    grid.Add(emplLabel, 5);
                    grid.Add(modByLabel, 6);
                    grid.Add(actions, 7);

                    return grid;
                })
            };

            var colHeader = new Grid
            {
                ColumnDefinitions =
                {
                    new ColumnDefinition(new GridLength(100)),
                    new ColumnDefinition(new GridLength(160)),
                    new ColumnDefinition(new GridLength(120)),
                    new ColumnDefinition(new GridLength(120)),
                    new ColumnDefinition(new GridLength(80)),
                    new ColumnDefinition(GridLength.Star),
                    new ColumnDefinition(new GridLength(120)),
                    new ColumnDefinition(new GridLength(150))
                },
                Padding = new Thickness(4),
                ColumnSpacing = 4,
                BackgroundColor = Color.FromArgb("#F5F5F5"),
                Children =
                {
                    new Label { Text = "ToolKit ID", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 0)),
                    new Label { Text = "ToolKit Name", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 1)),
                    new Label { Text = "Part #", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 2)),
                    new Label { Text = "Serial #", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 3)),
                    new Label { Text = "Status", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 4)),
                    new Label { Text = "Employee", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 5)),
                    new Label { Text = "Modified By", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 6)),
                    new Label { Text = "Actions", FontAttributes = FontAttributes.Bold, FontSize = 12 }.Apply(l => Grid.SetColumn(l, 7))
                }
            };

            collectionViewRef = collectionView;
            return CreateScrollableContainer(headerRow, collectionView, footer: footerBar, columnHeader: colHeader);
        }

        var mobileCollection = new CollectionView
        {
            ItemsSource = _cttmInventory,
            SelectionMode = SelectionMode.Single,
            RemainingItemsThreshold = 20,
            RemainingItemsThresholdReachedCommand = new Command(async () => await LoadMoreCTTMAsync()),
            ItemTemplate = new DataTemplate(() =>
            {
                var border = new Border { Stroke = Color.FromArgb("#DDD"), StrokeThickness = 1, Padding = new Thickness(12, 8), Margin = new Thickness(0, 4), BackgroundColor = Colors.White };

                var nameLabel = new Label { FontSize = 13, FontAttributes = FontAttributes.Bold };
                nameLabel.SetBinding(Label.TextProperty, nameof(CTTMInventory.ToolKitName));

                var idLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#888") };
                idLabel.SetBinding(Label.TextProperty, nameof(CTTMInventory.ToolKitID));

                var statusLabel = new Label { FontSize = 11, TextColor = Color.FromArgb("#666") };
                statusLabel.SetBinding(Label.TextProperty, nameof(CTTMInventory.Status));

                var editBtn = new Button { Text = "Edit", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#F5F5F5"), TextColor = Color.FromArgb("#333") };
                editBtn.SetBinding(Button.CommandParameterProperty, ".");
                editBtn.Command = new Command<CTTMInventory>(async c => await EditCTTMAsync(c));

                var deleteBtn = new Button { Text = "Delete", FontSize = 11, HeightRequest = 28, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#FFEBEE"), TextColor = Color.FromArgb("#C62828") };
                deleteBtn.SetBinding(Button.CommandParameterProperty, ".");
                deleteBtn.Command = new Command<CTTMInventory>(async c => await DeleteCTTMAsync(c));

                var btns = new HorizontalStackLayout { Spacing = 4 };
                btns.Add(editBtn);
                btns.Add(deleteBtn);

                var content = new VerticalStackLayout { Spacing = 4 };
                content.Add(nameLabel);
                content.Add(idLabel);
                content.Add(statusLabel);
                content.Add(btns);

                border.Content = content;
                return border;
            })
        };

        return CreateScrollableContainer(headerRow, mobileCollection, includeDivider: false, footer: footerBar);
    }

    private async Task AddCTTMAsync()
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var toolKitId = await page.DisplayPromptAsync("Add CTTM Item", "Enter ToolKit ID:");
        if (string.IsNullOrWhiteSpace(toolKitId)) return;

        var name = await page.DisplayPromptAsync("Add CTTM Item", "Enter ToolKit name:");
        var partNum = await page.DisplayPromptAsync("Add CTTM Item", "Part number (optional):");
        var serialNum = await page.DisplayPromptAsync("Add CTTM Item", "Serial number (optional):");
        var status = await page.DisplayPromptAsync("Add CTTM Item", "Status (optional):");

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            var item = new CTTMInventory
            {
                ToolKitID = toolKitId.Trim(),
                ToolKitName = name?.Trim(),
                PartNumber = partNum?.Trim(),
                SerialNumber = serialNum?.Trim(),
                Status = status?.Trim(),
                DateModified = DateTime.Now,
                ModifiedBy = _session.ATTUID ?? "system"
            };
            ctx.CTTMInventory.Add(item);
            await ctx.SaveChangesAsync();

            _cttmInventory.InsertSorted(item, c => c.ToolKitID ?? "");
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task EditCTTMAsync(CTTMInventory item)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var name = await page.DisplayPromptAsync("Edit CTTM Item", "ToolKit name:", initialValue: item.ToolKitName);
        if (string.IsNullOrWhiteSpace(name)) return;

        var partNum = await page.DisplayPromptAsync("Edit CTTM Item", "Part number:", initialValue: item.PartNumber);
        var serialNum = await page.DisplayPromptAsync("Edit CTTM Item", "Serial number:", initialValue: item.SerialNumber);
        var status = await page.DisplayPromptAsync("Edit CTTM Item", "Status:", initialValue: item.Status);

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            item.ToolKitName = name.Trim();
            item.PartNumber = partNum?.Trim();
            item.SerialNumber = serialNum?.Trim();
            item.Status = status?.Trim();
            item.DateModified = DateTime.Now;
            item.ModifiedBy = _session.ATTUID ?? "system";
            ctx.CTTMInventory.Update(item);
            await ctx.SaveChangesAsync();

            var index = _cttmInventory.IndexOf(item);
            if (index >= 0) { _cttmInventory.RemoveAt(index); _cttmInventory.Insert(index, item); }
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async Task DeleteCTTMAsync(CTTMInventory item)
    {
        var page = Application.Current?.MainPage;
        if (page is null) return;

        var confirm = await page.DisplayAlert("Confirm Delete", $"Delete CTTM item '{item.ToolKitID} - {item.ToolKitName}'?", "Delete", "Cancel");
        if (!confirm) return;

        try
        {
            await using var ctx = await _contextFactory.CreateDbContextAsync();
            ctx.CTTMInventory.Remove(item);
            await ctx.SaveChangesAsync();
            _cttmInventory.Remove(item);
        }
        catch (Exception ex)
        {
            await page.DisplayAlert("Delete Failed", $"Cannot delete: {ex.Message}", "OK");
        }
    }

    // ─── Incremental Loading Support ────────────────────────────────────

    private void UpdateAssetsStatus()
    {
        if (_assetsStatusLabel == null) return;
        var allLoaded = _assetsLoadedCount >= _assetsTotalCount;
        _assetsStatusLabel.Text = _assetsTotalCount > 0
            ? $"{_assets.Count} of {_assetsTotalCount} loaded{(allLoaded ? " ✔" : "")}"
            : $"{_assets.Count} loaded";
    }

    private void UpdateNotesStatus()
    {
        if (_notesStatusLabel == null) return;
        var allLoaded = _notesLoadedCount >= _notesTotalCount;
        _notesStatusLabel.Text = _notesTotalCount > 0
            ? $"{_notes.Count} of {_notesTotalCount} loaded{(allLoaded ? " ✔" : "")}"
            : $"{_notes.Count} loaded";
    }

    private async Task LoadMoreAssetsAsync()
    {
        if (_isLoadingAssets) return;

        try
        {
            _isLoadingAssets = true;

            // Load next page in background thread
            var newAssets = await Task.Run(async () =>
            {
                await using var ctx = await _contextFactory.CreateDbContextAsync();
                return await ctx.Asset
                    .AsNoTracking()
                    .OrderBy(a => a.AssetID)
                    .Skip(_assetsLoadedCount)
                    .Take(PAGE_SIZE)
                    .ToListAsync();
            });

            // Return early if no more data
            if (newAssets.Count == 0)
            {
                return;
            }

            // Add all items with single notification
            await MainThread.InvokeOnMainThreadAsync(() => _assets.AddRange(newAssets));

            _assetsLoadedCount += newAssets.Count;
            MainThread.BeginInvokeOnMainThread(UpdateAssetsStatus);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"LoadMoreAssetsAsync error: {ex.Message}");
        }
        finally
        {
            _isLoadingAssets = false;
        }
    }

    private async Task LoadMoreNotesAsync()
    {
        if (_isLoadingNotes) return;

        try
        {
            _isLoadingNotes = true;

            // Load next page in background thread
            var newNotes = await Task.Run(async () =>
            {
                await using var ctx = await _contextFactory.CreateDbContextAsync();
                return await ctx.Notes
                    .AsNoTracking()
                    .OrderBy(n => n.NotesID)
                    .Skip(_notesLoadedCount)
                    .Take(PAGE_SIZE)
                    .ToListAsync();
            });

            // Return early if no more data
            if (newNotes.Count == 0)
            {
                return;
            }

            // Add all items with single notification
            await MainThread.InvokeOnMainThreadAsync(() => _notes.AddRange(newNotes));

            _notesLoadedCount += newNotes.Count;
            MainThread.BeginInvokeOnMainThread(UpdateNotesStatus);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"LoadMoreNotesAsync error: {ex.Message}");
        }
        finally
        {
            _isLoadingNotes = false;
        }
    }

    private void UpdateCTTMStatus()
    {
        if (_cttmStatusLabel == null) return;
        var allLoaded = _cttmLoadedCount >= _cttmTotalCount;
        _cttmStatusLabel.Text = _cttmTotalCount > 0
            ? $"{_cttmInventory.Count} of {_cttmTotalCount} loaded{(allLoaded ? " ✔" : "")}"
            : $"{_cttmInventory.Count} loaded";
    }

    private async Task LoadMoreCTTMAsync()
    {
        if (_isLoadingCTTM) return;

        try
        {
            _isLoadingCTTM = true;

            var newItems = await Task.Run(async () =>
            {
                await using var ctx = await _contextFactory.CreateDbContextAsync();
                return await ctx.CTTMInventory
                    .AsNoTracking()
                    .OrderBy(c => c.ToolKitID)
                    .Skip(_cttmLoadedCount)
                    .Take(PAGE_SIZE)
                    .ToListAsync();
            });

            if (newItems.Count == 0) return;

            await MainThread.InvokeOnMainThreadAsync(() => _cttmInventory.AddRange(newItems));

            _cttmLoadedCount += newItems.Count;
            MainThread.BeginInvokeOnMainThread(UpdateCTTMStatus);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"LoadMoreCTTMAsync error: {ex.Message}");
        }
        finally
        {
            _isLoadingCTTM = false;
        }
    }
}
