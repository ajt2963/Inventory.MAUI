using Inventory.MAUI.Models;

namespace Inventory.MAUI.Pages;

public partial class CategoryEditDialog : ContentPage
{
    public Category? Result { get; private set; }

    public CategoryEditDialog(Category? existingCategory = null)
    {
        InitializeComponent();

        if (existingCategory is not null)
        {
            Title = "Edit Category";
            NameEntry.Text = existingCategory.CatName;
            DescriptionEditor.Text = existingCategory.Description;
            Result = existingCategory;
        }
        else
        {
            Title = "Add Category";
            Result = new Category { CatName = "", ModifiedBy = "" };
        }
    }

    private async void OnSave(object? sender, EventArgs e)
    {
        var name = NameEntry.Text?.Trim();
        if (string.IsNullOrWhiteSpace(name))
        {
            await DisplayAlert("Validation Error", "Category name is required.", "OK");
            return;
        }

        if (Result is not null)
        {
            Result.CatName = name;
            Result.Description = DescriptionEditor.Text?.Trim();
        }

        await Navigation.PopModalAsync();
    }

    private async void OnCancel(object? sender, EventArgs e)
    {
        Result = null;
        await Navigation.PopModalAsync();
    }
}
