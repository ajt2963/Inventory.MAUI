using Inventory.MAUI.Models;
using Inventory.MAUI.Services;

namespace Inventory.MAUI.Pages;

public partial class SecurityView : ContentView
{
    private readonly ISystemSettingsService _settings;
    private readonly IAuditService _audit;
    private readonly ISessionService _sessionService;
    private readonly IAppUserService _userService;
    private readonly PasswordPolicy _passwordPolicy;
    private readonly AppSessionService _session;
    private readonly IFileSaveService _fileSaveService;

    private string _activeTab = "Password";
    private Task? _initTask;

    // Tab content views (lazy-created)
    private View? _passwordView;
    private View? _sessionView;
    private View? _mfaView;
    private View? _ssoView;
    private View? _auditView;

    public SecurityView(
        ISystemSettingsService settings,
        IAuditService audit,
        ISessionService sessionService,
        IAppUserService userService,
        PasswordPolicy passwordPolicy,
        AppSessionService session,
        IFileSaveService fileSaveService)
    {
        InitializeComponent();
        _settings = settings;
        _audit = audit;
        _sessionService = sessionService;
        _userService = userService;
        _passwordPolicy = passwordPolicy;
        _session = session;
        _fileSaveService = fileSaveService;

        BuildTabBar();
        ActivateTab("Password");
    }

    public async Task EnsureInitializedAsync()
    {
        _initTask ??= LoadActiveTabAsync();
        await _initTask;
    }

    private void BuildTabBar()
    {
        var tabs = new[] { "Password", "Sessions", "MFA", "SSO", "Audit Log" };
        foreach (var tab in tabs)
        {
            var btn = new Button
            {
                Text = tab,
                FontSize = 12,
                HeightRequest = 34,
                Padding = new Thickness(14, 0),
                CornerRadius = 0,
                BorderWidth = 0,
                BackgroundColor = Colors.Transparent,
                TextColor = Color.FromArgb("#555")
            };
            btn.Clicked += (_, _) => ActivateTab(tab);
            TabBar.Add(btn);
        }
        UpdateTabStyles();
    }

    private void ActivateTab(string tab)
    {
        _activeTab = tab;
        UpdateTabStyles();
        _initTask = LoadActiveTabAsync();
    }

    private void UpdateTabStyles()
    {
        foreach (var child in TabBar)
        {
            if (child is Button btn)
            {
                var isActive = btn.Text == _activeTab;
                btn.BackgroundColor = isActive ? Color.FromArgb("#E3F2FD") : Colors.Transparent;
                btn.TextColor = isActive ? Color.FromArgb("#1565C0") : Color.FromArgb("#555");
                btn.FontAttributes = isActive ? FontAttributes.Bold : FontAttributes.None;
            }
        }
    }

    private async Task LoadActiveTabAsync()
    {
        View content = _activeTab switch
        {
            "Password" => await GetPasswordViewAsync(),
            "Sessions" => await GetSessionViewAsync(),
            "MFA" => await GetMfaViewAsync(),
            "SSO" => await GetSsoViewAsync(),
            "Audit Log" => await GetAuditViewAsync(),
            _ => new Label { Text = "Unknown tab", Padding = new Thickness(16) }
        };

        TabContent.Content = content;
    }

    // ??? Password Management Tab ???????????????????????????????????????

    private async Task<View> GetPasswordViewAsync()
    {
        _passwordView ??= await BuildPasswordViewAsync();
        return _passwordView;
    }

    private async Task<View> BuildPasswordViewAsync()
    {
        var minLen = await _settings.GetIntAsync(SettingKeys.PasswordMinLength, 8);
        var maxLen = await _settings.GetIntAsync(SettingKeys.PasswordMaxLength, 128);
        var requireUpper = await _settings.GetBoolAsync(SettingKeys.PasswordRequireUpper, true);
        var requireLower = await _settings.GetBoolAsync(SettingKeys.PasswordRequireLower, true);
        var requireDigit = await _settings.GetBoolAsync(SettingKeys.PasswordRequireDigit, true);
        var requireSpecial = await _settings.GetBoolAsync(SettingKeys.PasswordRequireSpecial, true);
        var historyCount = await _settings.GetIntAsync(SettingKeys.PasswordHistoryCount, 5);
        var expiryDays = await _settings.GetIntAsync(SettingKeys.PasswordExpiryDays, 90);
        var lockoutAttempts = await _settings.GetIntAsync(SettingKeys.LockoutMaxAttempts, 5);
        var lockoutMinutes = await _settings.GetIntAsync(SettingKeys.LockoutDurationMinutes, 15);

        var minLenEntry = new Entry { Text = minLen.ToString(), Keyboard = Keyboard.Numeric, HeightRequest = 32, WidthRequest = 80 };
        var maxLenEntry = new Entry { Text = maxLen.ToString(), Keyboard = Keyboard.Numeric, HeightRequest = 32, WidthRequest = 80 };
        var upperSwitch = new Switch { IsToggled = requireUpper };
        var lowerSwitch = new Switch { IsToggled = requireLower };
        var digitSwitch = new Switch { IsToggled = requireDigit };
        var specialSwitch = new Switch { IsToggled = requireSpecial };
        var historyEntry = new Entry { Text = historyCount.ToString(), Keyboard = Keyboard.Numeric, HeightRequest = 32, WidthRequest = 80 };
        var expiryEntry = new Entry { Text = expiryDays.ToString(), Keyboard = Keyboard.Numeric, HeightRequest = 32, WidthRequest = 80 };
        var lockoutAttemptsEntry = new Entry { Text = lockoutAttempts.ToString(), Keyboard = Keyboard.Numeric, HeightRequest = 32, WidthRequest = 80 };
        var lockoutMinutesEntry = new Entry { Text = lockoutMinutes.ToString(), Keyboard = Keyboard.Numeric, HeightRequest = 32, WidthRequest = 80 };

        var statusLabel = new Label { FontSize = 12, TextColor = Color.FromArgb("#2E7D32") };

        var saveButton = new Button { Text = "Save Password Policy", HeightRequest = 34, FontSize = 12, Padding = new Thickness(16, 0) };
        saveButton.Clicked += async (_, _) =>
        {
            try
            {
                // Input validation
                if (!int.TryParse(minLenEntry.Text, out var minVal) || minVal < 4 || minVal > 64)
                { statusLabel.TextColor = Color.FromArgb("#C62828"); statusLabel.Text = "Minimum length must be 4-64."; return; }
                if (!int.TryParse(maxLenEntry.Text, out var maxVal) || maxVal < minVal || maxVal > 256)
                { statusLabel.TextColor = Color.FromArgb("#C62828"); statusLabel.Text = $"Maximum length must be {minVal}-256."; return; }
                if (!int.TryParse(historyEntry.Text, out var histVal) || histVal < 0 || histVal > 24)
                { statusLabel.TextColor = Color.FromArgb("#C62828"); statusLabel.Text = "History count must be 0-24."; return; }
                if (!int.TryParse(expiryEntry.Text, out var expVal) || expVal < 0 || expVal > 365)
                { statusLabel.TextColor = Color.FromArgb("#C62828"); statusLabel.Text = "Expiry days must be 0-365."; return; }
                if (!int.TryParse(lockoutAttemptsEntry.Text, out var attVal) || attVal < 3 || attVal > 20)
                { statusLabel.TextColor = Color.FromArgb("#C62828"); statusLabel.Text = "Lockout attempts must be 3-20."; return; }
                if (!int.TryParse(lockoutMinutesEntry.Text, out var durVal) || durVal < 1 || durVal > 1440)
                { statusLabel.TextColor = Color.FromArgb("#C62828"); statusLabel.Text = "Lockout duration must be 1-1440 minutes."; return; }

                await _settings.SetAsync(SettingKeys.PasswordMinLength, minLenEntry.Text, SettingKeys.CategoryPassword);
                await _settings.SetAsync(SettingKeys.PasswordMaxLength, maxLenEntry.Text, SettingKeys.CategoryPassword);
                await _settings.SetAsync(SettingKeys.PasswordRequireUpper, upperSwitch.IsToggled.ToString(), SettingKeys.CategoryPassword);
                await _settings.SetAsync(SettingKeys.PasswordRequireLower, lowerSwitch.IsToggled.ToString(), SettingKeys.CategoryPassword);
                await _settings.SetAsync(SettingKeys.PasswordRequireDigit, digitSwitch.IsToggled.ToString(), SettingKeys.CategoryPassword);
                await _settings.SetAsync(SettingKeys.PasswordRequireSpecial, specialSwitch.IsToggled.ToString(), SettingKeys.CategoryPassword);
                await _settings.SetAsync(SettingKeys.PasswordHistoryCount, historyEntry.Text, SettingKeys.CategoryPassword);
                await _settings.SetAsync(SettingKeys.PasswordExpiryDays, expiryEntry.Text, SettingKeys.CategoryPassword);
                await _settings.SetAsync(SettingKeys.LockoutMaxAttempts, lockoutAttemptsEntry.Text, SettingKeys.CategoryLockout);
                await _settings.SetAsync(SettingKeys.LockoutDurationMinutes, lockoutMinutesEntry.Text, SettingKeys.CategoryLockout);
                await _settings.RefreshCacheAsync();

                // Audit log the change
                _ = _audit.LogAsync(
                    AuditEventTypes.SettingsChanged,
                    userId: _session.CurrentUser?.UserID,
                    attuid: _session.ATTUID,
                    entityType: "SystemSettings",
                    entityId: SettingKeys.CategoryPassword,
                    details: $"Password policy updated: MinLen={minVal}, MaxLen={maxVal}, History={histVal}, Expiry={expVal}d, Lockout={attVal}/{durVal}m");

                statusLabel.TextColor = Color.FromArgb("#2E7D32");
                statusLabel.Text = "Settings saved successfully.";
            }
            catch (Exception ex)
            {
                statusLabel.TextColor = Color.FromArgb("#C62828");
                statusLabel.Text = $"Error: {ex.Message}";
            }
        };

        // Password health dashboard
        var healthLabel = new Label { Text = "Loading password health...", FontSize = 12, TextColor = Color.FromArgb("#666") };
        _ = LoadPasswordHealthAsync(healthLabel);

        // Locked accounts
        var lockedLabel = new Label { Text = "Loading locked accounts...", FontSize = 12, TextColor = Color.FromArgb("#666") };
        var unlockAllButton = new Button { Text = "Unlock All", HeightRequest = 28, FontSize = 11, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#E65100"), TextColor = Colors.White };
        unlockAllButton.Clicked += async (_, _) =>
        {
            await UnlockAllAccountsAsync();
            lockedLabel.Text = "All accounts unlocked.";
        };
        _ = LoadLockedAccountsAsync(lockedLabel);

        // Force all passwords to expire
        var forceExpireButton = new Button { Text = "Force All Passwords to Expire", HeightRequest = 28, FontSize = 11, Padding = new Thickness(10, 0), BackgroundColor = Color.FromArgb("#C62828"), TextColor = Colors.White };
        forceExpireButton.Clicked += async (_, _) =>
        {
            var page = Application.Current?.Windows.FirstOrDefault()?.Page;
            if (page is null) return;
            var confirm = await page.DisplayAlert("Confirm", "Force all users to change their password on next login?", "Yes", "No");
            if (!confirm) return;
            await ForceAllPasswordsExpireAsync();
            statusLabel.TextColor = Color.FromArgb("#2E7D32");
            statusLabel.Text = "All users must change their password on next login.";
        };

        return new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = new Thickness(16),
                Spacing = 12,
                Children =
                {
                    new Label { Text = "Password Policy Settings", FontAttributes = FontAttributes.Bold, FontSize = 18 },
                    SettingRow("Minimum length:", minLenEntry),
                    SettingRow("Maximum length:", maxLenEntry),
                    SettingRow("Require uppercase (A-Z):", upperSwitch),
                    SettingRow("Require lowercase (a-z):", lowerSwitch),
                    SettingRow("Require digit (0-9):", digitSwitch),
                    SettingRow("Require special character:", specialSwitch),
                    SettingRow("Password history count (0=disabled):", historyEntry),
                    SettingRow("Password expiry days (0=never):", expiryEntry),
                    new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5") },
                    new Label { Text = "Account Lockout", FontAttributes = FontAttributes.Bold, FontSize = 16 },
                    SettingRow("Max failed attempts:", lockoutAttemptsEntry),
                    SettingRow("Lockout duration (minutes):", lockoutMinutesEntry),
                    new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5") },
                    saveButton,
                    statusLabel,
                    new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5") },
                    new Label { Text = "Password Health Dashboard", FontAttributes = FontAttributes.Bold, FontSize = 16 },
                    healthLabel,
                    new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5") },
                    new Label { Text = "Locked Accounts", FontAttributes = FontAttributes.Bold, FontSize = 16 },
                    lockedLabel,
                    unlockAllButton,
                    new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5") },
                    forceExpireButton
                }
            }
        };
    }

    private static View SettingRow(string label, View control)
    {
        var grid = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(new GridLength(280)), new ColumnDefinition(GridLength.Auto) },
            ColumnSpacing = 10
        };
        grid.Children.Add(new Label { Text = label, VerticalOptions = LayoutOptions.Center, FontSize = 13 });
        Grid.SetColumn(control, 1);
        grid.Children.Add(control);
        return grid;
    }

    private async Task LoadPasswordHealthAsync(Label label)
    {
        try
        {
            var users = await _userService.GetAllUsersAsync(includeInactive: false);
            var now = DateTime.UtcNow;
            var neverSet = users.Count(u => string.IsNullOrWhiteSpace(u.PasswordHash));
            var expired = users.Count(u => u.PasswordExpiresAt.HasValue && u.PasswordExpiresAt.Value <= now);
            var expiring7 = users.Count(u => u.PasswordExpiresAt.HasValue && u.PasswordExpiresAt.Value > now && u.PasswordExpiresAt.Value <= now.AddDays(7));
            var expiring30 = users.Count(u => u.PasswordExpiresAt.HasValue && u.PasswordExpiresAt.Value > now.AddDays(7) && u.PasswordExpiresAt.Value <= now.AddDays(30));
            var mustChange = users.Count(u => u.MustChangePassword);

            label.Text = $"Total active users: {users.Count}\n" +
                         $"Password never set: {neverSet}\n" +
                         $"Password expired: {expired}\n" +
                         $"Expiring in 7 days: {expiring7}\n" +
                         $"Expiring in 30 days: {expiring30}\n" +
                         $"Must change on next login: {mustChange}";
        }
        catch (Exception ex)
        {
            label.Text = $"Error loading health data: {ex.Message}";
            label.TextColor = Color.FromArgb("#C62828");
        }
    }

    private async Task LoadLockedAccountsAsync(Label label)
    {
        try
        {
            var users = await _userService.GetAllUsersAsync(includeInactive: false);
            var now = DateTime.UtcNow;
            var locked = users.Where(u => u.LockoutUntil.HasValue && u.LockoutUntil.Value > now).ToList();

            label.Text = locked.Count == 0
                ? "No accounts are currently locked."
                : string.Join("\n", locked.Select(u => $"{u.DisplayName} ({u.ATTUID}) - locked until {u.LockoutUntil!.Value:g}"));
        }
        catch (Exception ex)
        {
            label.Text = $"Error: {ex.Message}";
        }
    }

    private async Task UnlockAllAccountsAsync()
    {
        var users = await _userService.GetAllUsersAsync(includeInactive: true);
        var unlocked = users.Where(u => u.LockoutUntil.HasValue || u.FailedLoginAttempts > 0).ToList();
        foreach (var user in unlocked)
        {
            user.FailedLoginAttempts = 0;
            user.LockoutUntil = null;
            await _userService.SaveUserAsync(user);
        }
        _ = _audit.LogAsync(
            AuditEventTypes.SettingsChanged,
            userId: _session.CurrentUser?.UserID,
            attuid: _session.ATTUID,
            entityType: "SystemSettings",
            details: $"Admin unlocked {unlocked.Count} locked account(s)");
    }

    private async Task ForceAllPasswordsExpireAsync()
    {
        var users = await _userService.GetAllUsersAsync(includeInactive: false);
        foreach (var user in users)
        {
            user.MustChangePassword = true;
            await _userService.SaveUserAsync(user);
        }
        _ = _audit.LogAsync(
            AuditEventTypes.SettingsChanged,
            userId: _session.CurrentUser?.UserID,
            attuid: _session.ATTUID,
            entityType: "SystemSettings",
            details: $"Admin forced password expiry for all {users.Count} active users");
    }

    // ??? Session Management Tab ????????????????????????????????????????

    private async Task<View> GetSessionViewAsync()
    {
        _sessionView = await BuildSessionViewAsync();
        return _sessionView;
    }

    private async Task<View> BuildSessionViewAsync()
    {
        var timeoutMinutes = await _settings.GetIntAsync(SettingKeys.SessionTimeoutMinutes, 30);
        var timeoutEntry = new Entry { Text = timeoutMinutes.ToString(), Keyboard = Keyboard.Numeric, HeightRequest = 32, WidthRequest = 80 };
        var statusLabel = new Label { FontSize = 12 };

        var saveButton = new Button { Text = "Save Session Settings", HeightRequest = 34, FontSize = 12, Padding = new Thickness(16, 0) };
        saveButton.Clicked += async (_, _) =>
        {
            if (!int.TryParse(timeoutEntry.Text, out var timeoutVal) || timeoutVal < 5 || timeoutVal > 480)
            { statusLabel.TextColor = Color.FromArgb("#C62828"); statusLabel.Text = "Timeout must be 5-480 minutes."; return; }

            await _settings.SetAsync(SettingKeys.SessionTimeoutMinutes, timeoutEntry.Text, SettingKeys.CategorySession);
            await _settings.RefreshCacheAsync();

            _ = _audit.LogAsync(
                AuditEventTypes.SettingsChanged,
                userId: _session.CurrentUser?.UserID,
                attuid: _session.ATTUID,
                entityType: "SystemSettings",
                entityId: SettingKeys.CategorySession,
                details: $"Session timeout changed to {timeoutVal} minutes");

            statusLabel.TextColor = Color.FromArgb("#2E7D32");
            statusLabel.Text = "Session settings saved.";
        };

        var activeSessions = await _sessionService.GetActiveSessionsAsync();
        var sessionList = new VerticalStackLayout { Spacing = 4 };

        if (activeSessions.Count == 0)
        {
            sessionList.Children.Add(new Label { Text = "No active sessions.", FontSize = 12, TextColor = Color.FromArgb("#666") });
        }
        else
        {
            foreach (var s in activeSessions)
            {
                var row = new Grid
                {
                    ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) },
                    Padding = new Thickness(0, 2)
                };
                row.Children.Add(new Label
                {
                    Text = $"{s.ATTUID ?? "?"} | {s.Platform ?? "?"} | Started: {s.StartedAtUtc:g} | Last: {s.LastActivityUtc:g}",
                    FontSize = 11, VerticalOptions = LayoutOptions.Center
                });
                var termBtn = new Button
                {
                    Text = "Terminate",
                    FontSize = 10,
                    HeightRequest = 24,
                    Padding = new Thickness(8, 0),
                    BackgroundColor = Color.FromArgb("#C62828"),
                    TextColor = Colors.White
                };
                var token = s.SessionToken;
                termBtn.Clicked += async (_, _) =>
                {
                    await _sessionService.EndSessionAsync(token, "AdminTerminated");
                    _sessionView = null;
                    TabContent.Content = await GetSessionViewAsync();
                };
                Grid.SetColumn(termBtn, 1);
                row.Children.Add(termBtn);
                sessionList.Children.Add(row);
            }
        }

        return new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = new Thickness(16),
                Spacing = 12,
                Children =
                {
                    new Label { Text = "Session Settings", FontAttributes = FontAttributes.Bold, FontSize = 18 },
                    SettingRow("Inactivity timeout (minutes):", timeoutEntry),
                    saveButton,
                    statusLabel,
                    new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5") },
                    new Label { Text = $"Active Sessions ({activeSessions.Count})", FontAttributes = FontAttributes.Bold, FontSize = 16 },
                    sessionList
                }
            }
        };
    }

    // ??? MFA Configuration Tab ?????????????????????????????????????????

    private async Task<View> GetMfaViewAsync()
    {
        _mfaView ??= await BuildMfaViewAsync();
        return _mfaView;
    }

    private async Task<View> BuildMfaViewAsync()
    {
        var enabled = await _settings.GetBoolAsync(SettingKeys.MfaEnabled, false);
        var mode = await _settings.GetAsync(SettingKeys.MfaEnforcementMode, "Optional") ?? "Optional";
        var method = await _settings.GetAsync(SettingKeys.MfaMethod, "EmailOtp") ?? "EmailOtp";

        var enabledSwitch = new Switch { IsToggled = enabled };
        var modePicker = new Picker { HeightRequest = 32 };
        modePicker.Items.Add("Optional");
        modePicker.Items.Add("Required");
        modePicker.Items.Add("PerRole");
        modePicker.SelectedItem = mode;
        var methodPicker = new Picker { HeightRequest = 32 };
        methodPicker.Items.Add("EmailOtp");
        methodPicker.Items.Add("Totp");
        methodPicker.SelectedItem = method;

        var statusLabel = new Label { FontSize = 12 };
        var notActiveLabel = new Label
        {
            Text = "MFA authentication plumbing is not yet active. Configuration can be saved and will take effect when the MFA module is implemented.",
            FontSize = 11, TextColor = Color.FromArgb("#E65100"), Margin = new Thickness(0, 4)
        };

        var saveButton = new Button { Text = "Save MFA Settings", HeightRequest = 34, FontSize = 12, Padding = new Thickness(16, 0) };
        saveButton.Clicked += async (_, _) =>
        {
            await _settings.SetAsync(SettingKeys.MfaEnabled, enabledSwitch.IsToggled.ToString(), SettingKeys.CategoryMfa);
            await _settings.SetAsync(SettingKeys.MfaEnforcementMode, modePicker.SelectedItem?.ToString() ?? "Optional", SettingKeys.CategoryMfa);
            await _settings.SetAsync(SettingKeys.MfaMethod, methodPicker.SelectedItem?.ToString() ?? "EmailOtp", SettingKeys.CategoryMfa);
            await _settings.RefreshCacheAsync();

            _ = _audit.LogAsync(
                AuditEventTypes.SettingsChanged,
                userId: _session.CurrentUser?.UserID,
                attuid: _session.ATTUID,
                entityType: "SystemSettings",
                entityId: SettingKeys.CategoryMfa,
                details: $"MFA settings updated: Enabled={enabledSwitch.IsToggled}, Mode={modePicker.SelectedItem}, Method={methodPicker.SelectedItem}");

            statusLabel.TextColor = Color.FromArgb("#2E7D32");
            statusLabel.Text = "MFA settings saved.";
        };

        return new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = new Thickness(16),
                Spacing = 12,
                Children =
                {
                    new Label { Text = "Multi-Factor Authentication", FontAttributes = FontAttributes.Bold, FontSize = 18 },
                    notActiveLabel,
                    SettingRow("Enable MFA:", enabledSwitch),
                    SettingRow("Enforcement mode:", modePicker),
                    SettingRow("MFA method:", methodPicker),
                    saveButton,
                    statusLabel
                }
            }
        };
    }

    // ??? SSO Configuration Tab ?????????????????????????????????????????

    private async Task<View> GetSsoViewAsync()
    {
        _ssoView ??= await BuildSsoViewAsync();
        return _ssoView;
    }

    private async Task<View> BuildSsoViewAsync()
    {
        var enabled = await _settings.GetBoolAsync(SettingKeys.SsoEnabled, false);
        var providerType = await _settings.GetAsync(SettingKeys.SsoProviderType, "") ?? "";

        var enabledSwitch = new Switch { IsToggled = enabled };
        var providerPicker = new Picker { HeightRequest = 32 };
        providerPicker.Items.Add("OAuth2");
        providerPicker.Items.Add("OIDC");
        providerPicker.Items.Add("SAML2");
        providerPicker.Items.Add("EntraID");
        if (!string.IsNullOrWhiteSpace(providerType))
            providerPicker.SelectedItem = providerType;

        // Common fields
        var authorityEntry = new Entry { Text = await _settings.GetAsync(SettingKeys.SsoAuthorityUrl, ""), Placeholder = "https://login.microsoftonline.com/...", HeightRequest = 32 };
        var clientIdEntry = new Entry { Text = await _settings.GetAsync(SettingKeys.SsoClientId, ""), Placeholder = "Application / Client ID", HeightRequest = 32 };
        var clientSecretEntry = new Entry { Text = await _settings.GetAsync(SettingKeys.SsoClientSecret, ""), Placeholder = "Client Secret", IsPassword = true, HeightRequest = 32 };
        var tenantIdEntry = new Entry { Text = await _settings.GetAsync(SettingKeys.SsoTenantId, ""), Placeholder = "Azure AD Tenant ID", HeightRequest = 32 };
        var scopesEntry = new Entry { Text = await _settings.GetAsync(SettingKeys.SsoScopes, "openid profile email"), HeightRequest = 32 };
        var redirectEntry = new Entry { Text = await _settings.GetAsync(SettingKeys.SsoRedirectUri, ""), Placeholder = "https://localhost/callback", HeightRequest = 32 };

        // SAML2-specific fields
        var idpMetadataEntry = new Entry { Text = await _settings.GetAsync(SettingKeys.SsoIdpMetadataUrl, ""), Placeholder = "IdP Metadata URL", HeightRequest = 32 };
        var idpEntityEntry = new Entry { Text = await _settings.GetAsync(SettingKeys.SsoIdpEntityId, ""), Placeholder = "IdP Entity ID", HeightRequest = 32 };
        var spEntityEntry = new Entry { Text = await _settings.GetAsync(SettingKeys.SsoSpEntityId, ""), Placeholder = "SP Entity ID", HeightRequest = 32 };
        var certThumbEntry = new Entry { Text = await _settings.GetAsync(SettingKeys.SsoCertificateThumbprint, ""), Placeholder = "Certificate Thumbprint", HeightRequest = 32 };
        var acsEntry = new Entry { Text = await _settings.GetAsync(SettingKeys.SsoAcsUrl, ""), Placeholder = "Assertion Consumer Service URL", HeightRequest = 32 };

        var samlSection = new VerticalStackLayout
        {
            Spacing = 8,
            Children =
            {
                new Label { Text = "SAML2-Specific Settings", FontAttributes = FontAttributes.Bold, FontSize = 14, Margin = new Thickness(0, 8, 0, 0) },
                SettingRow("IdP Metadata URL:", idpMetadataEntry),
                SettingRow("IdP Entity ID:", idpEntityEntry),
                SettingRow("SP Entity ID:", spEntityEntry),
                SettingRow("Certificate Thumbprint:", certThumbEntry),
                SettingRow("ACS URL:", acsEntry)
            }
        };

        // Show/hide SAML section based on provider
        samlSection.IsVisible = providerType == "SAML2";
        providerPicker.SelectedIndexChanged += (_, _) =>
        {
            samlSection.IsVisible = providerPicker.SelectedItem?.ToString() == "SAML2";
        };

        var statusLabel = new Label { FontSize = 12 };
        var notActiveLabel = new Label
        {
            Text = "SSO authentication plumbing is not yet active. Configuration can be saved and will take effect when the SSO module is implemented.",
            FontSize = 11, TextColor = Color.FromArgb("#E65100"), Margin = new Thickness(0, 4)
        };

        var saveButton = new Button { Text = "Save SSO Settings", HeightRequest = 34, FontSize = 12, Padding = new Thickness(16, 0) };
        saveButton.Clicked += async (_, _) =>
        {
            await _settings.SetAsync(SettingKeys.SsoEnabled, enabledSwitch.IsToggled.ToString(), SettingKeys.CategorySso);
            await _settings.SetAsync(SettingKeys.SsoProviderType, providerPicker.SelectedItem?.ToString() ?? "", SettingKeys.CategorySso);
            await _settings.SetAsync(SettingKeys.SsoAuthorityUrl, authorityEntry.Text ?? "", SettingKeys.CategorySso);
            await _settings.SetAsync(SettingKeys.SsoClientId, clientIdEntry.Text ?? "", SettingKeys.CategorySso);
            await _settings.SetAsync(SettingKeys.SsoClientSecret, clientSecretEntry.Text ?? "", SettingKeys.CategorySso);
            await _settings.SetAsync(SettingKeys.SsoTenantId, tenantIdEntry.Text ?? "", SettingKeys.CategorySso);
            await _settings.SetAsync(SettingKeys.SsoScopes, scopesEntry.Text ?? "", SettingKeys.CategorySso);
            await _settings.SetAsync(SettingKeys.SsoRedirectUri, redirectEntry.Text ?? "", SettingKeys.CategorySso);
            await _settings.SetAsync(SettingKeys.SsoIdpMetadataUrl, idpMetadataEntry.Text ?? "", SettingKeys.CategorySso);
            await _settings.SetAsync(SettingKeys.SsoIdpEntityId, idpEntityEntry.Text ?? "", SettingKeys.CategorySso);
            await _settings.SetAsync(SettingKeys.SsoSpEntityId, spEntityEntry.Text ?? "", SettingKeys.CategorySso);
            await _settings.SetAsync(SettingKeys.SsoCertificateThumbprint, certThumbEntry.Text ?? "", SettingKeys.CategorySso);
            await _settings.SetAsync(SettingKeys.SsoAcsUrl, acsEntry.Text ?? "", SettingKeys.CategorySso);
            await _settings.RefreshCacheAsync();

            // Audit log � do NOT log the client secret value
            _ = _audit.LogAsync(
                AuditEventTypes.SettingsChanged,
                userId: _session.CurrentUser?.UserID,
                attuid: _session.ATTUID,
                entityType: "SystemSettings",
                entityId: SettingKeys.CategorySso,
                details: $"SSO settings updated: Enabled={enabledSwitch.IsToggled}, Provider={providerPicker.SelectedItem}, ClientID={clientIdEntry.Text}");

            statusLabel.TextColor = Color.FromArgb("#2E7D32");
            statusLabel.Text = "SSO settings saved.";
        };

        return new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = new Thickness(16),
                Spacing = 12,
                Children =
                {
                    new Label { Text = "Single Sign-On (SSO)", FontAttributes = FontAttributes.Bold, FontSize = 18 },
                    notActiveLabel,
                    SettingRow("Enable SSO:", enabledSwitch),
                    SettingRow("Provider Type:", providerPicker),
                    new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5") },
                    new Label { Text = "Common Settings", FontAttributes = FontAttributes.Bold, FontSize = 14 },
                    SettingRow("Authority / Issuer URL:", authorityEntry),
                    SettingRow("Client ID:", clientIdEntry),
                    SettingRow("Client Secret:", clientSecretEntry),
                    SettingRow("Tenant ID (Entra ID):", tenantIdEntry),
                    SettingRow("Scopes:", scopesEntry),
                    SettingRow("Redirect URI:", redirectEntry),
                    samlSection,
                    new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5") },
                    saveButton,
                    statusLabel
                }
            }
        };
    }

    // ??? Audit Log Tab ?????????????????????????????????????????????????

    private async Task<View> GetAuditViewAsync()
    {
        _auditView = await BuildAuditViewAsync();
        return _auditView;
    }

    private async Task<View> BuildAuditViewAsync()
    {
        var users = await _userService.GetAllUsersAsync(includeInactive: true);
        List<AuditLog> _lastSearchResults = [];

        var fromPicker = new DatePicker { Date = DateTime.Today.AddDays(-30), MinimumDate = DateTime.Today.AddYears(-2), MaximumDate = DateTime.Today };
        var toPicker = new DatePicker { Date = DateTime.Today, MinimumDate = DateTime.Today.AddYears(-2), MaximumDate = DateTime.Today };

        var userPicker = new Picker { Title = "All Users", HeightRequest = 32 };
        userPicker.Items.Add("All Users");
        foreach (var u in users)
            userPicker.Items.Add($"{u.ATTUID} - {u.DisplayName}");
        userPicker.SelectedIndex = 0;

        var eventPicker = new Picker { Title = "All Events", HeightRequest = 32 };
        eventPicker.Items.Add("All Events");
        foreach (var et in new[] { AuditEventTypes.Login, AuditEventTypes.LoginFailed, AuditEventTypes.Logout,
            AuditEventTypes.SessionExpired, AuditEventTypes.AccountLocked, AuditEventTypes.PasswordSet,
            AuditEventTypes.PasswordChanged, AuditEventTypes.PasswordReset, AuditEventTypes.UserCreated,
            AuditEventTypes.UserModified, AuditEventTypes.UserDeleted, AuditEventTypes.RoleCreated,
            AuditEventTypes.RoleModified, AuditEventTypes.RoleDeleted, AuditEventTypes.SettingsChanged })
            eventPicker.Items.Add(et);
        eventPicker.SelectedIndex = 0;

        var resultCount = new Label { FontSize = 11, TextColor = Color.FromArgb("#666") };
        var resultList = new VerticalStackLayout { Spacing = 2 };

        var exportButton = new Button
        {
            Text = "Export CSV",
            HeightRequest = 34,
            FontSize = 12,
            Padding = new Thickness(16, 0),
            BackgroundColor = Color.FromArgb("#2E7D32"),
            TextColor = Colors.White,
            IsEnabled = false
        };

        var searchButton = new Button { Text = "Search", HeightRequest = 34, FontSize = 12, Padding = new Thickness(16, 0) };
        searchButton.Clicked += async (_, _) =>
        {
            searchButton.IsEnabled = false;
            exportButton.IsEnabled = false;
            resultList.Children.Clear();
            resultCount.Text = "Searching...";

            try
            {
                int? userId = null;
                if (userPicker.SelectedIndex > 0)
                    userId = users[userPicker.SelectedIndex - 1].UserID;

                string? eventType = null;
                if (eventPicker.SelectedIndex > 0)
                    eventType = eventPicker.SelectedItem?.ToString();

                var fromUtc = fromPicker.Date.ToUniversalTime();
                var toUtc = toPicker.Date.AddDays(1).ToUniversalTime();

                var results = await _audit.GetFilteredAsync(fromUtc, toUtc, userId, eventType, 500);
                _lastSearchResults = results;
                resultCount.Text = $"{results.Count} records found (max 500)";
                exportButton.IsEnabled = results.Count > 0;

                foreach (var log in results)
                {
                    var row = new Label
                    {
                        Text = $"{log.TimestampUtc:yyyy-MM-dd HH:mm:ss} | {log.EventType,-18} | {log.ATTUID ?? "system",-12} | {log.Details}",
                        FontSize = 11,
                        FontFamily = "Courier New",
                        TextColor = Color.FromArgb("#333"),
                        LineBreakMode = LineBreakMode.TailTruncation
                    };
                    resultList.Children.Add(row);
                }
            }
            catch (Exception ex)
            {
                resultCount.Text = $"Error: {ex.Message}";
                resultCount.TextColor = Color.FromArgb("#C62828");
            }
            finally
            {
                searchButton.IsEnabled = true;
            }
        };

        exportButton.Clicked += async (_, _) =>
        {
            if (_lastSearchResults.Count == 0) return;

            exportButton.IsEnabled = false;
            try
            {
                var csvContent = BuildAuditLogCsv(_lastSearchResults);
                var timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                var fileName = $"AuditLog_{timestamp}.csv";

                var savedPath = await _fileSaveService.SaveFileAsync(fileName, csvContent, "text/csv");

                if (savedPath is null)
                {
                    // User cancelled the save dialog
                    resultCount.Text = "Export cancelled.";
                    return;
                }

                resultCount.TextColor = Color.FromArgb("#2E7D32");
                resultCount.Text = $"Exported {_lastSearchResults.Count} records to: {savedPath}";

                _ = _audit.LogAsync(
                    AuditEventTypes.SettingsChanged,
                    userId: _session.CurrentUser?.UserID,
                    attuid: _session.ATTUID,
                    entityType: "AuditLog",
                    details: $"Exported {_lastSearchResults.Count} audit log records to CSV: {savedPath}");

                var page = Application.Current?.Windows.FirstOrDefault()?.Page;
                if (page is not null)
                    await page.DisplayAlert("Export Successful",
                        $"{_lastSearchResults.Count} audit log records exported.\n\nSaved to:\n{savedPath}", "OK");
            }
            catch (Exception ex)
            {
                resultCount.TextColor = Color.FromArgb("#C62828");
                resultCount.Text = $"Export failed: {ex.Message}";

                var page = Application.Current?.Windows.FirstOrDefault()?.Page;
                if (page is not null)
                    await page.DisplayAlert("Export Failed", ex.Message, "OK");
            }
            finally
            {
                exportButton.IsEnabled = _lastSearchResults.Count > 0;
            }
        };

        var filterPanel = new VerticalStackLayout
        {
            Spacing = 8,
            Children =
            {
                new Label { Text = "Audit Log", FontAttributes = FontAttributes.Bold, FontSize = 18 },
                new FlexLayout
                {
                    Wrap = Microsoft.Maui.Layouts.FlexWrap.Wrap,
                    Direction = Microsoft.Maui.Layouts.FlexDirection.Row,
                    AlignItems = Microsoft.Maui.Layouts.FlexAlignItems.Center,
                    Children =
                    {
                        new Label { Text = "From:", FontSize = 12, VerticalOptions = LayoutOptions.Center, Margin = new Thickness(0, 0, 4, 0) },
                        fromPicker,
                        new Label { Text = "  To:", FontSize = 12, VerticalOptions = LayoutOptions.Center, Margin = new Thickness(8, 0, 4, 0) },
                        toPicker,
                        new Label { Text = "  User:", FontSize = 12, VerticalOptions = LayoutOptions.Center, Margin = new Thickness(8, 0, 4, 0) },
                        userPicker,
                        new Label { Text = "  Event:", FontSize = 12, VerticalOptions = LayoutOptions.Center, Margin = new Thickness(8, 0, 4, 0) },
                        eventPicker,
                        searchButton,
                        exportButton
                    }
                },
                resultCount
            }
        };

        var resultScroll = new ScrollView { Content = resultList };
        Grid.SetRow(resultScroll, 1);

        var grid = new Grid
        {
            RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Star) },
            Padding = new Thickness(16),
            RowSpacing = 12
        };
        grid.Children.Add(filterPanel);
        grid.Children.Add(resultScroll);

        return grid;
    }

    /// <summary>
    /// Builds CSV content from audit log records.
    /// </summary>
    private static string BuildAuditLogCsv(List<AuditLog> records)
    {
        var sb = new System.Text.StringBuilder();

        // CSV header
        sb.AppendLine("Timestamp (UTC),Event Type,ATTUID,Entity Type,Entity ID,Details");

        // CSV rows � escape fields that may contain commas or quotes
        foreach (var log in records)
        {
            sb.Append(log.TimestampUtc.ToString("yyyy-MM-dd HH:mm:ss")).Append(',');
            sb.Append(EscapeCsvField(log.EventType)).Append(',');
            sb.Append(EscapeCsvField(log.ATTUID ?? "system")).Append(',');
            sb.Append(EscapeCsvField(log.EntityType)).Append(',');
            sb.Append(EscapeCsvField(log.EntityID)).Append(',');
            sb.AppendLine(EscapeCsvField(log.Details));
        }

        return sb.ToString();
    }

    /// <summary>
    /// Escapes a CSV field value per RFC 4180.
    /// </summary>
    private static string EscapeCsvField(string? value)
    {
        if (string.IsNullOrEmpty(value))
            return string.Empty;

        if (value.Contains(',') || value.Contains('"') || value.Contains('\n') || value.Contains('\r'))
            return $"\"{value.Replace("\"", "\"\"")}\"";

        return value;
    }
}
