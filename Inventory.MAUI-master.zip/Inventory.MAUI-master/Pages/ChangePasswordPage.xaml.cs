using Inventory.MAUI.Services;

namespace Inventory.MAUI.Pages;

public partial class ChangePasswordPage : ContentPage
{
    private readonly IAppUserService _userService;
    private readonly AppSessionService _session;
    private readonly PasswordPolicy _passwordPolicy;

    private IDispatcherTimer? _currentRevealTimer;
    private IDispatcherTimer? _newRevealTimer;
    private IDispatcherTimer? _confirmRevealTimer;

    private static readonly TimeSpan RevealDuration = TimeSpan.FromSeconds(3);

    public event Action? PasswordChanged;
    public event Action? Cancelled;

    public ChangePasswordPage(IAppUserService userService, AppSessionService session, PasswordPolicy passwordPolicy)
    {
        InitializeComponent();
        _userService = userService;
        _session = session;
        _passwordPolicy = passwordPolicy;

        UserLabel.Text = $"Signed in as: {_session.DisplayName} ({_session.ATTUID})";
    }

    private void ShowError(string message)
    {
        ErrorLabel.Text = message;
        ErrorBanner.IsVisible = true;
        ErrorBanner.BackgroundColor = Color.FromArgb("#FFEBEE");
        ErrorBanner.Stroke = new SolidColorBrush(Color.FromArgb("#EF9A9A"));
        ErrorLabel.TextColor = Color.FromArgb("#C62828");
    }

    private void ClearError()
    {
        ErrorBanner.IsVisible = false;
        ErrorLabel.Text = string.Empty;
    }

    private void OnCurrentPasswordCompleted(object? sender, EventArgs e) => NewPasswordEntry.Focus();
    private void OnNewPasswordCompleted(object? sender, EventArgs e) => ConfirmPasswordEntry.Focus();

    private void OnToggleCurrentVisibility(object? sender, EventArgs e)
    {
        _currentRevealTimer = ToggleVisibility(CurrentPasswordEntry, CurrentEyeButton, _currentRevealTimer);
    }

    private void OnToggleNewVisibility(object? sender, EventArgs e)
    {
        _newRevealTimer = ToggleVisibility(NewPasswordEntry, NewEyeButton, _newRevealTimer);
    }

    private void OnToggleConfirmVisibility(object? sender, EventArgs e)
    {
        _confirmRevealTimer = ToggleVisibility(ConfirmPasswordEntry, ConfirmEyeButton, _confirmRevealTimer);
    }

    private IDispatcherTimer? ToggleVisibility(Entry entry, ImageButton eyeButton, IDispatcherTimer? timer)
    {
        if (entry.IsPassword)
        {
            entry.IsPassword = false;
            eyeButton.Source = "eye_on.png";

            timer?.Stop();
            var newTimer = Dispatcher.CreateTimer();
            newTimer.Interval = RevealDuration;
            newTimer.IsRepeating = false;
            newTimer.Tick += (_, _) =>
            {
                MainThread.BeginInvokeOnMainThread(() => HidePassword(entry, eyeButton));
            };
            newTimer.Start();
            return newTimer;
        }
        else
        {
            HidePassword(entry, eyeButton);
            timer?.Stop();
            return null;
        }
    }

    private static void HidePassword(Entry entry, ImageButton eyeButton)
    {
        entry.IsPassword = true;
        eyeButton.Source = "eye_off.png";
    }

    private void HideAllPasswords()
    {
        _currentRevealTimer?.Stop();
        _currentRevealTimer = null;
        HidePassword(CurrentPasswordEntry, CurrentEyeButton);

        _newRevealTimer?.Stop();
        _newRevealTimer = null;
        HidePassword(NewPasswordEntry, NewEyeButton);

        _confirmRevealTimer?.Stop();
        _confirmRevealTimer = null;
        HidePassword(ConfirmPasswordEntry, ConfirmEyeButton);
    }

    private async void OnSubmitClicked(object? sender, EventArgs e)
    {
        ClearError();

        var currentPassword = CurrentPasswordEntry.Text;
        var newPassword = NewPasswordEntry.Text;
        var confirmPassword = ConfirmPasswordEntry.Text;

        if (string.IsNullOrWhiteSpace(currentPassword))
        {
            ShowError("Current password is required.");
            CurrentPasswordEntry.Focus();
            return;
        }

        if (string.IsNullOrWhiteSpace(newPassword))
        {
            ShowError("New password is required.");
            NewPasswordEntry.Focus();
            return;
        }

        var policyError = await _passwordPolicy.ValidateAsync(newPassword);
        if (policyError is not null)
        {
            ShowError(policyError);
            NewPasswordEntry.Focus();
            return;
        }

        if (newPassword == currentPassword)
        {
            ShowError("New password must be different from current password.");
            NewPasswordEntry.Text = string.Empty;
            ConfirmPasswordEntry.Text = string.Empty;
            NewPasswordEntry.Focus();
            return;
        }

        if (newPassword != confirmPassword)
        {
            ShowError("New passwords do not match.");
            ConfirmPasswordEntry.Text = string.Empty;
            ConfirmPasswordEntry.Focus();
            return;
        }

        SubmitButton.IsEnabled = false;
        HideAllPasswords();

        try
        {
            var user = _session.CurrentUser;
            if (user is null)
            {
                ShowError("No active session. Please sign in again.");
                return;
            }

            // Verify current password by attempting authentication
            var verified = await _userService.AuthenticateAsync(user.ATTUID, currentPassword);
            if (verified is null)
            {
                ShowError("Current password is incorrect.");
                CurrentPasswordEntry.Text = string.Empty;
                CurrentPasswordEntry.Focus();
                return;
            }

            // Set the new password
            await _userService.SetPasswordAsync(user.UserID, newPassword);

            // Clear all fields immediately
            CurrentPasswordEntry.Text = string.Empty;
            NewPasswordEntry.Text = string.Empty;
            ConfirmPasswordEntry.Text = string.Empty;

            PasswordChanged?.Invoke();
        }
        catch (ArgumentException ex)
        {
            ShowError(ex.Message);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[IAM] Change password error: {ex.Message}");
            ShowError("An unexpected error occurred. Please try again.");
        }
        finally
        {
            SubmitButton.IsEnabled = true;
        }
    }

    private void OnCancelClicked(object? sender, EventArgs e)
    {
        HideAllPasswords();
        CurrentPasswordEntry.Text = string.Empty;
        NewPasswordEntry.Text = string.Empty;
        ConfirmPasswordEntry.Text = string.Empty;
        Cancelled?.Invoke();
    }
}
