using Inventory.MAUI.ViewModels;
using CommunityToolkit.Maui.Alerts;

namespace Inventory.MAUI.Pages;

public partial class InventoryItemEditPage : ContentView
{
    private readonly InventoryItemEditViewModel _vm;
    private int _inventoryId;
    private int _lastLoadedId;

    private CancellationTokenSource? _loadCts;

    public event EventHandler? BackRequested;
    public event Action<int>? Saved;

    public int InventoryId
    {
        get => _inventoryId;
        set
        {
            if (_inventoryId == value)
                return;

            _inventoryId = value;
            _ = LoadAsync(value);
        }
    }

    public int LastLoadedId
    {
        get => _lastLoadedId;
        private set
        {
            if (_lastLoadedId == value)
                return;

            _lastLoadedId = value;
            OnPropertyChanged();
        }
    }

    public InventoryItemEditPage(InventoryItemEditViewModel vm)
    {
        InitializeComponent();
        _vm = vm;
        BindingContext = _vm;

        _vm.Saved -= OnVmSaved;
        _vm.Saved += OnVmSaved;

        _vm.ConfirmAsync = async (title, message) =>
            await Application.Current!.MainPage!.DisplayAlert(title, message, "OK", "Cancel");

        _vm.ToastAsync = null;

        Unloaded += (_, _) =>
        {
            try { _loadCts?.Cancel(); } catch { }
            _loadCts?.Dispose();
            _loadCts = null;
        };
    }

    private void OnVmSaved(int id) => Saved?.Invoke(id);

    private async Task LoadAsync(int inventoryId)
    {
        if (inventoryId <= 0)
            return;

        _loadCts?.Cancel();
        _loadCts?.Dispose();
        _loadCts = new CancellationTokenSource();
        var token = _loadCts.Token;

        try
        {
            await _vm.LoadAsync(inventoryId, token);
            if (token.IsCancellationRequested)
                return;

            LastLoadedId = inventoryId;
        }
        catch (OperationCanceledException)
        {
        }
    }

    private void OnBackClicked(object sender, EventArgs e)
    {
        BackRequested?.Invoke(this, EventArgs.Empty);
    }
}