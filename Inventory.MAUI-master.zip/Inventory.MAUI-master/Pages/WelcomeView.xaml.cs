using Inventory.MAUI.ViewModels;

namespace Inventory.MAUI.Pages;

public partial class WelcomeView : ContentView
{
    public WelcomeView()
    {
        InitializeComponent();
        BindingContext = new WelcomeViewModel();
    }
}
