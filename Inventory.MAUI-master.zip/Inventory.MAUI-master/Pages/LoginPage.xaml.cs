using Inventory.MAUI.Services;

namespace Inventory.MAUI.Pages;

public partial class LoginPage : ContentPage
{
    private readonly IAppUserService _userService;
    private readonly AppSessionService _session;
    private readonly PasswordPolicy _passwordPolicy;
    private bool _isSettingPassword;

    private IDispatcherTimer? _passwordRevealTimer;
    private IDispatcherTimer? _confirmRevealTimer;

    /// <summary>
    /// Duration the password is visible before auto-hiding (security best practice).
    /// </summary>
    private static readonly TimeSpan RevealDuration = TimeSpan.FromSeconds(3);

    /// <summary>
    /// Raised when the user successfully signs in.
    /// </summary>
    public event Action? LoginSucceeded;

    /// <summary>
    /// Raised when the user cancels the login.
    /// </summary>
    public event Action? LoginCancelled;

    /// <summary>
    /// Raised when the user taps "Forgot Password?" so the parent can navigate to the recovery flow.
    /// </summary>
    public event Action? ForgotPasswordRequested;

    public LoginPage(IAppUserService userService, AppSessionService session, PasswordPolicy passwordPolicy)
    {
        InitializeComponent();
        _userService = userService;
        _session = session;
        _passwordPolicy = passwordPolicy;

        Loaded += (_, _) => AttuidEntry.Focus();
    }

    private void ShowError(string message)
    {
        ErrorLabel.Text = message;
        ErrorBanner.IsVisible = true;
    }

    private void ClearError()
    {
        ErrorBanner.IsVisible = false;
        ErrorLabel.Text = string.Empty;
    }

    private async void SwitchToSetPasswordMode()
    {
        _isSettingPassword = true;
        TitleLabel.Text = "Set Your Password";
        PasswordLabel.Text = "New Password";
        PasswordEntry.Placeholder = "New password";
        PasswordEntry.Text = string.Empty;
        ConfirmSection.IsVisible = true;
        ConfirmPasswordEntry.Text = string.Empty;
        SubmitButton.Text = "Set Password & Sign In";
        AttuidEntry.IsEnabled = false;
        PolicyLabel.Text = await _passwordPolicy.GetRequirementsTextAsync();
        PolicyLabel.IsVisible = true;
        ForgotPasswordLabel.IsVisible = false;
        HideAllPasswords();
    }

    private void SwitchToSignInMode()
    {
        _isSettingPassword = false;
        TitleLabel.Text = "Sign In";
        PasswordLabel.Text = "Password";
        PasswordEntry.Placeholder = "Password";
        PasswordEntry.Text = string.Empty;
        ConfirmSection.IsVisible = false;
        ConfirmPasswordEntry.Text = string.Empty;
        SubmitButton.Text = "Sign In";
        AttuidEntry.IsEnabled = true;
        PolicyLabel.IsVisible = false;
        ForgotPasswordLabel.IsVisible = true;
        HideAllPasswords();
    }

    private void OnAttuidCompleted(object? sender, EventArgs e)
    {
        PasswordEntry.Focus();
    }

    private void OnPasswordCompleted(object? sender, EventArgs e)
    {
        if (_isSettingPassword)
            ConfirmPasswordEntry.Focus();
        else
            OnSubmitClicked(sender, e);
    }

    private async void OnSubmitClicked(object? sender, EventArgs e)
    {
        ClearError();

        var attuid = AttuidEntry.Text?.Trim();
        var password = PasswordEntry.Text;

        if (string.IsNullOrWhiteSpace(attuid))
        {
            ShowError("ATTUID is required.");
            AttuidEntry.Focus();
            return;
        }

        if (string.IsNullOrWhiteSpace(password))
        {
            ShowError("Password is required.");
            PasswordEntry.Focus();
            return;
        }

        SubmitButton.IsEnabled = false;

        try
        {
            // If we're not yet in set-password mode, check if the user needs to set one
            if (!_isSettingPassword)
            {
                var user = await _userService.GetByAttuidAsync(attuid);
                if (user is not null && user.IsActive && user.MustChangePassword)
                {
                    ShowError("Your account requires a new password before first use.");
                    SwitchToSetPasswordMode();
                    PasswordEntry.Focus();
                    return;
                }

                // Normal sign-in
                var ok = await _session.SignInAsync(_userService, attuid, password);
                if (!ok)
                {
                    ShowError("Invalid credentials, account is inactive, or account is locked.\nAccounts lock after 5 failed attempts for 15 minutes.");
                    PasswordEntry.Text = string.Empty;
                    PasswordEntry.Focus();
                    return;
                }

                LoginSucceeded?.Invoke();
                return;
            }

            // Set-password mode
            var confirm = ConfirmPasswordEntry.Text;

            var policyError = await _passwordPolicy.ValidateAsync(password);
            if (policyError is not null)
            {
                ShowError(policyError);
                PasswordEntry.Focus();
                return;
            }

            if (password != confirm)
            {
                ShowError("Passwords do not match.");
                ConfirmPasswordEntry.Text = string.Empty;
                ConfirmPasswordEntry.Focus();
                return;
            }

            var set = await _session.SetInitialPasswordAsync(_userService, attuid, password);
            if (!set)
            {
                ShowError("Unable to set password. Contact an administrator.");
                return;
            }

            // Now sign in with the new password
            var signedIn = await _session.SignInAsync(_userService, attuid, password);
            if (!signedIn)
            {
                ShowError("Password was set but sign-in failed. Please try again.");
                SwitchToSignInMode();
                return;
            }

            LoginSucceeded?.Invoke();
        }
        catch (ArgumentException ex)
        {
            ShowError(ex.Message);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[IAM] Login error: {ex.Message}");

            if (ex is Microsoft.Data.SqlClient.SqlException || ex.InnerException is Microsoft.Data.SqlClient.SqlException)
                ShowError("Unable to reach the database. Check your network connection and try again.");
            else
                ShowError("An unexpected error occurred. Please try again.");
        }
        finally
        {
            SubmitButton.IsEnabled = true;
        }
    }

    private void OnCancelClicked(object? sender, EventArgs e)
    {
        HideAllPasswords();
        LoginCancelled?.Invoke();
    }

    private void OnForgotPasswordTapped(object? sender, EventArgs e)
    {
        var resetService = Services.AppServices.Get<IPasswordResetService>();
        if (resetService is null || !resetService.IsAvailable)
        {
            ShowError("Self-service password recovery is not currently available.\nPlease contact your system administrator to reset your password.");
            return;
        }

        ForgotPasswordRequested?.Invoke();
    }

    private void OnTogglePasswordVisibility(object? sender, EventArgs e)
    {
        _passwordRevealTimer = ToggleVisibility(PasswordEntry, PasswordEyeButton, _passwordRevealTimer);
    }

    private void OnToggleConfirmVisibility(object? sender, EventArgs e)
    {
        _confirmRevealTimer = ToggleVisibility(ConfirmPasswordEntry, ConfirmEyeButton, _confirmRevealTimer);
    }

    private IDispatcherTimer? ToggleVisibility(Entry entry, ImageButton eyeButton, IDispatcherTimer? timer)
    {
        if (entry.IsPassword)
        {
            entry.IsPassword = false;
            eyeButton.Source = "eye_on.png";

            timer?.Stop();
            var newTimer = Dispatcher.CreateTimer();
            newTimer.Interval = RevealDuration;
            newTimer.IsRepeating = false;
            newTimer.Tick += (_, _) =>
            {
                MainThread.BeginInvokeOnMainThread(() => HidePassword(entry, eyeButton));
            };
            newTimer.Start();
            return newTimer;
        }
        else
        {
            HidePassword(entry, eyeButton);
            timer?.Stop();
            return null;
        }
    }

    private static void HidePassword(Entry entry, ImageButton eyeButton)
    {
        entry.IsPassword = true;
        eyeButton.Source = "eye_off.png";
    }

    private void HideAllPasswords()
    {
        _passwordRevealTimer?.Stop();
        _passwordRevealTimer = null;
        HidePassword(PasswordEntry, PasswordEyeButton);

        _confirmRevealTimer?.Stop();
        _confirmRevealTimer = null;
        HidePassword(ConfirmPasswordEntry, ConfirmEyeButton);
    }
}
