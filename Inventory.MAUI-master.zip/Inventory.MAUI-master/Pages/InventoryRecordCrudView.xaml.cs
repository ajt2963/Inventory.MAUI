using Inventory.MAUI.ViewModels;

namespace Inventory.MAUI.Pages;

public partial class InventoryRecordCrudView : ContentView
{
    private readonly InventoryRecordCrudViewModel _vm;
    private Task? _initTask;
    private Task _actionGate = Task.CompletedTask;

#if WINDOWS
    private Microsoft.UI.Xaml.Controls.Control? _nativeControl;
    private DateTime _lastKeyAtUtc;
    private Windows.System.VirtualKey? _lastKey;
    private bool _keyboardReady;
    private bool _focusRequested;
    private bool _wired;
    private DateTime _lastEndHandledAtUtc;
#endif

    private bool _scrollToEndPending;

    public InventoryRecordCrudView(InventoryRecordCrudViewModel vm)
    {
        InitializeComponent();
        _vm = vm;
        BindingContext = _vm;

        _vm.ChooseAsync = async (title, message, accept, destructive, cancel) =>
        {
            var choice = await Application.Current!.Windows[0].Page.DisplayActionSheet(title, cancel, null, accept, destructive);
            return choice ?? cancel;
        };

        InventoryList.RemainingItemsThreshold = -1;
        InventoryList.RemainingItemsThresholdReached -= OnRemainingItemsThresholdReached;

        Loaded += (_, _) => { _initTask ??= InitializeOnceAsync(); };
    }

    private void RefocusList()
    {
#if WINDOWS
        MainThread.BeginInvokeOnMainThread(EnsureKeyboardWiredAndFocused);
#endif
    }

#if WINDOWS
    private void EnsureKeyboardWiredAndFocused()
    {
        _nativeControl ??= InventoryList.Handler?.PlatformView as Microsoft.UI.Xaml.Controls.Control;
        if (_nativeControl is null)
            return;

        if (!_wired)
        {
            _wired = true;
            _nativeControl.IsTabStop = true;

            _nativeControl.PreviewKeyDown -= OnNativePreviewKeyDown;
            _nativeControl.PreviewKeyDown += OnNativePreviewKeyDown;

            _nativeControl.GotFocus -= OnNativeGotFocus;
            _nativeControl.GotFocus += OnNativeGotFocus;
        }

        _lastKey = null;
        _lastKeyAtUtc = DateTime.MinValue;

        if (!_focusRequested)
        {
            _focusRequested = true;
            _nativeControl.Focus(Microsoft.UI.Xaml.FocusState.Programmatic);
        }
    }

    private void OnNativeGotFocus(object sender, Microsoft.UI.Xaml.RoutedEventArgs e)
    {
        _lastKey = null;
        _lastKeyAtUtc = DateTime.MinValue;

        if (_vm.ListVm.SelectedRow is null && _vm.ListVm.Rows.Count > 0)
            _vm.ListVm.SelectedRow = _vm.ListVm.Rows[0];
    }

    private void OnNativePreviewKeyDown(object sender, Microsoft.UI.Xaml.Input.KeyRoutedEventArgs e)
    {
        if (_vm.ListVm.SelectedRow is null && _vm.ListVm.Rows.Count > 0)
            _vm.ListVm.SelectedRow = _vm.ListVm.Rows[0];

        var key = e.Key;

        if (_keyboardReady && ShouldDebounce(key))
        {
            e.Handled = true;
            return;
        }

        switch (key)
        {
            case Windows.System.VirtualKey.Up:
            case Windows.System.VirtualKey.Down:
            case Windows.System.VirtualKey.Home:
            case Windows.System.VirtualKey.End:
            case Windows.System.VirtualKey.PageUp:
            case Windows.System.VirtualKey.PageDown:
                e.Handled = true;
                break;
            default:
                return;
        }

        OnKeyNavigate(key);
    }

    private bool ShouldDebounce(Windows.System.VirtualKey key)
    {
        var now = DateTime.UtcNow;

        var minIntervalMs = key is Windows.System.VirtualKey.PageUp or Windows.System.VirtualKey.PageDown
            or Windows.System.VirtualKey.Home or Windows.System.VirtualKey.End
            ? 120
            : 35;

        if (_lastKey == key && (now - _lastKeyAtUtc).TotalMilliseconds < minIntervalMs)
            return true;

        _lastKey = key;
        _lastKeyAtUtc = now;
        return false;
    }

    private bool ShouldSuppressHome()
        => (DateTime.UtcNow - _lastEndHandledAtUtc) < TimeSpan.FromMilliseconds(600);

    private void OnKeyNavigate(Windows.System.VirtualKey key)
    {
        switch (key)
        {
            case Windows.System.VirtualKey.End:
                _lastEndHandledAtUtc = DateTime.UtcNow;

                RefocusList();

                _ = RunExclusiveAsync(async () =>
                {
                    _scrollToEndPending = true;
                    await _vm.ListVm.MoveToLastAsync();
                    ScrollToLastItem();
                    RefocusList();
                });
                break;

            case Windows.System.VirtualKey.Home:
                if (ShouldSuppressHome())
                    return;

                RefocusList();

                _ = RunExclusiveAsync(async () =>
                {
                    await _vm.ListVm.MoveToFirstAsync();
                    ScrollSelectionIntoView();
                    RefocusList();
                });
                break;

            case Windows.System.VirtualKey.Up:
                _ = RunExclusiveAsync(async () =>
                {
                    await _vm.ListVm.MovePreviousAsync();
                    ScrollSelectionIntoView();
                });
                break;

            case Windows.System.VirtualKey.Down:
                _ = RunExclusiveAsync(async () =>
                {
                    await _vm.ListVm.MoveNextAsync();
                    ScrollSelectionIntoView();
                });
                break;

            case Windows.System.VirtualKey.PageUp:
                _ = RunExclusiveAsync(async () => await PageMoveAsync(direction: -1));
                break;

            case Windows.System.VirtualKey.PageDown:
                _ = RunExclusiveAsync(async () => await PageMoveAsync(direction: +1));
                break;
        }
    }

    private async Task PageMoveAsync(int direction)
    {
        var viewportHeight = InventoryList.Height;
        var rowHeight = 34d;
        var pageSize = viewportHeight > 0 ? Math.Max(1, (int)(viewportHeight / rowHeight) - 1) : 20;

        if (_vm.ListVm.Rows.Count == 0)
            return;

        var current = _vm.ListVm.SelectedRowIndex;
        if (current < 0)
            current = 0;

        var target = current + (direction * pageSize);

        if (direction < 0)
        {
            while (target < _vm.ListVm.SelectedRowIndex)
                await _vm.ListVm.MovePreviousAsync();
        }
        else
        {
            while (target > _vm.ListVm.SelectedRowIndex)
                await _vm.ListVm.MoveNextAsync();
        }

        ScrollSelectionIntoView();
    }

    private void ScrollSelectionIntoView()
    {
        if (_vm.ListVm.SelectedRow is null)
            return;

        MainThread.BeginInvokeOnMainThread(() =>
        {
            try
            {
                InventoryList.ScrollTo(_vm.ListVm.SelectedRow, position: ScrollToPosition.Center, animate: false);
            }
            catch
            {
            }
        });
    }
#endif

    private Task RunExclusiveAsync(Func<Task> action)
    {
        if (!_actionGate.IsCompleted)
            return _actionGate;

        return _actionGate = action();
    }

    private void OnRemainingItemsThresholdReached(object? sender, EventArgs e)
    {
        if (_vm.ListVm.CanLoadMore)
            _ = RunExclusiveAsync(() => _vm.ListVm.LoadMoreCommand.ExecuteAsync());
    }

    private async Task InitializeOnceAsync()
    {
        try
        {
            _vm.EditVm.ConfirmAsync = async (title, message) =>
                await Application.Current!.Windows[0].Page.DisplayAlert(title, message, "OK", "Cancel");

            _vm.EditVm.ToastAsync = async message =>
            {
                var page = Application.Current?.Windows.FirstOrDefault()?.Page;
                if (page is not null)
                    await page.DisplayAlert("Info", message, "OK");
            };

            await _vm.InitializeAsync();
            await _vm.LoadSelectedIntoEditorAsync();
        }
        catch (Exception ex)
        {
            await Application.Current!.Windows[0].Page.DisplayAlert("Inventory", $"Failed to load CRUD page: {ex.Message}", "OK");
        }
        finally
        {
#if WINDOWS
            MainThread.BeginInvokeOnMainThread(() =>
            {
                EnsureKeyboardWiredAndFocused();
                _keyboardReady = true;
            });
#endif
        }
    }

    private async void OnSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        var needsScrollToEnd = _scrollToEndPending;
        if (needsScrollToEnd)
            _scrollToEndPending = false;

        // Schedule scroll overrides BEFORE the async editor load so they start firing immediately.
        if (needsScrollToEnd)
            ScheduleScrollToEndOverrides();

        await _vm.OnSelectionChangedAsync(e.CurrentSelection);

        // Schedule again AFTER the async editor load completes, because the CollectionView
        // may do another internal scroll-to-selected after the await settles.
        if (needsScrollToEnd && _vm.ListVm.SelectedRow is not null)
            ScheduleScrollToEndOverrides();
    }

    private void ScheduleScrollToEndOverrides()
    {
#if WINDOWS
        MainThread.BeginInvokeOnMainThread(() =>
        {
            var attempts = 0;
            void TryScroll()
            {
                attempts++;
                try
                {
                    if (InventoryList.Handler?.PlatformView is Microsoft.UI.Xaml.Controls.ListViewBase list)
                    {
                        var sv = FindScrollViewer(list);
                        if (sv is not null && sv.ScrollableHeight > 0)
                        {
                            sv.ChangeView(null, sv.ScrollableHeight, null, disableAnimation: true);
                        }
                    }
                }
                catch { }

                if (attempts < 20)
                    Dispatcher.DispatchDelayed(TimeSpan.FromMilliseconds(attempts <= 5 ? 30 : 80), TryScroll);
            }

            TryScroll();
        });
#else
        for (var delayMs = 50; delayMs <= 600; delayMs += 100)
        {
            var d = delayMs;
            Dispatcher.DispatchDelayed(TimeSpan.FromMilliseconds(d), () =>
            {
                if (_vm.ListVm.Rows.Count == 0) return;
                try
                {
                    InventoryList.ScrollTo(_vm.ListVm.Rows.Count - 1, position: ScrollToPosition.End, animate: false);
                }
                catch { }
            });
        }
#endif
    }

#if WINDOWS
    private static Microsoft.UI.Xaml.Controls.ScrollViewer? FindScrollViewer(Microsoft.UI.Xaml.DependencyObject root)
    {
        if (root is Microsoft.UI.Xaml.Controls.ScrollViewer sv) return sv;
        var count = Microsoft.UI.Xaml.Media.VisualTreeHelper.GetChildrenCount(root);
        for (var i = 0; i < count; i++)
        {
            var found = FindScrollViewer(Microsoft.UI.Xaml.Media.VisualTreeHelper.GetChild(root, i));
            if (found is not null) return found;
        }
        return null;
    }
#endif

    private void OnSearchClicked(object sender, EventArgs e) => _ = RunExclusiveAsync(() => _vm.ListVm.SearchCommand.ExecuteAsync());
    private void OnClearClicked(object sender, EventArgs e) => _ = RunExclusiveAsync(() => _vm.ListVm.ClearCommand.ExecuteAsync());

    private void OnMoveFirstClicked(object sender, EventArgs e)
        => _ = RunExclusiveAsync(async () =>
        {
            await _vm.ListVm.MoveToFirstAsync();
            RefocusList();
        });

    private void OnMovePreviousClicked(object sender, EventArgs e)
        => _ = RunExclusiveAsync(async () =>
        {
            await _vm.ListVm.MovePreviousAsync();
            RefocusList();
        });

    private void OnMoveNextClicked(object sender, EventArgs e)
        => _ = RunExclusiveAsync(async () =>
        {
            await _vm.ListVm.MoveNextAsync();
            RefocusList();
        });

    private void OnMoveLastClicked(object sender, EventArgs e)
        => _ = RunExclusiveAsync(async () =>
        {
            _scrollToEndPending = true;
            await _vm.ListVm.MoveToLastAsync();
            ScrollToLastItem();
            RefocusList();
        });

#if WINDOWS
    private void OnRootLoaded(object? sender, EventArgs e)
    {
        if (_wired)
            return;

        var attempts = 0;
        void TryWire()
        {
            attempts++;
            if (InventoryList.Handler?.PlatformView is Microsoft.UI.Xaml.Controls.Control)
            {
                EnsureKeyboardWiredAndFocused();
                return;
            }

            if (attempts < 10)
                Dispatcher.DispatchDelayed(TimeSpan.FromMilliseconds(50), TryWire);
        }

        TryWire();
    }
#else
    private void OnRootLoaded(object? sender, EventArgs e)
    {
    }
#endif

    private void ScrollToLastItem()
    {
        if (_vm.ListVm.Rows.Count == 0)
            return;

        var lastIndex = _vm.ListVm.Rows.Count - 1;

        MainThread.BeginInvokeOnMainThread(() =>
        {
            try
            {
                InventoryList.ScrollTo(lastIndex, position: ScrollToPosition.End, animate: false);
            }
            catch { }
        });
    }
}
