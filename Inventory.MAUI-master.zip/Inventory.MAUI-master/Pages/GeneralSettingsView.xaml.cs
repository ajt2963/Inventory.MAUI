using Inventory.MAUI.Services;

namespace Inventory.MAUI.Pages;

public partial class GeneralSettingsView : ContentView
{
    private readonly ISystemSettingsService _settings;
    private readonly IEmailService _emailService;
    private Task? _initTask;

    public GeneralSettingsView(ISystemSettingsService settings, IEmailService emailService)
    {
        InitializeComponent();
        _settings = settings;
        _emailService = emailService;
    }

    public async Task EnsureInitializedAsync()
    {
        _initTask ??= LoadSettingsAsync();
        await _initTask;
    }

    private async Task LoadSettingsAsync()
    {
        SettingsLayout.Children.Clear();

        // ??? Application Info ??????????????????????????????????
        SettingsLayout.Children.Add(new Label { Text = "Application Information", FontAttributes = FontAttributes.Bold, FontSize = 18 });

        var version = AppInfo.Current.VersionString;
        var build = AppInfo.Current.BuildString;
        var platform = DeviceInfo.Current.Platform.ToString();
        var device = $"{DeviceInfo.Current.Manufacturer} {DeviceInfo.Current.Model}";

        SettingsLayout.Children.Add(InfoRow("App Version:", $"{version} (build {build})"));
        SettingsLayout.Children.Add(InfoRow("Platform:", platform));
        SettingsLayout.Children.Add(InfoRow("Device:", device));

        SettingsLayout.Children.Add(new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5"), Margin = new Thickness(0, 8) });

        // ??? Email Service Status ??????????????????????????????
        SettingsLayout.Children.Add(new Label { Text = "Email Service", FontAttributes = FontAttributes.Bold, FontSize = 18 });

        var emailStatus = _emailService.IsConfigured
            ? "Configured and ready"
            : "Not configured - password recovery via email is disabled";
        var emailStatusColor = _emailService.IsConfigured ? Color.FromArgb("#2E7D32") : Color.FromArgb("#E65100");

        SettingsLayout.Children.Add(new Label
        {
            Text = emailStatus,
            FontSize = 13,
            TextColor = emailStatusColor,
            Margin = new Thickness(0, 4)
        });

        SettingsLayout.Children.Add(new Label
        {
            Text = "SMTP settings are configured in appsettings.local.json on the device.\nContact your IT administrator to set up an SMTP relay.",
            FontSize = 11,
            TextColor = Color.FromArgb("#888"),
            Margin = new Thickness(0, 4)
        });

        if (_emailService.IsConfigured)
        {
            var testButton = new Button
            {
                Text = "Send Test Email",
                HeightRequest = 34,
                FontSize = 12,
                Padding = new Thickness(16, 0),
                HorizontalOptions = LayoutOptions.Start
            };
            var testStatus = new Label { FontSize = 12, Margin = new Thickness(0, 4) };

            testButton.Clicked += async (_, _) =>
            {
                var page = Application.Current?.Windows.FirstOrDefault()?.Page;
                if (page is null) return;

                var email = await page.DisplayPromptAsync("Test Email", "Enter recipient email address:", "Send", "Cancel", "email@example.com");
                if (string.IsNullOrWhiteSpace(email)) return;

                testButton.IsEnabled = false;
                testStatus.Text = "Sending...";
                testStatus.TextColor = Color.FromArgb("#666");

                var sent = await _emailService.SendAsync(email, "UCOM Inventory - Test Email",
                    "<h2>Email Test Successful</h2><p>This is a test email from the UCOM Inventory Management System.</p>");

                testStatus.TextColor = sent ? Color.FromArgb("#2E7D32") : Color.FromArgb("#C62828");
                testStatus.Text = sent ? $"Test email sent to {email}" : "Failed to send test email. Check SMTP settings.";
                testButton.IsEnabled = true;
            };

            SettingsLayout.Children.Add(testButton);
            SettingsLayout.Children.Add(testStatus);
        }

        SettingsLayout.Children.Add(new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5"), Margin = new Thickness(0, 8) });

        // ??? Feature Flags Overview ????????????????????????????
        SettingsLayout.Children.Add(new Label { Text = "Feature Status", FontAttributes = FontAttributes.Bold, FontSize = 18 });

        var mfaEnabled = await _settings.GetBoolAsync(Models.SettingKeys.MfaEnabled, false);
        var ssoEnabled = await _settings.GetBoolAsync(Models.SettingKeys.SsoEnabled, false);

        SettingsLayout.Children.Add(FeatureRow("Multi-Factor Authentication (MFA):", mfaEnabled, "Configure in Security > MFA tab"));
        SettingsLayout.Children.Add(FeatureRow("Single Sign-On (SSO):", ssoEnabled, "Configure in Security > SSO tab"));
        SettingsLayout.Children.Add(FeatureRow("Email Password Recovery:", _emailService.IsConfigured, "Configure SMTP in appsettings.local.json"));

        SettingsLayout.Children.Add(new BoxView { HeightRequest = 1, BackgroundColor = Color.FromArgb("#E5E5E5"), Margin = new Thickness(0, 8) });

        // ??? Data Retention ????????????????????????????????????
        SettingsLayout.Children.Add(new Label { Text = "Data Retention", FontAttributes = FontAttributes.Bold, FontSize = 18 });
        SettingsLayout.Children.Add(new Label
        {
            Text = "Audit log entries are retained for 2 years and can be queried via Security > Audit Log.\nSession records are retained indefinitely for compliance purposes.",
            FontSize = 12,
            TextColor = Color.FromArgb("#666")
        });
    }

    private static View InfoRow(string label, string value)
    {
        return new HorizontalStackLayout
        {
            Spacing = 8,
            Children =
            {
                new Label { Text = label, FontSize = 13, FontAttributes = FontAttributes.Bold, WidthRequest = 120 },
                new Label { Text = value, FontSize = 13 }
            }
        };
    }

    private static View FeatureRow(string label, bool isEnabled, string hint)
    {
        return new HorizontalStackLayout
        {
            Spacing = 8,
            Margin = new Thickness(0, 2),
            Children =
            {
                new Label
                {
                    Text = isEnabled ? "ON" : "OFF",
                    FontSize = 11,
                    FontAttributes = FontAttributes.Bold,
                    TextColor = isEnabled ? Color.FromArgb("#2E7D32") : Color.FromArgb("#999"),
                    BackgroundColor = isEnabled ? Color.FromArgb("#E8F5E9") : Color.FromArgb("#F5F5F5"),
                    Padding = new Thickness(6, 2),
                    VerticalOptions = LayoutOptions.Center
                },
                new Label { Text = label, FontSize = 13, VerticalOptions = LayoutOptions.Center },
                new Label { Text = $"({hint})", FontSize = 11, TextColor = Color.FromArgb("#999"), VerticalOptions = LayoutOptions.Center }
            }
        };
    }
}
