﻿using Inventory.MAUI.Pages;

namespace Inventory.MAUI
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
            Routing.RegisterRoute(nameof(InventoryRecordDetailPage), typeof(InventoryRecordDetailPage));
            Routing.RegisterRoute(nameof(InventoryItemEditPage), typeof(InventoryItemEditPage));
        }
    }
}
